<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateKreasi2goToCategoryTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('kreasi2go_to_category', function (Blueprint $table) {
            $table->integer('kreasi2go_id')->unsigned();
            $table->integer('category_id')->unsigned();

            $table->foreign('kreasi2go_id')
                ->references('id')
                ->on('kreasi2go')
                ->onDelete('cascade');

            $table->foreign('category_id')
                ->references('id')
                ->on('category')
                ->onDelete('cascade');

            $table->primary(['kreasi2go_id', 'category_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('kreasi2go_to_category');
    }
}
