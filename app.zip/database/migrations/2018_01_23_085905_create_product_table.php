<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateProductTable extends Migration {

	public function up()
	{
		Schema::create('product', function(Blueprint $table) {
			$table->increments('id');
			$table->string('model', 191);
			$table->string('name', 191);
			$table->text('desc');
			$table->string('slug', 191);
			$table->integer('category_id')->unsigned()->default('0');
			$table->text('related')->nullable();
			$table->decimal('price', 15,4)->default('0.0000');
			$table->integer('qty')->default('1');
			$table->integer('status')->default('1');
			$table->decimal('weight', 15,8)->nullable()->default('0.00000000');
			$table->integer('weight_class_id')->unsigned();
			$table->string('length', 15,8)->default('0.00000000');
			$table->decimal('width', 15,8)->default('0.00000000');
			$table->decimal('height', 15,8)->default('0.00000000');
			$table->integer('length_class_id')->unsigned();
			$table->integer('substract')->default('1');
			$table->integer('minimum')->default('1');
			$table->integer('sort_order')->default('0');
			$table->integer('viewed');
			$table->integer('stock_status_id')->unsigned()->default('1');
			$table->integer('shipping')->default('1');
			$table->integer('point')->default('0');
			$table->timestamps();
			$table->softDeletes();
		});
	}

	public function down()
	{
		Schema::drop('product');
	}
}