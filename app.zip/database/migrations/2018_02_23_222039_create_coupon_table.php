<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCouponTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('coupon', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name', 191);
            $table->string('code', 191);
            $table->string('type', 191);
            $table->decimal('discount', 15,4)->default('0.0000');
            $table->decimal('max_discount', 15,4)->default('0.0000');
            $table->integer('free_shipping')->default(0);
            $table->decimal('min_order', 15,4)->default('0.0000');
            $table->dateTime('start_date')->nullable();
            $table->dateTime('end_date')->nullable();
            $table->integer('uses_total')->default(1);
            $table->integer('uses_customer')->default(1);
            $table->integer('status')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('coupon');
    }
}
