<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateAdminTable extends Migration {

	public function up()
	{
		Schema::create('admin', function(Blueprint $table) {
			$table->increments('id');
			$table->string('name', 191);
			$table->string('username', 191)->nullable();
			$table->string('email', 191);
			$table->string('password', 191);
			$table->string('remember_token', 100)->nullable();
			$table->timestamps();
			$table->softDeletes();
			$table->string('ip', 191)->nullable();
		});
	}

	public function down()
	{
		Schema::drop('admin');
	}
}