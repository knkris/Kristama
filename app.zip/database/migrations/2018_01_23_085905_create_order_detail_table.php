<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateOrderDetailTable extends Migration {

	public function up()
	{
		Schema::create('order_detail', function(Blueprint $table) {
			$table->increments('id');
			$table->integer('order_id')->unsigned();
			$table->integer('product_id')->unsigned();
			$table->integer('product_option_id')->unsigned();
			$table->integer('qty');
			$table->decimal('price', 15,4)->default('0.0000');
			$table->string('shipping_courier', 191);
			$table->string('courier_service', 191);
			$table->string('shipping_province', 191);
			$table->string('shipping_city', 191);
			$table->string('shipping_postal_code', 191);
			$table->text('note')->nullable();
			$table->timestamps();
			$table->softDeletes();
		});
	}

	public function down()
	{
		Schema::drop('order_detail');
	}
}