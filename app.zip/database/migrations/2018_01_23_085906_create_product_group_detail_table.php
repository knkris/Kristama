<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateProductGroupDetailTable extends Migration {

	public function up()
	{
		Schema::create('product_group_detail', function(Blueprint $table) {
			$table->increments('id');
			$table->integer('product_group_id')->unsigned();
			$table->integer('product_id')->unsigned();
			$table->decimal('discount', 15,4)->nullable();
			$table->integer('discount_type_id')->unsigned();
			$table->timestamps();
			$table->softDeletes();
		});
	}

	public function down()
	{
		Schema::drop('product_group_detail');
	}
}