<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateProductGroupTable extends Migration {

	public function up()
	{
		Schema::create('product_group', function(Blueprint $table) {
			$table->increments('id');
			$table->string('name', 191);
			$table->text('desc')->nullable();
			$table->integer('timed_discount')->default('0');
			$table->datetime('start')->nullable();
			$table->datetime('end')->nullable();
			$table->integer('group_discount')->default('0');
			$table->decimal('discount', 15,4)->nullable();
			$table->integer('discount_type_id')->unsigned()->default('1');
			$table->timestamps();
			$table->softDeletes();
		});
	}

	public function down()
	{
		Schema::drop('product_group');
	}
}