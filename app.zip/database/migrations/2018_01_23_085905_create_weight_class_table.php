<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateWeightClassTable extends Migration {

	public function up()
	{
		Schema::create('weight_class', function(Blueprint $table) {
			$table->increments('id');
			$table->decimal('value', 15,8)->default('0.00000000');
			$table->string('title', 191);
			$table->string('unit', 191);
			$table->timestamps();
		});
	}

	public function down()
	{
		Schema::drop('weight_class');
	}
}