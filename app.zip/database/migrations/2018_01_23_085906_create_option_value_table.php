<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateOptionValueTable extends Migration {

	public function up()
	{
		Schema::create('option_value', function(Blueprint $table) {
			$table->increments('id');
			$table->timestamps();
			$table->integer('option_id')->unsigned();
			$table->string('name', 191);
			$table->integer('sort_order')->default('0');
		});
	}

	public function down()
	{
		Schema::drop('option_value');
	}
}