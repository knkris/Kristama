<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Eloquent\Model;

class CreateForeignKeys extends Migration {

	public function up()
	{
		Schema::table('product', function(Blueprint $table) {
			$table->foreign('category_id')->references('id')->on('category')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('product', function(Blueprint $table) {
			$table->foreign('weight_class_id')->references('id')->on('weight_class')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('product', function(Blueprint $table) {
			$table->foreign('length_class_id')->references('id')->on('length_class')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('product', function(Blueprint $table) {
			$table->foreign('stock_status_id')->references('id')->on('stock_status')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('category', function(Blueprint $table) {
			$table->foreign('parent_id')->references('id')->on('category')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('product_image', function(Blueprint $table) {
			$table->foreign('product_id')->references('id')->on('product')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('product_option', function(Blueprint $table) {
			$table->foreign('product_id')->references('id')->on('product')
						->onDelete('restrict')
						->onUpdate('restrict');
		});
		Schema::table('product_option', function(Blueprint $table) {
			$table->foreign('option_id')->references('id')->on('option')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('product_option', function(Blueprint $table) {
			$table->foreign('option_value_id')->references('id')->on('option_value')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('cart', function(Blueprint $table) {
			$table->foreign('product_id')->references('id')->on('product')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('order', function(Blueprint $table) {
			$table->foreign('customer_group_id')->references('id')->on('customer_group')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('order', function(Blueprint $table) {
			$table->foreign('order_status_id')->references('id')->on('order_status')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('order_detail', function(Blueprint $table) {
			$table->foreign('order_id')->references('id')->on('order')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('order_detail', function(Blueprint $table) {
			$table->foreign('product_id')->references('id')->on('product')
						->onDelete('restrict')
						->onUpdate('restrict');
		});
		Schema::table('order_detail', function(Blueprint $table) {
			$table->foreign('product_option_id')->references('id')->on('product_option')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('address', function(Blueprint $table) {
			$table->foreign('user_id')->references('id')->on('users')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('address', function(Blueprint $table) {
			$table->foreign('city_id')->references('id')->on('city')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('users', function(Blueprint $table) {
			$table->foreign('customer_group_id')->references('id')->on('customer_group')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('wishlist', function(Blueprint $table) {
			$table->foreign('user_id')->references('id')->on('users')
						->onDelete('restrict')
						->onUpdate('restrict');
		});
		Schema::table('wishlist', function(Blueprint $table) {
			$table->foreign('product_id')->references('id')->on('product')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('product_group', function(Blueprint $table) {
			$table->foreign('discount_type_id')->references('id')->on('discount_type')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('product_group_detail', function(Blueprint $table) {
			$table->foreign('product_group_id')->references('id')->on('product_group')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('product_group_detail', function(Blueprint $table) {
			$table->foreign('product_id')->references('id')->on('product')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('product_group_detail', function(Blueprint $table) {
			$table->foreign('discount_type_id')->references('id')->on('discount_type')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('product_review', function(Blueprint $table) {
			$table->foreign('product_id')->references('id')->on('product')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('product_review', function(Blueprint $table) {
			$table->foreign('user_id')->references('id')->on('users')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('product_review', function(Blueprint $table) {
			$table->foreign('parent_id')->references('id')->on('product_review')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('product_discussion', function(Blueprint $table) {
			$table->foreign('product_id')->references('id')->on('product')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('product_discussion', function(Blueprint $table) {
			$table->foreign('user_id')->references('id')->on('users')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('product_discussion', function(Blueprint $table) {
			$table->foreign('parent_id')->references('id')->on('product_discussion')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('view_history', function(Blueprint $table) {
			$table->foreign('product_id')->references('id')->on('product')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('view_history', function(Blueprint $table) {
			$table->foreign('user_id')->references('id')->on('users')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
		Schema::table('option_value', function(Blueprint $table) {
			$table->foreign('option_id')->references('id')->on('option')
						->onDelete('cascade')
						->onUpdate('restrict');
		});
	}

	public function down()
	{
		Schema::table('product', function(Blueprint $table) {
			$table->dropForeign('product_category_id_foreign');
		});
		Schema::table('product', function(Blueprint $table) {
			$table->dropForeign('product_weight_class_id_foreign');
		});
		Schema::table('product', function(Blueprint $table) {
			$table->dropForeign('product_length_class_id_foreign');
		});
		Schema::table('product', function(Blueprint $table) {
			$table->dropForeign('product_stock_status_id_foreign');
		});
		Schema::table('category', function(Blueprint $table) {
			$table->dropForeign('category_parent_id_foreign');
		});
		Schema::table('product_image', function(Blueprint $table) {
			$table->dropForeign('product_image_product_id_foreign');
		});
		Schema::table('product_option', function(Blueprint $table) {
			$table->dropForeign('product_option_product_id_foreign');
		});
		Schema::table('product_option', function(Blueprint $table) {
			$table->dropForeign('product_option_option_id_foreign');
		});
		Schema::table('product_option', function(Blueprint $table) {
			$table->dropForeign('product_option_option_value_id_foreign');
		});
		Schema::table('cart', function(Blueprint $table) {
			$table->dropForeign('cart_product_id_foreign');
		});
		Schema::table('order', function(Blueprint $table) {
			$table->dropForeign('order_customer_group_id_foreign');
		});
		Schema::table('order', function(Blueprint $table) {
			$table->dropForeign('order_order_status_id_foreign');
		});
		Schema::table('order_detail', function(Blueprint $table) {
			$table->dropForeign('order_detail_order_id_foreign');
		});
		Schema::table('order_detail', function(Blueprint $table) {
			$table->dropForeign('order_detail_product_id_foreign');
		});
		Schema::table('order_detail', function(Blueprint $table) {
			$table->dropForeign('order_detail_product_option_id_foreign');
		});
		Schema::table('address', function(Blueprint $table) {
			$table->dropForeign('address_user_id_foreign');
		});
		Schema::table('address', function(Blueprint $table) {
			$table->dropForeign('address_city_id_foreign');
		});
		Schema::table('users', function(Blueprint $table) {
			$table->dropForeign('users_customer_group_id_foreign');
		});
		Schema::table('wishlist', function(Blueprint $table) {
			$table->dropForeign('wishlist_user_id_foreign');
		});
		Schema::table('wishlist', function(Blueprint $table) {
			$table->dropForeign('wishlist_product_id_foreign');
		});
		Schema::table('product_group', function(Blueprint $table) {
			$table->dropForeign('product_group_discount_type_id_foreign');
		});
		Schema::table('product_group_detail', function(Blueprint $table) {
			$table->dropForeign('product_group_detail_product_group_id_foreign');
		});
		Schema::table('product_group_detail', function(Blueprint $table) {
			$table->dropForeign('product_group_detail_product_id_foreign');
		});
		Schema::table('product_group_detail', function(Blueprint $table) {
			$table->dropForeign('product_group_detail_discount_type_id_foreign');
		});
		Schema::table('product_review', function(Blueprint $table) {
			$table->dropForeign('product_review_product_id_foreign');
		});
		Schema::table('product_review', function(Blueprint $table) {
			$table->dropForeign('product_review_user_id_foreign');
		});
		Schema::table('product_review', function(Blueprint $table) {
			$table->dropForeign('product_review_parent_id_foreign');
		});
		Schema::table('product_discussion', function(Blueprint $table) {
			$table->dropForeign('product_discussion_product_id_foreign');
		});
		Schema::table('product_discussion', function(Blueprint $table) {
			$table->dropForeign('product_discussion_user_id_foreign');
		});
		Schema::table('product_discussion', function(Blueprint $table) {
			$table->dropForeign('product_discussion_parent_id_foreign');
		});
		Schema::table('view_history', function(Blueprint $table) {
			$table->dropForeign('view_history_product_id_foreign');
		});
		Schema::table('view_history', function(Blueprint $table) {
			$table->dropForeign('view_history_user_id_foreign');
		});
		Schema::table('option_value', function(Blueprint $table) {
			$table->dropForeign('option_value_option_id_foreign');
		});
	}
}