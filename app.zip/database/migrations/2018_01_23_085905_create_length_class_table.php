<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateLengthClassTable extends Migration {

	public function up()
	{
		Schema::create('length_class', function(Blueprint $table) {
			$table->increments('id');
			$table->decimal('value', 15,8)->default('0.00000000');
			$table->string('title', 191);
			$table->string('unit', 191);
			$table->timestamps();
		});
	}

	public function down()
	{
		Schema::drop('length_class');
	}
}