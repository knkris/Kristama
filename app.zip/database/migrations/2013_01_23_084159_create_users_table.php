<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateUsersTable extends Migration {

	public function up()
	{
		Schema::create('users', function(Blueprint $table) {
			$table->increments('id');
			$table->integer('customer_group_id')->unsigned()->default('1');
			$table->string('name', 191);
			$table->string('email', 191)->unique();
			$table->string('password', 191)->nullable();
			$table->rememberToken();
			$table->string('telephone', 191)->nullable();
			$table->string('fax', 191)->nullable();
			$table->integer('newsletter')->default('0');
			$table->string('ip', 191)->nullable();
			$table->integer('status')->nullable();
			$table->integer('safe')->nullable();
			$table->text('token')->nullable();
			$table->string('code', 191)->nullable();
			$table->timestamps();
			$table->softDeletes();
		});
	}

	public function down()
	{
		Schema::drop('users');
	}
}