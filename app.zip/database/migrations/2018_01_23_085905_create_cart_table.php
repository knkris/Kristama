<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateCartTable extends Migration {

	public function up()
	{
		Schema::create('cart', function(Blueprint $table) {
			$table->increments('id');
			$table->integer('user_id')->unsigned();
			$table->integer('product_id')->unsigned();
			$table->integer('product_option_id')->nullable()->default('0');
			$table->integer('qty');
			$table->string('shipping_courier', 191)->nullable();
			$table->string('courier_service', 191)->nullable();
			$table->integer('address_id')->nullable();
			$table->text('note')->nullable();
			$table->timestamps();
		});
	}

	public function down()
	{
		Schema::drop('cart');
	}
}