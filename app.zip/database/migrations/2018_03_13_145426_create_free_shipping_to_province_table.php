<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFreeShippingToProvinceTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('free_shipping_to_province', function (Blueprint $table) {
            $table->integer('free_shipping_id')->unsigned();
            $table->integer('province_id')->unsigned();

            $table->foreign('free_shipping_id')
                ->references('id')
                ->on('free_shipping')
                ->onDelete('cascade');

            $table->foreign('province_id')
                ->references('id')
                ->on('province')
                ->onDelete('cascade');

            $table->primary(['free_shipping_id', 'province_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('free_shipping_to_province');
    }
}
