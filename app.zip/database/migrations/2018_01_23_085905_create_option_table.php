<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateOptionTable extends Migration {

	public function up()
	{
		Schema::create('option', function(Blueprint $table) {
			$table->increments('id');
			$table->string('type', 191);
			$table->string('name', 191);
			$table->integer('sort_order')->default('0');
			$table->timestamps();
		});
	}

	public function down()
	{
		Schema::drop('option');
	}
}