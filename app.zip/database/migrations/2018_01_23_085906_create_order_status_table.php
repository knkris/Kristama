<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateOrderStatusTable extends Migration {

	public function up()
	{
		Schema::create('order_status', function(Blueprint $table) {
			$table->increments('id');
			$table->string('name_en', 191);
			$table->string('name_id', 191);
			$table->timestamps();
		});
	}

	public function down()
	{
		Schema::drop('order_status');
	}
}