<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFreeShippingTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('free_shipping', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('shipping_method_id')->unsigned();
            $table->string('name', 191);
            $table->decimal('subtotal', 15,4)->nullable();
            $table->integer('status')->default(0);
            $table->timestamps();
        });

        Schema::table('free_shipping', function(Blueprint $table) {
            $table->foreign('shipping_method_id')->references('id')->on('shipping_method')
                        ->onDelete('cascade')
                        ->onUpdate('restrict');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('free_shipping');
    }
}
