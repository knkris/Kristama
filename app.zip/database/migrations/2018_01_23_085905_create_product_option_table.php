<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateProductOptionTable extends Migration {

	public function up()
	{
		Schema::create('product_option', function(Blueprint $table) {
			$table->increments('id');
			$table->integer('product_id')->unsigned();
			$table->integer('option_id')->unsigned();
			$table->integer('option_value_id')->unsigned()->nullable();
			$table->integer('required')->default('0');
			$table->integer('qty')->default('0');
			$table->integer('substract')->default('1');
			$table->decimal('price', 15,4)->default('0.0000');
			$table->integer('point')->default('0');
			$table->timestamps();
			$table->softDeletes();
		});
	}

	public function down()
	{
		Schema::drop('product_option');
	}
}