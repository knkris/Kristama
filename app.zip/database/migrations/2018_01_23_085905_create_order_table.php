<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateOrderTable extends Migration {

	public function up()
	{
		Schema::create('order', function(Blueprint $table) {
			$table->increments('id');
			$table->string('invoice', 191);
			$table->integer('user_id')->unsigned();
			$table->integer('customer_group_id')->unsigned();
			$table->string('name', 191);
			$table->string('email', 191);
			$table->string('telephone', 191);
			$table->string('fax', 191);
			$table->text('payment_address')->nullable();
			$table->string('payment_province', 191)->nullable();
			$table->string('payment_city', 191)->nullable();
			$table->string('payment_postal_code', 191)->nullable();
			$table->string('payment_method', 191);
			$table->integer('order_status_id')->unsigned();
			$table->string('shipping_city', 191)->nullable();
			$table->string('coupon', 191)->nullable();
			$table->decimal('total', 15,4)->default('0.0000');
			$table->string('ip', 191)->nullable();
			$table->string('forwarded_ip', 191)->nullable();
			$table->string('user_agent', 191)->nullable();
			$table->string('accept_language', 191)->nullable();
			$table->timestamps();
			$table->softDeletes();
		});
	}

	public function down()
	{
		Schema::drop('order');
	}
}