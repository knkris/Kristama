<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddPriceFilterToProductTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('product', function($table) {
            $table->decimal('price_filter', 15,4)->nullable()->after('price');
        });

        App\Models\Product::withTrashed()
            ->whereNull('price_filter')
            ->update([
                "price_filter" => DB::raw("`price`"),
            ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('product', function($table) {
            $table->dropColumn('price_filter');
        });
    }
}
