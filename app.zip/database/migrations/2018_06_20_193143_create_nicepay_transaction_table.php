<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateNicepayTransactionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('nicepay_transaction', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('order_id')->unsigned();
            $table->string('txid');
            $table->text('callbackurl');
            $table->text('description');
            $table->string('payment_date');
            $table->string('payment_time');
            $table->string('va_number');
            $table->string('result_code');
            $table->string('result_message');
            $table->string('reference');
            $table->string('payment_method');
            $table->integer('status')->default(0);
            $table->timestamps();

            $table->foreign('order_id')
                ->references('id')
                ->on('order')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('nicepay_transaction');
    }
}
