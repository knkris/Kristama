<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateCityTable extends Migration {

	public function up()
	{
		Schema::create('city', function(Blueprint $table) {
			$table->increments('id');
			$table->integer('province_id');
			$table->string('province', 191);
			$table->string('type', 191);
			$table->string('name', 191);
			$table->string('postal_code', 191);
			$table->timestamps();
		});
	}

	public function down()
	{
		Schema::drop('city');
	}
}