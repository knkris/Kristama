<?php

use Illuminate\Database\Seeder;
use App\Models\LengthClass;

class LengthClassTableSeeder extends Seeder {

	public function run()
	{
		//DB::table('length_class')->delete();

		// Centimeter
		LengthClass::create(array(
				'value' => 1.00000000,
				'title' => 'Centimeter',
				'unit' => 'cm'
			));

		// Millimeter
		LengthClass::create(array(
				'value' => 10.00000000,
				'title' => 'Millimeter',
				'unit' => 'mm'
			));

		// Inch
		LengthClass::create(array(
				'value' => 0.39370000,
				'title' => 'Inch',
				'unit' => 'in'
			));

		// Meter
		LengthClass::create(array(
				'value' => 0.01000000,
				'title' => 'Meter',
				'unit' => 'm'
			));
	}
}