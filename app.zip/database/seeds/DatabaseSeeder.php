<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class DatabaseSeeder extends Seeder {

	public function run()
	{
		Model::unguard();

		// $this->call('CategoryTableSeeder');
		// $this->command->info('Category table seeded!');

		// $this->call('WeightClassTableSeeder');
		// $this->command->info('WeightClass table seeded!');

		// $this->call('LengthClassTableSeeder');
		// $this->command->info('LengthClass table seeded!');

		// $this->call('StockStatusTableSeeder');
		// $this->command->info('StockStatus table seeded!');

		// $this->call('OptionTableSeeder');
		// $this->command->info('Option table seeded!');

		// $this->call('CustomerGroupTableSeeder');
		// $this->command->info('CustomerGroup table seeded!');

		// $this->call('DiscountTypeTableSeeder');
		// $this->command->info('DiscountType table seeded!');

		// $this->call('OrderStatusTableSeeder');
		// $this->command->info('OrderStatus table seeded!');

		//Seed the countries
		$this->call('CountriesSeeder');
		$this->command->info('Seeded the countries!'); 
	}
}