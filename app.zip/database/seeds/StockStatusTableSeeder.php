<?php

use Illuminate\Database\Seeder;
use App\Models\StockStatus;

class StockStatusTableSeeder extends Seeder {

	public function run()
	{
		//DB::table('stock_status')->delete();

		// In Stock
		StockStatus::create(array(
				'name_en' => 'In Stock',
				'name_id' => 'Stock Tersedia'
			));

		// Pre-Order
		StockStatus::create(array(
				'name_en' => 'Pre-Order',
				'name_id' => 'Pre-Order'
			));

		// Out of Stock
		StockStatus::create(array(
				'name_en' => 'Out of Stock',
				'name_id' => 'Stock Habis'
			));

		// 2-3 Days
		StockStatus::create(array(
				'name_en' => '2-3 Days',
				'name_id' => '2-3 Hari'
			));
	}
}