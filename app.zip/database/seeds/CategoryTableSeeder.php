<?php

use Illuminate\Database\Seeder;
use App\Models\Category;

class CategoryTableSeeder extends Seeder {

	public function run()
	{
		//DB::table('category')->delete();

		// Elektronik
		Category::create(array(
				'name' => 'Elektronik',
				'slug' => 'elektronik',
				'parent_id' => null
			));

		// Makanan & Minuman
		Category::create(array(
				'name' => 'Makanan & Minuman',
				'slug' => 'makanan-minuman',
				'parent_id' => null
			));
	}
}