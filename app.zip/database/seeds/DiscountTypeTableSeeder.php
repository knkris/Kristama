<?php

use Illuminate\Database\Seeder;
use App\Models\DiscountType;

class DiscountTypeTableSeeder extends Seeder {

	public function run()
	{
		//DB::table('discount_type')->delete();

		// percentage
		DiscountType::create(array(
				'name' => 'percentage',
				'desc' => 'percentage discount'
			));

		// value
		DiscountType::create(array(
				'name' => 'value',
				'desc' => 'price value discount'
			));

		// fix price
		DiscountType::create(array(
				'name' => 'fix price',
				'desc' => 'fix price discount'
			));
	}
}