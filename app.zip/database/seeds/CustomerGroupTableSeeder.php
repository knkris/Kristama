<?php

use Illuminate\Database\Seeder;
use App\Models\CustomerGroup;

class CustomerGroupTableSeeder extends Seeder {

	public function run()
	{
		//DB::table('customer_group')->delete();

		// Default
		CustomerGroup::create(array(
				'name' => 'Default',
				'desc' => 'Default'
			));
	}
}