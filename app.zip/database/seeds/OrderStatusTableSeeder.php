<?php

use Illuminate\Database\Seeder;
use App\Models\OrderStatus;

class OrderStatusTableSeeder extends Seeder {

	public function run()
	{
		//DB::table('order_status')->delete();

		// pending
		OrderStatus::create(array(
				'name_en' => 'pending',
				'name_id' => 'menunggu pembayaran'
			));

		// processing
		OrderStatus::create(array(
				'name_en' => 'processing',
				'name_id' => 'sedang diproses'
			));

		// shipped
		OrderStatus::create(array(
				'name_en' => 'shipped',
				'name_id' => 'telah dikirim'
			));

		// complete
		OrderStatus::create(array(
				'name_en' => 'complete',
				'name_id' => 'selesai'
			));

		// denied
		OrderStatus::create(array(
				'name_en' => 'denied',
				'name_id' => 'ditolak'
			));

		// canceled
		OrderStatus::create(array(
				'name_en' => 'canceled',
				'name_id' => 'dibatalkan'
			));

		// canceled_reversal
		OrderStatus::create(array(
				'name_en' => 'canceled_reversal',
				'name_id' => 'dibatalkan oleh pembeli'
			));

		// failed
		OrderStatus::create(array(
				'name_en' => 'failed',
				'name_id' => 'gagal'
			));

		// expired
		OrderStatus::create(array(
				'name_en' => 'expired',
				'name_id' => 'kadaluarsa'
			));

		// processed
		OrderStatus::create(array(
				'name_en' => 'processed',
				'name_id' => 'telah diproses'
			));
	}
}