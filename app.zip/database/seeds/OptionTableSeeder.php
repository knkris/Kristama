<?php

use Illuminate\Database\Seeder;
use App\Models\Option;

class OptionTableSeeder extends Seeder {

	public function run()
	{
		//DB::table('option')->delete();

		// Size
		Option::create(array(
				'type' => 'select',
				'name' => 'Size',
				'sort_order' => 1
			));

		// Color
		Option::create(array(
				'type' => 'select',
				'name' => 'Color',
				'sort_order' => 2
			));
	}
}