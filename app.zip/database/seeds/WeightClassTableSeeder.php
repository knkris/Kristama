<?php

use Illuminate\Database\Seeder;
use App\Models\WeightClass;

class WeightClassTableSeeder extends Seeder {

	public function run()
	{
		//DB::table('weight_class')->delete();

		// kilogram
		WeightClass::create(array(
				'value' => 1.00000000,
				'title' => 'Kilogram',
				'unit' => 'kg'
			));

		// gram
		WeightClass::create(array(
				'value' => 1000.00000000,
				'title' => 'Gram',
				'unit' => 'g'
			));

		// pound
		WeightClass::create(array(
				'value' => 2.20460000,
				'title' => 'Pound',
				'unit' => 'lb'
			));

		// ounce
		WeightClass::create(array(
				'value' => 35.27400000,
				'title' => 'Ounce',
				'unit' => 'oz'
			));
	}
}