@extends('layouts.blog')

@section('title')
	{{ $blog->title }}
@endsection

@section('header')
<style type="text/css">
	.upvote-btn, .downvote-btn {
		font-size:40px;
		color: grey;
	}
	.upvote-btn.active {
		color:#76EE00;
	}
	.upvote-btn.reply.active {
		color:#b62126;
	}
	.downvote-btn.active {
		color:#76EE00;
	}
	.downvote-btn.reply.active {
		color:#b62126;
	}
	/* BLOG CATEGORY*/
#header.home .mega-dropdown-menu li:after {
    position: absolute;
    content: "";
    right: 0px;
    top: 13px;
    background-image: url(https://i.postimg.cc/0jhhmk5y/separetor.png);
    width: 2px;
    height: 20px;
    background-repeat: no-repeat;
    background-size: contain;
}
#header.home .mega-dropdown-menu li, #header.small-header .mega-dropdown-menu li>ul li a {
    align-items: center;
    width: 16.5%;
    float: left;
    color: #666;
    font-size: 13px;
    font-weight: 600;
    text-transform: capitalize;
    cursor: pointer;
    padding: 12px 25px;
    /*transition: 0.4s all;*/
	opacity:0;
	transition: color 1s ease-in, background-color 0.1s ease-in, opacity 1s ease-in;
    position: relative;
    border-radius: 0px 25px 25px 25px;
    display: flex;
}
#header.home .mega-dropdown-menu li:hover {
    background-color: #565656;
	transition: 0.1s all;
}
#header.small-header .mega-dropdown-menu li:after {
    position: absolute;
    content: "";
    right: 0px;
    top: 13px;
    background-image: url(https://i.postimg.cc/0jhhmk5y/separetor.png);
    width: 2px;
    height: 20px;
    background-repeat: no-repeat;
    background-size: contain;
}
#header.small-header .mega-dropdown-menu li, #header.small-header .mega-dropdown-menu li>ul li a {
    align-items: center;
    width: 16.5%;
    float: left;
    color: #fff;
    font-size: 13px;
    font-weight: 600;
    text-transform: capitalize;
    cursor: pointer;
    padding: 12px 25px;
	opacity:0;
	transition: color 1s ease-in, background-color 0.1s ease-in, opacity 1s ease-in;
    position: relative;
    border-radius: 0 0 0 25px;
    display: flex;
}
#header .mega-dropdown-menu {
    width: 0%;
	display:block;
	opacity:0;
    height: 90px;
    margin-top: 15px;
    background: #666666;
    border-bottom-left-radius: 20px;
    border-bottom-right-radius: 20px;
}
#header .navbar-default .navbar-nav li a.blog-menu-new {
    color: #000;
    text-transform: capitalize;
    font-size: 13px;
    font-family: 'gadugi';
    letter-spacing: 1px;
    line-height: 0px;
    padding: 0px 15px;
}
.open>.dropdown-menu {
			display: block;
			width: 100%!important;
			opacity:1!important;
		}
		.open>.dropdown-menu li{
			color:#fff!important;
			opacity:1!important;
		}
		.dropdown-menu{
			transition: width 2s;
		}
</style>
@endsection

@section('content')
<?php
	function get_words($sentence, $count = 10) {
      preg_match("/(?:\w+(?:\W+|$)){0,$count}/", $sentence, $matches);
      return $matches[0];
    }
?>
	<!---- Banner Start ---->
<section id="banner" class="margin-bottom">
	<ul class="bxslider">
		<li style="background:url({{ $blog->cover ?: $blog->image }}) 50% 50% no-repeat; background-size:cover;   box-shadow: inset 1000px 0px 1000px -500px #fff;">
			<div class="text-details">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 col-xs-12 col-sm-12">
							<div class="text">
								<p>
									<span class="red col-lg-6 flush col-xs-6 col-sm6">
										<i class="fa fa-star" aria-hidden="true" style="padding-right:15px;"></i>
										<i class="fa fa-bolt" aria-hidden="true"></i>
									</span>
									<span class=" col-lg-6 flush col-xs-6 col-sm6" style="color: #000000;">
										<img src="{{ asset('blog-asset/images/eye.png') }}" alt=""/> {{ $blog->viewed }}
									</span>
								</p>
								<p>
								{{ $blog->title }}
								</p>
								<p>
									<h3>
										<span class="span-banner-text">
											{{ $blog->BlogLike()->count() }} Likes
										</span>
										<span class="span-banner-text">
											{{ $blog->BlogComment()->count() }} Comments
										</span>
										<span class="span-banner-text">
											{{ $blog->shared }} Shares
										</span>
									</h3>
								</p>
								<p class="normal">By : {{ $blog->Admin->name ?? 'Admin' }}	&nbsp;&nbsp;&nbsp;&nbsp;{{ Carbon\Carbon::parse($blog->created_at)->diffForHumans() }}</p>
							</div>
						</div>	
					</div>
				</div>		
			</div>	
			
		</li>
		
	</ul>	
</section>
<!---- Banner End ---->
<!---- recipe Start ---->
<div id="recipe" class="container">
	<div class="col-lg-8 col-sm-12 col-xs-12 text-left">
		<span class="col-lg-12 col-xs-6 col-sm6">
			<i class="fa fa-star red " style="padding-right:20px; font-size:22px;"></i>
			<i class="fa fa-bolt red " style="padding-right:20px; font-size:22px;"></i>
			<i class="fa fa-eye" style="font-size:22px;"> {{ $blog->viewed }}</i>
		</span>
		<div class="col-lg-8"><h2 class="blog-title"><!-- <span class="subtitle">Resep</span> -->{{ $blog->title }}</h2></div>
		<div class="col-lg-4 flush">
		<h3>
		<span style="float:right; padding-right:15px;">
			{{ $blog->shared }} Shared
		</span>
		<span style="float:right; padding-right:15px;">
			{{ $blog->BlogComment()->count() }} Comments
		</span>
		<span style="float:right; padding-right:15px;">
			{{ $blog->BlogLike()->count() }} Likes
		</span>
		</h3>
		</br>
			<p class="meta-post" style="text-align:right; font-size:13px; padding-right:15px;">By : {{ $blog->Admin->name ?? 'Admin' }}	&nbsp;&nbsp;&nbsp;&nbsp;{{ Carbon\Carbon::parse($blog->created_at)->diffForHumans() }}</p>
			<!-- <p class="meta-post border-bottom">100 Share &nbsp;&nbsp;<a href="https://www.facebook.com/sharer/sharer.php?u={{ url()->current() }}" class="btn-facebook social-button" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i> Facebook</a>&nbsp;&nbsp;<a href="https://twitter.com/intent/tweet?text={{ $blog->title }}&url={{ url()->current() }}" class="btn-twitter social-button" target="_blank"> <i class="fa fa-twitter" aria-hidden="true"></i>Twitter </a>
				@if(Auth::check())
				<a href="#" id="btn-love" class="btn-love pull-right"><i class="fa fa-heart-o" aria-hidden="true"></i> {{ $blog->BlogLike()->count() }}</a>
				@endif 
			</p> -->
		</div>
		
			<div class="blog-content">
			{!! $blog->content !!}
			</div>
	</div>

	<div class="col-lg-4 col-sm-12 col-xs-12 trending-container">
		<h3><span class="red">Trending </span> of the week</h3>
		<ul class="images">
			@foreach($trending as $value)
			<li class="col-lg-12 col-sm-12 col-xs-12">
				<a href="{{ route('blog.detail',$value->slug) }}">
					<img src="{{ $value->image }}" aclass="img-responsive" style="width:100%" lt="" alt="Popular Image"/>
					<span class="blog-category-label">{{ strtoupper($value->category) }}</span>
					<div class="icon">
						@if($value->hot==1)
						<img src="{{ asset('blog-asset/images/fire.png') }}" alt="popular" title="popular" />
						@endif
						@if($value->trending==1)
						<img src="{{ asset('blog-asset/images/light.png') }}" alt="trending" title="trending" />
						@endif
						@if($value->favorite==1)
						<img src="{{ asset('blog-asset/images/star.png') }}" alt="favorite" title="favorite" />
						@endif
					</div>
					<div class="white-overlay">
						<h5>{{ strlen($value->title)>50 ? substr($value->title, 0, 60)."..." : $value->title }}</h5>
						<label>By {{ $value->Admin->name ?? ''}} - {{ \Carbon\Carbon::parse($value->created_at)->diffForHumans() }}</label>
						<?php
						$start = strpos($value->content, '<p>');
						$end = strpos($value->content, '</p>', $start);
						$paragraph = substr($value->content, $start, $end-$start+4);
						$paragraph = html_entity_decode(strip_tags($paragraph));
						?>
						<p>{{ strlen($paragraph)>80 ? get_words($paragraph, 80)."..." : $paragraph }}</p>
						<a href="{{ route('blog.detail',$value->slug) }}">Read More <i class="fa fa-caret-right" aria-hidden="true"></i></a>
					</div>
				</a>
			</li>
			@endforeach
			<li class="col-lg-12 col-sm-12 col-xs-12">
				<h3><span style="color:#b62126;font-family: 'gadugib'; font-size: 21px; text-align: center;">About</span> <img src="{{ asset('images/kreasi-text.png') }}" alt=""></h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
				<a class="btn" style="background-color:grey;color:#fff; font-family: 'gadugib'; font-size: 21px; text-align: center;">Know More</a>
			</li>
			<li class="col-lg-12 col-sm-12 col-xs-12">
				<h3><span style="color:#b62126;font-family: 'gadugib'; font-size: 21px; text-align: center;">Follow Us</span> on</h3>
<div style="display:inline-flex; margin-top: 15px; text-align: center;width: 100%;">
<a href="https://www.facebook.com/sharer/sharer.php?u={{ url()->current() }}" class="socials social-button">
	<i class="fa fa-facebook"></i>
</a>
<a href="https://twitter.com/intent/tweet?text{{ $blog->title }}&amp;url={{ url()->current() }}" class="socials social-button">
	<i class="fa fa-twitter"></i>
</a>
<a href="#" class="socials social-button">
	<i class="fa fa-instagram"></i>
</a>
<a href="#" class="socials social-button">
	<i class="fa fa-youtube-play"></i>
</a> 
<a href="https://plus.google.com/share?url={{ url()->current() }}" class="socials social-button">
	<i class="fa fa-google-plus"></i>
</a>
</div>
			</li>
		</ul>
			
	</div>
</div>
<div class="container share-post">
	<!--<div class="col-lg-12 margin-bottom">
		
	</div>
	<div class="col-lg-12">
		 <div style="float:left">
			<p><span class="total-share">2.0K</span><br>
			<span class="share-text">SHARE</span></p>	
		</div>
		<div class="col-lg-4">
			<a href="#" class="btn-facebook"><i class="fa fa-facebook" aria-hidden="true"></i> Facebook</a>&nbsp;&nbsp;
			<a href="#" class="btn-twitter"> <i class="fa fa-twitter" aria-hidden="true"></i>Twitter </a>
		</div>
	</div> -->
	<div class="col-lg-8">
	
		<h3>Post by:<span style="float:right;">
			<strong>Share with your friends</strong>
		</span>
		</h3>
	<div class="col-lg-8" style="display:inline-flex;">
		<div><img src="{{ asset('blog-asset/images/avatar.png') }}" width="150px" style="border-radius:50%;"> </div>
		 <div style="margin-top: 30px; margin-left: 10px;">
		 <h2 style="font-size:18px;">{{ $blog->Admin->name }}</h2>
		 <span>Sweltering in Singapore.
		 Email: {{ $blog->Admin->email }}
		 Twitter: @jacknwellis</span><br>
		 <!-- <a href="#" class="btn-love"><i class="fa fa-heart" aria-hidden="true"></i> 990</a> -->
	</div>
 </div>
 <div class="col-lg-4" style="padding-right:0px!important;">
 <div style="display:inline-flex; margin-top: 15px; text-align: center; float:right;">
<a href="https://www.facebook.com/sharer/sharer.php?u={{ url()->current() }}" class="socials social-button">
	<i class="fa fa-facebook"></i>
</a>
<a href="https://twitter.com/intent/tweet?text{{ $blog->title }}&amp;url={{ url()->current() }}" class="socials social-button">
	<i class="fa fa-twitter"></i>
</a>
{{-- <a href="#" class="socials social-button">
	<i class="fa fa-instagram"></i>
</a>
<a href="#" class="socials social-button">
	<i class="fa fa-youtube-play"></i>
</a> --}}
<a href="https://plus.google.com/share?url={{ url()->current() }}" class="socials social-button">
	<i class="fa fa-google-plus"></i>
</a>
</div>
</div>
	</div>
	
	<div class="col-lg-8" style="margin-top:60px;">
	<h3><strong>Comments:</strong><span style="float:right; padding-right:15px;">
			{{ $blog->BlogLike()->count() }} Likes
		</span>
		<span style="float:right; padding-right:15px;">
			{{ $blog->BlogComment()->count() }} Comments
		</span>
		<span style="float:right; padding-right:15px;">
			{{ $blog->shared }} Shared
		</span>
		</h3>
		<hr>
	</div>
	
	<div class="comment-container"> 
	<?php
	$last_page=1;
	$items=$blog->BlogComment()->whereParent_id(0)->orderBy('created_at','desc')->paginate(3);
	$last_page=$items->lastPage();
	?>
	@foreach($items as $key => $comment)
	<!-- Case 1 Upvote-->
	<div class="col-lg-8" style="margin-top:60px;">
	<div>
	<div class="col-lg-1" style="margin-top: -14px;">
		<i id="upvote-arrow-{{ $comment->id }}" class="fa fa-caret-up upvote-btn {{ Auth::check() ? $comment->BlogCommentLike()->whereUser_id(Auth::user()->id)->whereUp(1)->count() ? 'active' : '' : '' }}" data-id="{{ $comment->id }}"></i></br>
		<?php 
		$count=$comment->BlogCommentLike()->whereUp(1)->count() ?: '-'.$comment->BlogCommentLike()->whereDown(1)->count();
		if($count==='-0')
		{
			$count=0;
		}
		?>
		<a id="vote-count-{{ $comment->id }}" href="#">{{ $count }}</a></br>
		<i id="downvote-arrow-{{ $comment->id }}" class="fa fa-caret-down downvote-btn {{ Auth::check() ? $comment->BlogCommentLike()->whereUser_id(Auth::user()->id)->whereDown(1)->count() ? 'active' : '' : '' }}" data-id="{{ $comment->id }}"></i>
	</div>
	<div class="col-lg-2" style="text-align: center;"><img src="{{ $comment->User->avatar ?: $comment->User->getPhotoUrlAttribute() }}" width="75px"></div>
	<div class="col-lg-9">
		<span style="font-size:18px;"><strong>{{ $comment->User->name }}</strong></span></br>
		<span>{{ $comment->text }}</span>
	</div>	
	</div>	
	</div>
	
	<?php
	$reply = $comment->getConversation();
	$countreply=count($reply);
	?>
	@foreach($reply as $key2 => $value)
	<div class="col-lg-8" style="margin-top:20px;">
	<div>
	<div class="col-lg-1"></div>
	
	@if($key2==0)
	<div class="col-lg-2 reply-collapse hide-reply" data-commentid="{{ $comment->id }}" style="text-align: center;">
		[ <i class="fa fa-plus" style="font-size:12px;"></i> ]
	</div>
	<div class="col-lg-9 show-comment-reply">
		<span style="color:grey;">See {{ $countreply }} Replies</span>
	</div>
	@else
	<div class="col-lg-2 " style="text-align: center;"></div>
	@endif

	
	
	<div class="col-lg-1 replies1-{{ $comment->id }}" style="display: none;margin-top: -14px;">
		<i id="upvote-arrow-{{ $value->id }}" class="fa fa-caret-up upvote-btn reply {{ Auth::check() ? $value->BlogCommentLike()->whereUser_id(Auth::user()->id)->whereUp(1)->count() ? 'active' : '' : '' }}" data-id="{{ $value->id }}" data-id="{{ $value->id }}"></i></br>
		<?php 
		$countreply=$value->BlogCommentLike()->whereUp(1)->count() ?: '-'.$value->BlogCommentLike()->whereDown(1)->count();
		if($countreply==='-0')
		{
			$countreply=0;
		}
		?>
		<a id="vote-count-{{ $value->id }}" href="#">{{ $countreply }}</a></br>
		<i id="downvote-arrow-{{ $value->id }}" class="fa fa-caret-down downvote-btn reply {{ Auth::check() ? $value->BlogCommentLike()->whereUser_id(Auth::user()->id)->whereDown(1)->count() ? 'active' : '' : '' }}" data-id="{{ $value->id }}" data-id="{{ $value->id }}"></i>
	</div>
	<div class="col-lg-2 replies2-{{ $comment->id }}" style="display: none;text-align: center;"><img src="{{ $value->User->avatar ?: $value->User->getPhotoUrlAttribute() }}" width="75px"></div>
	<div class="col-lg-6 replies3-{{ $comment->id }}" style="display: none;">
		<span style="font-size:18px;"><strong>{{ $value->User->name }}</strong></span></br>
		<span>{{ $value->text }}</span>
	</div>	
	</div>	
	</div>
	@endforeach
	
	@if(Auth::check())
	<div class="col-lg-8" style="margin-top:20px;">
	<div>
	<div class="col-lg-3"></div>
	<div class="col-lg-9">
		<img src="{{ Auth::user()->avatar ?: Auth::user()->getPhotoUrlAttribute() }}" width="75px" style="float:left;">
		<form action="{{ url('post-comment-reply/'.$comment->id) }}" method="post">
			{!! csrf_field() !!}
			<input type="text" class="reply-comment" name="reply" placeholder="Write a reply . . ." style="float:left; height:75px; width: 85%; padding: 28px 20px;margin: 0 0;display: inline-block;border: 1px solid #ccc;border-radius: 0px; box-sizing: border-box;">
		</form>
	</div>
	</div>	
	</div>
	@endif
	@endforeach

	</div>
	
	<!-- end case 3 -->
	<!-- show more comment -->
	@if($last_page>1)
	<div id="show-more-comment">
	<div class="col-lg-8" style="margin-top:20px;">
	<div>
	<div class="col-lg-12">
		<span style="color:grey;" onclick="retrieveComment()">Show More Comments <i class="fa fa-chevron-down" style="font-size:14px;"></i></span>
	</div>	
	</div>	
	</div>
	</div>
	@endif
	
	
	<!-- Leave Comment here -->
	<div class="col-lg-8" style="margin-top:60px;">
	<h3><strong>Leave a comment</strong>
		</h3>
		<hr>
	</div>
	
	@if(Auth::check())
	<div class="col-lg-8" style="margin-top:20px; margin-bottom:60px;">
	<div>
	<div class="col-lg-12">
		<img src="{{ Auth::user()->avatar ?: Auth::user()->getPhotoUrlAttribute() }}" width="75px" style="float:left;">
		<form action="{{ url('post-comment/'.$blog->slug)}}" method="post">
			{!! csrf_field() !!}
			<input type="text" id="reply" name="reply" placeholder="Write a reply . . ." style="float:left; height:75px; width: 89%; padding: 28px 20px;margin: 0 0;display: inline-block;border: 1px solid #ccc;border-radius: 0px; box-sizing: border-box;">
			
		</form>
	</div>
	</div>	
	</div>
	@endif
	
</div>

<section>
			<div class=" text-center back-top">
				<a href="#banner">
					Back To TOP
				</a>
			</div>
			</section>
@endsection

@section('script')
<script>
    // $('.social-button').click(function(e) {
    //     e.preventDefault();
    //     window.open($(this).attr('href'), 'fbShareWindow', 'height=450, width=550, top=' + ($(window).height() / 2 - 275) + ', left=' + ($(window).width() / 2 - 225) + ', toolbar=0, location=0, menubar=0, directories=0, scrollbars=0');
    //     return false;
    // });

    var popupSize = {
	    width: 780,
	    height: 550
	};

	$(document).on('click', '.social-button', function (e) {
	    var verticalPos = Math.floor(($(window).width() - popupSize.width) / 2),
	        horisontalPos = Math.floor(($(window).height() - popupSize.height) / 2);

	    var popup = window.open($(this).prop('href'), 'social',
	        'width=' + popupSize.width + ',height=' + popupSize.height +
	        ',left=' + verticalPos + ',top=' + horisontalPos +
	        ',location=0,menubar=0,toolbar=0,status=0,scrollbars=1,resizable=1');

	    if (popup) {
	        popup.focus();
	        e.preventDefault();
	        $.get( "{{ url('blog/shared/'.$blog->slug) }}", function( data ) {
			  
			});
	    }

	});

	@if(Auth::check())
	$('#btn-love').on('click', function (e) {
		e.preventDefault();
		$.get( "{{ url('blog/like/'.$blog->slug) }}", function( data ) {
		  if(data.status === true) {
		  	$('#btn-love').html('<i class="fa fa-heart" aria-hidden="true"></i> '+ data.count);
		  	toastr.success('You liked this blog!', 'Liked!')  
		  }else{
		  	$('#btn-love').html('<i class="fa fa-heart-o" aria-hidden="true"></i> '+ data.count);
		  	toastr.info('Your action has been undo!', 'Undo Success!')  
		  }
		});
	});
	$(document).on('click', '.upvote-btn', function(e) {
		e.preventDefault();
		var ele=$(this);
		$id=ele.data('id');
		$.get( "{{ url('blog-comment/up-vote') }}/"+$id, function( data ) {
			$('#vote-count-'+$id).html(data.count);
		  if(data.status === true) {
		  	ele.addClass('active');
		  	toastr.success('You upvoted this comment!', 'Upvoted!')
		  	if($('#downvote-arrow-'+$id).hasClass('active')) {
		  		$('#downvote-arrow-'+$id).removeClass('active');
		  	}
	  	  }else{
		  	ele.removeClass('active');
		  	toastr.info('Your action has been undo!', 'Undo Success!')  
		  }
		});
	});
	$(document).on('click', '.downvote-btn', function(e) {
		e.preventDefault();
		var ele=$(this);
		$id=ele.data('id');
		$.get( "{{ url('blog-comment/down-vote') }}/"+$id, function( data ) {
			$('#vote-count-'+$id).html(data.count);
		  if(data.status === true) {
		  	ele.addClass('active');
		  	toastr.success('You downvoted this comment!', 'Upvoted!')
		  	if($('#upvote-arrow-'+$id).hasClass('active')) {
		  		$('#upvote-arrow-'+$id).removeClass('active');
		  	}
		  }else{
			  	ele.removeClass('active');
			  	toastr.info('Your action has been undo!', 'Undo Success!')  
		  }
		});
	});
	@endif
	var plusicon='[ <i class="fa fa-plus" style="font-size:12px;"> ]';
	var minusicon='[ </i><i class="fa fa-minus" style="font-size:12px;"></i> ]';
	$(document).on('click', '.reply-collapse', function(e) {
		var comment_id=$(this).data('commentid');
		if($(this).hasClass('hide-reply')) {
			$(this).addClass('show-reply');
			$(this).removeClass('hide-reply');
			$(this).html(minusicon);
			$(this).next('.show-comment-reply').hide();
			$('.replies1-'+comment_id).show();
			$('.replies2-'+comment_id).show();
			$('.replies3-'+comment_id).show();
			console.log('show');
		}
		else if($(this).hasClass('show-reply')) {
			$(this).addClass('hide-reply');
			$(this).removeClass('show-reply');
			$(this).html(plusicon);
			$(this).next('.show-comment-reply').show();
			$('.replies1-'+comment_id).hide();
			$('.replies2-'+comment_id).hide();
			$('.replies3-'+comment_id).hide();
			console.log('hide');
		}
	});
	$(document).on('click', '.show-comment-reply', function(e) {
		$(this).prev().trigger('click');
	});
	$('#reply').keypress(function (e) {
		 var key = e.which;
		 if(key == 13)  // the enter key code
		  {
		    $(this).closest("form").submit(); 
		  }
		});
	$('.reply-comment').keypress(function (e) {
		 var key = e.which;
		 if(key == 13)  // the enter key code
		  {
		    $(this).closest("form").submit(); 
		  }
		});
	var page=2;
	var lastpage='{{ $last_page }}';
	function retrieveComment() {
		$.get('{{ url('blog/retrieve-comment/'.$blog->slug) }}?page='+page, function(data) {
            $('.comment-container').append(data.html);
            page++;
            if(page>lastpage){
            	$('#show-more-comment').hide();
            }
        })
	}
</script>
<script>
$(window).on("scroll", function() { 
    if($(window).scrollTop() > 50) { 
        $(".small-header").addClass("active"); 
    } else { 
        //remove the background property so it comes transparent again (defined in your css) 
       $(".small-header").removeClass("active"); 
    } 
}); 
</script>
<script>
$(document).ready(function(){
$( ".unhover").hover(function() {
	$cat=$(this).data('category');
	//console.log(".cat-child-"+$cat);
  $(".cat-child-"+$cat ).toggleClass( "cat3-expand" );
});
 $('.back-top a[href*="#"]:not([href="#"])').click(function() {
	    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
	      var target = $(this.hash);
	      target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
	      if (target.length) {
	        $('html, body').animate({
	          scrollTop: target.offset().top - $('#header').height()
	        }, 1000);
	        return false;
	      }
	    }
	  });

});
</script>
@endsection