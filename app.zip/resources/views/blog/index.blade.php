@extends('layouts.blog')

@section('title')
	{{ isset($category) ? 'Tag: '.$category : 'Kreasi | Kreasi2Shop ' }}
@endsection

@section('header')
<style type="text/css">
	a.dropdown-toggle.icon-height.icon-height{
			padding: 0px 0px!important;
		}
.filterk2s{
	background-color: white;
    box-shadow: none!important;
    color: grey!important;
}
div.scrollmenu {
    overflow: auto;
    white-space: nowrap;
}

div.scrollmenu button {
    display: inline-block;
    text-align: center;
    text-decoration: none;
}

a.blogk2s {
    display: inline-block;
    background-color: grey;
    margin-right: 10px;
}

a.blogk2s:hover .top, a.blogk2s:hover .bottom{
  border: 4px solid #e74c3c;
}

a.blogk2s:hover .top:after, a.blogk2s:hover .bottom:after{
  border-top: 4px solid #e74c3c;
  border-right: 4px solid #e74c3c;
	margin-top: 4px;
}

.bottom {
    display: inline-block;
    width: 35px;
    height: 35px;
    border: 0px solid gray;
    border-radius: 0%;
}

.bottom:after {
  content: '';
	display: inline-block;
  margin-top: 8px;
  width: 14px;
  height: 14px;
  border-top: 4px solid white;
  border-right: 4px solid white;
  -moz-transform: rotate(135deg);
  -webkit-transform: rotate(135deg);
  transform: rotate(135deg);
}

.btn{
	padding: 6px 16px!important;
}
/* BLOG CATEGORY*/
#header.home .mega-dropdown-menu li:after {
    position: absolute;
    content: "";
    right: 0px;
    top: 13px;
    background-image: url(https://i.postimg.cc/0jhhmk5y/separetor.png);
    width: 2px;
    height: 20px;
    background-repeat: no-repeat;
    background-size: contain;
}
#header.home .mega-dropdown-menu li, #header.small-header .mega-dropdown-menu li>ul li a {
    align-items: center;
    width: 16.5%;
    float: left;
    color: #666;
    font-size: 13px;
    font-weight: 600;
    text-transform: capitalize;
    cursor: pointer;
    padding: 12px 25px;
    /*transition: 0.4s all;*/
	opacity:0;
	transition: color 1s ease-in, background-color 0.1s ease-in, opacity 1s ease-in;
    position: relative;
    border-radius: 0px 25px 25px 25px;
    display: flex;
}
#header.home .mega-dropdown-menu li:hover {
    background-color: #565656;
	transition: 0.1s all;
}
#header.small-header .mega-dropdown-menu li:after {
    position: absolute;
    content: "";
    right: 0px;
    top: 13px;
    background-image: url(https://i.postimg.cc/0jhhmk5y/separetor.png);
    width: 2px;
    height: 20px;
    background-repeat: no-repeat;
    background-size: contain;
}
#header.small-header .mega-dropdown-menu li, #header.small-header .mega-dropdown-menu li>ul li a {
    align-items: center;
    width: 16.5%;
    float: left;
    color: #fff;
    font-size: 13px;
    font-weight: 600;
    text-transform: capitalize;
    cursor: pointer;
    padding: 12px 25px;
	opacity:0;
	transition: color 1s ease-in, background-color 0.1s ease-in, opacity 1s ease-in;
    position: relative;
    border-radius: 0 0 0 25px;
    display: flex;
}
#header .mega-dropdown-menu {
    width: 0%;
	display:block;
	opacity:0;
    height: 90px;
    margin-top: 15px;
    background: #666666;
    border-bottom-left-radius: 20px;
    border-bottom-right-radius: 20px;
}
#header .navbar-default .navbar-nav li a.blog-menu-new {
    color: #000;
    text-transform: capitalize;
    font-size: 13px;
    font-family: 'gadugi';
    letter-spacing: 1px;
    line-height: 0px;
    padding: 0px 15px;
}
.open>.dropdown-menu {
			display: block;
			width: 100%!important;
			opacity:1!important;
		}
		.open>.dropdown-menu li{
			color:#fff!important;
			opacity:1!important;
		}
		.dropdown-menu{
			transition: width 2s;
		}
	</style>
@endsection

@section('content')
<?php
	function getFirstPara($string){
        $string = substr($string,0, strpos($string, "</p>")+4);
        $string = str_replace("<p>", "", str_replace("<p/>", "", $string));
        return $string;
    }
	function get_words($sentence, $count = 10) {
      preg_match("/(?:\w+(?:\W+|$)){0,$count}/", $sentence, $matches);
      return $matches[0];
    }
?>
<!---- Banner Start ---->
<section id="banner">
	<div class="post">
		<p><a data-toggle="tooltip" data-placement="left" title="Post Submission" href="#"><img src="{{ asset('blog-asset/images/edit.png') }}" alt=""/></a></p>
	</div>
	<ul class="bxslider">
		<li style="background:url({{ asset('blog-asset/images/186.jpg') }}) 50% 50% no-repeat; background-size:cover;   box-shadow: inset 1000px 0px 1000px -500px #fff;">
			<div class="text-details">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 col-xs-12 col-sm-12">
							<div class="text">
								<p>
									<span class="red">
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-bolt" aria-hidden="true"></i>
									</span>
									<span>
										<img src="{{ asset('blog-asset/images/eye.png') }}" alt=""/> 999
									</span>
								</p>
								<p>SNAP STORY LIFE</p>
								<p>
									<h3>
										<span class="span-banner-text">
											100 Likes
										</span>
										<span class="span-banner-text">
											15 Comments
										</span>
										<span class="span-banner-text">
											20 Shares
										</span>
									</h3>
								</p>
								<p class="normal">By : Momo	&nbsp;&nbsp;&nbsp;&nbsp;1 Day ago</p>
							</div>
						</div>	
					</div>
				</div>		
			</div>	
		</li>
		<li style="background:url({{ asset('blog-asset/images/186.jpg') }}) 50% 50% no-repeat; background-size:cover; box-shadow: inset 1000px 0px 1000px -500px #fff;">
			<div class="text-details">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 col-xs-12 col-sm-12">
							<div class="text">
								<p>
									<span class="red">
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-bolt" aria-hidden="true"></i>
									</span>
									<span class="">
										<img src="{{ asset('blog-asset/images/eye.png') }}" alt=""/> 999
									</span>
								</p>
								<p>SNAP STORY LIFE</p>
								<p>
									<h3>
										<span class="span-banner-text">
											100 Likes
										</span>
										<span class="span-banner-text">
											15 Comments
										</span>
										<span class="span-banner-text">
											20 Shares
										</span>
									</h3>
								</p>
								<p class="normal">By : Momo	&nbsp;&nbsp;&nbsp;&nbsp;1 Day ago</p>
							</div>
						</div>	
					</div>
				</div>		
			</div>	
		</li>
	</ul>	
</section>
<!---- Banner End ---->
<!---- recipe Start ---->
<div class="title-head">
	<div class="container">
		<div class="row">
			<div class="col-lg-12  col-xs-12 col-sm-12">
				<h3>Blog</h3>
			</div>
		</div>
	</div>		 
</div>
<!--<section id="filtercategory" class="container-k2s-blog">
<div class="scrollmenu">

		<button class="btn filterk2s item carousel-col block" id="New"><a class="blogk2s" href="#"><span class="bottom"></span></a>NEW</button>
		<button class="btn filterk2s item carousel-col block" id="all">ALL</button>
		<button class="btn filterk2s item carousel-col block" id="kesehatan">KESEHATAN</button>	
		<button class="btn filterk2s item carousel-col block" id="produk">PRODUK</button>
		<button class="btn filterk2s item carousel-col block" id="kecantikan">KECANTIKAN</button>
		<button class="btn filterk2s item carousel-col block" id="tips">TIPS</button>
		<button class="btn filterk2s item carousel-col block" id="travelling">TRAVELLING</button>
		<button class="btn filterk2s item carousel-col block" id="life">LIFE</button>
		<button class="btn filterk2s item carousel-col block" id="resep">RESEP</button>
		<button class="btn filterk2s item carousel-col block" id="fashionn">FASHION</button>
		<button class="btn filterk2s item carousel-col block" id="food and beverage">FOOD AND BEVERAGE</button>
		<button class="btn filterk2s item carousel-col block" id="olahraga">OLAHRAGA</button>
		<button class="btn filterk2s item carousel-col block" id="zodiak">ZODIAK</button>
		</div>
</section> -->
<div id="recipe" class="container-k2s-blog">
	<div class="col-lg-9 flush col-sm-12 col-xs-12 ">
		<ul class="images" id="parent">
			@foreach($blog as $value)
			<li class="col-lg-6 col-sm-12 col-xs-12 height-min {{ strlen($value->category) ? strtoupper($value->category) : 'BLOG' }}">
			<div style="padding-bottom:10px;">
			<i class="fa fa-eye" style="font-size: 18px;color:grey;"> {{ $value->viewed }}</i>
			<i class="fa fa-reply" style="font-size: 18px;color:grey;float:right;"> {{ $value->shared }}</i>
			<i class="fa fa-comment-o" style="font-size: 18px;color:grey; padding-right: 15px; float:right;"> {{ $value->BlogComment()->count() }}</i>
			<i class="fa fa-heart" style="font-size: 18px;color:grey; padding-right: 15px; float:right;"> {{ $value->BlogLike()->count() }}</i>
			</div>	
				<a href="{{ route('blog.detail',$value->slug) }}">
					<img src="{{ $value->image }}" aclass="img-responsive" style="width:100%" lt="" alt="Popular Image"/>
					<!-- <a href="{{ route('blog.tag', strlen($value->category) ? strtoupper($value->category) : 'BLOG') }}"> -->
						<span class="blog-category-label">{{ strlen($value->category) ? strtoupper($value->category) : 'BLOG' }}</span>
					<!-- </a> -->
					<div class="icon">
						@if($value->hot==1)
						<img src="{{ asset('blog-asset/images/fire.png') }}" alt="popular" title="popular" />
						@endif
						@if($value->trending==1)
						<img src="{{ asset('blog-asset/images/light.png') }}" alt="trending" title="trending" />
						@endif
						@if($value->favorite==1)
						<img src="{{ asset('blog-asset/images/star.png') }}" alt="favorite" title="favorite" />
						@endif
					</div>
					<div class="white-overlay">
									<!-- <h5>{{ strlen($value->title)>50 ? substr($value->title, 0, 60)."..." : $value->title }}</h5> -->
									<h5>{{$value->title}}</h5>
									<label>By {{ $value->Admin->name ?? ''}} - {{ \Carbon\Carbon::parse($value->created_at)->diffForHumans() }}</label>
									<?php
									$value->content=str_replace('<p></p>', '', $value->content);
									$start = strpos($value->content, '<p>');
									$end = strpos($value->content, '</p>', $start);
									$firstparagraph = substr($value->content, $start, $end-$start+4);
									$paragraph = html_entity_decode(strip_tags($firstparagraph));
									$try=10;
									while($try>0){
										$value->content=str_replace($firstparagraph, '', $value->content);
										$start = strpos($value->content, '<p>');
										$end = strpos($value->content, '</p>', $start);
										$nextparagraph = substr($value->content, $start, $end-$start+4);
										$paragraph = html_entity_decode(strip_tags($nextparagraph));
										$firstparagraph=$nextparagraph;
										if(strlen($paragraph)>20){
											$try=0;
										}
										$try--;
									}
									?>
									<p>{{ strlen($paragraph)>20  ? $paragraph."..." : $paragraph }}</p>
									<a href="{{ route('blog.detail',$value->slug) }}">Read More <i class="fa fa-caret-right" aria-hidden="true"></i></a>
								</div>
				</a>
			</li>
			@endforeach
			
		</ul>
		<div class="col-lg-12 flush col-sm-12 col-xs-12 " style="text-align:right;">
		<?php /* {!! $blog->links() !!} */ ?>
		<paginate
			v-model="page"
			:page-count="maxPage"
			:page-range="5"
			:margin-pages="1"
			:click-handler="clickCallback"
			prev-text="<span class='ic-none'>Previous</span>"
			next-text="<span class='ic-none'>Next</span>"
			prev-class="ic-prev"
			next-class="ic-next">
		</paginate>
		</div>
	</div>
	<div class="col-lg-3 col-sm-12 col-xs-12 trending-container">
		<h3><span class="red">Trending </span> of the week</h3>
		<ul class="images parent-filter">
			@foreach($trending as $value)
			<li class="col-lg-12 col-sm-12 col-xs-12">
				<a href="{{ route('blog.detail',$value->slug) }}">
					<img src="{{ $value->image }}" aclass="img-responsive" style="width:100%" lt="" alt="Popular Image"/>
					<!--<a href="{{ route('blog.tag', strtolower($value->category)) }}"> -->
						<span class="blog-category-label">{{ strtoupper($value->category) }}</span>
					<!-- </a> -->
					<div class="icon">
						@if($value->hot==1)
						<img src="{{ asset('blog-asset/images/fire.png') }}" alt="popular" title="popular" />
						@endif
						@if($value->trending==1)
						<img src="{{ asset('blog-asset/images/light.png') }}" alt="trending" title="trending" />
						@endif
						@if($value->favorite==1)
						<img src="{{ asset('blog-asset/images/star.png') }}" alt="favorite" title="favorite" />
						@endif
					</div>
					<div class="white-overlay">
						<h5>{{ strlen($value->title)>50 ? substr($value->title, 0, 60)."..." : $value->title }}</h5>
						<label>By {{ $value->Admin->name ?? ''}} - {{ \Carbon\Carbon::parse($value->created_at)->diffForHumans() }}</label>
						<?php
						$value->content=str_replace('<p></p>', '', $value->content);
						$start = strpos($value->content, '<p>');
						$end = strpos($value->content, '</p>', $start);
						$firstparagraph = substr($value->content, $start, $end-$start+4);
						$paragraph = html_entity_decode(strip_tags($firstparagraph));
						$try=10;
						while($try>0){
							$value->content=str_replace($firstparagraph, '', $value->content);
							$start = strpos($value->content, '<p>');
							$end = strpos($value->content, '</p>', $start);
							$nextparagraph = substr($value->content, $start, $end-$start+4);
							$paragraph = html_entity_decode(strip_tags($nextparagraph));
							$firstparagraph=$nextparagraph;
							if(strlen($paragraph)>20){
								$try=0;
							}
							$try--;
						}
						?>
						<p>{{ strlen($paragraph)>20 ? $paragraph."..." : $paragraph }}</p>
						<a href="{{ route('blog.detail',$value->slug) }}">Read More <i class="fa fa-caret-right" aria-hidden="true"></i></a>
					</div>
				</a>
			</li>
			@endforeach
			<li class="col-lg-12 col-sm-12 col-xs-12">
				<h3><span style="color:#b62126;font-family: 'gadugib'; font-size: 21px; text-align: center;">About</span> K R E<span style="color:#b62126;"> A </span>S I</h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
				<a class="btn" style="background-color:grey;color:#fff; font-family: 'gadugib'; font-size: 21px; text-align: center;">Know More</a>
			</li>
			<li class="col-lg-12 col-sm-12 col-xs-12">
				<h3><span style="color:#b62126;font-family: 'gadugib'; font-size: 21px; text-align: center;">Follow Us</span> on</h3>
				<div style="display:inline-flex; margin-top: 15px; text-align: center;width: 100%;">
				<a href="#" class="socials"><i class="fa fa-facebook"></i></a> <a href="#" class="socials"><i class="fa fa-twitter"></i></a> <a href="#" class="socials"><i class="fa fa-instagram"></i></a> <a href="#" class="socials"><i class="fa fa-youtube-play"></i></a> <a href="#" class="socials"><i class="fa fa-google-plus"></i></a>
				</div>
			</li>
		</ul>
	</div>
</div>
<!-- <section id="fashion">
	<ul class="bxslider">
		<li style="background:url({{ asset('blog-asset/images/what-bg.jpg') }}) 50% 50% no-repeat; background-size:cover;">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-sm-12 col-xs-12 text-center">
						<h4><span>Fashion</span></h4>
					</div>
					<div class="col-lg-12 col-sm-12 col-xs-12 text-center">
						<h2><img src="{{ asset('blog-asset/images/text.png') }}" alt=""/></h2>
					</div>	
					<div class="col-lg-12 col-sm-12 col-xs-12 text-center">
						<a href="#" class="btn-success">See More</a>
						<a href="#" class="btn-success gray">Share My OOTD</a>
					</div>
				</div>	
			</div>    
		</li>
		<li style="background:url({{ asset('blog-asset/images/what-bg.jpg') }}) 50% 50% no-repeat; background-size:cover;">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-sm-12 col-xs-12 text-center">
						<h4><span>Fashion</span></h4>
					</div>
					<div class="col-lg-12 col-sm-12 col-xs-12 text-center">
						<h2><img src="{{ asset('blog-asset/images/text.png') }}" alt=""/></h2>
					</div>	
					<div class="col-lg-12 col-sm-12 col-xs-12 text-center">
						<a href="#" class="btn-success">See More</a>
						<a href="#" class="btn-success gray">Share My OOTD</a>
					</div>
				</div>	
			</div>    
		</li>
		<li style="background:url({{ asset('blog-asset/images/what-bg.jpg') }}) 50% 50% no-repeat; background-size:cover;">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-sm-12 col-xs-12 text-center">
						<h4><span>Fashion</span></h4>
					</div>
					<div class="col-lg-12 col-sm-12 col-xs-12 text-center">
						<h2><img src="{{ asset('blog-asset/images/text.png') }}" alt=""/></h2>
					</div>	
					<div class="col-lg-12 col-sm-12 col-xs-12 text-center">
						<a href="#" class="btn-success">See More</a>
						<a href="#" class="btn-success gray">Share My OOTD</a>
					</div>
				</div>	
			</div>    
		</li>
		<li style="background:url({{ asset('blog-asset/images/what-bg.jpg') }}) 50% 50% no-repeat; background-size:cover;">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-sm-12 col-xs-12 text-center">
						<h4><span>Fashion</span></h4>
					</div>
					<div class="col-lg-12 col-sm-12 col-xs-12 text-center">
						<h2><img src="{{ asset('blog-asset/images/text.png') }}" alt=""/></h2>
					</div>	
					<div class="col-lg-12 col-sm-12 col-xs-12 text-center">
						<a href="#" class="btn-success">See More</a>
						<a href="#" class="btn-success gray">Share My OOTD</a>
					</div>
				</div>	
			</div>    
		</li>
		<li style="background:url({{ asset('blog-asset/images/what-bg.jpg') }}) 50% 50% no-repeat; background-size:cover;">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-sm-12 col-xs-12 text-center">
						<h4><span>Fashion</span></h4>
					</div>
					<div class="col-lg-12 col-sm-12 col-xs-12 text-center">
						<h2><img src="{{ asset('blog-asset/images/text.png') }}" alt=""/></h2>
					</div>	
					<div class="col-lg-12 col-sm-12 col-xs-12 text-center">
						<a href="#" class="btn-success">See More</a>
						<a href="#" class="btn-success gray">Share My OOTD</a>
					</div>
				</div>	
			</div>    
		</li>
	</ul>	
</section> -->
<!-- <section id="recipe" class="follow">
	<div class="col-lg-12 col-sm-12 col-xs-12 text-center">
		<h4><b>Follow us on</b></h4>
	</div>
	<div class="col-lg-12 social col-sm-12 col-xs-12 text-center">
		<a href="https://www.facebook.com/Kreasi2shop-923111347801427/" target="_blank"><img src="{{ asset('blog-asset/images/facebook.png') }}" alt=""/> Kreasi  Duashop</a>
		<a href="https://www.instagram.com/kreasiduashop/" target="_blank"><img src="{{ asset('blog-asset/images/insta.png') }}" alt=""/> kreasiduashop</a>
	</div>
	
</section>
<section id="photostack-2" class="photostack photostack-start">
				<div>
					<figure>
						<a href="#" class="photostack-img"><img src="{{ asset('blog-asset/images/img-4.jpg') }}" alt="img04"/></a>
						<figcaption>
							<h2 class="photostack-title">Heaven of time</h2>
							<div class="photostack-back">
								<p>What might be right for you may not be right for some. And we know Flipper lives in a world full of wonder flying there-under under the sea.</p>
							</div>
						</figcaption>
					</figure>
					<figure>
						<a href="#" class="photostack-img"><img src="{{ asset('blog-asset/images/img-5.jpg') }}" alt="img05"/></a>
						<figcaption>
							<h2 class="photostack-title">Speed Racer</h2>
						</figcaption>
					</figure>
					<figure data-shuffle-iteration="2">
						<a href="#" class="photostack-img"><img src="{{ asset('blog-asset/images/img-1.jpg') }}" alt="img01"/></a>
						<figcaption>
							<h2 class="photostack-title">Serenity Beach</h2>
							<div class="photostack-back">
								<p>I have never been to a place so serene in my entire life before. Swimming in clear waters opened my mind to nature and reminded me of my and <span>eveybody</span> everybody else's mortality.</p>
							</div>
						</figcaption>
					</figure>
					<figure>
						<a href="#" class="photostack-img"><img src="{{ asset('blog-asset/images/img-2.jpg') }}" alt="img02"/></a>
						<figcaption>
							<h2 class="photostack-title">Happy Days</h2>
							<div class="photostack-back">
								<p>These Happy Days are yours and mine Happy Days. It's a beautiful day in this neighborhood a beautiful day for a neighbor. Would you be mine?</p>
							</div>
						</figcaption>
					</figure>
					<figure data-shuffle-iteration="3">
						<a href="#" class="photostack-img"><img src="{{ asset('blog-asset/images/img-3.jpg') }}" alt="img03"/></a>
						<figcaption>
							<h2 class="photostack-title">Beautywood</h2>
						</figcaption>
					</figure>
					<figure data-shuffle-iteration="2">
						<a href="#" class="photostack-img"><img src="{{ asset('blog-asset/images/img-6.jpg') }}" alt="img06"/></a>
						<figcaption>
							<h2 class="photostack-title">Forever this</h2>
						</figcaption>
					</figure>
					<figure data-dummy>
						<a href="#" class="photostack-img"><img src="{{ asset('blog-asset/images/img-7.jpg') }}" alt="img07"/></a>
						<figcaption>
							<h2 class="photostack-title">Lovely Green</h2>
						</figcaption>
					</figure>
					<figure data-dummy>
						<a href="#" class="photostack-img"><img src="{{ asset('blog-asset/images/img-8.jpg') }}" alt="img08"/></a>
						<figcaption>
							<h2 class="photostack-title">Wonderful</h2>
						</figcaption>
					</figure>
					<figure data-dummy>
						<a href="#" class="photostack-img"><img src="{{ asset('blog-asset/images/img-9.jpg') }}" alt="img09"/></a>
						<figcaption>
							<h2 class="photostack-title">Love Addict</h2>
						</figcaption>
					</figure>
					<figure data-dummy>
						<a href="#" class="photostack-img"><img src="{{ asset('blog-asset/images/img-10.jpg') }}" alt="img10"/></a>
						<figcaption>
							<h2 class="photostack-title">Friendship</h2>
						</figcaption>
					</figure>
					<figure data-dummy>
						<a href="#" class="photostack-img"><img src="{{ asset('blog-asset/images/img-11.jpg') }}" alt="img11"/></a>
						<figcaption>
							<h2 class="photostack-title">White Nights</h2>
						</figcaption>
					</figure>
					<figure data-dummy>
						<a href="#" class="photostack-img"><img src="{{ asset('blog-asset/images/img-12.jpg') }}" alt="img12"/></a>
						<figcaption>
							<h2 class="photostack-title">Serendipity</h2>
						</figcaption>
					</figure>
					<figure data-dummy>
						<a href="#" class="photostack-img"><img src="{{ asset('blog-asset/images/img-13.jpg') }}" alt="img13"/></a>
						<figcaption>
							<h2 class="photostack-title">Pure Soul</h2>
						</figcaption>
					</figure>
					<figure data-dummy>
						<a href="#" class="photostack-img"><img src="{{ asset('blog-asset/images/img-14.jpg') }}" alt="img14"/></a>
						<figcaption>
							<h2 class="photostack-title">Winds of Peace</h2>
						</figcaption>
					</figure>
					<figure data-dummy>
						<a href="#" class="photostack-img"><img src="{{ asset('blog-asset/images/img-15.jpg') }}" alt="img15"/></a>
						<figcaption>
							<h2 class="photostack-title">Shades of blue</h2>
						</figcaption>
					</figure>
					<figure data-dummy>
						<a href="#" class="photostack-img"><img src="{{ asset('blog-asset/images/img-16.jpg') }}" alt="img16"/></a>
						<figcaption>
							<h2 class="photostack-title">Lightness</h2>
						</figcaption>
					</figure>
				</div>
			</section> -->
			<!--<section>
			<div class="col-lg-4 col-sm-12 col-xs-12 text-center back-top">
				<a href="#">
					Kebijakan Privasi
				</a>
			</div>
			<div class="col-lg-4 col-sm-12 col-xs-12  text-center back-top">
				<a href="#banner">
					Hubungi Kami
				</a>
			</div>
			<div class="col-lg-4 col-sm-12 col-xs-12  text-center back-top">
				<a href="#banner">
					Cara Menambah Artikel
				</a>
			</div>
			</section> -->
@endsection

@section('script')
<script type="text/javascript">
var $btns = $('.btn').click(function() {
  if (this.id == 'all') {
    $('#parent > li').fadeIn(450);
  } else {
    var $el = $('.' + this.id).fadeIn(450);
    $('#parent > li').not($el).hide();
  }
  $btns.removeClass('active');
  $(this).addClass('active');
})
</script>
<script type="text/javascript">
$(document).ready(function(){
	$('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
	  if (!$(this).next().hasClass('show')) {
	    $(this).parents('.dropdown-menu').first().find('.show').removeClass("show");
	  }
	  var $subMenu = $(this).next(".dropdown-menu");
	  $subMenu.toggleClass('show');
	  return false;
	});
});
</script>
<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});

// $("#btn-1").click(function(){
//     $("#ul-1 li").toggleClass("show");
//     $("#btn-1").toggleClass("arrow-rotate"); 
// });

// $("#btn-2").click(function(){
//     $("#ul-2 li").toggleClass("show");
// });

// $("#btn-3").click(function(){
//     $("#ul-3 li").toggleClass("show");
// });

// $("#btn-4").click(function(){
//     $("#ul-4 li").toggleClass("show");
// });

// $("#btn-5").click(function(){
//     $("#ul-5 li").toggleClass("show");
// });
$(window).on("scroll", function() { 
    if($(window).scrollTop() > 50) { 
        $(".small-header").addClass("active"); 
    } else { 
        //remove the background property so it comes transparent again (defined in your css) 
       $(".small-header").removeClass("active"); 
    } 
}); 
</script>

<script>
$(document).ready(function(){
  $('.dropdown-subaccount a').on("hover", function(e){
    $(this).next('ul').toggle();
  });
});
</script>
<script type="text/javascript">
$(document).ready(function(){
	$('.bxslider').bxSlider({
		auto: true,
		touchEnabled: true
  // autoControls: true,
  // stopAutoOnClick: true,
  // pager: true,
	});
	
});
</script>
<script>
$(document).ready(function(){
$( ".unhover").hover(function() {
	$cat=$(this).data('category');
	//console.log(".cat-child-"+$cat);
  $(".cat-child-"+$cat ).toggleClass( "cat3-expand" );
});
});
</script>
<script type="text/javascript">
$(document).ready(function(){
 $('.multiple-items').slick({
  infinite: false,
  slidesToShow: 10,
  slidesToScroll: 1,
  adaptiveHeight: true,
arrow:false
});
});
</script>
<script>
//test script carousel
$('.carousel[data-type="multi"] .item').each(function() {
	var next = $(this).next();
	if (!next.length) {
		next = $(this).siblings(':first');
	}
	next.children(':first-child').clone().appendTo($(this));

	for (var i = 0; i < 2; i++) {
		next = next.next();
		if (!next.length) {
			next = $(this).siblings(':first');
		}

		next.children(':first-child').clone().appendTo($(this));
	}
});
</script>
<script>

$(function() {
  $('a[href*="#"]:not([href="#"])').click(function() {
    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
      if (target.length) {
        $('html, body').animate({
          scrollTop: target.offset().top - $('#header').height()
        }, 1000);
        return false;
      }
    }
  });
});
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
});

</script>
<script>
    var swiper = new Swiper('.swiper-container', {
      slidesPerView: 3,
      slidesPerColumn: 2,
      spaceBetween: 30,
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
    });
  </script>
<script>

$("#OpenMenu").click(function(e){
    $("#ShowMenu").toggle();
});


$("#OpenMenu2").click(function(){
    $("#ShowMenu").toggle();
});
</script>

		<script>
			// [].slice.call( document.querySelectorAll( '.photostack' ) ).forEach( function( el ) { new Photostack( el ); } );
			
			
			new Photostack( document.getElementById( 'photostack-2' ), {
				callback : function( item ) {
					//console.log(item)
				}
			} );
			
		</script>
		<script>
		$(document).ready(function () {
    var itemsMainDiv = ('.MultiCarousel');
    var itemsDiv = ('.MultiCarousel-inner');
    var itemWidth = "";

    $('.leftLst, .rightLst').click(function () {
        var condition = $(this).hasClass("leftLst");
        if (condition)
            carou(0, this);
        else
            carou(1, this)
    });

    ResCarouselSize();




    $(window).resize(function () {
        ResCarouselSize();
    });

    //this function define the size of the items
    function ResCarouselSize() {
        var incno = 0;
        var dataItems = ("data-items");
        var itemClass = ('.item');
        var id = 0;
        var btnParentSb = '';
        var itemsSplit = '';
        var sampwidth = $(itemsMainDiv).width();
        var bodyWidth = $('body').width();
        $(itemsDiv).each(function () {
            id = id + 1;
            var itemNumbers = $(this).find(itemClass).length;
            btnParentSb = $(this).parent().attr(dataItems);
            itemsSplit = btnParentSb.split(',');
            $(this).parent().attr("id", "MultiCarousel" + id);


            if (bodyWidth >= 1200) {
                incno = itemsSplit[3];
                itemWidth = sampwidth / incno;
            }
            else if (bodyWidth >= 992) {
                incno = itemsSplit[2];
                itemWidth = sampwidth / incno;
            }
            else if (bodyWidth >= 768) {
                incno = itemsSplit[1];
                itemWidth = sampwidth / incno;
            }
            else {
                incno = itemsSplit[0];
                itemWidth = sampwidth / incno;
            }
            $(this).css({ 'transform': 'translateX(0px)', 'width': itemWidth * itemNumbers });
            $(this).find(itemClass).each(function () {
                $(this).outerWidth(itemWidth);
            });

            $(".leftLst").addClass("over");
            $(".rightLst").removeClass("over");

        });
    }


    //this function used to move the items
    function ResCarousel(e, el, s) {
        var leftBtn = ('.leftLst');
        var rightBtn = ('.rightLst');
        var translateXval = '';
        var divStyle = $(el + ' ' + itemsDiv).css('transform');
        var values = divStyle.match(/-?[\d\.]+/g);
        var xds = Math.abs(values[4]);
        if (e == 0) {
            translateXval = parseInt(xds) - parseInt(itemWidth * s);
            $(el + ' ' + rightBtn).removeClass("over");

            if (translateXval <= itemWidth / 2) {
                translateXval = 0;
                $(el + ' ' + leftBtn).addClass("over");
            }
        }
        else if (e == 1) {
            var itemsCondition = $(el).find(itemsDiv).width() - $(el).width();
            translateXval = parseInt(xds) + parseInt(itemWidth * s);
            $(el + ' ' + leftBtn).removeClass("over");

            if (translateXval >= itemsCondition - itemWidth / 2) {
                translateXval = itemsCondition;
                $(el + ' ' + rightBtn).addClass("over");
            }
        }
        $(el + ' ' + itemsDiv).css('transform', 'translateX(' + -translateXval + 'px)');
    }

    //It is used to get some elements from btn
    function carou(ell, ee) {
        var Parent = "#" + $(ee).parent().attr("id");
        var slide = $(Parent).attr("data-slide");
        ResCarousel(ell, Parent, slide);
    }

});
		</script>
<script type="text/javascript">
if (window.location.href.indexOf("blog") != -1) {
$("#cart-blog").hide();
$("#account-blog").hide();
}

</script>

<script src="https://cdn.jsdelivr.net/npm/vue@2.5.17/dist/vue.js"></script>
<script src="https://unpkg.com/vuejs-paginate@latest"></script>

<script>
	var module = {};
    Vue.component('paginate', VuejsPaginate)
	var content = new Vue({
            el: '#recipe',
            data: {
                loading: true,
                page: {{ \Request::get('page') ?: 1 }},
                maxPage: {{ $blog->lastPage() }},
                url: '{{ url()->full() }}'
            },

            created(){


            },

            methods: {
                clickCallback: function(pageNum) {
                    this.page=pageNum
                },
                updateQueryStringParameter(uri,key, value) {
				  var re = new RegExp("([?&])" + key + "=.*?(&|$)", "i");
				  var separator = uri.indexOf('?') !== -1 ? "&" : "?";
				  if (uri.match(re)) {
				    this.url = uri.replace(re, '$1' + key + "=" + value + '$2');
				  }
				  else {
				    this.url = uri + separator + key + "=" + value;
				  }
				}

            },
            watch: {
                'page' () {
                	this.updateQueryStringParameter(this.url, 'page', this.page)
                    window.location.href = this.url
                }
            }
        })
</script>
@endsection