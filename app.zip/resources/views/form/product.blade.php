{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('model', 'Model:') !!}
			{!! Form::text('model') !!}
		</li>
		<li>
			{!! Form::label('name', 'Name:') !!}
			{!! Form::text('name') !!}
		</li>
		<li>
			{!! Form::label('desc', 'Desc:') !!}
			{!! Form::textarea('desc') !!}
		</li>
		<li>
			{!! Form::label('slug', 'Slug:') !!}
			{!! Form::text('slug') !!}
		</li>
		<li>
			{!! Form::label('category_id', 'Category_id:') !!}
			{!! Form::text('category_id') !!}
		</li>
		<li>
			{!! Form::label('related', 'Related:') !!}
			{!! Form::textarea('related') !!}
		</li>
		<li>
			{!! Form::label('price', 'Price:') !!}
			{!! Form::text('price') !!}
		</li>
		<li>
			{!! Form::label('qty', 'Qty:') !!}
			{!! Form::text('qty') !!}
		</li>
		<li>
			{!! Form::label('status', 'Status:') !!}
			{!! Form::text('status') !!}
		</li>
		<li>
			{!! Form::label('weight', 'Weight:') !!}
			{!! Form::text('weight') !!}
		</li>
		<li>
			{!! Form::label('weight_class_id', 'Weight_class_id:') !!}
			{!! Form::text('weight_class_id') !!}
		</li>
		<li>
			{!! Form::label('length', 'Length:') !!}
			{!! Form::text('length') !!}
		</li>
		<li>
			{!! Form::label('width', 'Width:') !!}
			{!! Form::text('width') !!}
		</li>
		<li>
			{!! Form::label('height', 'Height:') !!}
			{!! Form::text('height') !!}
		</li>
		<li>
			{!! Form::label('length_class_id', 'Length_class_id:') !!}
			{!! Form::text('length_class_id') !!}
		</li>
		<li>
			{!! Form::label('substract', 'Substract:') !!}
			{!! Form::text('substract') !!}
		</li>
		<li>
			{!! Form::label('minimum', 'Minimum:') !!}
			{!! Form::text('minimum') !!}
		</li>
		<li>
			{!! Form::label('sort_order', 'Sort_order:') !!}
			{!! Form::text('sort_order') !!}
		</li>
		<li>
			{!! Form::label('viewed', 'Viewed:') !!}
			{!! Form::text('viewed') !!}
		</li>
		<li>
			{!! Form::label('stock_status_id', 'Stock_status_id:') !!}
			{!! Form::text('stock_status_id') !!}
		</li>
		<li>
			{!! Form::label('shipping', 'Shipping:') !!}
			{!! Form::text('shipping') !!}
		</li>
		<li>
			{!! Form::label('point', 'Point:') !!}
			{!! Form::text('point') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}