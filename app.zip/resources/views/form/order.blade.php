{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('invoice', 'Invoice:') !!}
			{!! Form::text('invoice') !!}
		</li>
		<li>
			{!! Form::label('user_id', 'User_id:') !!}
			{!! Form::text('user_id') !!}
		</li>
		<li>
			{!! Form::label('customer_group_id', 'Customer_group_id:') !!}
			{!! Form::text('customer_group_id') !!}
		</li>
		<li>
			{!! Form::label('name', 'Name:') !!}
			{!! Form::text('name') !!}
		</li>
		<li>
			{!! Form::label('email', 'Email:') !!}
			{!! Form::text('email') !!}
		</li>
		<li>
			{!! Form::label('telephone', 'Telephone:') !!}
			{!! Form::text('telephone') !!}
		</li>
		<li>
			{!! Form::label('fax', 'Fax:') !!}
			{!! Form::text('fax') !!}
		</li>
		<li>
			{!! Form::label('payment_address', 'Payment_address:') !!}
			{!! Form::textarea('payment_address') !!}
		</li>
		<li>
			{!! Form::label('payment_province', 'Payment_province:') !!}
			{!! Form::text('payment_province') !!}
		</li>
		<li>
			{!! Form::label('payment_city', 'Payment_city:') !!}
			{!! Form::text('payment_city') !!}
		</li>
		<li>
			{!! Form::label('payment_postal_code', 'Payment_postal_code:') !!}
			{!! Form::text('payment_postal_code') !!}
		</li>
		<li>
			{!! Form::label('payment_method', 'Payment_method:') !!}
			{!! Form::text('payment_method') !!}
		</li>
		<li>
			{!! Form::label('order_status_id', 'Order_status_id:') !!}
			{!! Form::text('order_status_id') !!}
		</li>
		<li>
			{!! Form::label('shipping_city', 'Shipping_city:') !!}
			{!! Form::text('shipping_city') !!}
		</li>
		<li>
			{!! Form::label('coupon', 'Coupon:') !!}
			{!! Form::text('coupon') !!}
		</li>
		<li>
			{!! Form::label('total', 'Total:') !!}
			{!! Form::text('total') !!}
		</li>
		<li>
			{!! Form::label('ip', 'Ip:') !!}
			{!! Form::text('ip') !!}
		</li>
		<li>
			{!! Form::label('forwarded_ip', 'Forwarded_ip:') !!}
			{!! Form::text('forwarded_ip') !!}
		</li>
		<li>
			{!! Form::label('user_agent', 'User_agent:') !!}
			{!! Form::text('user_agent') !!}
		</li>
		<li>
			{!! Form::label('accept_language', 'Accept_language:') !!}
			{!! Form::text('accept_language') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}