{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('name', 'Name:') !!}
			{!! Form::text('name') !!}
		</li>
		<li>
			{!! Form::label('desc', 'Desc:') !!}
			{!! Form::textarea('desc') !!}
		</li>
		<li>
			{!! Form::label('timed_discount', 'Timed_discount:') !!}
			{!! Form::text('timed_discount') !!}
		</li>
		<li>
			{!! Form::label('start', 'Start:') !!}
			{!! Form::text('start') !!}
		</li>
		<li>
			{!! Form::label('end', 'End:') !!}
			{!! Form::text('end') !!}
		</li>
		<li>
			{!! Form::label('group_discount', 'Group_discount:') !!}
			{!! Form::text('group_discount') !!}
		</li>
		<li>
			{!! Form::label('discount', 'Discount:') !!}
			{!! Form::text('discount') !!}
		</li>
		<li>
			{!! Form::label('discount_type_id', 'Discount_type_id:') !!}
			{!! Form::text('discount_type_id') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}