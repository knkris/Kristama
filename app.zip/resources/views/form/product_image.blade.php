{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('product_id', 'Product_id:') !!}
			{!! Form::text('product_id') !!}
		</li>
		<li>
			{!! Form::label('image', 'Image:') !!}
			{!! Form::textarea('image') !!}
		</li>
		<li>
			{!! Form::label('sort', 'Sort:') !!}
			{!! Form::text('sort') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}