{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('order_id', 'Order_id:') !!}
			{!! Form::text('order_id') !!}
		</li>
		<li>
			{!! Form::label('product_id', 'Product_id:') !!}
			{!! Form::text('product_id') !!}
		</li>
		<li>
			{!! Form::label('product_option_id', 'Product_option_id:') !!}
			{!! Form::text('product_option_id') !!}
		</li>
		<li>
			{!! Form::label('qty', 'Qty:') !!}
			{!! Form::text('qty') !!}
		</li>
		<li>
			{!! Form::label('price', 'Price:') !!}
			{!! Form::text('price') !!}
		</li>
		<li>
			{!! Form::label('shipping_courier', 'Shipping_courier:') !!}
			{!! Form::text('shipping_courier') !!}
		</li>
		<li>
			{!! Form::label('courier_service', 'Courier_service:') !!}
			{!! Form::text('courier_service') !!}
		</li>
		<li>
			{!! Form::label('shipping_province', 'Shipping_province:') !!}
			{!! Form::text('shipping_province') !!}
		</li>
		<li>
			{!! Form::label('shipping_city', 'Shipping_city:') !!}
			{!! Form::text('shipping_city') !!}
		</li>
		<li>
			{!! Form::label('shipping_postal_code', 'Shipping_postal_code:') !!}
			{!! Form::text('shipping_postal_code') !!}
		</li>
		<li>
			{!! Form::label('note', 'Note:') !!}
			{!! Form::textarea('note') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}