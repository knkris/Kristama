{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('product_id', 'Product_id:') !!}
			{!! Form::text('product_id') !!}
		</li>
		<li>
			{!! Form::label('option_id', 'Option_id:') !!}
			{!! Form::text('option_id') !!}
		</li>
		<li>
			{!! Form::label('option_value_id', 'Option_value_id:') !!}
			{!! Form::text('option_value_id') !!}
		</li>
		<li>
			{!! Form::label('required', 'Required:') !!}
			{!! Form::text('required') !!}
		</li>
		<li>
			{!! Form::label('qty', 'Qty:') !!}
			{!! Form::text('qty') !!}
		</li>
		<li>
			{!! Form::label('substract', 'Substract:') !!}
			{!! Form::text('substract') !!}
		</li>
		<li>
			{!! Form::label('price', 'Price:') !!}
			{!! Form::text('price') !!}
		</li>
		<li>
			{!! Form::label('point', 'Point:') !!}
			{!! Form::text('point') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}