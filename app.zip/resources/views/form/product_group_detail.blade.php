{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('product_group_id', 'Product_group_id:') !!}
			{!! Form::text('product_group_id') !!}
		</li>
		<li>
			{!! Form::label('product_id', 'Product_id:') !!}
			{!! Form::text('product_id') !!}
		</li>
		<li>
			{!! Form::label('discount', 'Discount:') !!}
			{!! Form::text('discount') !!}
		</li>
		<li>
			{!! Form::label('discount_type_id', 'Discount_type_id:') !!}
			{!! Form::text('discount_type_id') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}