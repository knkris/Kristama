{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('customer_group_id', 'Customer_group_id:') !!}
			{!! Form::text('customer_group_id') !!}
		</li>
		<li>
			{!! Form::label('name', 'Name:') !!}
			{!! Form::text('name') !!}
		</li>
		<li>
			{!! Form::label('email', 'Email:') !!}
			{!! Form::text('email') !!}
		</li>
		<li>
			{!! Form::label('password', 'Password:') !!}
			{!! Form::text('password') !!}
		</li>
		<li>
			{!! Form::label('remember_token', 'Remember_token:') !!}
			{!! Form::text('remember_token') !!}
		</li>
		<li>
			{!! Form::label('telephone', 'Telephone:') !!}
			{!! Form::text('telephone') !!}
		</li>
		<li>
			{!! Form::label('fax', 'Fax:') !!}
			{!! Form::text('fax') !!}
		</li>
		<li>
			{!! Form::label('newsletter', 'Newsletter:') !!}
			{!! Form::text('newsletter') !!}
		</li>
		<li>
			{!! Form::label('ip', 'Ip:') !!}
			{!! Form::text('ip') !!}
		</li>
		<li>
			{!! Form::label('status', 'Status:') !!}
			{!! Form::text('status') !!}
		</li>
		<li>
			{!! Form::label('safe', 'Safe:') !!}
			{!! Form::text('safe') !!}
		</li>
		<li>
			{!! Form::label('token', 'Token:') !!}
			{!! Form::textarea('token') !!}
		</li>
		<li>
			{!! Form::label('code', 'Code:') !!}
			{!! Form::text('code') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}