<div class="navbar-default sidebar" role="navigation">
    <div class="sidebar-nav navbar-collapse">
        <ul class="nav" id="side-menu">
            {{-- <li class="sidebar-search">
                <div class="input-group custom-search-form">
                    <input type="text" class="form-control" placeholder="Search...">
                    <span class="input-group-btn">
                    <button class="btn btn-default" type="button">
                        <i class="fa fa-search"></i>
                    </button>
                </span>
                </div>
                <!-- /input-group -->
            </li> --}}
            <li>
                <a href="{{url('admin/home')}}"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
            </li>
            <li>
                <a href="#"><i class="fa fa-tags fw"></i> Catalog<span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="{{ url('admin/category') }}">Categories</a>
                    </li>
                    <li>
                        <a href="{{ url('admin/manufacturer') }}">Manufacturer</a>
                    </li>
                    <li>
                        <a href="{{ url('admin/option') }}">Option</a>
                    </li>
                    <li>
                        <a href="{{ url('admin/product') }}">Product</a>
                    </li>
                    <li>
                        <a href="{{ url('admin/stock') }}">Stock</a>
                    </li>
                    <li>
                        <a href="#" class="parent collapsed">
                            Attribute
                            <span class="fa arrow"></span>
                        </a>
                        <ul class="nav nav-third-level">
                            <li>
                                <a href="{{ url('admin/attribute') }}">
                                    Attribute
                                </a>
                            </li>
                            <li>
                                <a href="{{ url('admin/attribute-group') }}">
                                    Attribute Group
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="{{ url('admin/discussion') }}">Discussion</a>
                    </li>
                    <li>
                        <a href="{{ url('admin/review') }}">Review</a>
                    </li>
                </ul>
                <!-- /.nav-second-level -->
            </li>
            <li>
                <a href="#"><i class="fa fa-shopping-cart fw"></i> Sales<span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="{{ url('admin/order') }}"> Order</a>
                    </li>
                    <li>
                        <a href="#" class="parent collapsed">
                            Gift Vouchers
                            <span class="fa arrow"></span>
                        </a>
                        <ul class="nav nav-third-level">
                            <li>
                                <a href="{{ url('admin/vouchers') }}">
                                    Gift Vouchers
                                </a>
                            </li>
                            <li>
                                <a href="{{ url('admin/voucher-theme') }}">
                                    Voucher Themes
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <!-- /.nav-second-level -->
            </li>
            <li>
                <a href="#"><i class="fa fa-user fw"></i> Customer<span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="{{ url('admin/customer') }}"> Customer</a>
                    </li>
                    <li>
                        <a href="{{ url('admin/customer-group') }}"> Customer Group</a>
                    </li>
                </ul>
                <!-- /.nav-second-level -->
            </li>
            <li>
                <a href="#"><i class="fa fa-share-alt fw"></i> Marketing<span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="{{ url('admin/coupon') }}"> Coupon</a>
                    </li>
                    <li>
                        <a href="{{ url('admin/product-group') }}"> Product Group</a>
                    </li>
                </ul>
                <!-- /.nav-second-level -->
            </li>
            <li>
                <a href="{{ url('admin/blog') }}">
                    <i class="fa fa-list-alt"></i> Blog
                </a>
            </li>
            @can('manage admin')
            <li>
                <a href="#"><i class="fa fa-cog fw"></i> System<span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="{{ url('admin/shipping-method') }}">Shipping Method</a>
                    </li>
                    <li>
                        <a href="{{ url('admin/payment-method') }}">Payment Method</a>
                    </li>
                    <li>
                        <a href="{{ url('admin/admin') }}">Admin</a>
                    </li>
                </ul>
                <!-- /.nav-second-level -->
            </li>
            @endcan
            
        </ul>
    </div>
    <!-- /.sidebar-collapse -->
</div>
<!-- /.navbar-static-side -->