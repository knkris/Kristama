<div class="details grey-bg">
    <div class="container">
        <div class="row" style="padding:30px 0;">
            <div class="col-lg-12 col-sm-12 col-xs-12">
                <h3><span class="red">Produk </span> Rekomendasi</h3>
            </div>
            <div class="panel ic-recomend-product">
                @foreach($recommended_products as $recommended)
                    <?php $product=$recommended->Product; ?>
                    <div class="ic-pr-col text-center">
                        <a href="{{ url($product->slug) }}">
                        @if($product->Image->count())
                            <div class="img-container">
                                <img src="{{ $product->Image->first()->image }}" alt="{{ $product->name }}"  class="product-search-height"/>
                            </div>
                        @else
                            <div class="img-container">
                                <img src="http://via.placeholder.com/350x150" alt="{{ $product->name }}"  class="product-search-height"/>
                            </div>
                        @endif
                        <h4>{{ $product->name }}<br><span>{{ $product->model }}</span></h4>
                        @for($x=0;$x<$product->Star();$x++)
                        <i class="fa fa-star" aria-hidden="true"></i>
                        @endfor
                        @for($x=$product->Star();$x<5;$x++)
                        <i class="fa fa-star-o" aria-hidden="true"></i>
                        @endfor
                        @if (Auth::check())
                        <h4 class="red">{{ currency_format($product->finalPrice(Auth::user()->id,1),'IDR') }}<br><span>{{ currency_format($product->price,'IDR') }}</span></h4>
                        @else
                        <h4 class="red">{{ currency_format($product->finalPrice(1,1),'IDR') }}<br><span>{{ currency_format($product->price,'IDR') }}</span></h4>
                        @endif
                        </a>
                    </div>
                    @endforeach

            </div>
        </div>
    </div>
</div>