<!---- Footer Start ---->
<section id="footer">
	<div class="container">
		<div class="row">
			<div class="col-lg-4 col-xs-12 col-sm-4">
				<h3><span>KREASI2SHOP</span></h3>
				<ul>
					<li><a href="tentang-kami.html">Tentang kami</a></li>
					<li><a href="kenapa-beli-di-kreasi2shop.html">Kenapa beli di Kreasi2shop?</a></li>
					<li><a href="hubungi-kami.html">Hubungi Kami</a></li>
					<li><a href="lokasi-mitra-kami.html">Lokasi Mitra Kami</a></li>
					<li><a href="lokasi-service-center.html">Lokasi Service Center</a></li>
				</ul>
			</div>	
			<div class="col-lg-4 col-xs-12 col-sm-4">
				<div class="center-side">
					<h3><span>FAQ SUPPORT</span></h3>
					<ul>
						<li><a href="umum.html">Umum</a></li>
						<li><a href="akun.html">Akun</a></li>
						<li><a href="cara-belanja.html">Cara Belanja</a></li>
						<li><a href="garansi.html">Garansi</a></li>
						<li><a href="pembayaran.html">Pembayaran</a></li>
						<li><a href="pengiriman.html">Pengiriman</a></li>
						<li><a href="refund-retur-produk.html">Refund /  Retur Produk</a></li>
						<li><a href="form-retur.html">Form Retur</a></li>
						<li><a href="kupon-diskon.html">Kupon Diskon</a></li>
					</ul>
				</div>	
			</div>	
			<div class="col-lg-4 col-xs-12 col-sm-4">
				<div class="right-side">
					<h3><span>CONTACT US</span></h3>
					<p>Kreasi2Shop<br>
					Jl. Daan Mogot No. 111<br>
					Grogol Petamburan<br>
					Jakarta Barat<br>
					11460<br>
					<a href="tel:22561357">(021) - 2256 1357</a><br>
					<a href="mailto:cs@kreasiduashop.com">cs@kreasiduashop.com</a></p>
				</div>	
			</div>	
		</div>	
	</div>       
</section>
<!---- Footer End ---->