<!---- Header Start ---->
<section id="header">
	<div class="top-head">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 text-right hidden-xs col-xs-12 col-sm-12">
					<p><a href="#">Sign In</a> <span>/</span> <a href="#">Sign Up</a><img src="images/user.png" alt=""/></p>
				</div>
			</div>
		</div>		
	</div>
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-xs-12 text-center col-sm-12">
				<a class="top-space" href="index.html"><img src="{{ asset('blog-asset/images/logo.png') }}" alt=""/></a>
			</div>
			<div class="col-lg-12 col-xs-12 text-center col-sm-12">
				<nav class="navbar navbar-default navbar-static-top" role="navigation">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
					</div>
					<div id="navbar" class="navbar-collapse collapse">
						<ul class="nav navbar-nav">
							<li class="hidden-xs"><a id="OpenMenu" href="#"><i class="fa fa-bars" aria-hidden="true"></i></a></li>
							<li class=""><a href="index.html"><img src="images/icon-1.png" alt=""/> Home</a></li>
							<li><a href="shop.html"><img src="images/icon-2.png" alt=""/> Shop</a></li>
							<li><a href="blog.html"><img src="images/icon-3.png" alt=""/> blog</a></li>
							<li><a href="news.html"><img src="images/icon-4.png" alt=""/> News</a></li>
							<li class="hidden-xs"><a href="#"><input type="search"/></a></li>
						</ul>
					</div><!--/.nav-collapse -->
				</nav> 
			</div>	
			<a id="OpenMenu2" class="hidden-sm hidden-lg hidden-md" href="#"><i class="fa fa-bars" aria-hidden="true"></i></a>
			<div class="col-lg-6 col-lg-offset-1 col-xs-offset-0 col-xs-12 col-sm-12">
				<div id="ShowMenu" class="mobile-menu">
					<h5><b>Sort by</b></h5>
					<p>
						<span><i class="fa fa-star" aria-hidden="true"></i> Trending</span>
						<span><i class="fa fa-bolt" aria-hidden="true"></i> Popular</span>
					</p>
					<h5><b>Sections</b></h5>
					<div class="col-lg-12 flush col-xs-12 col-sm-12">
						<div class="col-lg-4 col-sm-4 col-xs-12">
							<ul>
								<li><a href="food.html">Food</a></li>
								<li><a href="fashion.html">Fashion</a></li>
								<li><a href="recipe.html">Recipe</a></li>
								<li><a href="product-review.html">Product Review</a></li>
								<li><a href="game.html">Game</a></li>
								<li><a href="manga.html">Manga</a></li>
							</ul>
						</div>
						<div class="col-lg-4 text-center col-sm-4 col-xs-12">
							<ul>
								<li><a href="cosplay.html">Cosplay</a></li>
								<li><a href="music.html">Music</a></li>
								<li><a href="lifestyle.html">Lifestyle</a></li>
								<li><a href="cafe-resto.html">Cafe /  Resto</a></li>
								<li><a href="gadget.html">Gadget</a></li>
								<li><a href="culture.html">Culture</a></li>
							</ul>
						</div>
						<div class="col-lg-4 col-sm-4 col-xs-12">
							<div class="right-side">
								<ul>
									<li><a href="in-ex-terior.html">In / Ex - terior</a></li>
									<li><a href="art.html">Art</a></li>
									<li><a href="diy.html">DIY</a></li>
									<li><a href="sport.html">Sport</a></li>
									<li><a href="movie.html">Movie</a></li>
									<li><a href="entertaiment.html">Entertaiment</a></li>
								</ul>
							</div>	
						</div>
					</div>
				</div>
			</div>
		</div>	
	</div>       
</section>
<!---- Header End ---->