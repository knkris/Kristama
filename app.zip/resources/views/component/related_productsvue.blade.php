<div class="details grey-bg">
    <div class="container">
        <div class="row" style="padding:30px 0;">
            <div class="col-lg-12 col-sm-12 col-xs-12">
                <h3><span class="red">Produk </span> Rekomendasi</h3>
            </div>
            <div class="panel ic-recomend-product">
                <div v-for="item in recommended" class="ic-pr-col text-center">
                    <a :href="'{{url('/')}}/'+item.product.slug">
                        <div class="img-container">
                            <img v-lazy="item.product.img" :alt="item.product.name"  class="product-search-height"/>
                        </div>
                        <h4>@{{ item.product.name }}</h4>
						<!-- <p>@{{ item.product.model }}</p> -->
                        <i v-for="index in 5" :class="{ 'fa fa-star': index <= item.product.star, 'fa fa-star-o': index > item.product.star }"class="fa fa-star-o" aria-hidden="true"></i>
                        <h4 class="red">@{{ item.product.final_price }}<br><span>@{{ item.product.price_format }}</span></h4>
                    </a>
                </div>


            </div>
        </div>
    </div>
</div>