<div class="slide">
	<ul class="bxslider">
		@foreach($parent as $key => $value)
		<?php
		$class=$key+1;
		$classlabel;
		$img;
		switch ($class) {
			case 1:
				$classlabel='Home';
				$img=$class;
				break;

			case 5:
				$classlabel=$value->name;
				$img=1;
				break;

			case 6:
				$classlabel=$value->name;
				$img=2;
				break;
			
			default:
				$classlabel=$value->name;
				$img=$class;
				break;
		}
		?>
		<li><a href="#shop-{{$class}}" data-toggle="tooltip" data-placement="left" title="{{ucfirst($classlabel)}}"><img src="img/side-{{$img}}.png" alt=""/></a></li>
		@endforeach
		
	</ul>
</div>