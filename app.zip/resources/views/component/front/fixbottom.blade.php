<div class="fixed">
	<ul>
		<li><a href="{{ route('dashboard')}}" data-toggle="tooltip" data-placement="top" title="My Account"><img src="img/dashboard-1.png" alt="" width="40px;" /></a></li>
		<li><a href="#" data-toggle="tooltip" data-placement="top" title="Dashboard"><img src="img/dashboard-2.png" alt="" width="40px;" /></a></li>
		<li><a href="#" data-toggle="tooltip" data-placement="top" title="Account Setting"><img src="img/dashboard-3.png" alt="" width="40px;" /></a></li>
		<li><a href="{{ route('address') }}" data-toggle="tooltip" data-placement="top" title="My Address"><img src="img/dashboard-2.png" alt="" width="40px;" /></a></li>
	</ul>
</div>