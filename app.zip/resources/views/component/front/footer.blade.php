<section id="footer">
	<div class="container">
		<div class="row">
			<div class="col-lg-4 col-xs-12 col-sm-4">
				<h3><span>KREASI2SHOP</span></h3>
				<ul>
					<li><a href="{{ url('tentang-kami') }}">Tentang kami</a></li>
					<li><a href="{{ url('faq/kenapa-beli') }}">Kenapa beli di Kreasi2shop?</a></li>
					<li><a href="{{ url('faq/hubungi-kami') }}">Hubungi Kami</a></li>
					<li><a href="{{ url('faq/mitra-kami') }}">Lokasi Mitra Kami</a></li>
					<li><a href="{{ url('faq/service-center') }}">Lokasi Service Center</a></li>
				</ul>
			</div>	
			<div class="col-lg-4 col-xs-12 col-sm-4">
				<div class="center-side">
					<h3><span>FAQ SUPPORT</span></h3>
					<ul>
						<li><a href="{{ url('faq/umum') }}">Umum</a></li>
						<li><a href="{{ url('faq/akun') }}">Akun</a></li>
						<li><a href="{{ url('faq/cara-belanja') }}">Cara Belanja</a></li>
						<li><a href="{{ url('faq/garansi') }}">Garansi</a></li>
						<li><a href="{{ url('faq/pembayaran') }}">Pembayaran</a></li>
						<li><a href="{{ url('faq/pengiriman') }}">Pengiriman</a></li>
						<li><a href="{{ url('faq/retur') }}">Refund /  Retur Produk</a></li>
						<li><a href="{{ url('faq/form-retur') }}">Form Retur</a></li>
						<li><a href="{{ url('faq/kupon-diskon') }}">Kupon Diskon</a></li>
					</ul>
				</div>	
			</div>	
			<div class="col-lg-4 col-xs-12 col-sm-4">
				<div class="right-side">
					<h3><span>CONTACT US</span></h3>
					<p>Kreasi2Shop<br>
					Jl. Daan Mogot No. 111<br>
					Grogol Petamburan<br>
					Jakarta Barat<br>
					11460<br>
					<a href="tel:22561357">(021) - 2256 1357</a><br>
					<a href="mailto:cs@kreasiduashop.com">cs@kreasiduashop.com</a></p>
				</div>	
			</div>	
		</div>	
	</div>     
</section>