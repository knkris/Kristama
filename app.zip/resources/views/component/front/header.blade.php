<!---- Header Start ---->
<section id="header" class="landing b-none home">
	<div class="ic-fixed-nav">
		<a class="flush-left ic-nav-icon"><img src="{{ url('img/icon-4.png') }}" alt=""/></a>
		<div class="ic-mobile-nav">
			<div class="ic-open">
				<div class="ic-mbl-nav">
					<div class="ic-close-icon text-right">
						&#10006;
					</div>
					<div class="ic-logo">
						<a class="logo" href="{{ route('index') }}"><img class="high-max" src="{{ url('img/logo-2.png') }}" alt=""/></a>
					</div>
					<div class="ic-collapsible-nav">
						<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
							@foreach($navbarCat as $key => $value)

								<div class="panel panel-default">
									<div class="panel-heading" role="tab" id="icNavCat{{ $key }}">
										<h4 class="panel-title">
											<a role="button" data-toggle="collapse" data-parent="#accordion" href="#icNavCollapse{{ $key }}" aria-expanded="true" aria-controls="icNavCollapse{{ $key }}">
												{{ $value->name }}
											</a>
										</h4>
									</div>

									<div id="icNavCollapse{{ $key }}" class="panel-collapse collapse @if($key==1){{ 'in' }} @endif" role="tabpanel" aria-labelledby="icNavCat{{ $key }}">
										<div class="panel-body">
											<ul class="ic-sm-items">
                                                <?php
                                                	$childs=\App\Models\Category::whereParent_id($value->id)->get();
                                                ?>
												@foreach($childs as $val)
													<li><a href="{{ url('search/'.$val->slug) }}"><i class="fa fa-angle-right"></i> {{ $val->name }}</a></li>
												@endforeach

											</ul>
										</div>
									</div>
								</div>
							@endforeach
						</div>
						<div class="ic-shop-blog">
							<ul>
								<li><a href="{{ route('blog') }}">Kreasi <img src="http://kreasi2shop.itclanbd.com/img/icon-5.png" alt=""></a></li>
								<li><a href="{{ route('index') }}">Shop <img src="http://kreasi2shop.itclanbd.com/img/icon-6.png" alt=""></a></li>
							</ul>
						</div>
						<div class="ic-user-access-nav">
							<a href="{{ route('sign.in') }}">Sign In</a>
							<a href="{{ route('sign.up') }}">Sign Up</a>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row">
			<div class="col-lg-4 col-xs-12 col-sm-4">

			</div>
			<div class="col-lg-4 text-center col-xs-12 col-sm-4 ic-xs-logo">
				<a class="logo" href="{{ route('index') }}"><img class="high-max" src="{{ url('img/logo-2.png') }}" alt=""/></a><br>
				<div class="link">
					@if(strpos(url()->current(), url('blog')) !== false)
					<a class="active border-right" href="{{ route('blog') }}">Kreasi <img src="{{ url('img/icon-5.png') }}" alt=""/></a>
					<a class="" href="{{ route('index') }}">Shop <img src="{{ url('img/icon-6.png') }}" alt=""/></a>
					
					@else
					<a class="border-right" href="{{ route('blog') }}">Kreasi <img src="{{ url('img/icon-5.png') }}" alt=""/></a>
					<a class="active" href="{{ route('index') }}">Shop <img src="{{ url('img/icon-6.png') }}" alt=""/></a>
					@endif
				</div>
			</div>
			<div class="col-lg-4 text-right col-xs-12 col-sm-4 ic-sm-sign">
				<p class="inline">
					@guest
					<a href="{{ route('sign.in') }}">Sign In</a> <span>/</span>
					<a href="{{ route('sign.up') }}">Sign Up</a>
					@else
					{{ Auth::user()->name }}
					<span>
						<div class="dropdown">
							<button id="dLabel" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								{{-- <img src="{{ url('img/icon-2.png') }}') }}" alt=""/> --}}
								@if(Auth::user()->avatar==null)
								<img src="https://www.gravatar.com/avatar/{{ md5(strtolower(Auth::user()->email)) }}.jpg?s=200&d=mm" alt="" style="max-width:40px;max-height:40px;border-radius:100%;" />
								@else
								<img src="{{ Auth::user()->avatar }}" alt="" style="max-width:40px;max-height:40px;border-radius:100%;" />
								@endif
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu ic sign-drop" aria-labelledby="dLabel">
								<li><a href="{{  route('dashboard') }}">My Account</a></li>
								<li class="ic-submenu"><a href="{{ route('orderhistory')}}">Dashboard</a>
									<ul>
										<li><a href="{{ url('my-order') }}">Orders</a></li>
										<li><a href="{{ url('my-return') }}">Returns</a></li>
									</ul>
								</li>
								<li><a href="{{ url('wishlist') }}">Wishlist</a></li>
								<li class="ic-submenu"><a href="#">Support</a>
									<ul>
										<li><a href="{{ url('tentang-kami') }}">About us</a></li>
										<li><a href="{{ url('faq/hubungi-kami') }}">Contact us</a></li>
										<li><a href="{{ url('faq/umum') }}">FAQ support</a></li>
										<li><a href="{{ url('support-issue') }}">Issue</a></li>
										<li><a href="{{ url('support-email-preference') }}">Email preferences</a></li>
									</ul>
								</li>
								<li>
									<a href="{{ route('logout') }}"
                                        onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                        Sign out
                                    </a>
									<form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        {{ csrf_field() }}
                                    </form></li>
							</ul>
						</div>
					</span>
					@endguest
				</p>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<ul>
					<li class="fi dropdown mega-dropdown col-lg-1 border-right text-center flush col-sm-2 col-xs-2 dropdown ic-open ic-sm-none">
						<a class="flush-left dropdown-toggle" data-toggle="dropdown" href="#"><img src="{{ url('img/icon-4.png') }}" alt=""/></a>
							<ul class="dropdown-menu mega-dropdown-menu row">
								@foreach($navbarCat as $key => $value)

								<li>
									<span>
										<img src="{{ $value->image }}" alt="nav icon">
									</span>
									{{ $value->name }}

									<ul>
										<?php 
										$childs=\App\Models\Category::whereParent_id($value->id)->get();
										?>
										@foreach($childs as $val)
										<li class="{{ $val->slug }}" data-category="{{ $val->slug }}"">
											<a href="{{ url('search/'.$val->slug) }}">
												<span>
													<img src="{{ $val->image }}" alt="{{ $val->name }}">
												</span>
												{{ $val->name }}
											</a>
										</li>
										@endforeach
									</ul>
								</li>
								@endforeach
								
							</ul>
					</li>
					<li class="col-lg-10 sd col-sm-8 col-xs-8 ic-sm-12 ic-xs-search">
						<form id="navbar-search" action="{{ url('search') }}" method="get">
							<div class="col-lg-11 col-sm-10 flush col-xs-8 ic-xs-search-input">
								<input type="search" id="navbar-search-input" class="form-control"  name="q" placeholder="Cari produk disini..." />
							</div>
							<div class="col-lg-1 col-sm-2 col-xs-4 flush ic-xs-search-submit">
								<button type="submit"><img src="{{ url('img/icon-3.png') }}" alt=""/></button>
							</div>
						</form>
					</li>
					<li id="cart-blog" class="col-lg-1 text-center flush col-sm-2 col-xs-2 ic-cart">
						<a href="{{ route('cart') }}"><span class="typcn typcn-shopping-cart" style="    font-size: 60px;
    color: white;
    position: absolute;
    top: -20px;
    right: 57px;"></span></a>
						<!-- <a href="{{ route('cart') }}"><img class="cart-icon" src="{{ url('img/cart.svg') }}" alt=""/></a> -->
						@if(Auth::check())
						<?php 
						$user=\App\Models\User::find(Auth::user()->id);
						$cart=$user->Cart;
						?>
						<div class="total-item"><span>{{ $user->CartQty() }}</span></div>
						<ul class="ic-cart-items">
							@if(count($cart))
							@foreach($cart as $key => $value)
							<?php
							$product=$value->Product;
							?>
							@if($product)
							<li>
								<a href="{{ url($product->slug) }}">
									<span><img src="{{ $product->Image->first()->image }}" alt="{{ $product->name }}"/></span>
									<span>{{ $product->name }} <br>{{ $product->model }}</span>
									<span>{{ currency_format($product->price_filter, 'IDR') }}</span>
								</a>
							</li>
							@endif
							@endforeach
							@else
							<li>Keranjang belanja kosong</li>
							@endif
							<li><a href="{{ url('cart') }}">Tampilkan semua keranjang</a></li>
						</ul>
						@else
						<div class="total-item"><span>0</span></div>
						<ul class="ic-cart-items">
							<li>Keranjang belanja kosong</li>
							<li><a href="#">Tampilkan semua keranjang</a></li>
						</ul>
					
						@endif
					</li>
					<!-- <li id="account-blog"class="dropdown right">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><img src="{{ url('img/icon-2.png') }}" alt=""></a>
						<ul class="dropdown-menu ic sign-drop" aria-labelledby="dLabel">
							<li><a href="{{  route('dashboard') }}">My Account</a></li>
							<li class="ic-submenu"><a href="{{  route('dashboard') }}">Dashboard</a>
								<ul>
									<li><a href="{{ url('order-history') }}">Orders</a></li>
									<li><a href="#">Returns</a></li>
								</ul>
							</li>
							<li><a href="#">Wishlist</a></li>
							<li class="ic-submenu"><a href="#">Support</a>
								<ul>
									<li><a href="{{ url('tentang-kami') }}">About us</a></li>
									<li><a href="{{ url('faq/hubungi-kami') }}">Contact us</a></li>
									<li><a href="{{ url('faq/umum') }}">FAQ support</a></li>
									<li><a href="{{ url('support-issue') }}">Issue</a></li>
									<li><a href="{{ url('support-email-preference') }}">Email preferences</a></li>
								</ul>
							</li>
							<li><a href="{{ route('logout') }}"
								onclick="event.preventDefault();
										 document.getElementById('logout-form').submit();">
								Sign out
							</a>
							<form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
								{{ csrf_field() }}
							</form></li>
						</ul>
					</li> -->
				</ul>
			</div>
		</div>
	</div>
</section>

<section id="header" class="small-header">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-xs-12 col-sm-12">
				<nav class="navbar navbar-default navbar-static-top" role="navigation">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<div id="logo" class="navbar-brand">
							<a class="hidden-sm hidden-lg hidden-md" href="index.html"><img src="{{ url('img/logo.png') }}" alt="logo-kreasi" width="150px;"></a>
						</div>
					</div>
					<div id="navbar" class="navbar-collapse collapse">
						<ul class="nav navbar-nav">
							<li class="fi dropdown mega-dropdown">
								<a class="flush-left dropdown-toggle" data-toggle="dropdown" href="#"><img src="{{ url('img/icon-4.png') }}" alt=""></a>
								<ul class="dropdown-menu mega-dropdown-menu row">
									@foreach($navbarCat as $key => $value)

								<li>
									<span>
										<img src="{{ $value->image }}" alt="nav icon">
									</span>
									{{ $value->name }}

									<ul>
										<?php 
										$childs=\App\Models\Category::whereParent_id($value->id)->get();
										?>
										@foreach($childs as $val)
										<li class="{{ $val->slug }}" data-category="{{ $val->slug }}"">
											<a href="{{ url('search/'.$val->slug) }}">
												<span>
													<img src="{{ $val->image }}" alt="{{ $val->name }}">
												</span>
												{{ $val->name }}
											</a>
										</li>
										@endforeach
									</ul>
								</li>
								@endforeach

								</ul>
							</li>
							<li class="hidden-sm sd"><a href="{{ route('index') }}"><img src="{{ url('img/logo.png') }}" alt="" width="150px;"></a></li>
							<li class="xs-search">
								<div class="search">
									<form id="navbar-search-2" action="{{ url('search') }}" method="get">
										<input type="search" id="navbar-search-input-2" class="form-control"  name="q" placeholder="Cari produk disini..." />
										<button type="submit"><img src="{{ url('img/icon-3.png') }}" alt=""></button>
									</form>
								</div>
							</li>
							<li id="cart-blog-hide"><a href="{{ route('cart') }}"><img class="cart-icon" style="margin: 5px 0 0 13px;" src="{{ url('img/icon-1.png') }}" alt=""></a>
								
							</li>
							@guest
							@else
							<li class="dropdown right">
								<a href="#" class="dropdown-toggle icon-height" data-toggle="dropdown" aria-expanded="false" ><img src="{{ url('img/icon-2.png') }}" alt=""></a>
								<ul class="dropdown-menu ic sign-drop" aria-labelledby="dLabel">
									<li><a href="{{  route('dashboard') }}">My Account</a></li>
									<li class="ic-submenu"><a href="{{ url('dashboard-orders') }}">Dashboard</a>
										<ul>
											<li><a href="{{ url('my-order') }}">Orders</a></li>
											<li><a href="{{ url('my-return') }}">Returns</a></li>
										</ul>
									</li>
									<li><a href="{{ url('wishlist') }}">Wishlist</a></li>
									<li class="ic-submenu"><a href="#">Support</a>
										<ul>
											<li><a href="{{ url('tentang-kami') }}">About us</a></li>
											<li><a href="{{ url('faq/hubungi-kami') }}">Contact us</a></li>
											<li><a href="{{ url('faq/umum') }}">FAQ support</a></li>
											<li><a href="{{ url('support-issue') }}">Issue</a></li>
											<li><a href="{{ url('support-email-preference') }}">Email preferences</a></li>
										</ul>
									</li>
									<li><a href="{{ route('logout') }}"
                                        onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                        Sign out
                                    </a>
									<form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        {{ csrf_field() }}
                                    </form></li>
								</ul>
							</li>
							@endguest
						</ul>
					</div><!--/.nav-collapse -->
				</nav>
			</div>
		</div>
	</div>
</section>
<!---- Header End ---->
