<div id="details">
    <div class="ic-container">
        <div class="ic-blog-head">
            <h3><span class="red">Blog </span> Kami</h3>
            <a href="https://k2s.playit.tech/blog" class="ic-blog-detail"><img src="https://s22.postimg.cc/mqzpggxbl/ic-blog-detail.jpg" alt=""></a>
        </div>
        <div class="container flush">
            @foreach ($blogs as $key => $blog)
            <div class="col-md-4 col-lg-4 col-xs-12">
                <div class="food">
                    <div class="images">
                        <img class="high" src="{{ $blog->image}}" alt="{{ $blog->title }}"/>
                        <span>{{ strlen($blog->category) ? strtoupper($blog->category) : 'BLOG' }}</span>
                    </div>
                    <div class="white-overlay">
                        <h5>{{ $blog->title }}</h5>
                        <span>By {{ $blog->Admin->name }} - {{ \Carbon\Carbon::parse($blog->created_at)->diffForHumans() }}</span>
                        <!--<p>@{{ item.paragrah }}</p> -->
                        <br><a href="{{ url('blog/'.$blog->slug) }}">Read More <!-- <i class="fa fa-caret-right" aria-hidden="true"></i> --></a>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</div>