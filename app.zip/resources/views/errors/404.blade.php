@extends('layouts.front')

@section('title')
	Not Found
@endsection

@section('head')

@endsection

@section('content')
<section id="content" class="error">
	<div class="tableRow">
		<div class="tableCell">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 text-center col-xs-12 col-sm-12">
						<img src="img/error.png" alt=""/>
						<h5>HALAMAN TIDAK DAPAT DITEMUKAN</h5>
						<a class="btn-success" href="{{url('/')}}">Back to Home</a>
					</div>	
				</div>	
			</div>
		</div>			
	</div>
</section>
@include('component.front.footer')
@endsection

@section('script')

@endsection