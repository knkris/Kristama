@extends('layouts.front')

@section('title')
	Maintenance
@endsection

@section('head')

@endsection

@section('content')
<!---- Content Start ---->
<section id="content" class="error">
	<div class="tableRow">
		<div class="tableCell">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 text-center col-xs-12 col-sm-12">
						<img src="img/img-1.png" alt=""/>
						<h5>MOHON MAAF, HALAMAN INI SEDANG DALAM PERBAIKAN</h5>
						<a class="btn-success" href="index.html">Back to Home</a>
					</div>	
				</div>	
			</div>
		</div>			
	</div>
</section>
<!---- Content End ---->
@include('component.front.footer')
@endsection

@section('script')

@endsection