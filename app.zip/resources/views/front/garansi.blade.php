@extends('layouts.front')

@section('title')
	Garansi
@endsection

@section('head')

@endsection

@section('content')
<!---- Content Start ---->
<section id="content" style="padding-bottom:60px;">
	<div class="title-head">
		<div class="container">
			<div class="row">
				<div class="col-lg-12  col-xs-12 col-sm-12">
					<h3>Garansi</h3>
				</div>
			</div>
		</div>		
	</div>
</section>
<section id="Pertanyaan-Umum" style="padding-bottom:60px;">
<div class="row">
		<div class="col-lg-10 col-lg-offset-1 col-md-10 col-md-offset-1">
			<div class="col-lg-3">
				<h3 style="margin-top:0px;"><strong>FAQ SUPPORT</strong></h3>
				<hr>
				<a href="{{url('faq/form-retur')}}"><p>Form Retur</p></a>
				<hr>
				<a href="{{url('faq/retur')}}"><p>Refund / Retur</p></a>
				<hr>
				<div class="dropdown">
				<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Serangkaian Pertanyaan Umum<span class="caret"></span></button>
				<ul class="dropdown-menu">
				<li><a title="General" href="https://k2s.playit.tech/faq/status-pesanan">Status pesanan</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/umum">Umum</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/akun">Akun</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/cara-belanja">Cara Belanja</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/garansi">Garansi</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/pembayaran">Pembayaran</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/pengiriman">Pengiriman</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/retur">Refund</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/retur">Retur Produk</a></li>
				<li><a title="General" href="#">Tiket</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/kupon-diskon">Kupon Diskon</a></li>
				</ul>
				</div>
			</div>
			<div class="col-lg-9">
				<div>
				<h3>Garansi</h3>
				<p>Pelanggan Yang Terhormat,</p>
				<p>Kami informasikan mengenai Garansi Online Shop adalah:</p>
				<ul style="padding-left: 40px;">
				<li>Garansi yang diberikan hanya oleh Kreasi2shop untuk meyakinkan pelanggan bahwa produk yang dibeli adalah produk yang berkualitas</li>
				<li>Yang bergaransi 7 hari hanya bagian suku cadang tertentu seperti yang ditulis pada keterangan. Bagian lain yang tidak ditulis tidak digaransi.</li>
				<li>Daya tahan suatu produk tergantung dari aturan/cara pemakaian dan tidak digaransikan oleh Kreasi2shop sebagai reseller.</li>
				<li>KERUSAKAN FISIK/FUNGSINYA akibat kelalaian pihak pembeli ataupun agen pengiriman tidak termasuk dalam garansi Kreasi2shop.</li>
				<li>7 hari adalah waktu yang cukup untuk memeriksa/mengetahui suatu produk pabrikan dinyatakan buruk</li>
				<li>Apabila dalam masa garansi 7 hari terjadi kerusakan/kegagalan suatu produk, barang akan langsung diganti dengan yang baru tanpa harus menunggu dalam daftar Service Center dan ongkir bolak baliknya akan ditanggung Kreasi2shop</li>
				<li>Apabila dalam pemeriksaan teknisi, kerusakan/kegagalan produk dinyatakan akibat kelalaian pemakaian maka masa garansi tidak berlaku lagi dan harus menunggu dalam daftar Service Center. Dan pelanggan akan dikenakan biaya service + ongkir bolak baliknya.</li>
				<li>Biaya reparasi dan suku cadang akan diinformasikan ke pelanggan sebelumnya.</li>
				<li>Hasil pemeriksaan teknisi Service Center adalah mutlak penjelasan teknikal dan tidak untuk diperdebatkan.</li>
				<li>Jika termasuk kategori reparasi, Service Center tidak menanggung biaya pengiriman apapun.</li>
				<li>Kreasi2shop akan memperpanjang waktu garansi 7 hari hingga batas waktu tertentu apabila suatu produk terindikasi adanya penurunan kualitas dan sebagainya.</li>
				</ul>
				</div>	
			</div>
			<hr>
		</div>
</div>
</section>
<!-- Content End-->
@include('component.front.footer')
@endsection

@section('script')

@endsection