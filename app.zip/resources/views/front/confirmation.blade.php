@extends('layouts.front')

@section('title')
	Pesanan Berhasil dibuat
@endsection

@section('first_head')
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.1.8/semantic.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.1.8/semantic.min.js"></script>

@endsection

@section('head')
	
	
	<style type="text/css">
		.ui.label, .ui.labels .label {
		    white-space: normal;
		    text-align: left;
		}
	</style>
@endsection

@section('content')
<!---- Content Start ---->
<section id="content" class=" bg-none">
	<div class="title-head">
		<div class="container">
			<div class="row">
				<div class="col-lg-12  col-xs-12 col-sm-12">
					<h3>Confirmation Page</h3>
				</div>
			</div>
		</div>		
	</div>
	<div class="white-bg">
		<div class="container">
			<div class="thankyou">
				<h4>Thank you, your order has been placed.</h4>
				<div class="">
					<div  class="field">
						<div class="col-lg-4 flush col-sm-3 col-xs-5">
							<label>Order Number:</label>
						</div>
						<div class="col-lg-8 col-sm-9 col-xs-7">
							<label>#{{ $store->invoice }}</label>
						</div>
					</div>
					<div  class="field">
						<div class="col-lg-4 flush col-sm-3 col-xs-5">
							<label>Date:</label>
						</div>
						<div class="col-lg-8 col-sm-9 col-xs-7">
							<label>{{ \Carbon\Carbon::parse($store->created_at)->format('d/m/Y') }}</label>
						</div>
					</div>
					<div class="field top-space">
						<div class="col-lg-4 flush col-sm-3 col-xs-5">
							<label>Estimated delivery:</label>
						</div>
						<div class="col-lg-8 col-sm-9 col-xs-7">
							<label>{{ \Carbon\Carbon::parse($store->created_at)->addDays(3)->format('d/m/Y') }}</label>
						</div>
					</div>
					<div  class="field">
						<div class="col-lg-4 flush col-sm-3 col-xs-5">
							<label>Shipped to:</label>
						</div>
						<div class="col-lg-8 col-sm-9 col-xs-7">
							<label>{{ $store->shipping_name }}<br>
							{{ $store->shipping_address }}<br>
							{{ $store->shipping_city }}<br>
							{{ $store->shipping_province }}<br>
							{{ $store->shipping_postal_code }}</label>
						</div>
					</div>
					@if($store->payment_method=='Bank Transfer')
					<div  class="field">
						<div class="col-lg-4 flush col-sm-3 col-xs-5">
							<label>Unique Code:</label>
						</div>
						<div class="col-lg-8 col-sm-9 col-xs-7">
							<label>{{ currency_format($store->transfer_code, 'IDR') }}</label>
						</div>
					</div>
					<div  class="field">
						<div class="col-lg-4 flush col-sm-3 col-xs-5">
							<label>Total:</label>
						</div>
						<div class="col-lg-8 col-sm-9 col-xs-7">
							<label>{{ currency_format($store->total, 'IDR') }}</label>
						</div>
					</div>
					<div class="info-transfer">
						<p>
						Please make sure you make transfer to this account number:<br>
						<br>
						1. BCA (Bank Central Asia)<br>
						Account Number : 8350230999<br>
						A/N : PT Kreasi Dua Indonesia<br>
						<br>
						2. BNI (Bank Negara Indonesia)<br>
						Account Number : 5664790008<br>
						A/N : PT Kreasi Dua Indonesia
						</p>
					</div>
					@endif
					<?php
				  	$inv=explode('/', $store->invoice);
				  	?>
					<div  class="field">
						<div class="col-lg-12 text-right col-sm-12 col-xs-12">
							<a class="btn-success" href="#">Print Invoice</a>
							<a class="btn-success" href="{{ route('order.show', $inv[2]) }}">See Details</a>
						</div>
					</div>
				</div>
				@switch($store->bank_code)
				    @case('CENA')
				        <div class="col-lg-11 col-lg-offset-1 col-sm-12 col-xs-12">
							@include('front.va.bca')
						</div>
				        @break

				    @case('BMRI')
				        <div class="col-lg-11 col-lg-offset-1 col-sm-12 col-xs-12">
							@include('front.va.mandiri')
						</div>
				        @break

			        @case('IBBK')
				        <div class="col-lg-11 col-lg-offset-1 col-sm-12 col-xs-12">
							@include('front.va.bii')
						</div>
				        @break

			        @case('BBBA')
				        <div class="col-lg-11 col-lg-offset-1 col-sm-12 col-xs-12">
							@include('front.va.permata')
						</div>
				        @break

			        @case('BNIN')
				        <div class="col-lg-11 col-lg-offset-1 col-sm-12 col-xs-12">
							@include('front.va.bni')
						</div>
				        @break

			        @case('HNBN')
				        <div class="col-lg-11 col-lg-offset-1 col-sm-12 col-xs-12">
							@include('front.va.hana')
						</div>
				        @break

			        @case('BRIN')
				        <div class="col-lg-11 col-lg-offset-1 col-sm-12 col-xs-12">
							@include('front.va.bri')
						</div>
				        @break

			        @case('BNIA')
				        <div class="col-lg-11 col-lg-offset-1 col-sm-12 col-xs-12">
							@include('front.va.cimb')
						</div>
				        @break

			        @case('BDIN')
				        <div class="col-lg-11 col-lg-offset-1 col-sm-12 col-xs-12">
							@include('front.va.danamon')
						</div>
				        @break

			        @case('OTHR')
				        <div class="col-lg-11 col-lg-offset-1 col-sm-12 col-xs-12">
							@include('front.va.others')
						</div>
				        @break

				    @default
				    	@if(count(\App\Models\Bank::whereCode($store->bank_code)->first()))
				    		@include('front.cvs')
				    	@endif
				    	@break
				        
				@endswitch
				
			</div>
		</div>
		<a class="left-side" href="#details"><img src="img/img-3.png" alt=""/></a>
	</div>	
</section>
<section id="middle-content">
	<div class="details grey-bg">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-sm-12 col-xs-12">
					<h3><span class="red">Produk </span> Rekomendasi</h3>
				</div>
				<div class="panel">
					@foreach($recommended_products as $recommended)
					<?php $product=$recommended->Product; ?>
					<div class="col-lg-2 text-center col-sm-3 col-xs-12">
						<a href="#">
							<div class="img-container">
						@if($product->Image->count())
							<img src="{{ $product->Image->first()->image }}" alt="{{ $product->name }}"  style="max-width:174px;max-height:111px;"/>
						@else
							<img src="http://via.placeholder.com/350x150" alt="{{ $product->name }}"/>
						@endif
							</div>
						<h4>{{ $product->name }}<br><span>{{ $product->model }}</span></h4>
						@for($x=0;$x<$product->Star();$x++)
						<i class="fa fa-star" aria-hidden="true"></i>
						@endfor
						@for($x=$product->Star();$x<5;$x++)
						<i class="fa fa-star-o" aria-hidden="true"></i>
						@endfor
						@if (Auth::check())
						<h4 class="red">{{ currency_format($product->finalPrice(Auth::user()->id,1),'IDR') }}<br><span>{{ currency_format($product->price,'IDR') }}</span></h4>
						@else
						<h4 class="red">{{ currency_format($product->finalPrice(1,1),'IDR') }}<br><span>{{ currency_format($product->price,'IDR') }}</span></h4>
						@endif
						</a>
					</div>
					@endforeach
				</div>	
			</div>
		</div>	
	</div>
	<div id="details" class="details">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-sm-12 col-xs-12">
					<h3><span class="red">Blog </span> Kami</h3>
				</div>
				<div class="col-lg-12 text-right go-to col-sm-12 col-xs-12">
					<a href="/blog"><img src="img/go-to.png" alt=""/></a>
				</div>
				<div class="col-lg-12 flush col-sm-12 col-xs-12">
						<?php $cblog=0; ?>
						@foreach($blogs as $key => $value)
						<div class="col-lg-4 col-sm-4 col-xs-12">
							<div class="food">
								<div class="images">
									<img class="high" src="{{ $value->image }}" alt=""/>
									<span>Blog</span>
								</div>
								<div class="white-overlay">
									<h5>{{ strlen($value->title)>100 ? substr($value->title, 0, 100)."..." : $value->title }}</h5>
									<label>By {{ $value->Admin->name ?? ''}} - 0 comments</label>
									<?php
									$start = strpos($value->content, '<p>');
									$end = strpos($value->content, '</p>', $start);
									$paragraph = substr($value->content, $start, $end-$start+4);
									$paragraph = html_entity_decode(strip_tags($paragraph));
									?>
									<p>{{ strlen($paragraph)>200 ? substr($paragraph, 0, 200)."..." : $paragraph }}</p>
									<a href="{{ route('blog.detail',$value->slug) }}">Read More <i class="fa fa-caret-right" aria-hidden="true"></i></a>
								</div>
							</div>
						</div>
						<?php $cblog=$key; ?>
						@endforeach		
						<!-- <div class="col-lg-3  col-sm-3 col-xs-12">
							<div class="recent-post">
								<h4>recent-post</h4>
								@foreach($blogs as $key => $value)
								<div class="recent-box">
									<img class="high" src="{{ $value->image }}" alt=""/>
									<div class="text-content">
										<h5>{{ strlen($value->title)>15 ? substr($value->title, 0, 15)."..." : $value->title }}</h5>
										<label>By{{ $value->Admin->name ?? ''}} - 0 comments</label>
									</div>
								</div>
								@endforeach
							</div>
						</div> -->
				</div>
				<!-- <div class="col-lg-3  col-sm-3 col-xs-12">
					<div class="recent-post">
						<h4>recent-post</h4>
						@foreach($blogs as $key => $value)
						<div class="recent-box">
							<img class="high" src="{{ $value->image }}" alt=""/>
							<div class="text-content">
								<h5>{{ strlen($value->title)>15 ? substr($value->title, 0, 15)."..." : $value->title }}</h5>
								<label>By{{ $value->Admin->name ?? ''}} - 0 comments</label>
							</div>
						</div>
						@endforeach
					</div>
				</div> -->
				<div class="col-lg-12 text-right go-to col-sm-12 col-xs-12">
					<a href="/blog"><img src="img/go-to.png" alt=""/></a>
				</div>
			</div>
		</div>	
	</div>
	<div class="pertanyaan">
			<h4>Ada Pertanyaan?<br><span>Chat disini..</span></h4>
			<a id="Open" href="#">
				<i class="fa fa-minus" aria-hidden="true"></i>
			</a>	
		<form id="FormOpen">
			<div class="field">
				<label>Perkenalkan diri anda</label>
				<input type="text" placeholder="Nama, Email"/>
			</div>
			<div class="field">
				<label>Pesan</label>
				<textarea></textarea>
			</div>
			<div class="field text-right">
				<input type="submit" value="Submit"/>
			</div>
		</form>
	</div>
</section>
<!---- Content End ---->
@include('component.front.footer')
@endsection

@section('script')

@endsection