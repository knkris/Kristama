@extends('layouts.front')

@section('title')
	Checkout
@endsection

@section('head')

@endsection

@section('content')
<!---- Content Start ---->
<section id="content" class=" bg-none">
	<div class="title-head">
		<div class="container">
			<div class="row">
				<div class="col-lg-12  col-xs-12 col-sm-12">
					<h3>Checkout Page</h3>
				</div>
			</div>
		</div>		
	</div>
	<form>
		<div class="container">
			<div class="details border-none">
				<div class="row">
					<div id="hidden_form_container" style="display:none;"></div>
						<div class="col-lg-3 col-sm-4 col-xs-12">
							<div class="min-height">
								<h3><span>Shipping Address</span></h3>
								<input type="hidden" id="shipping_address_id" name="shipping_address_id" value="{{$address->id}}">
								<p>{{$address->name}}<br>
								{{$address->address}}<br>
								{{$address->getCity()}}<br>
								{{$address->Subdistrict->province}}<br>
								{{$address->postal_code}}</p>
							</div>	
							<button type="button" class="btn-change-address top-space" data-toggle="modal" data-target="#changeAddress">Change Address</button>
						</div>
						<div class="col-lg-3 col-sm-4 col-xs-12">
							<div class="min-height">
								<h3><span>Shipping Method</span></h3>
								<div class="shipping-method">
									{!! $shipping_method !!}
								</div>
							</div>	
						</div>
						<div class="col-lg-3 flush-right col-sm-4 col-xs-12">
							<div class="min-height">
								<h3><span>Payment Method</span></h3>
								@foreach($payment_method as $key => $value)
								<label class="payment-method"><input id="payment-method" type="radio" name="method" value="{{ $value->id }}" /> {{ $value->name }}</label>
								@endforeach
								<select id="choose-bank" name="bank" style="display: none;">
									@foreach($bank as $key => $value)
										<option value="{{ $value->id }}" /> {{ $value->name }}</option>
									@endforeach
								</select>
								<select id="choose-cvs" name="cvs" style="display: none;">
									<option value="ALMA_Alfamart" /> Alfamart</option>
									<option value="INDO_Indomaret" /> Indomaret</option>
									<option value="MDRC_ClickPay Mandiri" /> ClickPay Mandiri</option>
									<option value="BCAC_ClickPay BCA" /> ClickPay BCA</option>
									<option value="CIMC_ClickPay CIMB" /> ClickPay CIMB</option>
									<option value="MDRE_E-Wallet Mandiri" /> E-Wallet Mandiri</option>
									<option value="BCAE_Sakuku" /> Sakuku</option>
								</select>
							</div>	
						</div>
						<div class="col-lg-3 col-sm-6 col-xs-12">
							<h3><span>Masukkan kode kupon</span></h3>
							<div class="field">
								<div class="col-lg-8 flush-left col-sm-8 col-xs-8"><input id="coupon" type="text" placeholder="ABC1234xyz"/></div>
								<div class="col-lg-4 flush col-sm-4 col-xs-4"><input id="submit-coupon" type="submit" value="Apply"/></div>
							</div>
							<!-- <div class="field">
								<h3><span>Gunakan Dompet</span></h3>
								<div class="col-lg-1  col-sm-1 col-xs-1 flush">Rp.</div>
								<div class="col-lg-7 flush-left col-sm-7 col-xs-7"><input type="text" placeholder="ABC1234xyz"/><br><span class="wollet"><img src="img/icon-7-wollet.png" alt=""/> {{ currency_format(0, 'IDR') }}</span></div>
								<div class="col-lg-4 flush col-sm-4 col-xs-4"><input type="submit" value="Apply"/></div>
							</div> -->
						</div>
				</div>	
			</div>
			<div class="row">
				<div class="col-lg-6 col-sm-12 col-xs-12" style="margin-top:50px;">
					<?php 
					$total=0;
					$nettotal=0;
					$totaldisc=0;
					?>
					@foreach($cart as $key => $value)
					<?php
					$product=$value->Product;
					//$productStock=$product->ProductStock()->whereId($value->product_stock_id)->first();
					//$productStock=\App\Models\ProductStock::find($value->product_stock_id);
					$grosssubtotal=$product->price*$value->qty;
					$subtotal=$product->finalPrice(Auth::user()->customer_group_id,$value->qty)*$value->qty;
					$total+=$grosssubtotal;
					$nettotal+=$subtotal;
					$disc=($product->price*$value->qty)-($product->finalPrice(Auth::user()->customer_group_id,$value->qty)*$value->qty);
					$totaldisc+=$disc;
					?>
					<div id="cart-item-{{$value->id}}" class="cart-item details border-top space-two">
						<div class="col-lg-4 text-center col-sm-4 col-xs-12">
							<img onclick="goToProduct('{{$product->slug}}')" class="sm-high" src="{{ $product->Image->first()->image }}" alt="" style="max-width: 150px;max-height: 150px;" />
						</div>
						<div class="col-lg-8 responsive-flush col-sm-8 col-xs-12">
							<div class="field">
								<div class="text-content">
									<div class="col-lg-3 flush col-sm-3 col-xs-4">
										<label class="gray">Items</label>
									</div>
									<div class="col-lg-9 col-sm-9 col-xs-8">
										<label onclick="goToProduct('{{$product->slug}}')">{{ $product->name }}</label>
									</div>
								</div>
								<div class="text-content">
									<div class="col-lg-3 flush col-sm-3 col-xs-4">
										<label class="gray">SKU</label>
									</div>
									<div class="col-lg-9 col-sm-9 col-xs-8">
										<label onclick="goToProduct('{{$product->slug}}')">{{ $product->model }}</label>
									</div>
								</div>
								<div class="text-content">
									<div class="col-lg-3 flush col-sm-3 col-xs-4">
										<label class="gray">Qty</label>
									</div>
									<div class="col-lg-4 col-sm-6 col-xs-5">
										<div class="center">
											<div class="input-group">
											  <span class="input-group-btn">
												  <button type="button" class="btn btn-default btn-number" data-type="minus" data-field="quant[{{$value->id}}]">
													  <span class="glyphicon glyphicon-minus"></span>
												  </button>
											  </span>
											  <input type="text" name="quant[{{$value->id}}]" class="form-control input-number cart-item-qty" data-id="{{$value->id}}" value="{{ $value->qty }}" min="1" max="{{ $product->qty }}" style="border: 1px solid #ccc;">
											  <span class="input-group-btn">
												  <button type="button" class="btn btn-default btn-number" data-type="plus" data-field="quant[{{$value->id}}]">
													  <span class="glyphicon glyphicon-plus"></span>
												  </button>
											  </span>
											</div>
										</div>	  
									</div>
									<div class="col-lg-5 col-sm-3 top-xs text-right flush col-xs-12">
										{{-- <a href="#" class="btn-success update-cart" data-id="{{$value->id}}">Update</a> --}}
										<i class="fa fa-spinner fa-spin loading-{{$value->id}}" style="display: none;"></i>
			      						<a href="#" class="btn-success remove-item" data-id="{{$value->id}}" data-name="{{$value->name}}">Delete</a>
									</div>
								</div>
							</div>
							<div class="field">
								<div class="text-content">
									<div class="col-lg-3 flush col-sm-3 col-xs-4">
										<label class="gray">Price</label>
									</div>
									<div class="col-lg-9 col-sm-9 col-xs-8">
										<label id="price-{{$value->id}}">{{ currency_format($product->finalPrice(Auth::user()->customer_group_id,$value->qty),'IDR') }}</label>
									</div>
								</div>
								<div class="text-content">
									<div class="col-lg-3 flush col-sm-3 col-xs-4">
										<label class="gray">Discount</label>
									</div>
									<div class="col-lg-9 col-sm-9 col-xs-8">
										<label id="discount-{{$value->id}}">{{ currency_format($disc,'IDR') }}</label>
									</div>
								</div>
							</div>
							<div class="field border-none">
								<div class="text-content">
									<div class="col-lg-3 flush col-sm-3 col-xs-4">
										<label class="gray size">Total</label>
									</div>
									<div class="col-lg-9 col-sm-9 col-xs-8">
										<label id="subtotal-{{$value->id}}" class="size">{{ currency_format($subtotal,'IDR') }}</label>
									</div>
								</div>
							</div>
						</div>
					</div>
					@endforeach
					
				</div>
				<div class="col-lg-6 col-sm-12 col-xs-12 container-summary">
					<div class="min-height">
						<h3><span class="red">Order </span> Summary</h3>
							<div class="col-lg-6 col-sm-6 col-xs-4 flush">
								<label>Price</label>
							</div>
							<div class="col-lg-6 text-right col-sm-6 col-xs-8 flush">
								<label id="cart-total">{{ currency_format($total, 'IDR') }}</label>
							</div>
						
						
							<!-- <div class="col-lg-6 col-sm-6 col-xs-4 flush">
								<label>Tax</label>
							</div>
							<div class="col-lg-6 text-right col-sm-6 col-xs-8 flush">
								<label>Rp 0,-</label>
							</div> -->
						
							<div class="col-lg-6 col-sm-6 col-xs-4 flush">
								<label>Shipping</label>
							</div>
							<div class="col-lg-6 text-right col-sm-6 col-xs-8 flush">
								<label id="shipping-cost">-</label>
							</div>
						
							<div class="col-lg-6 col-sm-6 col-xs-4 flush">
								<label>Discount</label>
							</div>
							<div class="col-lg-6 text-right col-sm-6 col-xs-8 flush">
								<label id="total-discount">-({{ currency_format($totaldisc, 'IDR') }})</label>
							</div>
						
							<div class="col-lg-6 col-sm-6 col-xs-4 flush">
								<label>Kupon</label>
							</div>
							<div class="col-lg-6 text-right col-sm-6 col-xs-8 flush">
								<label id="coupon-value">-({{ currency_format(0, 'IDR') }})</label>
							</div>
						
						<div class="col-lg-12 col-sm-12 col-xs-12 flush">
							
								<div class="col-lg-6 col-sm-6 col-xs-4 flush">
									<label>Jumlah</label>
								</div>
								<div class="col-lg-6 text-right col-sm-6 col-xs-8 flush">
									<label id="nettotal" data-nettotal="{{$nettotal}}">{{ currency_format($nettotal, 'IDR') }}</label>
								</div>
							
								<div class="col-lg-6 col-sm-6 col-xs-4 flush">
									<label>Dompet</label>
								</div>
								<div class="col-lg-6 text-right col-sm-6 col-xs-8 flush">
									<label id="wallet">{{ currency_format(0, 'IDR') }}</label>
								</div>
							
						</div>
						<div class="col-lg-12 col-sm-12 col-xs-12 flush">
								<div class="col-lg-6 col-sm-6 col-xs-4 flush">
									<label class="total">TOTAL</label>
								</div>
								<div class="col-lg-6 text-right col-sm-6 col-xs-8 flush">
									<label id="finalbill" class="total">-</label>
								</div>
								<div class="col-lg-6 col-sm-6 col-xs-4 flush">
									<label>You Save</label>
								</div>
								<div class="col-lg-6 text-right col-sm-6 col-xs-8 flush">
									<label id="saved">{{ currency_format($totaldisc, 'IDR') }}</label>
								</div>
						</div>	
					</div>	
						<a href="#" class="btn-success beli">Beli Sekarang</a>
				</div>
			</div>	
		</div>
	</form>	
	{{-- <a class="left-side" href="#details"><img src="img/img-3.png" alt=""/></a> --}}
</section>
<section id="middle-content">
	<div class="details grey-bg">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-sm-12 col-xs-12">
					<h3><span class="red">Produk </span> Rekomendasi</h3>
				</div>
				<div class="panel">
					@foreach($recommended_products as $recommended)
					<?php $product=$recommended->Product; ?>
					<div class="col-lg-2 text-center col-sm-3 col-xs-12">
						<a href="#">
						@if($product->Image->count())
							<img src="{{ $product->Image->first()->image }}" alt="{{ $product->name }}"  style="max-width:174px;max-height:111px;"/>
						@else
							<img src="http://via.placeholder.com/350x150" alt="{{ $product->name }}"/>
						@endif
						<h4>{{ $product->name }}<br><span>{{ $product->model }}</span></h4>
						@for($x=0;$x<$product->Star();$x++)
						<i class="fa fa-star" aria-hidden="true"></i>
						@endfor
						@for($x=$product->Star();$x<5;$x++)
						<i class="fa fa-star-o" aria-hidden="true"></i>
						@endfor
						@if (Auth::check())
						<h4 class="red">{{ currency_format($product->finalPrice(Auth::user()->id,1),'IDR') }}<br><span>{{ currency_format($product->price,'IDR') }}</span></h4>
						@else
						<h4 class="red">{{ currency_format($product->finalPrice(1,1),'IDR') }}<br><span>{{ currency_format($product->price,'IDR') }}</span></h4>
						@endif
						</a>
					</div>
					@endforeach
				</div>	
			</div>
		</div>	
	</div>
	<div class="pertanyaan">
			<h4>Ada Pertanyaan?<br><span>Chat disini..</span></h4>
			<a id="Open" href="#">
				<i class="fa fa-minus" aria-hidden="true"></i>
			</a>	
		<form id="FormOpen">
			<div class="field">
				<label>Perkenalkan diri anda</label>
				<input type="text" placeholder="Nama, Email"/>
			</div>
			<div class="field">
				<label>Pesan</label>
				<textarea></textarea>
			</div>
			<div class="field text-right">
				<input type="submit" value="Submit"/>
			</div>
		</form>
	</div>
</section>
<section>
<div class=" text-center back-top">
	<a href="#header">
		Back To TOP
	</a>
</div>
</section>
<!-- Change Address Modal -->
<div class="modal fade" id="changeAddress" tabindex="-1" role="dialog" aria-labelledby="changeAddress">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Change Address</h4>
      </div>
      <div class="modal-body">
      	<div class="container-fluid">
	      	@foreach($addresses as $key => $value)
	        <a href="{{ url()->current().'?address='.$value->id }}" class="col-xs-12 btn btn-link" style="border: 1px solid black;">
				<p>{{$value->name}}<br>
				{{$value->address}}<br>
				{{$value->getCity()}}<br>
				{{$value->Subdistrict->province}}<br>
				{{$value->postal_code}}</p>
	    	</a>
	    	@endforeach
    	</div>
      </div>
    </div>
  </div>
</div>

@include('component.front.footer')
@endsection

@section('script')
<script>
var coupon=0;
function goToProduct(url){
	window.open("{{ url('/') }}/"+url, '_blank');
}
$('.btn-number').click(function(e){
    e.preventDefault();
    
    fieldName = $(this).attr('data-field');
    type      = $(this).attr('data-type');
    var input = $("input[name='"+fieldName+"']");
    var currentVal = parseInt(input.val());
    if (!isNaN(currentVal)) {
        if(type == 'minus') {
            
            if(currentVal > input.attr('min')) {
                input.val(currentVal - 1).change();
            } 
            if(parseInt(input.val()) == input.attr('min')) {
                $(this).attr('disabled', true);
            }

        } else if(type == 'plus') {

            if(currentVal < input.attr('max')) {
                input.val(currentVal + 1).change();
            }
            if(parseInt(input.val()) == input.attr('max')) {
                $(this).attr('disabled', true);
            }

        }
    } else {
        input.val(0);
    }
});
$('.input-number').focusin(function(){
   $(this).data('oldValue', $(this).val());
});
$('.input-number').change(function() {
    
    minValue =  parseInt($(this).attr('min'));
    maxValue =  parseInt($(this).attr('max'));
    valueCurrent = parseInt($(this).val());
    
    name = $(this).attr('name');
    if(valueCurrent >= minValue) {
        $(".btn-number[data-type='minus'][data-field='"+name+"']").removeAttr('disabled')
    } else {
        alert('Sorry, the minimum value was reached');
        $(this).val($(this).data('oldValue'));
    }
    if(valueCurrent <= maxValue) {
        $(".btn-number[data-type='plus'][data-field='"+name+"']").removeAttr('disabled')
    } else {
        alert('Sorry, the maximum value was reached');
        $(this).val($(this).data('oldValue'));
    }
    
    
});
$(".input-number").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 190]) !== -1 ||
             // Allow: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) || 
             // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });

$('#submit-coupon').on('click', function(e) {
	e.preventDefault();
	$coupon=$('#coupon').val();
	$cost=$('input[name="shipping"]:checked').data('price');
	var formData = new FormData();
	formData.append('coupon', $coupon);
	formData.append('shipping_cost', $cost);
	formData.append('_token', '{{csrf_token()}}');
	$.ajax({
	    url: '{{ url('submit-coupon') }}',
	    data: formData,
	    type: 'POST',
	    contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
		processData: false, // NEEDED, DON'T OMIT THIS
	    success: function(data){  
	    	$('#nettotal').html(data.nettotal);
	    	$('#nettotal').data('nettotal',data.nettotal_raw);
	    	$('#finalbill').html(data.nettotal);
	    	$('#coupon-value').html(data.coupon);
	    	$('#shipping-cost').html(data.shipping_cost);
	    	coupon=data.coupon_raw;
	        // Display a success toast, with a title
	        if(data.coupon_raw>1){
				toastr.success('Coupon is Valid!', 'Success!')  
			}
	    },
	    error: function(XMLHttpRequest, textStatus, errorThrown) { 
	    	if ( XMLHttpRequest.status== 401 ) {
		      toastr.error('You must login first!', 'Error!') 
		    }else if ( XMLHttpRequest.status== 404 ) {
		      toastr.error(XMLHttpRequest.responseJSON['error'], 'Error!')  
		    }else{
		        // Display a error toast, with a title
				toastr.error(XMLHttpRequest.responseJSON.errors[Object.keys(XMLHttpRequest.responseJSON.errors)[0]], 'Error!')  
			}
	    }    
	    // ... Other options like success and etc
	});
});

$('.cart-item-qty').on('change', function(e){
	$this=$(this);
	$id=$this.data('id');
	$('.loading-'+$id).show();
	$qty=$(this).val();
	$cost=$('input[name="shipping"]:checked').data('price');
	$coupon=$('#coupon').val();
	var formData = new FormData();
	formData.append('coupon', $coupon);
	formData.append('cart_id', $id);
	formData.append('qty', $qty);
	formData.append('shipping_cost', $cost);
	formData.append('_token', '{{csrf_token()}}');
	$.ajax({
	    url: '{{ url('update-cart') }}',
	    data: formData,
	    type: 'POST',
	    contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
		processData: false, // NEEDED, DON'T OMIT THIS
	    success: function(data){  
	    	$('#price-'+$id).html(data.formated_price);
	    	$('#discount-'+$id).html(data.formated_disc);
	    	$('#subtotal-'+$id).html(data.formated_subtotal);
	    	$('#cart-total').html(data.cart_total);
	    	$('#total-discount').html(data.cart_totaldisc);
	    	$('#saved').html(data.cart_totaldisc);
	    	$('#nettotal').html(data.cart_nettotal);
	    	$('#nettotal').data('nettotal',data.cart_nettotal_raw);
	    	$('#finalbill').html(data.cart_nettotal);
	    	$('.shipping-method').html(data.shipping_option);
	    	$('#shipping-cost').html(data.shipping_cost);

	        // Display a success toast, with a title
			toastr.success('Cart Updated!', 'Success!')  
			$('.loading-'+$id).hide();
	    },
	    error: function(XMLHttpRequest, textStatus, errorThrown) { 
	    	$('.loading-'+$id).hide();
	    	if ( XMLHttpRequest.status== 401 ) {
		      toastr.error('You must login first!', 'Error!') 
		    }else if ( XMLHttpRequest.status== 404 ) {
		      toastr.error(XMLHttpRequest.responseJSON['error'], 'Error!')  
		    }else{
		        // Display a error toast, with a title
				toastr.error(XMLHttpRequest.responseJSON.errors[Object.keys(XMLHttpRequest.responseJSON.errors)[0]], 'Error!')  
			}
	    }    
	    // ... Other options like success and etc
	});
});
$('.update-cart').on('click', function(e){
	e.preventDefault();
	$this=$(this);
	$id=$this.data('id');
	$cost=$('input[name="shipping"]:checked').data('price');
	$qty=$('input[name="quant['+$id+']').val();
	var formData = new FormData();
	formData.append('cart_id', $id);
	formData.append('qty', $qty);
	formData.append('shipping_cost', $cost);
	formData.append('_token', '{{csrf_token()}}');
	$.ajax({
	    url: '{{ url('update-cart') }}',
	    data: formData,
	    type: 'POST',
	    contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
		processData: false, // NEEDED, DON'T OMIT THIS
	    success: function(data){  
	    	$('#price-'+$id).html(data.formated_price);
	    	$('#discount-'+$id).html(data.formated_disc);
	    	$('#subtotal-'+$id).html(data.formated_subtotal);
	    	$('#cart-total').html(data.cart_total);
	    	$('#total-discount').html(data.cart_totaldisc);
	    	$('#saved').html(data.cart_totaldisc);
	    	$('#nettotal').html(data.cart_nettotal);
	    	$('#nettotal').data('nettotal',data.cart_nettotal_raw);
	    	$('#finalbill').html(data.cart_nettotal);
	    	$('.shipping-method').html(data.shipping_option);
	    	$('#shipping-cost').html(data.shipping_cost);

	        // Display a success toast, with a title
			toastr.success('Cart Updated!', 'Success!')  
	    },
	    error: function(XMLHttpRequest, textStatus, errorThrown) { 
	    	if ( XMLHttpRequest.status== 401 ) {
		      toastr.error('You must login first!', 'Error!') 
		    }else if ( XMLHttpRequest.status== 404 ) {
		      toastr.error(XMLHttpRequest.responseJSON['error'], 'Error!')  
		    }else{
		        // Display a error toast, with a title
				toastr.error(XMLHttpRequest.responseJSON.errors[Object.keys(XMLHttpRequest.responseJSON.errors)[0]], 'Error!')  
			}
	    }    
	    // ... Other options like success and etc
	});
})

function removeCartItem($id,$name){
	var formData = new FormData();
	formData.append('cart_id', $id);
	formData.append('_token', '{{csrf_token()}}');
	$.ajax({
	    url: '{{ url('remove-cart-item') }}',
	    data: formData,
	    type: 'POST',
	    contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
		processData: false, // NEEDED, DON'T OMIT THIS
	    success: function(data){  
	    	$('#cart-item-'+$id).remove();
	        // Display a success toast, with a title
			toastr.success(data+' deleted from your cart!', 'Success!')  
			location.reload();
	    },
	    error: function(XMLHttpRequest, textStatus, errorThrown) { 
	    	if ( XMLHttpRequest.status== 401 ) {
		      toastr.error('You must login first!', 'Error!') 
		    }else if ( XMLHttpRequest.status== 404 ) {
		      toastr.error(XMLHttpRequest.responseJSON['error'], 'Error!')  
		    }else{
		        // Display a error toast, with a title
				toastr.error(XMLHttpRequest.responseJSON.errors[Object.keys(XMLHttpRequest.responseJSON.errors)[0]], 'Error!')  
			}
	    }    
	    // ... Other options like success and etc
	});
}
function rupiah_format(number){
        	number=parseFloat(number)
	      var number_string = number.toString(),
	        sisa  = number_string.length % 3,
	        rupiah  = number_string.substr(0, sisa),
	        ribuan  = number_string.substr(sisa).match(/\d{3}/g);
	          
	      if (ribuan) {
	        var separator = sisa ? '.' : '';
	        rupiah += separator + ribuan.join('.');
	      }

	      return "Rp "+rupiah;
	    }
$('.remove-item').on('click', function(e){
	e.preventDefault();
	$this=$(this);
	$id=$this.data('id');
	$name=$this.data('name');
	swal({
          title: 'Delete Item?',
          text: "Delete "+$name+" from your cart?",
          type: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
          if (result.value) {
            removeCartItem($id,$name)
          }
        })
})
$('input[name="shipping"]').click(function(e){
    if ($(this).is(':checked'))
    {
    	$cost=$(this).data('price');
		$coupon=$('#coupon').val();
		var formData = new FormData();
		formData.append('coupon', $coupon);
		formData.append('shipping_cost', $cost);
		formData.append('_token', '{{csrf_token()}}');
		$.ajax({
		    url: '{{ url('submit-coupon') }}',
		    data: formData,
		    type: 'POST',
		    contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
			processData: false, // NEEDED, DON'T OMIT THIS
		    success: function(data){  
		    	$('#nettotal').html(data.nettotal);
		    	$('#nettotal').data('nettotal',data.nettotal_raw);
		    	$('#finalbill').html(data.nettotal);
		    	$('#coupon-value').html(data.coupon);
		    	$('#shipping-cost').html(data.shipping_cost);
		    },
		    error: function(XMLHttpRequest, textStatus, errorThrown) { 
		    	if ( XMLHttpRequest.status== 401 ) {
			      toastr.error('You must login first!', 'Error!') 
			    }else if ( XMLHttpRequest.status== 404 ) {
			      toastr.error(XMLHttpRequest.responseJSON['error'], 'Error!')  
			    }else{
			        // Display a error toast, with a title
					toastr.error(XMLHttpRequest.responseJSON.errors[Object.keys(XMLHttpRequest.responseJSON.errors)[0]], 'Error!')  
				}
		    }    
		    // ... Other options like success and etc
		});
    }
  });

$('.payment-method').on('click', function(){
	console.log('clicked');
	if($('#payment-method:checked').val()==3){
		$('#choose-bank').show();
	}else{
		$('#choose-bank').hide();
	}	
	if($('#payment-method:checked').val()==4){
		$('#choose-cvs').show();
	}else{
		$('#choose-cvs').hide();
	}	
});

$('.beli').on('click', function(e){
	e.preventDefault();
	$shipping_address_id=$('#shipping_address_id').val();
	$shipping_method=$('input[name=shipping]:checked').val();
	$payment_method=$('input[name=method]:checked').val();

	if($shipping_address_id==undefined){
		return toastr.error('Shipping Address Not Found!', 'Error!') 
	}

	if($shipping_method==undefined){
		return toastr.error('Please Select Shipping Method!', 'Error!') 
	}

	if($payment_method==undefined){
		return toastr.error('Please Select Payment Method!', 'Error!') 
	}

	$data={
		shipping_address_id: $('#shipping_address_id').val(),
		shipping_method: $('input[name=shipping]:checked').val(),
		payment_method: $('input[name=method]:checked').val()
	}
	console.log($data)
	postRefreshPage()
})

function postRefreshPage () {
  $shipping_address_id=$('#shipping_address_id').val();
  $shipping_method=$('input[name=shipping]:checked').val();
  $payment_method=$('input[name=method]:checked').val();
  var theForm, newInput1, newInput2, newInput3, token;
  // Start by creating a <form>
  theForm = document.createElement('form');
  theForm.action = '{{ url('checkout') }}';
  theForm.method = 'post';
  // Next create the <input>s in the form and give them names and values
  newInput1 = document.createElement('input');
  newInput1.type = 'hidden';
  newInput1.name = 'shipping_address_id';
  newInput1.value = $shipping_address_id;
  token = document.createElement('input');
  token.type = 'hidden';
  token.name = '_token';
  token.value = '{{csrf_token()}}';
  newInput2 = document.createElement('input');
  newInput2.type = 'hidden';
  newInput2.name = 'shipping_method';
  newInput2.value = $shipping_method;
  newInput3 = document.createElement('input');
  newInput3.type = 'hidden';
  newInput3.name = 'payment_method';
  newInput3.value = $payment_method;
  if($payment_method=='3'){
  	  $bank=$('#choose-bank').val();
  	  newInput4 = document.createElement('input');
  	  newInput4.type = 'hidden';
	  newInput4.name = 'bank';
	  newInput4.value = $bank;
  }
  if($payment_method=='4'){
  	  $bank=$('#choose-cvs').val();
  	  newInput4 = document.createElement('input');
  	  newInput4.type = 'hidden';
	  newInput4.name = 'cvs';
	  newInput4.value = $bank;
  }

  // Now put everything together...
  theForm.appendChild(token);
  theForm.appendChild(newInput1);
  theForm.appendChild(newInput2);
  theForm.appendChild(newInput3);
  if($payment_method=='3'){
  	  theForm.appendChild(newInput4);
  }
  if($payment_method=='4'){
  	  theForm.appendChild(newInput4);
  }
  // ...and it to the DOM...
  document.getElementById('hidden_form_container').appendChild(theForm);
  // ...and submit it
  theForm.submit();
}
</script>
@endsection