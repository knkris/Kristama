@extends('layouts.front')

@section('title')
    Test Page Issue - contact us
@endsection

@section('head')

@endsection

@section('content')
    <!---- Content Start ---->

    <!-- issue - contact us -->
    <section class="ic-issue-contact" id="content">
        <div class="title-head">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <h3>Issue - contact us</h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="ic-issue-contact">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.749462399913!2d106.77642931530913!3d-6.164297562130541!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f64eef0aee61%3A0x1d2b9a11d717599f!2zSmwuIERhYW4gTW9nb3QgTm8uMTE2LCBSVC40L1JXLjIsIFdpamF5YSBLdXN1bWEsIEdyb2dvbCBwZXRhbWJ1cmFuLCBLb3RhIEpha2FydGEgQmFyYXQsIERhZXJhaCBLaHVzdXMgSWJ1a290YSBKYWthcnRhIDExNDYwLCDgpofgpqjgp43gpqbgp4vgpqjgp4fgprbgpr_gpq_gprzgpr4!5e0!3m2!1sbn!2sbd!4v1537092318547" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="ic-issue-contact">
                        <h3><span>Office </span> address</h3>
                        <div class="ic-single-ic ic-address">
                            <span><i class="fa fa-home"></i></span>
                            <address>
                                <h4>kreasi 2 shop</h4>
                                <span>Jl. Sosial No. 02 RT 004/002</span>
                                <span>Jakarta Barat, Grogol Pertamburan,</span>
                                <span>Kode Pos 11460</span>
                            </address>
                        </div>
                        <div class="ic-single-ic">
                            <span><i class="fa fa-envelope"></i></span>
                            <span><a href="mailto:cs@kreasiduashop.com">mailto:cs@kreasiduashop.com</a></span>
                        </div>
                        <div class="ic-single-ic">
                            <span><i class="fa fa-phone"></i></span>
                            <span><a href="tel:02122561357">Hotline: (021) 2256 1357</a></span>
                        </div>
                    </div>
                    <div class="ic-issue-contact">
                        <h3><span>contact </span> us</h3>
                        <p>Jika pesanan Anda mengalami permasalahan, silahkan tekan tombol 'New Issue' untuk mengisi kolom pengaduan.</p>
                        <a href="{{ action('Front\GeneralController@contact_us') }}" class="ic-contact-btn">New Issue</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- issue - contact us /end-->

    @include('component.front.accountright')
    @include('component.front.fixbottom')
    <!---- Content End ---->

    @include('component.front.footer')
@endsection

@section('script')
    <script src="{{ asset('js/ic-bmbtn.js') }}"></script>
@endsection