@extends('layouts.front')

@section('title')
    Advance Search | Kreasi 2 Shop
@endsection

@section('head')
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/placeholder-loading/dist/css/placeholder-loading.min.css">
    <style type="text/css">
        .text-red {
            color:#b82e2a !important;
        }
        .star-active .fa-star{
            color:#b82e2a !important;
        }
        #content .kategori-details li a img.category-active {
            -webkit-filter: grayscale(0);
            filter: grayscale(0);
        }
        .filter-price{
            border: 0;
        }
        .ic-min-max-col span
        {
            color:  black;
        }
    </style>
@endsection

@section('content')
    <!---- Content Start ---->
    <section class="ic-advance-search" id="content">
        <div class="title-head">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <h3>Advance search</h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <form action="{{ url('search') }}">
                        <div class="ic-single-input">
                            <input type="text" placeholder="All these words">
                        </div>
                        <div class="ic-single-input">
                            <input type="text" placeholder="Exact words">
                        </div>
                        <div class="ic-single-input">
                            <input type="text" placeholder="Excluding these words">
                        </div>
                        <div class="ic-single-input ic-sp-desc">
                            <div class="ic-select">
                                <select name="category" id="ic-adnvace-options">
                                    <option>Section / Category</option>
                                    @foreach($categories as $key => $value)
                                    <option value="{{ $value->slug }}">{{ $value->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="ic-single-input ic-border-btm">
                            <input type="hidden" id="price-filter" name="price_filter" value="">
                            <div class="ic-min-max-col dropdown">
                                <button class="ic-dprice ic-btn" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                    price
                                </button>
                                <ul class="ic-min-max-val dropdown-menu black" aria-labelledby="dropdownMenu1">
                                    <li class="price-filter" data-value="0 - 9999"><span>Rp 0</span> - <span>Rp 9.999</span></li>
                                    <li class="price-filter" data-value="10000 - 49999"><span>Rp 10.000</span> - <span>Rp 49.999</span></li>
                                    <li class="price-filter" data-value="50000 - 99999"><span>Rp 50.000</span> - <span>Rp 99.999</span></li>
                                    <li class="price-filter" data-value="100000 - 299999"><span>Rp 100.000</span> - <span>Rp 299.999</span></li>
                                    <li class="price-filter" data-value="300000 - 499999"><span>Rp 300.000</span> - <span>Rp 499.999</span></li>
									<li class="price-filter" data-value="500000 - 999999"><span>Rp 500.000</span> - <span>Rp 999.999</span></li>
									<li class="price-filter" data-value="1000000 - 4999999"><span>Rp 1.000.000</span> - <span>Rp 4.999.999</span></li>
                                    <li class="price-filter" data-value="5000000 - "><span>Rp 5.000.000 < </span> <span></span></li>
                                </ul>
                            </div>
                        </div>
                        <div class="ic-single-input ic-rating-s ic-border-btm">
                            <input type="hidden" id="rating-filter" name="rating" value="">
                            <div class="ic-min-max-col dropdown">
                                <button class="ic-dprice ic-btn" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                    Rating
                                </button>
                                <ul class="ic-min-max-val dropdown-menu" aria-labelledby="dropdownMenu1">
                                    <li class="rating-filter" data-value="5">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </li>
                                    <li class="rating-filter" data-value="4">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </li>
                                    <li class="rating-filter" data-value="3">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </li>
                                    <li class="rating-filter" data-value="2">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </li>
                                    <li class="rating-filter" data-value="1">
                                        <i class="fa fa-star"></i>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="ic-single-input ic-search-btn">
                            <button type="submit">Search</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <section id="middle-content">
        {{-- For Related Products --}}
        @include('component.related_productsvue')

        {{-- For Blog --}}
        @include('component.blogs')

    </section>
    <!---- Content End ---->
    <section class="ic-back-to-top">
        <button id="return-to-top">Back to top</button>
    </section>
    @include('component.front.footer')

@endsection

@section('script')
    <script>
        $(document.body).on('click', '.price-filter', function (e) {
            e.preventDefault();
            $price=$(this).data('value');
            $('#price-filter').val($price);
        });
        $(document.body).on('click', '.rating-filter', function (e) {
            $rating=$(this).data('value');
            $('#rating-filter').val($rating);
        });
        $("#price-one").click(function(e){
            e.preventDefault();
            $("#all-price-one").toggle();
        });
        // $("#btnv-1").click(function(){
        //     $("#view-2").addClass("hide");
        //     $("#view-1").removeClass("hide");
        // });

        // $("#btnv-2").click(function(){
        // 	console.log('btnv-2')
        //     $("#view-1").addClass("hide");
        //     $("#view-2").removeClass("hide");
        // });
    </script>
    <script>
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();
        });
        function updateQueryStringParameter(uri, key, value) {
            var re = new RegExp("([?&])" + key + "=.*?(&|$)", "i");
            var separator = uri.indexOf('?') !== -1 ? "&" : "?";
            if (uri.match(re)) {
                return uri.replace(re, '$1' + key + "=" + value + '$2');
            }
            else {
                return uri + separator + key + "=" + value;
            }
        }

        function removeParam(key, sourceURL) {
            var rtn = sourceURL.split("?")[0],
                param,
                params_arr = [],
                queryString = (sourceURL.indexOf("?") !== -1) ? sourceURL.split("?")[1] : "";
            if (queryString !== "") {
                params_arr = queryString.split("&");
                for (var i = params_arr.length - 1; i >= 0; i -= 1) {
                    param = params_arr[i].split("=")[0];
                    if (param === key) {
                        params_arr.splice(i, 1);
                    }
                }
                rtn = rtn + "?" + params_arr.join("&");
            }
            return rtn;
        }

        var i=0,h=0;
        var CU="{{ url()->full() }}";
        goto=CU.replace(/&amp;/g, '&');
        var index=goto.indexOf("?");


        $('.brand-filter').on('change', function(){
            var method=$("input[name=brands]:checked").map(function () {
                return this.value;
            }).get().join(",");
            var gen=updateQueryStringParameter(goto, 'brand',method);
            window.location.href=gen;
        })
        $('#sort-by').on('change', function(){
            var gen=updateQueryStringParameter(goto, 'sort',this.value);
            window.location.href=gen;
        })

        // $('.filter-price').on('change', function(){
        // 	$min=$('#min-price').val();
        // 	$max=$('#max-price').val();
        // 	filterPrice($min,$max)
        // })

        // $('.filter-price').keypress(function(e) {
        //     if(e.which == 13) {
        //         $min=$('#min-price').val();
        // 		$max=$('#max-price').val();
        // 		filterPrice($min,$max)
        //     }
        // });

        function filterRating(int){
            var url = new URL(goto);
            var c = url.searchParams.get("rating");
            if(c == int){
                var gen=removeParam('rating', goto);
                window.location.href=gen;
            }else{
                var gen=updateQueryStringParameter(goto, 'rating',int);
                window.location.href=gen;
            }
        }


        function filterPrice(min,max){
            var min = min;
            var gen=updateQueryStringParameter(goto, 'min',min);
            var max = max;
            var gen=updateQueryStringParameter(gen, 'max',max);
            window.location.href=gen;
        }

        function rupiah(bil){
            var bilangan = bil;

            var	number_string = bilangan.toString(),
                sisa 	= number_string.length % 3,
                rupiah 	= number_string.substr(0, sisa),
                ribuan 	= number_string.substr(sisa).match(/\d{3}/g);

            if (ribuan) {
                separator = sisa ? '.' : '';
                rupiah += separator + ribuan.join('.');
            }

            return rupiah;
        }
    </script>
    <script src="{{ asset('js/ic-select-option.js') }}"></script>
    <script src="https://cdn.jsdelivr.net/npm/vue@2.5.17/dist/vue.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/vue-resource/1.5.1/vue-resource.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/vue-lazyload/1.2.6/vue-lazyload.js"></script>
    <script src="https://unpkg.com/vue-router/dist/vue-router.js"></script>
    <script src="https://rawgit.com/fergaldoyle/vue-form/master/dist/vue-form.min.js"></script>
    <script src="https://unpkg.com/lodash@4.17.10/lodash.min.js"></script>
    <script src="https://unpkg.com/vuejs-paginate@latest"></script>
    <script>
        var module = {};
        Vue.use(VueRouter)
        Vue.use(VueResource);
        Vue.component('paginate', VuejsPaginate)
        Vue.use(VueLazyload, {
            preLoad: 1.3,
            // error: 'dist/error.png',
            loading: '{{ url('img/135.gif') }}',
            attempt: 1,
            // the default is ['scroll', 'wheel', 'mousewheel', 'resize', 'animationend', 'transitionend']
            listenEvents: [ 'scroll' ],
            filter: {
                progressive (listener, options) {
                    const isCDN = /playit.tech/
                    if (isCDN.test(listener.src)) {
                        listener.el.setAttribute('lazy-progressive', 'true')
                        listener.loading = listener.src + '?imageView2/1/w/10/h/10'
                    }
                },
                webp (listener, options) {
                    const isCDN = /playit.tech/
                    if (isCDN.test(listener.src)) {
                        listener.src += '?imageView2/2/format/webp'
                    }
                }
            }
        })
        Vue.use(VueForm, {
            inputClasses: {
                valid: 'form-control-success',
                invalid: 'form-control-danger'
            }
        });
        Vue.use(VueLazyload)
        const routes = [
            { path: '/search' },
            { path: '/search/:category' }
        ]
        const router = new VueRouter({
            mode: 'history',
            routes
        })


        var content = new Vue({
            el: '#content',
            router,
            data: {
                form: {
                    min: '',
                    max: '',
                    brands: [],
                    category: '',
                    q: '',
                    sort: ''
                },
                products: [],
                page: 1,
                maxPage: 1,
                view: 1,
                loading: true
            },

            created(){
                console.log(this.$route)
                this.form.q=this.$route.params.q
                this.form.min=this.$route.params.min
                this.form.max=this.$route.params.max
                this.form.brands=this.$route.params.q
                if ('category' in this.$route.params){
                    this.form.category=this.$route.params.category
                }
                this.page=this.$route.query.page || 1;
                this.fetchProducts()



            },

            methods: {
                changeView (val) {
                    this.view=val
                },
                fetchProducts: _.debounce(function() {
                    this.loading=true;
                    this.$http.get('{{ url('api/products') }}',{params: { min: this.$route.query.min, max: this.$route.query.max, category: this.$route.params.category, rating: this.$route.query.rating, sort: this.form.sort, brand: this.$route.query.brands, q: this.$route.query.q, page: this.$route.query.page }}).then(resp => {
                        this.loading=false;
                        this.products = resp.body.data;
                        this.maxPage = resp.body.last_page;
                    });
                }, 350),
                filterRating(int){
                    var url = new URL(goto);
                    var c = this.$route.query.rating;
                    if(c == int){
                        let query = Object.assign({}, this.$route.query);
                        delete query.rating;
                        this.$router.replace({ query });
                        $('#filter-rating-'+int).removeClass('star-active')
                    }else{
                        this.$router.replace({ query: Object.assign({}, this.$route.query, { rating: int }) })
                        $('.star-active').removeClass('star-active')
                        $('#filter-rating-'+int).addClass('star-active')
                    }
                },
                filterCategory(val){
                    console.log(this.$route.params.category === val)
                    if(this.form.category!==val){
                        this.form.category=val;
                    }else{
                        this.form.category='';
                    }
                },
                filterBrand(){
                    var method=$("input.brand-filter:checked").map(function () {
                        return this.value;
                    }).get().join(",");
                    this.form.brands=method;
                },
                clickCallback: function(pageNum) {
                    this.page=pageNum
                },
                isNumeric: function (n) {
                    return !isNaN(parseFloat(n)) && isFinite(n);
                },

            },
            watch: {
                '$route' (to, from) {
                    this.fetchProducts()
                },
                'form.min' (){
                    if(this.isNumeric(this.form.min) === true){
                        this.$router.replace({ query: Object.assign({}, this.$route.query, { min: this.form.min }) })
                    }
                },
                'form.max' (){
                    if(this.isNumeric(this.form.max) === true){
                        this.$router.replace({ query: Object.assign({}, this.$route.query, { max: this.form.max }) })
                    }
                },
                'form.brands' (){
                    this.$router.replace({ query: Object.assign({}, this.$route.query, { brands: this.form.brands }) })
                },
                'form.category' (){
                    this.$router.replace({ path : '/search/'+this.form.category , query: this.$route.query })
                },
                'form.sort' (){
                    this.$router.replace({ query: Object.assign({}, this.$route.query, { sort: this.form.sort }) })
                },
                'page' () {
                    this.$router.replace({ query: Object.assign({}, this.$route.query, { page: this.page }) })
                }
            }
        })

        var mcontent = new Vue({
            el: '#middle-content',
            router,
            data: {
                recommended: [],
                blogs: []
            },

            created(){
                this.fetchRecommended()
                this.fetchBlogs()

            },

            methods: {
                fetchRecommended: function(val){
                    this.$http.get('{{ url('api/recommended-products') }}').then(resp => {
                        this.recommended = resp.body;
                    });
                },
                fetchBlogs: function(val){
                    this.$http.get('{{ url('api/blogs') }}').then(resp => {
                        this.blogs = resp.body;
                    });
                },


            }
        })
    </script>
@endsection