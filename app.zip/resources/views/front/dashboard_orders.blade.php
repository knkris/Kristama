@extends('layouts.front')

@section('title')
    Test Page Dashboard - Orders
@endsection

@section('head')

@endsection

@section('content')
    <!---- Content Start ---->

    <!-- dashboard orders -->
    <section class="ic-dashboard-orders" id="content">
        <div class="title-head">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <h3>Dashboard - Recent Transaction</h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="ic-single-order ic-order-proegress ic-brd-btm0">
                        <div class="ic-order-head">
                            <p><span class="text-left">On Progress</span> <span class="text-right">01 Januari 2011</span></p>
                            <table>
                                <tr>
                                    <td>Return Number</td>
                                    <td>:</td>
                                    <td>ABC1234567890</td>
                                </tr>
                                <tr>
                                    <td>Return status</td>
                                    <td>:</td>
                                    <td>Rusak</td>
                                </tr>
                            </table>
                        </div>
                        <div class="ic-order-detail">
                            <div class="ic-order-product">
                                <img src="/img/selected-product.jpg" alt="">
                            </div>
                            <div class="ic-op-detail">
                                <h3>Turbo dry iron EHL3018/5</h3>
                                <span>color: black</span>
                                <span>Qty: 1</span>
                                <span>Price: Rp 143.000</span>
                            </div>
                            <div class="ic-order-ftr text-right">
                                <p>Total: RP. 143,000.00</p>
                            </div>
                        </div>
                    </div>
                    <div class="ic-single-order ic-multiple-order ic-brd-btm0">
                        <div class="ic-order-head">
                            <p><span class="text-left">Done</span><span class="text-right">01 Januari 2011</span></p>
                            <table>
                                <tr>
                                    <td>Return Number</td>
                                    <td>:</td>
                                    <td>ABC1234567890</td>
                                </tr>
                                <tr>
                                    <td>Return status</td>
                                    <td>:</td>
                                    <td>Rusak</td>
                                </tr>
                            </table>
                        </div>
                        <div class="ic-order-detail">
                            <div class="ic-order-product">
                                <img src="/img/selected-product.jpg" alt="">
                            </div>
                            <div class="ic-op-detail">
                                <h3>Turbo dry iron EHL3018/5</h3>
                                <span>color: black</span>
                                <span>Qty: 1</span>
                                <span>Price: Rp 143.000</span>
                            </div>
                        </div>
                        <div class="ic-order-detail">
                            <div class="ic-order-product">
                                <img src="/img/selected-product.jpg" alt="">
                            </div>
                            <div class="ic-op-detail">
                                <h3>Turbo dry iron EHL3018/5</h3>
                                <span>color: black</span>
                                <span>Qty: 1</span>
                                <span>Price: Rp 143.000</span>
                            </div>
                            <div class="ic-order-ftr text-right">
                                <p>Total: RP. 143,000.00</p>
                            </div>
                        </div>
                    </div>
                    <div class="ic-single-order">
                        <div class="ic-order-head">
                            <p><span class="text-left">done</span> <span class="text-right">01 Januari 2011</span></p>
                            <table>
                                <tr>
                                    <td>Return Number</td>
                                    <td>:</td>
                                    <td>ABC1234567890</td>
                                </tr>
                                <tr>
                                    <td>Return status</td>
                                    <td>:</td>
                                    <td>Rusak</td>
                                </tr>
                            </table>
                        </div>
                        <div class="ic-order-detail">
                            <div class="ic-order-product">
                                <img src="/img/selected-product.jpg" alt="">
                            </div>
                            <div class="ic-op-detail">
                                <h3>Turbo dry iron EHL3018/5</h3>
                                <span>color: black</span>
                                <span>Qty: 1</span>
                                <span>Price: Rp 143.000</span>
                            </div>
                            <div class="ic-order-ftr text-right">
                                <p>Total: RP. 143,000.00</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- dashboard orders /end -->

    @include('component.front.accountright')
    <!-- @include('component.front.fixbottom') -->>
    <!---- Content End ---->

    @include('component.front.footer')
@endsection

@section('script')
    <script src="{{ asset('js/ic-bmbtn.js') }}"></script>
@endsection