@extends('layouts.front')

@section('title')
	Kreasi2Shop || Official Website 
@endsection
@section('head')
	<style type="text/css">
a.dropdown-toggle.icon-height{
			padding:3px 0px!important;
		}
	
	</style>
@endsection
@section('content')
<section id="slider">
	<ul class="bxslider-two">
		<li><img src="img/banner-1.jpg" alt=""/></li>
		<li><img src="img/banner-2.jpg" alt=""/></li>
		<li><img src="img/banner-3.jpg" alt=""/></li>
		<li><img src="img/banner-4.jpg" alt=""/></li>
	</ul>
</section>
<!---- Content Start ---->
<section id="content" class="shop-content">
	@foreach($parent as $key => $value)
	<?php
	$class=$key+1;
	$classlabel;
	switch ($class) {
		case 1:
			$classlabel='';
			break;

		case 2:
			$classlabel=' two';
			break;

		case 3:
			$classlabel=' three';
			break;

		case 4:
			$classlabel=' four';
			break;

		case 5:
			$classlabel=' five';
			break;
			
		case 6:
			$classlabel=' six';
			break;
		
		default:
			$classlabel=$class;
			break;
	}
	?>
	<div id="shop-{{$class}}" class="shop{{$classlabel}}" data="{{$class}}">
		<div class="blackoverlay"></div>
		<div class="container">
			<div class="row">
				<div class="col-lg-12 text-center col-sm-12 col-xs-12">
					<h4>{{ $value->name }}</h4>
				</div>
				<ul id="ul-{{$class}}">
					@foreach($value->child() as $k => $val)
					<li class="col-lg-4 text-center col-sm-6 col-md-4 col-xs-6">
						<a href="{{ url('search/'.$val->slug) }}"><img src="{{ $val->image ?: 'http://via.placeholder.com/111x103'}}" alt=""/><br>{!! str_replace(' ','<br>',$val->name) !!}</a>
					</li>
					@endforeach
					
				</ul>
			</div>
		</div>
		<div class="col-lg-12 down-arrow text-center col-sm-12 col-xs-12">
			<a id="btn-{{$class}}" ><img src="img/arrow-down.png" width="30px" alt="" /></a>
		</div>
	</div>
	@endforeach
	
	<div class="pertanyaan">
			<h4>Ada Pertanyaan?<br><span>Chat disini..</span></h4>
			<a id="Open" href="#">
				<i class="fa fa-minus" aria-hidden="true"></i>
			</a>	
		<form id="FormOpen">
			<div class="field">
				<label>Perkenalkan diri anda</label>
				<input type="text" placeholder="Nama, Email"/>
			</div>
			<div class="field">
				<label>Pesan</label>
				<textarea></textarea>
			</div>
			<div class="field text-right">
				<input type="submit" value="Submit"/>
			</div>
		</form>
	</div>
	{{-- <a class="left-side" href="#"><img src="img/img-3.png" alt=""/></a> --}}
</section>
<section>
<div class=" text-center back-top">
	<a href="#slider">
		Back To TOP
	</a>
</div>
</section>

@include('component.front.footer')


@endsection

@section('script')
<script type="text/javascript">
$(document).ready(function(){
	  $('.back-top a[href*="#"]:not([href="#"])').click(function() {
	    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
	      var target = $(this.hash);
	      target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
	      if (target.length) {
	        $('html, body').animate({
	          scrollTop: target.offset().top - $('#header').height()
	        }, 1000);
	        return false;
	      }
	    }
	  });

	$('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
	  if (!$(this).next().hasClass('show')) {
	    $(this).parents('.dropdown-menu').first().find('.show').removeClass("show");
	  }
	  var $subMenu = $(this).next(".dropdown-menu");
	  $subMenu.toggleClass('show');
	  return false;
	});

	$('.bxslider').bxSlider({
		auto:false,
		controls:true,
		pager:false,
		slideWidth: 50,
		minSlides: 4,
		maxSlides: 4,
		moveSlides: 1,
		slideMargin: 0,
		speed: 450,
		mode: 'vertical',
		infiniteLoop: false,
		touchEnabled:true 

	});
	$('.bxslider-two').bxSlider({
		auto:true,
		touchEnabled:true,
		controls:true
	});
});
</script>
<script>
$('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
  if (!$(this).next().hasClass('show')) {
    $(this).parents('.dropdown-menu').first().find('.show').removeClass("show");
  }
  var $subMenu = $(this).next(".dropdown-menu");
  $subMenu.toggleClass('show');
  return false;
});
</script>
<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});

// $("#btn-1").click(function(){
//     $("#ul-1 li").toggleClass("show");
//     $("#btn-1").toggleClass("arrow-rotate"); 
// });

// $("#btn-2").click(function(){
//     $("#ul-2 li").toggleClass("show");
// });

// $("#btn-3").click(function(){
//     $("#ul-3 li").toggleClass("show");
// });

// $("#btn-4").click(function(){
//     $("#ul-4 li").toggleClass("show");
// });

// $("#btn-5").click(function(){
//     $("#ul-5 li").toggleClass("show");
// });
$(window).on("scroll", function() { 
    if($(window).scrollTop() > 50) { 
        $(".small-header").addClass("active"); 
    } else { 
        //remove the background property so it comes transparent again (defined in your css) 
       $(".small-header").removeClass("active"); 
    } 
}); 
</script>

<script>
$(document).ready(function(){
  $('.dropdown-subaccount a').on("hover", function(e){
    $(this).next('ul').toggle();
  });
});
</script>
<script type="text/javascript">
$(document).ready(function(){
	$('#content .shop').hover(function(){
		var str = $(this).attr("data");
		$("#ul-" + str + " li").toggleClass("show");
		$("#btn-" + str + "").toggleClass("arrow-rotate"); 
	});
});
</script>
<script type="text/javascript">
if (window.location.hostname != -1) {
$("#account-blog").hide();
}
</script>
@endsection