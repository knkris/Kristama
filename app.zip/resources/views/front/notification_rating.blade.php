@extends('layouts.front')

@section('title')
    Rating Success Page
@endsection

@section('first_head')
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.1.8/semantic.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.1.8/semantic.min.js"></script>

@endsection

@section('head')
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/placeholder-loading/dist/css/placeholder-loading.min.css">
    <style type="text/css">
        .text-red {
            color:#b82e2a !important;
        }
        .star-active .fa-star{
            color:#b82e2a !important;
        }
        #content .kategori-details li a img.category-active {
            -webkit-filter: grayscale(0);
            filter: grayscale(0);
        }
        .filter-price{
            border: 0;
        }
		a.dropdown-toggle.icon-height{
			padding:3px 0px!important;
		}
    </style>
@endsection

@section('content')
    <!---- Content Start ---->
    <section class="ic-confirmation">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="ic-confirmation-dsc">
                        <h2>Thank you, your review and rating has been submitted.</h2>
                </div>
            </div>
        </div>
    </section>

    <section id="middle-content">
        {{-- For Related Products --}}
        @include('component.related_products')

        {{-- For Blog --}}
        @include('component.blogs')

    </section>
    <!---- Content End ---->
    <section class="ic-back-to-top">
        <button id="return-to-top">Back to top</button>
    </section>
    @include('component.front.footer')

@endsection

@section('script')
	<script type="text/javascript">
	$(document).ready(function(){
		  $('a[href*="#"]:not([href="#"])').click(function() {
			if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
			  var target = $(this.hash);
			  target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
			  if (target.length) {
				$('html, body').animate({
				  scrollTop: target.offset().top - $('#header').height()
				}, 1000);
				return false;
			  }
			}
		  });

		$('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
		  if (!$(this).next().hasClass('show')) {
			$(this).parents('.dropdown-menu').first().find('.show').removeClass("show");
		  }
		  var $subMenu = $(this).next(".dropdown-menu");
		  $subMenu.toggleClass('show');
		  return false;
		});
	});
	</script>
	<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});

// $("#btn-1").click(function(){
//     $("#ul-1 li").toggleClass("show");
//     $("#btn-1").toggleClass("arrow-rotate"); 
// });

// $("#btn-2").click(function(){
//     $("#ul-2 li").toggleClass("show");
// });

// $("#btn-3").click(function(){
//     $("#ul-3 li").toggleClass("show");
// });

// $("#btn-4").click(function(){
//     $("#ul-4 li").toggleClass("show");
// });

// $("#btn-5").click(function(){
//     $("#ul-5 li").toggleClass("show");
// });
$(window).on("scroll", function() { 
    if($(window).scrollTop() > 50) { 
        $(".small-header").addClass("active"); 
    } else { 
        //remove the background property so it comes transparent again (defined in your css) 
       $(".small-header").removeClass("active"); 
    } 
}); 
</script>

<script>
$(document).ready(function(){
  $('.dropdown-subaccount a').on("hover", function(e){
    $(this).next('ul').toggle();
  });
});
</script>
    <script>
        $("#price-one").click(function(e){
            e.preventDefault();
            $("#all-price-one").toggle();
        });
        // $("#btnv-1").click(function(){
        //     $("#view-2").addClass("hide");
        //     $("#view-1").removeClass("hide");
        // });

        // $("#btnv-2").click(function(){
        // 	console.log('btnv-2')
        //     $("#view-1").addClass("hide");
        //     $("#view-2").removeClass("hide");
        // });
    </script>
    <script>
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();
        });
        function updateQueryStringParameter(uri, key, value) {
            var re = new RegExp("([?&])" + key + "=.*?(&|$)", "i");
            var separator = uri.indexOf('?') !== -1 ? "&" : "?";
            if (uri.match(re)) {
                return uri.replace(re, '$1' + key + "=" + value + '$2');
            }
            else {
                return uri + separator + key + "=" + value;
            }
        }

        function removeParam(key, sourceURL) {
            var rtn = sourceURL.split("?")[0],
                param,
                params_arr = [],
                queryString = (sourceURL.indexOf("?") !== -1) ? sourceURL.split("?")[1] : "";
            if (queryString !== "") {
                params_arr = queryString.split("&");
                for (var i = params_arr.length - 1; i >= 0; i -= 1) {
                    param = params_arr[i].split("=")[0];
                    if (param === key) {
                        params_arr.splice(i, 1);
                    }
                }
                rtn = rtn + "?" + params_arr.join("&");
            }
            return rtn;
        }

        var i=0,h=0;
        var CU="{{ url()->full() }}";
        goto=CU.replace(/&amp;/g, '&');
        var index=goto.indexOf("?");


        $('.brand-filter').on('change', function(){
            var method=$("input[name=brands]:checked").map(function () {
                return this.value;
            }).get().join(",");
            var gen=updateQueryStringParameter(goto, 'brand',method);
            window.location.href=gen;
        })
        $('#sort-by').on('change', function(){
            var gen=updateQueryStringParameter(goto, 'sort',this.value);
            window.location.href=gen;
        })

        // $('.filter-price').on('change', function(){
        // 	$min=$('#min-price').val();
        // 	$max=$('#max-price').val();
        // 	filterPrice($min,$max)
        // })

        // $('.filter-price').keypress(function(e) {
        //     if(e.which == 13) {
        //         $min=$('#min-price').val();
        // 		$max=$('#max-price').val();
        // 		filterPrice($min,$max)
        //     }
        // });

        function filterRating(int){
            var url = new URL(goto);
            var c = url.searchParams.get("rating");
            if(c == int){
                var gen=removeParam('rating', goto);
                window.location.href=gen;
            }else{
                var gen=updateQueryStringParameter(goto, 'rating',int);
                window.location.href=gen;
            }
        }


        function filterPrice(min,max){
            var min = min;
            var gen=updateQueryStringParameter(goto, 'min',min);
            var max = max;
            var gen=updateQueryStringParameter(gen, 'max',max);
            window.location.href=gen;
        }

        function rupiah(bil){
            var bilangan = bil;

            var	number_string = bilangan.toString(),
                sisa 	= number_string.length % 3,
                rupiah 	= number_string.substr(0, sisa),
                ribuan 	= number_string.substr(sisa).match(/\d{3}/g);

            if (ribuan) {
                separator = sisa ? '.' : '';
                rupiah += separator + ribuan.join('.');
            }

            return rupiah;
        }
    </script>
    <script src="{{ asset('js/ic-select-option.js') }}"></script>
    <script src="https://cdn.jsdelivr.net/npm/vue@2.5.17/dist/vue.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/vue-resource/1.5.1/vue-resource.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/vue-lazyload/1.2.6/vue-lazyload.js"></script>
    <script src="https://unpkg.com/vue-router/dist/vue-router.js"></script>
    <script src="https://rawgit.com/fergaldoyle/vue-form/master/dist/vue-form.min.js"></script>
    <script src="https://unpkg.com/lodash@4.17.10/lodash.min.js"></script>
    <script src="https://unpkg.com/vuejs-paginate@latest"></script>
    <script>
        var module = {};
        Vue.use(VueRouter)
        Vue.use(VueResource);
        Vue.component('paginate', VuejsPaginate)
        Vue.use(VueLazyload, {
            preLoad: 1.3,
            // error: 'dist/error.png',
            loading: '{{ url('img/135.gif') }}',
            attempt: 1,
            // the default is ['scroll', 'wheel', 'mousewheel', 'resize', 'animationend', 'transitionend']
            listenEvents: [ 'scroll' ],
            filter: {
                progressive (listener, options) {
                    const isCDN = /playit.tech/
                    if (isCDN.test(listener.src)) {
                        listener.el.setAttribute('lazy-progressive', 'true')
                        listener.loading = listener.src + '?imageView2/1/w/10/h/10'
                    }
                },
                webp (listener, options) {
                    const isCDN = /playit.tech/
                    if (isCDN.test(listener.src)) {
                        listener.src += '?imageView2/2/format/webp'
                    }
                }
            }
        })
        Vue.use(VueForm, {
            inputClasses: {
                valid: 'form-control-success',
                invalid: 'form-control-danger'
            }
        });
        Vue.use(VueLazyload)
        const routes = [
            { path: '/search' },
            { path: '/search/:category' }
        ]
        const router = new VueRouter({
            mode: 'history',
            routes
        })


        var content = new Vue({
            el: '#content',
            router,
            data: {
                form: {
                    min: '',
                    max: '',
                    brands: [],
                    category: '',
                    q: '',
                    sort: ''
                },
                products: [],
                page: 1,
                maxPage: 1,
                view: 1,
                loading: true
            },

            created(){
                console.log(this.$route)
                this.form.q=this.$route.params.q
                this.form.min=this.$route.params.min
                this.form.max=this.$route.params.max
                this.form.brands=this.$route.params.q
                if ('category' in this.$route.params){
                    this.form.category=this.$route.params.category
                }
                this.page=this.$route.query.page || 1;
                this.fetchProducts()



            },

            methods: {
                changeView (val) {
                    this.view=val
                },
                fetchProducts: _.debounce(function() {
                    this.loading=true;
                    this.$http.get('{{ url('api/products') }}',{params: { min: this.$route.query.min, max: this.$route.query.max, category: this.$route.params.category, rating: this.$route.query.rating, sort: this.form.sort, brand: this.$route.query.brands, q: this.$route.query.q, page: this.$route.query.page }}).then(resp => {
                        this.loading=false;
                        this.products = resp.body.data;
                        this.maxPage = resp.body.last_page;
                    });
                }, 350),
                filterRating(int){
                    var url = new URL(goto);
                    var c = this.$route.query.rating;
                    if(c == int){
                        let query = Object.assign({}, this.$route.query);
                        delete query.rating;
                        this.$router.replace({ query });
                        $('#filter-rating-'+int).removeClass('star-active')
                    }else{
                        this.$router.replace({ query: Object.assign({}, this.$route.query, { rating: int }) })
                        $('.star-active').removeClass('star-active')
                        $('#filter-rating-'+int).addClass('star-active')
                    }
                },
                filterCategory(val){
                    console.log(this.$route.params.category === val)
                    if(this.form.category!==val){
                        this.form.category=val;
                    }else{
                        this.form.category='';
                    }
                },
                filterBrand(){
                    var method=$("input.brand-filter:checked").map(function () {
                        return this.value;
                    }).get().join(",");
                    this.form.brands=method;
                },
                clickCallback: function(pageNum) {
                    this.page=pageNum
                },
                isNumeric: function (n) {
                    return !isNaN(parseFloat(n)) && isFinite(n);
                },

            },
            watch: {
                '$route' (to, from) {
                    this.fetchProducts()
                },
                'form.min' (){
                    if(this.isNumeric(this.form.min) === true){
                        this.$router.replace({ query: Object.assign({}, this.$route.query, { min: this.form.min }) })
                    }
                },
                'form.max' (){
                    if(this.isNumeric(this.form.max) === true){
                        this.$router.replace({ query: Object.assign({}, this.$route.query, { max: this.form.max }) })
                    }
                },
                'form.brands' (){
                    this.$router.replace({ query: Object.assign({}, this.$route.query, { brands: this.form.brands }) })
                },
                'form.category' (){
                    this.$router.replace({ path : '/search/'+this.form.category , query: this.$route.query })
                },
                'form.sort' (){
                    this.$router.replace({ query: Object.assign({}, this.$route.query, { sort: this.form.sort }) })
                },
                'page' () {
                    this.$router.replace({ query: Object.assign({}, this.$route.query, { page: this.page }) })
                }
            }
        })

        var mcontent = new Vue({
            el: '#middle-content',
            router,
            data: {
                recommended: [],
                blogs: []
            },

            created(){
                this.fetchRecommended()
                this.fetchBlogs()

            },

            methods: {
                fetchRecommended: function(val){
                    this.$http.get('{{ url('api/recommended-products') }}').then(resp => {
                        this.recommended = resp.body;
                    });
                },
                fetchBlogs: function(val){
                    this.$http.get('{{ url('api/blogs') }}').then(resp => {
                        this.blogs = resp.body;
                    });
                },


            }
        })
    </script>
@endsection