@extends('layouts.front')

@section('title')
	Form Retur
@endsection

@section('head')

@endsection

@section('content')
<!---- Content Start ---->
<section id="content" style="padding-bottom:60px;">
	<div class="title-head">
		<div class="container">
			<div class="row">
				<div class="col-lg-12  col-xs-12 col-sm-12">
					<h3>Form Retur / Refund</h3>
				</div>
			</div>
		</div>		
	</div>
</section>
<section id="Pertanyaan-Umum" style="padding-bottom:60px;">
<div class="row">
		<div class="col-lg-10 col-lg-offset-1 col-md-10 col-md-offset-1">
			<div class="col-lg-3">
				<h3 style="margin-top:0px;"><strong>FAQ SUPPORT</strong></h3>
				<hr>
				<a href="{{url('faq/form-retur')}}"><p>Form Retur</p></a>
				<hr>
				<a href="{{url('faq/retur')}}"><p>Refund / Retur</p></a>
				<hr>
				<div class="dropdown">
				<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Serangkaian Pertanyaan Umum<span class="caret"></span></button>
				<ul class="dropdown-menu">
				<li><a title="General" href="https://k2s.playit.tech/faq/status-pesanan">Status pesanan</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/umum">Umum</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/akun">Akun</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/cara-belanja">Cara Belanja</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/garansi">Garansi</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/pembayaran">Pembayaran</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/pengiriman">Pengiriman</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/retur">Refund</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/retur">Retur Produk</a></li>
				<li><a title="General" href="#">Tiket</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/kupon-diskon">Kupon Diskon</a></li>
				</ul>
				</div>
			</div>
			<div class="col-lg-9">
				<div>
				<div class="std"><p>&nbsp;</p></div><div class="awrma-account">
				<div class="page-title title-buttons">
				<h1>Request RMA</h1>
				</div>
				<div id="messages">
				</div>
				<p>You have no completed orders to request RMA or your orders were placed more than 30 days ago</p>
				</div>
				</div>	
			</div>
			<hr>
		</div>
</div>
</section>
<!-- Content End-->
@include('component.front.footer')
@endsection

@section('script')

@endsection