@extends('layouts.front')

@section('title')
    {{ $order->invoice }}
@endsection

@section('head')
 <style type="text/css">
        .gray-bg {
            background:  #ebecee; 
			padding:15px;
        }
	</style>
@endsection

@section('content')
    <!---- Content Start ---->

    <!-- order detail  -->
    <section class="ic-upport-issue ic-detail-issue-wrapper" id="content">
        <div class="title-head">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <h3>Dashboard order {{ $order->invoice }} order-detail</h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="ic-order-steps">
                        @foreach($order->OrderHistory as $key => $value)
                        @switch($value->order_status_id)
                            @case(1)
                            <div class="ic-step ic-step-active @if($order->order_status_id!=1) ic-progress-fill @endif">
                                <span class="ic-round-icon">
                                    {!! $order_made !!}
                                    <span class="ic-progress">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                  </span>
                                </span>
                                <span class="ic-step-title">
                                  pesanan dibuat
                                  <span class="ic-step-date">
                                    {{ \Carbon\Carbon::parse($value->created_at)->format('d/m/Y H:i:s') }}
                                  </span>
                                </span>
                            </div>
                            @break

                            @case(11)
                                <div class="ic-step ic-step-active @if($order->order_status_id==3 || $order->order_status_id==4) ic-progress-fill @endif">
                                    <span class="ic-round-icon">
                                        {!! $order_sent !!}
                                        <span class="ic-progress">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                      </span>
                                    </span>
                                            <span class="ic-step-title">
                                      pesanan dibayarkan
                                      <span class="ic-step-date">
                                        {{ \Carbon\Carbon::parse($value->created_at)->format('d/m/Y H:i:s') }}
                                      </span>
                                    </span>
                                </div>
                                @break

                            @case(3)
                                <div class="ic-step ic-step-active @if($order->order_status_id==4) ic-progress-fill @endif">
                                    <span class="ic-round-icon">
                                        {!! $order_shipping !!}
                                        <span class="ic-progress">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                      </span>
                                    </span>
                                            <span class="ic-step-title">
                                      pesanan dikirimkan
                                      <span class="ic-step-date">
                                        {{ \Carbon\Carbon::parse($value->created_at)->format('d/m/Y H:i:s') }}
                                      </span>
                                    </span>
                                        </div>
                                        @break

                                @case(4)
                                    <div class="ic-step @if($order->order_status_id==4) ic-step-active ic-progress-fill @endif">
                                    <span class="ic-round-icon">
                                        {!! $order_box !!}
                                        <span class="ic-progress">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                      </span>
                                    </span>
                                            <span class="ic-step-title">
                                      pesanan diterima
                                      <span class="ic-step-date">
                                        {{ \Carbon\Carbon::parse($value->created_at)->format('d/m/Y H:i:s') }}
                                      </span>
                                    </span>
                                        </div>
                                        <div class="ic-step ic-step-active">
                                    <span class="ic-round-icon">
                                        {!! $order_check !!}
                                    </span>
                                            <span class="ic-step-title">
                                      pesanan selesai
                                      <span class="ic-step-date">
                                        {{ \Carbon\Carbon::parse($value->created_at)->format('d/m/Y H:i:s') }}
                                      </span>
                                    </span>
                                </div>
                                @break

                            @default

                                @break

                            @endswitch  
                        @endforeach

                        @if($order->order_status_id==1)
                            <div class="ic-step">
                                <span class="ic-round-icon">
                                    {!! $order_sent !!}
                                    <span class="ic-progress">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                  </span>
                                </span>
                                        <span class="ic-step-title">
                                  pesanan dibayarkan
                                  <span class="ic-step-date">
                                    
                                  </span>
                                </span>
                            </div>

                            <div class="ic-step">
                                    <span class="ic-round-icon">
                                        {!! $order_shipping !!}
                                        <span class="ic-progress">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                      </span>
                                    </span>
                                            <span class="ic-step-title">
                                      pesanan dikirimkan
                                      <span class="ic-step-date">
                                      </span>
                                    </span>
                                        </div>

                                        <div class="ic-step">
                                    <span class="ic-round-icon">
                                        {!! $order_box !!}
                                        <span class="ic-progress">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                      </span>
                                    </span>
                                            <span class="ic-step-title">
                                      pesanan diterima
                                      <span class="ic-step-date">
                                      </span>
                                    </span>
                                        </div>
                                        <div class="ic-step">
                                    <span class="ic-round-icon">
                                        {!! $order_check !!}
                                    </span>
                                            <span class="ic-step-title">
                                      pesanan selesai
                                      <span class="ic-step-date">
                                      </span>
                                    </span>
                                </div>
                        @elseif($order->order_status_id==11)
                            <div class="ic-step">
                                    <span class="ic-round-icon">
                                        {!! $order_shipping !!}
                                        <span class="ic-progress">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                      </span>
                                    </span>
                                            <span class="ic-step-title">
                                      pesanan dikirimkan
                                      <span class="ic-step-date">
                                      </span>
                                    </span>
                                        </div>

                                        <div class="ic-step">
                                    <span class="ic-round-icon">
                                        {!! $order_box !!}
                                        <span class="ic-progress">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                      </span>
                                    </span>
                                            <span class="ic-step-title">
                                      pesanan diterima
                                      <span class="ic-step-date">
                                      </span>
                                    </span>
                                        </div>
                                        <div class="ic-step">
                                    <span class="ic-round-icon">
                                        {!! $order_check !!}
                                    </span>
                                            <span class="ic-step-title">
                                      pesanan selesai
                                      <span class="ic-step-date">
                                      </span>
                                    </span>
                                </div>
                        @elseif($order->order_status_id==3)
                             <div class="ic-step">
                                <span class="ic-round-icon">
                                    {!! $order_box !!}
                                    <span class="ic-progress">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                  </span>
                                </span>
                                        <span class="ic-step-title">
                                  pesanan diterima
                                  <span class="ic-step-date">
                                  </span>
                                </span>
                                    </div>
                                    <div class="ic-step">
                                <span class="ic-round-icon">
                                    {!! $order_check !!}
                                </span>
                                        <span class="ic-step-title">
                                  pesanan selesai
                                  <span class="ic-step-date">
                                  </span>
                                </span>
                            </div>
                        @endif
                        
                    </div>
                    <?php
                    $try=$order->OrderHistory()->whereOrder_status_id(3)->first();
                    $resi='-';
                    if(count($try)){
                        $resi=$try->comment;
                    }
                    ?>
                    <div class="ic-order-delivery">
                        <span>Pengiriman</span>
                        <span class="ic-order-id">No Resi: <strong>{{ $resi }}</strong></span>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="ic-order-shipping-address">
                                <h3>Shipping address</h3>
                                <address>
                                    <h4>{{ $order->shipping_name }}<br>
                                    {{ $order->shipping_address }}<br>
                                    {{ $order->shipping_city }}<br>
                                    {{ $order->shipping_province }}<br>
                                    {{ $order->shipping_postal_code }}
                                </address>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="ic-v-steps ic-vsteps-active">
                                @foreach($order->OrderHistory as $key => $value)
                                @switch($value->order_status_id)
                                    @case(1)
                                    <div class="ic-vstep">
                                        <span></span>
                                        <p>{{ \Carbon\Carbon::parse($value->created_at)->format('d/m/Y H:i:s') }} <span>Pesanan dibuat</span></p>
                                    </div>
                                    @break

                                    @case(11)
                                    <div class="ic-vstep">
                                        <span></span>
                                        <p>{{ \Carbon\Carbon::parse($value->created_at)->format('d/m/Y H:i:s') }} <span>Pesanan Dibayarkan</span></p>
                                    </div>
                                    @break

                                    @case(3)
                                    <div class="ic-vstep">
                                        <span></span>
                                        <p>{{ \Carbon\Carbon::parse($value->created_at)->format('d/m/Y H:i:s') }} <span>Pesanan Dikirimkan</span></p>
                                    </div>
                                    @break

                                    @case(4)
                                    <div class="ic-vstep">
                                        <span></span>
                                        <p>{{ \Carbon\Carbon::parse($value->created_at)->format('d/m/Y H:i:s') }} <span>Pesanan Diterima</span></p>
                                    </div>
                                    <div class="ic-vstep">
                                        <span></span>
                                        <p>{{ \Carbon\Carbon::parse($value->created_at)->format('d/m/Y H:i:s') }} <span>Pesanan Selesai</span></p>
                                    </div>
                                    @break

                                @default

                                    @break

                                @endswitch
                                @endforeach
                                <!-- <span class="ic-v-step-btm"></span> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- order detail  /end -->

    <!-- orders-item -->
    <section class="ic-order-items-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="ic-order-delivery">
                        <span>Items</span>
                        <span class="ic-order-id">Order Number: <strong>{{ $order->invoice }}</strong></span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    @foreach($order->OrderDetail as $key => $value)
                    <?php $product=$value->Product; ?>
                    <div class="ic-single-order-item">
                        <div class="ic-order-product-fig">
                            <img src="{{ $product->Image->first()->image }}" alt="{{$product->name }}">
                        </div>
                        <div class="ic-order-product-dsc">
                            <h4>{{ $product->name }}</h4>
                            <table>
                                {{-- <tr>
                                    <td>Color</td>
                                    <td>:</td>
                                    <td>Black</td>
                                </tr> --}}
                                <tr>
                                    <td>Qty</td>
                                    <td>:</td>
                                    <td>{{ $value->qty }}</td>
                                </tr>
                                <tr class="ic-red">
                                    <td>Price</td>
                                    <td>:</td>
                                    <td>{{ currency_format($value->price, 'IDR')}}</td>
                                </tr>
                                <?php
                                $inv=explode('/',$order->invoice);
                                ?>
                                <tr>
                                    <td colspan="3">
                                       
                                    </td>
                                </tr>
                            </table>
                            <div style="margin-top:15px;"> 
                                @if($order->order_status_id==3 || $order->order_status_id==4)
                                <a href="{{ url('return/'.$inv[2]) }}" class="btn-success">Return</a>
                                @elseif($order->order_status_id==12)
                                <button type="button" class="btn btn-pending" disabled="disabled">Waiting Return Approval</button>
                                @endif
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
                <div class="col-sm-6">
                    <div class="ic-order-summery gray-bg">
                        <h3><span>Order </span> Summary</h3>
                        <table class="order-summary">
                            <tr>
                                <td>Price</td>
                                <td>{{ currency_format($order->subtotal, 'IDR')}}</td>
                            </tr>
                            <tr>
                                <td>Tax</td>
                                <td>Rp 0,-</td>
                            </tr>
                            <tr>
                                <td>Shipping &amp; Handling</td>
                                <td>{{ currency_format($order->shipping_cost, 'IDR')}}</td>
                            </tr>
                            {{-- <tr>
                                <td>Discount</td>
                                <td>-Rp 100.000,-</td>
                            </tr>
                            <tr>
                                <td>Kupon</td>
                                <td>-Rp 0,-</td>
                            </tr> --}}
                            <tr>
                                <td></td>
                                <td></td>
                            </tr>
                            {{-- <tr>
                                <td>Jumlah</td>
                                <td>Rp 286.00,-</td>
                            </tr>
                            <tr>
                                <td>Dompet</td>
                                <td>Rp 0,-</td>
                            </tr> --}}
                            <tr class="ic-order-price">
                                <td>Total</td>
                                <td>{{ currency_format($order->total, 'IDR')}}</td>
                            </tr>
                           {{--  <tr>
                                <td>You have</td>
                                <td>Rp 1000.000,-</td>
                            </tr> --}}
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- orders-item /end -->

    @include('component.front.accountright')
    @include('component.front.fixbottom')
    <!---- Content End ---->

    @include('component.front.footer')
@endsection

@section('script')
    <script src="{{ asset('js/ic-bmbtn.js') }}"></script>
@endsection