@extends('layouts.front')

@section('title')
    Test Page Address Book
@endsection

@section('head')
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.min.css">
@endsection

@section('content')
    <!---- Content Start ---->
    <section id="content" class="ic-mc-daddress-book bg-none">
        <div class="title-head">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <h3>My Account - Address Book</h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="ic-address-book-col">
                        <form id="address-form" class="ic-form ic-psf" action="{{ route('address.create') }}" method="post">
                            {!! csrf_field() !!}
                            <input type="hidden" name="back_url" value="{{ \Request::get('back_url') }}">
                            <div class="ic-form-head">
                                <div class="ic-adddress-book">
                        <span>
                            <!-- {//!! $address_book_image !!} -->
                            <i class="fa fa-plus"></i>
                        </span>
                                </div>
                                <div class="ic-fh-title">
                                    <h3>Profile settings</h3>
                                </div>
                            </div>
                            <div class="ic-input-wrapper">
                                <div class="ic-single-input">
                                    <input type="text" placeholder="First Name" name="first_name" value="{{ old('first_name') }}">
                                    <span class="ic-required">*</span>
                                </div>
                                <div class="ic-single-input">
                                    <input type="text" placeholder="Middle Name" name="middle_name" value="{{ old('middle_name') }}">
                                </div>
                                <div class="ic-single-input">
                                    <input class="ic-brdr-btm" type="text" placeholder="Last Name" name="last_name" value="{{ old('last_name') }}">
                                    <span class="ic-required">*</span>
                                </div>
                                <div class="ic-dbl-input">
                                    <label>Recipient's Phone Number</label>
                                    <input class="ic-country-cod" type="text" name="phone_prefix" value="+62" disabled="">
                                    <input class="ic-c-phone" type="text" name="phone" value="{{ old('phone') }}" placeholder="" style="border-left: 0;">
                                    <span class="ic-required">*</span>
                                </div>
                                <div class="ic-single-input ic-hauto ic-detail-txtarea">
                                    <textarea cols="30" rows="7" placeholder="Jl. keselepet secara disengaja" name="address">{{ old('address') }}</textarea>
                                </div>
                                <div class="ic-single-input ic-hauto ic-sp-desc">
                                    <?php /*<div class="ic-select">
                                        <select name="city" id="city">
                                        @if(old('city'))
                                            <?php
                                            $city=\App\Models\Subdistrict::find(old('city'));
                                            ?>
                                            <option value="{{ $city->id }}">{{ $city->name.' - '.$city->type.' '.$city->city }}</option>
                                        @endif
                                        </select>
                                    </div>*/ ?>
                                </div>
                                <div class="ic-single-input">
                                    {{-- <input type="text" placeholder="Kasian"> --}}
                                    <select name="city" id="city" style="width: 100%">
                                        @if(old('city'))
                                            <?php
                                            $city=\App\Models\City::find(old('city'));
                                            ?>
                                            <option value="{{ $city->id }}">{{ $city->name.' - '.$subdistrict->province }}</option>
                                        @endif
                                        </select>
                                </div>
                                <div class="ic-single-input">
                                    {{-- <input type="text" placeholder="Kasian"> --}}
                                    <select name="subdistrict" id="subdistrict" style="width: 100%">
                                        @if(old('subdistrict'))
                                            <?php
                                            $subdistrict=\App\Models\Subdistrict::find(old('subdistrict'));
                                            ?>
                                            <option value="{{ $subdistrict->id }}">{{ $subdistrict->name.' - '.$subdistrict->type.' '.$subdistrict->city }}</option>
                                        @endif
                                        </select>
                                </div>
                                <div class="ic-single-input">
                                    <input type="text" placeholder="10110" name="postal_code" value="{{ old('postal_code') }}"> 
                                </div>
                                <div class="ic-single-input">
                                    <input type="text" class="ic-brdr-btm" name="country" value="Indonesia" disabled="true" />
                                </div>
                                <div class="ic-single-input ic-form-btns">
                                    <button type="reset" value="Reset">Cancel</button>
                                    <button class="ic-submit add-address" id="profile-submit" type="button" value="Submit">+ Add</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
                <div class="col-md-4">
                    @foreach($address as $key => $value)
                    
                    <div class="ic-address-card">
                        <h3>{{ $value->name }}</h3>
                        <span>{{ $value->address }}</span>
                        <span>{{$value->getCity().', '.$value->Subdistrict->province.', '.$value->postal_code}}</span>
                        <span>Indonesia</span>
                        <a href="tel:+{{ $value->telephone }}">{{ $value->telephone }}</a>
                        <div id="address-icon-{{ $value->id }}" class="ic-address-flag address-icon @if($value->main==1) flag-active @endif" data-id="{{ $value->id }}"></div>
                        <!-- <span class="bookmark"><i id="address-icon-{{ $value->id }}" class="fa fa-bookmark fa-3 default address-icon @if($value->main==1) active @endif" data-id="{{ $value->id }}" aria-hidden="true"></i></span>-->
                        <a href="{{ route('address.edit',$value->id) }}"><span class="edit-address"><i class="fa fa-gear fa-3 default" aria-hidden="true"></i></span></a>
                        <span class="delete-address" data-id="{{ $value->id }}"><i class="fa fa-trash fa-3 default" aria-hidden="true"></i></span>
                    </div>
                    @endforeach
                    
                </div>
            </div>
        </div>
    </section>

    @include('component.front.accountright')
    @include('component.front.fixbottom')
    <!---- Content End ---->

    @include('component.front.footer')
@endsection

@section('script')
    <script src="{{ asset('js/ic-bmbtn.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.full.min.js"></script>
    <script>
    $('#city').select2({
        placeholder: "Choose city...",
        ajax: {
            url: '{{ url('search-city')}}',
            dataType: 'json',
            quietMillis: 1000,
            data: function (params) {
                return {
                    q: $.trim(params.term)
                };
            },
            processResults: function (data) {
                return {
                    results: data
                };
            },
            cache: true
        }
    });

    $('#subdistrict').select2({
        placeholder: "Choose subdistrict...",
        ajax: {
            url: '{{ url('search-subdistrict')}}',
            dataType: 'json',
            quietMillis: 1000,
            data: function (params) {
                return {
                    q: $.trim(params.term),
                    city_id: $('#city').val()
                };
            },
            processResults: function (data) {
                return {
                    results: data
                };
            },
            cache: true
        }
    });

    $('.add-address').on('click', function(){
        $('#address-form').submit();
    })

    </script>
    <script type="text/javascript">
    $('.address-icon').on('click', function(e){
        e.preventDefault();
        var id=$(this).data('id');
        $.get('{{ url('set-main-address') }}/'+id, function() {
            $('.address-icon.flag-active').removeClass('flag-active');
            $('#address-icon-'+id).addClass('flag-active');
          toastr.success('Alamat utama berhasil diubah!', 'Success!')
        })
        .fail(function() {
          toastr.error('Terjadi Kesalahan pada server!', 'Kesalahan!')
        })
    })

    $('.delete-address').on('click', function(e){
        e.preventDefault();
        $this=$(this);
        $id=$this.data('id');
        swal({
              title: 'Delete Address?',
              text: "You are going to delete this address, confirm?",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
              if (result.value) {
                window.location.href="{{ url('delete-address') }}/"+$id;
              }
            })
    })

</script>
@endsection