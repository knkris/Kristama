@extends('layouts.front')

@section('title')
	Add Address
@endsection

@section('head')
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.min.css">

	<style type="text/css">
		span.select2, span.select2 span {
			left: 0;
		}
	</style>
@endsection

@section('content')
<!---- Content Start ---->
<section id="content" class="sign">
	<div class="title-head">
		<div class="container">
			<div class="row">
				<div class="col-lg-12  col-xs-12 col-sm-12">
					<h3>Add Address</h3>
				</div>
			</div>
		</div>		
	</div>
	<div class="container">
		<div class="row">
			<div class="col-lg-4 col-lg-offset-4  col-xs-12 col-sm-12">
				<form id="address-form" class="space-side" action="{{ route('address.create') }}" method="post">
					{{ csrf_field() }}
					<input type="hidden" name="back_url" value="{{ \Request::get('back_url') }}">
					<div class="field">
						<div class="col-lg-12 flush">
							<input type="text" name="name" value="{{ old('name') }}" placeholder="Nama Penerima"/>
							<div class="required">*</div>
						</div>
					</div>
					<div class="field text-left">
						<div class="col-lg-3 text-center flush col-sm-3 col-xs-12">
							<input type="text" name="phone_code" value="+62" disabled="" />
						</div>
						<div class="col-lg-9 text-center flush col-sm-9 col-xs-12">
							<input type="text" name="phone" value="{{ old('phone') }}" placeholder="" style="border-left: 0;" /><div class="required">*</div>
						</div>
					</div>
					<div class="field">
						<div class="col-lg-12 flush">
							<input type="text" name="country" value="Indonesia" disabled="true" /><div class="required">*</div>
						</div>
					</div>
					<div class="field">
						<div class="col-lg-12 flush">
							<select name="city" id="city">
							@if(old('city'))
								<?php
								$city=\App\Models\Subdistrict::find(old('city'));
								?>
								<option value="{{ $city->id }}">{{ $city->name.' - '.$city->type.' '.$city->city }}</option>
							@endif
							</select>
							<div class="required">*</div>
						</div>
					</div>
					<div class="field">
						<div class="col-lg-12 flush">
							<input type="text" name="postal_code" value="{{ old('postal_code') }}" placeholder="Kodepos"/>
							<div class="required">*</div>
						</div>
					</div>
					<div class="field">
						<div class="col-lg-12 flush">
							<textarea name="address" placeholder="Alamat">{{ old('address') }}</textarea><div class="required">*</div>
						</div>
					</div>
					<div class="field">
						<div class="col-lg-12 flush">
							<div class="checkbox">
							  <label><input type="checkbox" name="default" value="1" @if(old('default')==1) checked="checked" @endif >Set sebagai Default</label>
							</div>
						</div>
					</div>
				</form>
			</div>

			<div class="col-lg-12 top-bottom col-sm-12 col-xs-12" style="margin-bottom: 15px;">
				<div class="field">
					<div class="col-lg-6 col-sm-6 col-xs-6">
						<button type="submit">Cancel</button>
					</div>
					<div class="col-lg-6 text-right col-sm-6 col-xs-6">
						<button type="submit" class="add-address">Save</button>
					</div>
				</div>	
			</div>
		</div>	
	</div>

</section>
@include('component.front.fixbottom')
<!-- Content End-->
@include('component.front.footer')
@endsection

@section('script')
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.full.min.js"></script>
<script>
$('#city').select2({
    placeholder: "Choose city...",
    ajax: {
        url: '{{ url('search-city')}}',
        dataType: 'json',
        quietMillis: 1000,
        data: function (params) {
            return {
                q: $.trim(params.term)
            };
        },
        processResults: function (data) {
            return {
                results: data
            };
        },
        cache: true
    }
});

$('.add-address').on('click', function(){
	$('#address-form').submit();
})

</script>
@endsection