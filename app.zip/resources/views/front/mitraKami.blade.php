@extends('layouts.front')

@section('title')
	Mitra Kami
@endsection

@section('head')

@endsection

@section('content')
<!---- Content Start ---->
<section id="content" style="padding-bottom:60px;">
	<div class="title-head">
		<div class="container">
			<div class="row">
				<div class="col-lg-12  col-xs-12 col-sm-12">
					<h3>Lokasi Mitra Kami</h3>
				</div>
			</div>
		</div>		
	</div>
</section>
<section id="Tentang-kami" style="padding-bottom:60px;">
<div class="row">
		<div class="col-lg-10 col-lg-offset-1 col-md-10 col-md-offset-1">
			<div class="col-lg-3">
				<h3 style="margin-top:0px;"><strong>KREASI2SHOP OFFICE</strong></h3>
				<hr>
				<a href="{{url('faq/kenapa-beli')}}"><p>Kenapa Beli Di Kreasi2Shop?</p></a>
				<hr>
				<a href="{{url('faq/hubungi-kami')}}"><p>Hubungi Kami</p></a>
				<hr>
				<a href="{{url('faq/mitra-kami')}}"><p>Lokasi mitra Kami</p></a>
				<hr>
				<a href="{{url('faq/service-center')}}"><p>Lokasi Service Center</p></a>
			</div>
			<div class="col-lg-9">
				<div class="col-md-4 col-sm-4">
				<div class="content pickupstore-container">
				<p><span style="font-size: medium;"><strong>Jakarta</strong></span></p>
				<p><strong>Alamat</strong><br> Showroom daan mogot <br> Jl. Daan mogot No. 111<br> Grogol - Petamburan<br> Jakarta Barat 11460</p>
				<p><strong>Jam buka toko</strong><br> Senin – Jumat : 08:30 - 17:00<br> Sabtu : 08:30 - 14:30<br> Minggu / Hari Besar : Libur</p>
				<p><strong>Telp : (021) 5664790</strong></p>
				<p><a class="btn show-up" href="https://www.google.co.id/maps/place/Jl.+Daan+Mogot+No.30,+Wijaya+Kusuma,+Grogol+petamburan,+Kota+Jakarta+Barat,+Daerah+Khusus+Ibukota+Jakarta/@-6.1646896,106.7768337,17z/data=!4m13!1m7!3m6!1s0x2e69f64ee6e91bf9:0xae6fd369064538cb!2sJl.+Daan+Mogot+No.111,+Wijaya+Kusuma,+Grogol+petamburan,+Kota+Jakarta+Barat,+Daerah+Khusus+Ibukota+Jakarta!3b1!8m2!3d-6.1640396!4d106.7793122!3m4!1s0x2e69f64efbf65bef:0x811fea7a5dfd7a05!8m2!3d-6.1646949!4d106.7790224?hl=id" target="”_blank”">SHOW MAP</a></p>
				</div>
				</div>
				<div class="col-md-4 col-sm-4">
				<div class="content pickupstore-container">
				<p><span style="font-size: medium;"><strong>Bandung</strong></span></p>
				<p><strong>Alamat</strong><br> Jl. Pasir Koja No. 38A Bandung</p>
				<p><strong>Jam buka toko</strong><br> Senin – Jumat : 08:30 - 17:00<br> Sabtu : 08:30 - 14:30<br> Minggu / Hari Besar : Libur</p>
				<p><strong>Telp : (022) 420 8266</strong></p>
				<p><a class="btn show-up" href="https://www.google.co.id/maps/place/Philips+Authorized+Service+Centre+(DAP)/@-6.9269918,107.600454,19.5z/data=!4m13!1m7!3m6!1s0x2e68e620ed8c02af:0x36ceb794ed9aa01!2sJl.+Terusan+Pasir+Koja+No.38,+Nyengseret,+Astanaanyar,+Kota+Bandung,+Jawa+Barat!3b1!8m2!3d-6.9270012!4d107.6014074!3m4!1s0x0:0x991f5a2ef4f93e69!8m2!3d-6.9268376!4d107.6013663?hl=id" target="”_blank”">SHOW MAP</a></p>
				</div>
				</div>
				<div class="col-md-4 col-sm-4">
				<div class="content pickupstore-container">
				<p><span style="font-size: medium;"><strong>Kediri</strong></span></p>
				<p><strong>Alamat</strong><br>Jl. Brigjen katamso No. 112 Kediri</p>
				<p><strong>Jam buka toko</strong><br>Senin – Jumat : 08:30 - 17:00<br> Sabtu : 08:30 - 14:30<br> Minggu / Hari Besar : Libur</p>
				<p><strong>Telp : (0354) 672 389</strong></p>
				<p><a class="btn show-up" href="https://www.google.co.id/maps/place/Philips+Authorized+Service+Center/@-7.829159,112.0148283,17z/data=!3m1!4b1!4m5!3m4!1s0x2e785709689690e9:0x1ad945fc6b8f0310!8m2!3d-7.829159!4d112.017017?hl=en" target="”_blank”">SHOW MAP</a></p>
				</div>
				</div>
				<div class="col-md-4 col-sm-4">
				<div class="content pickupstore-container">
				<p><span style="font-size: medium;"><strong>Medan</strong></span></p>
				<p><strong>Alamat</strong><br>Jl. Glugur No. 47 / Jl. S. Parman Medan</p>
				<p><strong>Jam buka toko</strong><br>Senin – Jumat : 08:30 - 17:00<br> Sabtu : 08:30 - 14:30<br> Minggu / Hari Besar : Libur</p>
				<p><strong>Telp : (061) 414 3348</strong></p>
				<p><a class="btn show-up" href="https://www.google.co.id/maps/place/Philips+Authorized+Service+Center+Medan/@3.6000907,98.6579438,14z/data=!4m8!1m2!2m1!1sJl.+Glugur+No.+47+%2F+Jl.+S.+Parman+Medan!3m4!1s0x303131daf062f419:0x329a427fc86a6110!8m2!3d3.592362!4d98.668832?hl=id" target="”_blank”">SHOW MAP</a></p>
				</div>
				</div>
				<div class="col-md-4 col-sm-4">
				<div class="content pickupstore-container">
				<p><span style="font-size: medium;"><strong>Surabaya</strong></span></p>
				<p><strong>Alamat</strong><br>Jl. HR Mohammad No.5 Surabaya</p>
				<p><strong>Jam buka toko</strong><br>Senin – Jumat : 08:30 - 17:00<br> Sabtu : 08:30 - 14:30<br> Minggu / Hari Besar : Libur</p>
				<p><strong>Telp : (031) 732 1218</strong></p>
				<p><a class="btn show-up" href="https://www.google.co.id/maps/place/Jl.+HR.+Moh.+No.5,+Putat+Gede,+Suko+Manunggal,+Kota+SBY,+Jawa+Timur/@-7.2868213,112.699009,17z/data=!3m1!4b1!4m5!3m4!1s0x2dd7fc12f7ba7c39:0xeca166bdb7987d31!8m2!3d-7.2868266!4d112.7011977?hl=id" target="”_blank”">SHOW MAP</a></p>
				</div>
				</div>
				<div class="col-md-4 col-sm-4">
				<div class="content pickupstore-container">
				<p><span style="font-size: medium;"><strong>Semarang</strong></span></p>
				<p><strong>Alamat</strong><br>Jl. Karang Anyar No. 28c Rt 06 / Rw 05 Semarang</p>
				<p><strong>Jam buka toko</strong><br>Senin – Jumat : 08:30 - 17:00<br> Sabtu : 08:30 - 14:30<br> Minggu / Hari Besar : Libur</p>
				<p><strong>Telp : (024) 356 5626</strong></p>
				<p><a class="btn show-up" href="https://www.google.co.id/maps/place/Warung+Makan+Asem-asem+Koh+Liem/@-6.9812766,110.4263054,19z/data=!3m1!4b1!4m5!3m4!1s0x2e70f4d28cd21e5b:0x4b99e7145ff0159a!8m2!3d-6.9812779!4d110.4268526?hl=id" target="”_blank”">SHOW MAP</a></p>
				</div>
				</div>
				<div class="col-md-4 col-sm-4">
				<div class="content pickupstore-container">
				<p><span style="font-size: medium;"><strong>Solo</strong></span></p>
				<p><strong>Alamat</strong><br>Jl. Baturan Indah Raya No. BP 7 Surakarta-Solo</p>
				<p><strong>Jam buka toko</strong><br>Senin – Jumat : 08:30 - 17:00<br> Sabtu : 08:30 - 14:30<br> Minggu / Hari Besar : Libur</p>
				<p><strong>Telp : (0271) 727 942</strong></p>
				<p><a class="btn show-up" href="https://www.google.co.id/maps/place/Satu+Karya+Community.+CV/@-7.546298,110.7930107,20.25z/data=!4m5!3m4!1s0x2e7a14170445d903:0x92037cce9852269f!8m2!3d-7.546124!4d110.793212?hl=en" target="”_blank”">SHOW MAP</a></p>
				</div>
				</div>
			</div>
			<hr>
		</div>
</div>
</section>
<!-- Content End-->
@include('component.front.footer')
@endsection

@section('script')

@endsection