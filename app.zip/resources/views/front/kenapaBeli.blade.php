@extends('layouts.front')

@section('title')
	Mengapa K2s?
@endsection

@section('head')

@endsection

@section('content')
<!---- Content Start ---->
<section id="content" style="padding-bottom:60px;">
	<div class="title-head">
		<div class="container">
			<div class="row">
				<div class="col-lg-12  col-xs-12 col-sm-12">
					<h3>Mengapa Memilih Kreasi2shop?</h3>
				</div>
			</div>
		</div>		
	</div>
</section>
<section id="Tentang-kami" style="padding-bottom:60px;">
<div class="row">
		<div class="col-lg-10 col-lg-offset-1 col-md-10 col-md-offset-1">
			<div class="col-lg-3">
				<h3 style="margin-top:0px;"><strong>KREASI2SHOP OFFICE</strong></h3>
				<hr>
				<a href="{{url('faq/kenapa-beli')}}"><p>Kenapa Beli Di Kreasi2Shop?</p></a>
				<hr>
				<a href="{{url('faq/hubungi-kami')}}"><p>Hubungi Kami</p></a>
				<hr>
				<a href="{{url('faq/mitra-kami')}}"><p>Lokasi mitra Kami</p></a>
				<hr>
				<a href="{{url('faq/service-center')}}"><p>Lokasi Service Center</p></a>
			</div>
			<div class="col-lg-9">
				<div>
				<p><strong>Mengapa Memilih Kreasi2shop?</strong></p>
				<ul style="padding-left: 40px;">
				<li>KREASI2SHOP merupakan E-commerce specialist dalam menyediakan produk untuk semua kebutuhan rumah tangga dan kebutuhan anak anda dari brand terbaik lokal dan internasional.</li>
				<li>Cicilan 0% Semua Produk untuk minimal pembelanjaan Rp.500.000,-.</li>
				<li>Pengiriman Seluruh Indonesia.</li>
				<li>Selalu siap membantu Anda dalam berkonsultasi atau bertanya seputar produk dan layanan kami.</li>
				<li>Jaminan Pengembalian Produk bila cacat/rusak.</li>
				<li>Sistem pembayaran yang mudah, aman dan terpercaya.</li>
				<li>KREASI2SHOP selalu mengadakan event potongan diskon untuk anda.</li>
				<li>KREASI2SHOP memiliki system pembelanjaan pick up store yang dapat mempermudah konsumen yang ingin lansung mengambil barang yang dibeli.</li>
				<li>KREASI2SHOP menyediakan pelayanan service after sales untuk produk* yang kami sediakan.</li>
				</ul>
				</div>	
			</div>
			<hr>
		</div>
</div>
</section>
<!-- Content End-->
@include('component.front.footer')
@endsection

@section('script')

@endsection