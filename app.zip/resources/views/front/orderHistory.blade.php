@extends('layouts.front')

@section('title')
	Order History
@endsection

@section('head')

@endsection

@section('content')
<!---- Content Start ---->
<section id="content" class=" bg-none">
	<div class="title-head">
		<div class="container">
			<div class="row">
				<div class="col-lg-12  col-xs-12 col-sm-12">
					<h3>Dashboard </h3>
				</div>
			</div>
		</div>		
	</div>
	<div class="container" style="min-height: 600px;">
		<div class="col-md-6">
			<table class="table">
			  <thead>
			    <tr>
			      <th scope="col">Order ID</th>
			      <th scope="col">Order Status</th>
			      <th scope="col">Date Added</th>
			      <th scope="col">Qty Products</th>
			      <th scope="col">Total</th>
			    </tr>
			  </thead>
			  <tbody>
			  	@foreach($orderhistory as $key=>$value)
			  	<?php
			  	$inv=explode('/', $value->invoice);
			  	?>
			    <tr>
			      <th scope="row">#{{$value->invoice}}</th>
			      <td>
			      	@switch($value->order_status_id)
					    @case(15)
					        <button type="button" class="btn btn-success" onclick="window.open('{{ route('order.show', $inv[2]) }}/', '_blank');">
					        @break

					    @case(11)
					        <button type="button" class="btn btn-primary" onclick="window.open('{{ route('order.show', $inv[2]) }}/', '_blank');">
					        @break

				        @case(14)
				        	<button type="button" class="btn btn-danger" onclick="window.open('{{ route('order.show', $inv[2]) }}/', '_blank');">
			        		@break

		        		@case(12)
				        	<button type="button" class="btn btn-pending" onclick="window.open('{{ route('order.show', $inv[2]) }}/', '_blank');">
			        		@break

			      	  	@default
	        				<button type="button" class="btn btn-pending" onclick="window.open('{{ route('order.show', $inv[2]) }}/', '_blank');">

						@endswitch
				      	{{ $value->OrderStatus->name_en }}
				      </button>
				  </td>
			      <td>{{ \Carbon\Carbon::parse($value->created_at)->format('d-m-Y H:i:s') }}</td>
			      <td>{{ $value->orderQty() }}</td>
			      <td>{{ currency_format($value->total,'IDR') }}</td>
			    </tr>
			    @endforeach
			    
			  </tbody>
			</table>
			<div class="field">
				<div class="col-lg-12 text-right col-sm-12 col-xs-12">
					<a href="/my-order"><button type="submit">See More</button></a>
				</div>
			</div>
		</div>
		<div class="col-md-6">
			<table class="table">
			  <thead>
			    <tr>
			      <th scope="col">Return ID</th>
			      <th scope="col">Order ID</th>
			      <th scope="col">Product</th>
			      <th scope="col">Reason</th>
			      <th scope="col">Status</th>
			      <th scope="col">Date Added</th>
			    </tr>
			  </thead>
			  <tbody>
			     <!-- <tr>
			      <th scope="row">#0001</th>
			      <th scope="row">#0124</th>
			      <td>Philips Earware SHE 2675YB/98 </td>
			      <td>Received Wrong Item</td>
			      <td><button type="button" class="btn btn-pending">Sedang diproses</button></td>
			      <td>2018-12-05 09:00:00</td>
			    </tr> -->
			  </tbody>
			</table>
			<div class="field">
				<div class="col-lg-12 text-right col-sm-12 col-xs-12">
					<a href="/my-return"><button type="submit">See More</button></a>
				</div>
			</div> 
		</div>
		
	</div>
	
</section>
@include('component.front.accountright')
<!-- <div class="right-button">
	<ul>
		<li><a href="{{ route('dashboard')}}" data-toggle="tooltip" data-placement="left" title="My Account"><img src="img/dashboard-1.png" alt="" width="40px;" /></a></li>
		<li><a href="{{ route('orderhistory')}}" data-toggle="tooltip" data-placement="left" title="My Order"><img src="img/dashboard-2.png" alt="" width="40px;" /></a></li>
		<li><a href="#" data-toggle="tooltip" data-placement="left" title="Notification"><img src="img/dashboard-3.png" alt="" width="40px;" /></a></li>
		
	</ul>
</div>
<div class="fixed">
	<ul>
		<li><a href="{{ route('dashboard')}}" data-toggle="tooltip" data-placement="top" title="My Account"><img src="img/dashboard-1.png" alt="" width="40px;" /></a></li>
		<li><a href="#" data-toggle="tooltip" data-placement="top" title="Dashboard"><img src="img/dashboard-2.png" alt="" width="40px;" /></a></li>
		<li><a href="#" data-toggle="tooltip" data-placement="top" title="Account Setting"><img src="img/dashboard-3.png" alt="" width="40px;" /></a></li>
		<li><a href="#" data-toggle="tooltip" data-placement="top" title="My Address"><img src="img/dashboard-2.png" alt="" width="40px;" /></a></li>
	</ul>
</div> -->
<!---- Content End ---->
@include('component.front.footer')
@endsection

@section('script')

@endsection