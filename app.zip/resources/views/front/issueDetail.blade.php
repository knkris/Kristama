@extends('layouts.front')

@section('title')
    {{ $issue->subject }}
@endsection

@section('head')

@endsection

@section('content')
    <!---- Content Start ---->

    <!-- support issue -->
    <section class="ic-upport-issue ic-detail-issue-wrapper" id="content">
        <div class="title-head">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <h3>Support - Issue details</h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="ic-issue-inbox">
                        <div class="ic-issue-inbox-head">
                            <h3><span>Inbox</span> Issue</h3>
                            <div class="ic-iih-topic ic-issue-detail-head">
                                <span class="ic-issue-no">Issue no. <span class="ic-red">#{{ $issue->id }}</span></span>
                                <span class="ic-topic ic-issue">issue: {{ $issue->category }}, {{ $issue->subcategory }}</span>
                                <span class="ic-status">Status: 
                                    @switch($issue->status)
                                        @case(1)
                                            <span class="ic-red">
                                                Processing
                                            </span>
                                            @break

                                        @case(2)
                                            <span class="ic-red">
                                                Complete
                                            </span>
                                            @break

                                        @default
                                            <span class="ic-red">
                                                Pending
                                            </span>
                                            @break
                                    @endswitch
                                </span>
                            </div>
                        </div>
                        <div class="row ic-issue-inbox-info">
                            <div class="col-sm-4 ic-issue-hcol">
                                <h3><strong>{{ Auth::user()->name }}</strong> ({{ Auth::user()->email }}</h3>
                            </div>
                            <div class="col-sm-4 ic-issue-hcol">
                                <h3>To: kreasi2shop(Admin@kresidushop.com)</h3>
                            </div>
                            <div class="col-sm-4 ic-issue-hcol text-right">
                                <h3><i class="fa fa-link"></i> {{ \Carbon\Carbon::parse($issue->created_at)->format('M, j, y') }}</h3>
                            </div>
                            <div class="col-md-12 ic-clear">
                                <div class="ic-issue-desc">
                                    <p>{{ $issue->category }} {{ $issue->subject }}</p>
                                    {!! $issue->message !!}
                                </div>
                                <?php $attachments=$issue->IssueAttachment; ?>
                                @if(count($attachments))
                                <div class="ic-gallery">
                                    @foreach($attachments as $attachment)
                                    <div class="ic-single-gitem">
                                        <img src="{{ $attachment->path }}" alt="attachment-{{ $attachment->id }}">
                                        <div class="ic-gcaption">
                                            <span><i class="fa fa-link"></i> <span class="ic-img-name">{{ basename($attachment->path) }}</span></span> <a href="{{ url('download-attachment/'. $attachment->id) }}"> <i class="fa fa-arrow-down"></i></a>
                                        </div>
                                    </div>
                                    @endforeach
                                </div>
                                @endif
                            </div>
                        </div>
                        <hr class="ic-break">
                        {{-- <div class="row ic-issue-inbox-info">
                            <div class="col-md-4 ic-issue-hcol">
                                <h3><strong>Pengu de pinguin</strong> (PenguDePinglin@gmail.com</h3>
                            </div>
                            <div class="col-md-4 ic-issue-hcol">
                                <h3>To: me</h3>
                            </div>
                            <div class="col-md-4 ic-issue-hcol text-right">
                                <h3><i class="fa fa-link"></i> Jan, 1, 18</h3>
                            </div>
                            <div class="col-md-12 ic-clear">
                                <div class="ic-issue-desc">
                                    <p>No Order : #1234567890</p>
                                    <p>essentially unchanged. It was popularised in the 1960 with the release of Lateraset sheet containing Lorem Ipsum pagges, and more recently with desktop publishing software like Aldus PageMaker including version of Lorem Ipsum.</p>
                                    <p>Where does it come from? <br> Contrary to pupular belief., Lrem Ipsum is not simply random text. It has root in piece of clasiccal Latin.Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source.</p>
                                    <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source.</p>
                                    <p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p>
                                </div>
                            </div>
                        </div> --}}
                        <hr class="ic-break">
                        <div class="ic-issue-btn ic-single-input">
                            <a href="#" class="ic-gen-btn" type="button">Issue close</a>
                            <a href="#" class="ic-gen-btn" type="button"  data-toggle="modal" data-target="#myModal">New issue</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- support issue /end -->

    @include('component.front.accountright')
    @include('component.front.fixbottom')
    <!---- Content End ---->

    @include('component.front.footer')
@endsection

@section('script')
    <script src="{{ asset('js/ic-bmbtn.js') }}"></script>
@endsection