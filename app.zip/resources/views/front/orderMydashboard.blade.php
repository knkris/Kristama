@extends('layouts.front')

@section('title')
	My Order History
@endsection

@section('head')
<style type="text/css">
.btn-primary {
    color: #fff!important;
    background-color: #b62327!important;
}
button.detail-order-button{
	margin-bottom:12px;
	background-color:#b62327;
	color:white;
}
button.detail-order-button:hover{
	background-color:white;
	color:#b62327;
	border: 1px solid #b62327;
}

</style>
@endsection

@section('content')
<!---- Content Start ---->
<section id="content" class=" bg-none">
	<div class="title-head">
		<div class="container">
			<div class="row">
				<div class="col-lg-12  col-xs-12 col-sm-12">
					<h3>My Order </h3>
				</div>
			</div>
		</div>		
	</div>
	<div class="container" style="min-height: 600px;">
		<div class="col-md-12">
			<table class="table">
			  <thead>
			    <tr>
			      <th scope="col">Order ID</th>
			      <th scope="col">Order Status</th>
			      <th scope="col">Date Added</th>
			      <th scope="col">Qty Products</th>
			      <th scope="col">Total</th>
			    </tr>
			  </thead>
			  <tbody>
			  	@foreach($orderhistory as $key=>$value)
			  	<?php
			  	$inv=explode('/', $value->invoice);
			  	?>
			    <tr>
			      <th scope="row"> <a class="btn btn-primary" data-toggle="collapse" href="#{{substr($value->invoice,-8)}}" role="button" aria-expanded="false" aria-controls="{{substr($value->invoice,-8)}}">#{{$value->invoice}}</a></th>
			      <td>
			      	@switch($value->order_status_id)
					    @case(15)
					        <button type="button" class="btn btn-success" onclick="window.open('{{ route('order.show', $inv[2]) }}/', '_blank');">
					        @break

					    @case(11)
					        <button type="button" class="btn btn-primary" onclick="window.open('{{ route('order.show', $inv[2]) }}/', '_blank');">
					        @break

				        @case(14)
				        	<button type="button" class="btn btn-danger" onclick="window.open('{{ route('order.show', $inv[2]) }}/', '_blank');">
			        		@break

		        		@case(12)
				        	<button type="button" class="btn btn-pending" onclick="window.open('{{ route('order.show', $inv[2]) }}/', '_blank');">
			        		@break

			      	  	@default
	        				<button type="button" class="btn btn-pending" onclick="window.open('{{ route('order.show', $inv[2]) }}/', '_blank');">

						@endswitch
				      	{{ $value->OrderStatus->name_en }}
				      </button>
				  </td>
			      <td>{{ \Carbon\Carbon::parse($value->created_at)->format('d-m-Y H:i:s') }}</td>
			      <td>{{ $value->orderQty() }}</td>
			      <td>{{ currency_format($value->total,'IDR') }}</td>
			    </tr>
				<!--Content Accordion-->
				<tr class="collapse" id="{{substr($value->invoice,-8)}}">
				<td colspan="5">
				<div class="ic-single-order ic-order-proegress ic-brd-btm0">
					<div class="ic-order-head">
						<p><span class="text-left">{{ $value->OrderStatus->name_en }}</span> <span class="text-right">{{ \Carbon\Carbon::parse($value->created_at)->format('d F Y') }}</span></p>
						<table>
							<tr>
								<td>Order Number</td>
								<td>:</td>
								<td>#{{substr($value->invoice,-8)}}</td>
							</tr>
						</table>
					</div>
					<?php $total=0; ?>
					@foreach($value->OrderDetail as $x => $od)
					<?php
					$product=$od->Product;
					$total=(int)$total+((int)$product->price_filter*(int)$od->qty);
					?>
					<div class="ic-order-detail">
						<div class="ic-order-product">
							<img src="{{ $product->Image->first()->image }}" alt="">
						</div>
						<div class="ic-op-detail">
							<h3>{{ $product->name }}</h3>
							<span>color: black</span>
							<span>Qty: {{ $od->qty }}</span>
							<span>Price: {{ currency_format((int)$product->price_filter, 'IDR')}}</span>
						</div>
						@if($loop->last)
						<div class="ic-order-ftr text-right">
						<button class="btn detail-order-button" onclick="window.open('{{ route('order.show', $inv[2]) }}/', '_blank');">See Detail</button>
							<p>Total: {{ currency_format($total, 'IDR')}}</p>
						</div>
						@endif
					</div>
					@endforeach
				</div>
				</td>
				</tr>
			    @endforeach
			    
			  </tbody>
			</table>
			<!-- <div class="field">
				<div class="col-lg-12 text-right col-sm-12 col-xs-12">
					<button type="submit">See More</button>
				</div>
			</div> -->
		</div>
	</div>
	
</section>
@include('component.front.accountright')
<!---- Content End ---->
@include('component.front.footer')
@endsection

@section('script')

@endsection