@extends('layouts.front')

@section('title')
	Address Book
@endsection

@section('head')
	<style>
		.bookmark .fa-3.active, .delete-address.active, .edit-address.active {
		    color: #b62126;
		}
	</style>
@endsection

@section('content')
	<!---- Content Start ---->
<section id="content" class="sign">
	<div class="title-head">
		<div class="container">
			<div class="row">
				<div class="col-lg-12  col-xs-12 col-sm-12">
					<h3>Shop - My Account - Address Book</h3>
				</div>
			</div>
		</div>		
	</div>
	<div class="container">
		<div class="row">
			<div class="col-xs-12 col-sm-12">
				@foreach($address as $key => $value)
				<div class="col-md-4">
					<div class="card-address">
						<label>{{ $value->name }}</label><br>
						<label>{{ $value->address }}</label><br>
						<label>
							{{$value->getCity().', '.$value->Subdistrict->province.', '.$value->postal_code}}</label><br>
						<label>{{ $value->telephone }}</label>
						<span class="bookmark"><i id="address-icon-{{ $value->id }}" class="fa fa-bookmark fa-3 default address-icon @if($value->main==1) active @endif" data-id="{{ $value->id }}" aria-hidden="true"></i></span>
						<a href="{{ route('address.edit',$value->id) }}"><span class="edit-address"><i class="fa fa-gear fa-3 default" aria-hidden="true"></i></span></a>
						<span class="delete-address" data-id="{{ $value->id }}"><i class="fa fa-trash fa-3 default" aria-hidden="true"></i></span>
					</div>
				</div>
				@endforeach
				
				<div class="col-md-4">
					<div class="card-address">
						<div class="text-center"><a href="{{ url('add-address') }}"><i class="fa fa-plus fa-3" aria-hidden="true"></i> Add Address</a></span>
					</div>
				</div>
				
			</div>
			<div class="col-md-12 text-center">

				<ul class="pagination">
				  <li><a href="#">Page</a></li>
				  <li><a href="#">1</a></li>
				  <li class="active"><a href="#">2</a></li>
				  <li><a href="#">3</a></li>
				  <li><a href="#">4</a></li>
				  <li><a href="#">5</a></li>
				</ul>
			</div>
		</div>	
	</div>

</section>
@include('component.front.fixbottom')
<!-- Content End-->
@endsection

@section('script')
<script type="text/javascript">
	$('.address-icon').on('click', function(e){
		e.preventDefault();
		var id=$(this).data('id');
		$.get('{{ url('set-main-address') }}/'+id, function() {
			$('.address-icon.active').removeClass('active');
			$('#address-icon-'+id).addClass('active');
		  toastr.success('Alamat utama berhasil diubah!', 'Success!')
		})
		.fail(function() {
		  toastr.error('Terjadi Kesalahan pada server!', 'Kesalahan!')
		})
	})

	$('.delete-address').on('click', function(e){
		e.preventDefault();
		$this=$(this);
		$id=$this.data('id');
		swal({
	          title: 'Delete Address?',
	          text: "You are going to delete this address, confirm?",
	          type: 'warning',
	          showCancelButton: true,
	          confirmButtonColor: '#3085d6',
	          cancelButtonColor: '#d33',
	          confirmButtonText: 'Yes, delete it!'
	        }).then((result) => {
	          if (result.value) {
	            window.location.href="{{ url('delete-address') }}/"+$id;
	          }
	        })
	})
</script>
@endsection