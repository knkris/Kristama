@extends('layouts.front')

@section('title')
	Akun
@endsection

@section('head')

@endsection

@section('content')
<!---- Content Start ---->
<section id="content" style="padding-bottom:60px;">
	<div class="title-head">
		<div class="container">
			<div class="row">
				<div class="col-lg-12  col-xs-12 col-sm-12">
					<h3>Akun</h3>
				</div>
			</div>
		</div>		
	</div>
</section>
<section id="Pertanyaan-Umum" style="padding-bottom:60px;">
<div class="row">
		<div class="col-lg-10 col-lg-offset-1 col-md-10 col-md-offset-1">
			<div class="col-lg-3">
				<h3 style="margin-top:0px;"><strong>FAQ SUPPORT</strong></h3>
				<hr>
				<a href="{{url('faq/form-retur')}}"><p>Form Retur</p></a>
				<hr>
				<a href="{{url('faq/retur')}}"><p>Refund / Retur</p></a>
				<hr>
				<div class="dropdown">
				<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Serangkaian Pertanyaan Umum<span class="caret"></span></button>
				<ul class="dropdown-menu">
				<li><a title="General" href="https://k2s.playit.tech/faq/status-pesanan">Status pesanan</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/umum">Umum</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/akun">Akun</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/cara-belanja">Cara Belanja</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/garansi">Garansi</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/pembayaran">Pembayaran</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/pengiriman">Pengiriman</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/retur">Refund</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/retur">Retur Produk</a></li>
				<li><a title="General" href="#">Tiket</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/kupon-diskon">Kupon Diskon</a></li>
				</ul>
				</div>
			</div>
			<div class="col-lg-9">
				<div>
				<h3>Akun</h3>
				<p><strong>Registrasi</strong></p>
				<ul style="padding-left: 40px;">
				<li>Pada <em>Bar</em> bagian paling atas halaman <em>Website</em> terdapat pilihan <strong>Sign Up</strong> &amp; <strong>Sign In</strong>. Pilih <a title="Sign Up Now !" href="{{ route('sign.up') }}" target="_self"><em>Sign Up</em></a> jika anda ingin membuat akun baru di Kreasi2shop.</li>
				<li>Isi form dengan Nama Lengkap, Alamat Email yang Valid, Tanggal Lahir, Jenis Kelamin, Kota Tempat Tinggal, Negara, Nomor Telepon yang Valid, serta Kata Sandi yang ingin Anda gunakan, lalu klik tombol Submit.</li>
				<li>Buka Email anda dan klik pada link verifikasi yang kami kirimkan ke Email anda.</li>
				</ul>
				<p><strong>Lupa Password</strong></p>
				<p>Jika Anda lupa dengan Kata Sandi untuk Login, Anda dapat melakukan reset ulang password dengan meminta <a title="Lupa Password ?" href="{{ url('password/reset') }}" target="_self">Link Reset Password</a> yang akan dikirimkan melalui email, ikuti langkah-langkah dibawah ini untuk mendapatkan kembali password Anda yang hilang:</p>
				<ul style="padding-left: 40px;">
				<li>Klik "<em><a title="Lupa Password ?" href="{{ url('password/reset') }}" target="_self">Forgot Your Password?</a></em>" pada halaman Login (Sign In --&gt; Login).</li>
				<li>Masukkan Alamat Email anda lalu klik <em>Submit</em>. </li>
				<li>Cek Inbox Email anda (Pastikan untuk mengecek juga folder Spam/Junk). Lalu klik pada pilihan "<em>RESET PASSWORD</em>".</li>
				<li>Masukkan <em>Password</em> baru anda, dan ulangi kembali <em>Password</em> untuk kolom berikutnya. Lalu klik "<em>Reset a Password<strong>"</strong></em></li>
				<li>Anda sekarang bisa melakukan Login kembali dengan <em>Password</em> baru yang anda masukkan.</li>
				</ul>
				</div>	
			</div>
			<hr>
		</div>
</div>
</section>
<!-- Content End-->
@include('component.front.footer')
@endsection

@section('script')

@endsection