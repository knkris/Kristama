@extends('layouts.front')

@section('title')
	Pertanyaan Umum
@endsection

@section('head')

@endsection

@section('content')
<!---- Content Start ---->
<section id="content" style="padding-bottom:60px;">
	<div class="title-head">
		<div class="container">
			<div class="row">
				<div class="col-lg-12  col-xs-12 col-sm-12">
					<h3>Pertanyaan Umum</h3>
				</div>
			</div>
		</div>		
	</div>
</section>
<section id="Pertanyaan-Umum" style="padding-bottom:60px;">
<div class="row">
		<div class="col-lg-10 col-lg-offset-1 col-md-10 col-md-offset-1">
			<div class="col-lg-3">
				<h3 style="margin-top:0px;"><strong>FAQ SUPPORT</strong></h3>
				<hr>
				<p>Form Retur</p>
				<hr>
				<p>Refund / Retur</p>
				<hr>
				<div class="dropdown">
				<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Serangkaian Pertanyaan Umum<span class="caret"></span></button>
				<ul class="dropdown-menu">
				<li><a title="General" href="https://k2s.playit.tech/faq/status-pesanan">Status pesanan</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/umum">Umum</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/akun">Akun</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/cara-belanja">Cara Belanja</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/garansi">Garansi</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/#">Pembayaran</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/pengiriman">Pengiriman</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/#">Refund</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/faq-retur-product">Retur Produk</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/form-retur">Tiket</a></li>
				<li><a title="General" href="https://k2s.playit.tech/faq/kupon-diskon">Kupon Diskon</a></li>
				</ul>
				</div>
			</div>
			<div class="col-lg-9">
				<div>
				<h3>FAQ</h3>
				<div class="faq-content">
				<p><img style="width: 100%;" alt="" src="{{ asset('images/retur-step.png') }}"></p>
				<ul class="que-ans">
				<li class="que">1. Apa arti status Menunggu Pembayaran?</li>
				<li class="ans">Anda diharapkan segera menyelesaikan pembayaran dalam batas waktu yang ditentukan atau jika Anda sudah melakukan pembayaran, maka Kreasi2shop.com akan segera menerima konfirmasi dari bank dan pesanan akan diproses secepatnya.</li>
				</ul>
				<ul class="que-ans">
				<li class="que">2. Apa arti status Pembayaran Diterima?</li>
				<li class="ans">Kreasi2shop.com telah menerima konfirmasi pembayaran dari pihak bank.</li>
				</ul>
				<ul class="que-ans">
				<li class="que">3. Apa arti status Pesanan Sedang Diproses?</li>
				<li class="ans">Barang yang Anda pesan sedang dipersiapkan oleh&nbsp;Kreasi2shop.com</li>
				</ul>
				<ul class="que-ans">
				<li class="que">4. Apa arti status pesanan Pengambilan Barang di&nbsp;Toko?</li>
				<li class="ans"><strong>Pengambilan Barang Di&nbsp;Toko:</strong></li>
				<li>Untuk pengambilan barang di Toko, Anda akan menerima&nbsp;email pick up code untuk diambil langsung di lokasi yang ditentukan.</li>
				</ul>
				<ul class="que-ans">
				<li class="que">5. Apa arti status menunggu Pengambilan Kurir?</li>
				<li class="ans">Jasa pengiriman akan segera mengambil barang untuk segera dikirimkan ke lokasi Anda</li>
				</ul>
				<ul class="que-ans">
				<li class="que">6. Apa arti status Pesanan Dalam Pengiriman?</li>
				<li class="ans">Barang sedang dalam proses pengiriman menuju lokasi Anda.</li>
				</ul>
				<ul class="que-ans">
				<li class="que">7. Apa arti status Pesanan Telah Terkirim?</li>
				<li class="ans">Barang telah diterima pemesan.</li>
				</ul>
				</div>
				</div>	
			</div>
			<hr>
		</div>
</div>
</section>
<!-- Content End-->
@include('component.front.footer')
@endsection

@section('script')

@endsection