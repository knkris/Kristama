@extends('layouts.front')

@section('title')
	Dashboard {{ $user->name }}
@endsection

@section('content')
<!---- Content Start ---->
<section id="content" class="sign">
	<div class="title-head">
		<div class="container">
			<div class="row">
				<div class="col-lg-12  col-xs-12 col-sm-12">
					<h3>My Account</h3>
				</div>
			</div>
		</div>		
	</div>
	{{--<div class="container">--}}
		{{--<div class="row">--}}
			{{--<form class="space-side" action="{{ route('profile.update') }}" method="post" enctype="multipart/form-data">--}}
				{{--<div class="col-lg-4 col-lg-offset-4 text-center col-xs-12 col-sm-12">--}}
					{{--<div class="space-side">--}}
						{{--{{ csrf_field() }}--}}
						{{--<img class="bottom-m" src="{{ Auth::user()->avatar ?: Auth::user()->getPhotoUrlAttribute() }}" alt=""/>--}}
						{{--<div class="field">--}}
							{{--<input type="file" name="avatar" placeholder="avatar"/>--}}
						{{--</div>--}}
						{{--<div class="field">--}}
							{{--<input type="text" name="firstname" value="{{ old('firstname')?: $user->firstname }}" placeholder="First Name"/>--}}
						{{--</div>--}}
						{{--<div class="field">--}}
							{{--<input type="text" name="lastname" value="{{ old('lastname')?: $user->lastname }}" placeholder="Last Name"/>--}}
						{{--</div>--}}
						{{--<div class="field text-left">--}}
							{{--<div class="col-lg-3 text-center flush col-sm-3 col-xs-12">--}}
								{{--<input type="text" name="day" value="{{ $user->dob ? $dob->format('d') : '' }}" placeholder="DD"/>--}}
							{{--</div>--}}
							{{--<div class="col-lg-1 flush text-center  col-sm-1 col-xs-1">--}}
								{{--<i class="fa fa-minus" aria-hidden="true"></i>--}}
							{{--</div>--}}
							{{--<div class="col-lg-3 text-center flush col-sm-3 col-xs-12">--}}
								{{--<input type="text" name="month" value="{{ $user->dob ? $dob->format('m') : '' }}" placeholder="MM"/>--}}
							{{--</div>--}}
							{{--<div class="col-lg-1 flush text-center  col-sm-1 col-xs-1">	--}}
								{{--<i class="fa fa-minus" aria-hidden="true"></i>--}}
							{{--</div>--}}
							{{--<div class="col-lg-4 text-center flush col-sm-4 col-xs-12">--}}
								{{--<input type="text" name="year" value="{{ $user->dob ? $dob->format('Y') : '' }}" placeholder="YYYY"/>--}}
							{{--</div>--}}
						{{--</div>--}}
						{{--<div class="field text-left">--}}
							{{--<div class="col-lg-3 text-center flush col-sm-3 col-xs-12">--}}
								{{--<input type="text" name="phone_prefix" value="+62" disabled="" />--}}
							{{--</div>--}}
							{{--<div class="col-lg-9 text-center flush col-sm-9 col-xs-12">--}}
								{{--<input type="text" placeholder="" name="phone" value="{{ old('phone')?: $user->telephone }}" style="border-left: 0;" />--}}
							{{--</div>--}}
						{{--</div>--}}
						{{--<div class="field">--}}
							{{--<select name="gender">--}}
								{{--<option>Gender</option>--}}
								{{--<option value="M" @if($user->gender=="M") selected @endif>Male</option>--}}
								{{--<option value="F" @if($user->gender=="F") selected @endif>Female</option>--}}
							{{--</select>--}}
						{{--</div>--}}
						{{--<div class="field">--}}
							{{--<select id="input-country" name="country">--}}
								{{--<option>Country</option>--}}
								{{--@foreach($countries as $value)--}}
								{{--<option value="{{ $value->id }}" @if($user->country_id==$value->id) selected @endif>{{ $value->name }}</option>--}}
								{{--@endforeach--}}
							{{--</select>--}}
						{{--</div>--}}
						{{--<div class="field">--}}
							{{--<textarea name="about" placeholder="About Me">{{ old('about')?: $user->about }}</textarea>--}}
						{{--</div>--}}
						{{--<div class="field">--}}
							{{--<a href="change-password.html">Change Password</a> | <a href="change-email.html">Change Email</a>--}}
						{{--</div>--}}
						{{----}}
					{{--</div>--}}
				{{--</div>--}}

				{{--<div class="col-lg-12 top-bottom col-sm-12 col-xs-12">--}}
					{{--<div class="field">--}}
						{{--<div class="col-lg-6 col-sm-6 col-xs-6">--}}
							{{--<a href="{{ route('index') }}" ><button>Cancel</button></a>--}}
						{{--</div>--}}
						{{--<div class="col-lg-6 text-right col-sm-6 col-xs-6">--}}
							{{--<button type="submit">Save</button>--}}
						{{--</div>--}}
					{{--</div>	--}}
				{{--</div>--}}
			{{--</form>--}}
	{{--</div>--}}
<!-- my account -->
	<div class="ic-my-account-wrapper">
		<div class="container">
			<div class="row ic-dflex">
				<div class="col-md-4 ic-long-brdr">
					<form class="ic-form ic-psf" id="profile-setting" action="{{ route('profile.update') }}" method="post">
						{!! csrf_field() !!}
						<div class="ic-form-head">
							<div id="image-preview">
								<label for="image-upload" id="image-label">
									<img src="{{ Auth::user()->avatar ?: $user->getPhotoUrlAttribute() }}" alt="">
									<span>edit</span>
								</label>
								<input type="file" name="image" id="image-upload" />
							</div>
							<div class="ic-fh-title">
								<h3>Profile settings</h3>
							</div>
						</div>
						<div class="ic-prev-head">
							<span><img src="{{ Auth::user()->avatar ?: $user->getPhotoUrlAttribute() }}" alt=""></span>
						</div>
						<div class="ic-input-wrapper">
							<div class="ic-single-input">
								<input type="text" placeholder="First Name" name="firstname" value="{{ old('firstname')?: $user->firstname }}">
							</div>
							<div class="ic-single-input">
								<input class="ic-brdr-btm" type="text" placeholder="Last Name" name="lastname" value="{{ old('lastname')?: $user->lastname }}">
							</div>
							<div class="ic-single-input ic-hauto ic-radio-col">
								<div class="ic-radio">
									<label> Female
										<input type="radio" name="gender" @if($user->gender=="F") checked @endif value="F">
										<span class="checkmark"></span>
									</label>
								</div>
								<div class="ic-radio">
									<label> Male
										<input type="radio" name="gender" @if($user->gender=="M") checked @endif value="M">
										<span class="checkmark"></span>
									</label>
								</div>
								<span class="ic-required">*</span>
							</div>
							<div class="ic-dbl-input">
								<label>Phone Number</label>
								<input class="ic-country-cod" type="text" name="phone_prefix" value="+62" disabled="">
								<input class="ic-c-phone" type="text" name="phone" value="{{ old('phone')?: $user->telephone }}">
								<span class="ic-required">*</span>
							</div>
							<div class="ic-dbl-input ic-triple-inpt">
								<label>Date of birth</label>
								<input class="ic-date" type="text" placeholder="DD" name="day" value="{{ $user->dob ? $dob->format('d') : '' }}">
								<input class="ic-month" type="text" placeholder="MM" name="month" value="{{ $user->dob ? $dob->format('m') : '' }}">
								<input class="ic-year" type="text" placeholder="YYYY" name="year" value="{{ $user->dob ? $dob->format('Y') : '' }}">
								<span class="ic-required">*</span>
							</div>
							<div class="ic-single-input ic-hauto">
								<textarea name="about" cols="30" rows="7" placeholder="About (Max 30 words)">{{ old('about')?: $user->about }}</textarea>
							</div>
							<div class="ic-single-input ic-form-btns">
								<button type="reset" value="Reset">Cancel</button>
								<button class="ic-submit" type="submit" value="Submit">Save</button>
							</div>
						</div>

					</form>
				</div>
				<div class="col-md-4 ic-long-brdr">
					<form class="ic-form" id="email-settings" action="{{ route('profile.update.email') }}" method="post">
						{!! csrf_field() !!}
						<div class="ic-form-head">
							<div class="ic-adeight">
								<span>@</span>
							</div>
							<div class="ic-fh-title">
								<h3>Email settings</h3>
							</div>
						</div>
						<!-- <div class="ic-prev-head">
							<div class="ic-adeight">
								<span>@</span>
							</div>
						</div> -->
						<div class="ic-input-wrapper">
							<div class="ic-single-input">
								<input type="email" placeholder="Current Email" name="email">
							</div>
							<div class="ic-single-input">
								<input type="email" placeholder="New Email" name="new_email">
							</div>
							<div class="ic-single-input">
								<input type="email" placeholder="Confirm New" name="confirm_new_email">
							</div>
							<div class="ic-single-input">
								<input id="password-field"  class="ic-brdr-btm" type="password" placeholder="Password" name="password">
								<span toggle="#password-field" class="fa fa-fw fa-eye-slash field-icon toggle-password"></span>
								<span class="ic-required">*</span>
							</div>
							<div class="ic-single-input ic-form-btns">
								<button type="reset" value="Reset">Cancel</button>
								<button class="ic-submit" type="submit" value="button">Save</button>
							</div>
						</div>
					</form>
				</div>
				<div class="col-md-4">
					<form class="ic-form" id="password-settings" action="{{ route('profile.update.password') }}" method="post">
						{!! csrf_field() !!}
						<div class="ic-form-head">
							<div class="ic-adeight">
								<span><i class="fa fa-lock" style="margin-top: 15px;"></i></span>
							</div>
							<div class="ic-fh-title">
								<h3>Password settings</h3>
							</div>
						</div>
						<div class="ic-input-wrapper">
							<div class="ic-single-input">
								<input id="current-password" class="ic-brdr-btm" type="password" placeholder="Current Password" name="old_password">
								<span toggle="#current-password" class="fa fa-fw fa-eye-slash field-icon toggle-password"></span>
								<span class="ic-required">*</span>
							</div>
							<div class="ic-single-input">
								<input id="new-password" class="ic-brdr-btm" type="password" name="password" placeholder="New Password">
								<span toggle="#new-password" class="fa fa-fw fa-eye-slash field-icon toggle-password"></span>
								<span class="ic-required">*</span>
							</div>
							<div class="ic-single-input">
								<input id="confirm-password" class="ic-brdr-btm" type="password" name="password_confirmation" placeholder="Confirm Password">
								<span toggle="#confirm-password" class="fa fa-fw fa-eye-slash field-icon toggle-password"></span>
								<span class="ic-required">*</span>
							</div>
							<div class="ic-single-input ic-form-btns">
								<button type="reset" value="Reset">Cancel</button>
								<button class="ic-submit" type="submit" value="Submit">Save</button>
								{{-- <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
									<div class="modal-dialog" role="document">
										<div class="ic-modal modal-content">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
											</div>
											<div class="modal-body">
												<img src="{{ url('img/check-circle.jpg') }}" alt="checked">
												<p>Item Terhapus</p>
											</div>
										</div>
									</div>
								</div> --}}
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<!-- my account /end -->
</section>
@include('component.front.accountright')
<!-- @include('component.front.fixbottom') -->
@endsection

@section('script')
<script>
	$.get('{{ url('api/get-calling-code') }}/'+$('#input-country').val(), function(data){
			$('input[name="phone_prefix"]').val(data);
		});
	$('#input-country').on('change', function(){
		$.get('{{ url('api/get-calling-code') }}/'+$(this).val(), function(data){
			$('input[name="phone_prefix"]').val(data);
		});
	})
</script>
@endsection