@extends('layouts.front')

@section('title')
	My Return
@endsection

@section('head')
<style type="text/css">
.btn-primary {
    color: #fff!important;
    background-color: #b62327!important;
}
button.detail-return-button{
	margin-bottom:12px;
	background-color:#b62327;
	color:white;
}
button.detail-return-button:hover{
	background-color:white;
	color:#b62327;
	border: 1px solid #b62327;
}
</style>
@endsection

@section('content')
<!---- Content Start ---->
<section id="content" class=" bg-none">
	<div class="title-head">
		<div class="container">
			<div class="row">
				<div class="col-lg-12  col-xs-12 col-sm-12">
					<h3>Retur</h3>
				</div>
			</div>
		</div>		
	</div>
	<div class="container" style="min-height: 600px;">
		<div class="col-md-12">
			<table class="table">
			  <thead>
			    <tr>
			      <th scope="col">Return ID</th>
			      <th scope="col">Order ID</th>
			      <th scope="col">Product</th>
			      <th scope="col">Reason</th>
			      <th scope="col">Status</th>
			      <th scope="col">Date Added</th>
			    </tr>
			  </thead>
			  <tbody>

                @foreach($return as $key => $value)
                <?php 
                $order=$value->Order;
                $product=$value->Product;
                $order_detail=$order->OrderDetail()->whereProduct_id($value->product_id)->first();
                switch ($value->status) {
                    case '1':
                        $class="ic-order-proegress ic-brd-btm0";
                        break;
                    
                    default:
                        $class="";
                        break;
                }
                ?>
				<tr>
				 
			      <th scope="row"><a class="btn btn-primary" data-toggle="collapse" href="#{{ $value->id }}" role="button" aria-expanded="false" aria-controls="{{ $value->id }}">#{{ $value->id }}</a></th>
				
			      <th scope="row">#{{ $order->invoice }}</th>
			      <td>{{ $product->name ." ". $product->model }} </td>
			      <td>{{ $value->reason }}</td>
			      <td>
			      	<button type="button" class="btn btn-pending">
				      	@switch($value->status)
                                    @case(1)
                                        Sedang diproses
                                    @break

                                    @case(2)
                                        Selesai
                                    @break

                                    @default

                                    @break
                                @endswitch
				      </button>
				  </td>
			      <td>{{ \Carbon\Carbon::parse($value->created_at)->format('d F Y') }}</td>
			    </tr>
				
				<!--Content Accordion-->
				<tr class="collapse" id="{{ $value->id }}">
				<td colspan="6">
				<div class="ic-single-order ic-order-proegress ic-brd-btm0">
					<div class="ic-order-head">
						<p>
							<span class="text-left">
								@switch($value->status)
                                    @case(1)
                                        On Process
                                    @break

                                    @case(2)
                                        Done
                                    @break

                                    @default

                                    @break
                                @endswitch
							</span> 
							<span class="text-right">01 Januari 2011</span></p>
						<table>
							<tr>
								<td>Return Number</td>
								<td>:</td>
								<td>{{ $value->id }}</td>
							</tr>
							<tr>
								<td>Return status</td>
								<td>:</td>
								<td>{{ $value->reason }}</td>
							</tr>
						</table>
					</div>
					<div class="ic-order-detail">
						<div class="ic-order-product">
							<img src="{{ $product->Image->first()->image }}" alt="">
						</div>
						<div class="ic-op-detail">
							<h3>{{ $product->name." ".$product->model }}</h3>
							{{-- <span>color: black</span> --}}
							<span>Qty: {{ $order_detail->qty }}</span>
							<span>Price: {{ currency_format($order_detail->price, 'IDR') }}</span>
						</div>
						<div class="ic-order-ftr text-right">
							<button class="btn detail-return-button">Return Detail</button>
							<p>Total: {{ currency_format($order_detail->price*$order_detail->qty, 'IDR') }}</p>
						</div>
					</div>
				</div>
				</td>
				</tr>
				@endforeach
			  </tbody>
			</table>
			{{-- <div class="field">
				<div class="col-lg-12 text-right col-sm-12 col-xs-12">
					<button type="submit">See More</button>
				</div>
			</div>  --}}
		</div>
		
	</div>
	
</section>
@include('component.front.accountright')
<!---- Content End ---->
@include('component.front.footer')
@endsection

@section('script')

@endsection