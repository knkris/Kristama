@extends('layouts.front')

@section('title')
	{{ $order->invoice }}
@endsection

@section('head')

@endsection

@section('content')
<!---- Content Start ---->
<section id="content" class=" bg-none">
	<div class="title-head">
		<div class="container">
			<div class="row">
				<div class="col-lg-12  col-xs-12 col-sm-12">
					<h3>Shop - Order- Order History -Order {{ $order->invoice }} </h3>
				</div>
			</div>
		</div>		
	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center">
				<ol>
					@foreach($order->OrderHistory as $key => $value)
					@switch($value->order_status_id)
					    @case(1)
					        <li class="status-step @if($loop->last) done @endif"><img src="{{ asset('images/status-1.png') }}" width="100px"><div><label>{{ $value->OrderStatus->name_id }}<br>{{ \Carbon\Carbon::parse($order->created_at)->format('d/m/Y H:i:s') }}</label></div></li>
					        @break

					    @case(11)
					        <li class="status-step @if($loop->last) done @endif"><img src="{{ asset('images/status-2.png') }}" width="100px"><div><label>{{ $value->OrderStatus->name_id }}<br>{{ \Carbon\Carbon::parse($order->created_at)->format('d/m/Y H:i:s') }}</label></div></li>
					        @break

			      	  	@default
	        				<li class="status-step @if($loop->last) done @endif"><img src="{{ asset('images/status-1.png') }}" width="100px"><div><label>{{ $value->OrderStatus->name_id }}<br>{{ \Carbon\Carbon::parse($order->created_at)->format('d/m/Y H:i:s') }}</label></div></li>
					        @break

						@endswitch
					@endforeach
				</ol>
				
			</div>
		</div>
		<div class="row">
			<div class="col-md-12 border-full">
				<div class="col-md-3">
					<div class="title-status border-right">
					<p class="judul">Alamat:</p>
					<span>{{ $order->shipping_name }}<br>
							{{ $order->shipping_address }}<br>
							{{ $order->shipping_city }}<br>
							{{ $order->shipping_province }}<br>
							{{ $order->shipping_postal_code }}
					</span>
					</div>
				</div>
				<div class="col-md-3 ">
					<div class="title-status border-right">
						<p class="judul">Jasa Pengirimaan:</p>
						<span>{{ $order->shipping_courier }}</span>
					</div>
				</div>
				<div class="col-md-3">
					<div class="title-status border-right">
						<p class="judul">No. Resi:</p>
						<span>
							<?php $getresi=$order->OrderHistory()->whereOrder_status_id(3)->first(); ?>
							@if(count($getresi))
								{{ $getresi->comment }}
							@endif
						</span>
					</div>
				</div>
				<div class="col-md-3">
					<div class="title-status  ">
						<p class="judul">Estimasi Delivery Date:</p>
						<span>{{ \Carbon\Carbon::parse($order->created_at)->addDays(3)->formatLocalized('%A, %d %B %Y') }}</span>
					</div>
				</div>
				
			</div>
			
			<div class="col-md-12">
				<table class="table">
				  <thead>
				    <tr>
				      <th scope="col">Order {{ $order->invoice }}</th>
				      <th scope="col">Product Name</th>
				      <th scope="col">Price</th>
				      <th scope="col">Qty</th>
				      <th scope="col">Action</th>
				    </tr>
				  </thead>
				  <tbody>
				  	@foreach($order->OrderDetail as $key => $value)
				  	<?php $product=$value->Product; ?>
				    <tr>
				      <th scope="row"><img src="{{ $product->Image->first()->image }}" width="90px;"></th>
				      <td>{{ $product->name }}</td>
				      <td>{{ currency_format($value->price, 'IDR')}}</td>
				      <td>
				      	<div class="center">
							{{ $value->qty }}
						</div>	
						</td>
						<?php
						$inv=explode('/',$order->invoice);
						?>
				      <td>
				      	@if($order->order_status_id==3 || $order->order_status_id==4)
				      	<a href="{{ url('return/'.$inv[2]) }}" class="btn-success">Return</a>
				      	@elseif($order->order_status_id==12)
				      	<button type="button" class="btn btn-pending" disabled="disabled">Waiting Return Approval</button>
				      	@endif
				      </td>
				    </tr>
				    @endforeach
				    
				  </tbody>
				  <tfoot>
				  	<tr>
				  		<td></td>
				  		<td>Subtotal</td>
				  		<td>{{ currency_format($order->subtotal, 'IDR')}}</td>
				  		<td></td>
				  	</tr>
				  	<tr>
				  		<td></td>
				  		<td>Shipping</td>
				  		<td>{{ currency_format($order->shipping_cost, 'IDR')}}</td>
				  		<td></td>
				  	</tr>
				  	@if($order->transfer_code>0)
				  	<tr>
				  		<td></td>
				  		<td>Kode Unik</td>
				  		<td>{{ currency_format($order->transfer_code, 'IDR')}}</td>
				  		<td></td>
				  	</tr>
				  	@endif
				  	<tr>
				  		<td></td>
				  		<td>Total</td>
				  		<td>{{ currency_format($order->total, 'IDR')}}</td>
				  		<td></td>
				  	</tr>
				  </tfoot>
				</table>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="field">
			<div class="col-lg-6 col-sm-6 col-xs-6">
				<button type="submit">Back</button>
			</div>
			
		</div>	
	</div>
</section>
@include('component.front.accountright')
@include('component.front.fixbottom')
@endsection

@section('script')

@endsection