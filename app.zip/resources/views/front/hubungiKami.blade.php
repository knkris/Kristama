@extends('layouts.front')

@section('title')
	Hubungi Kami
@endsection

@section('head')

@endsection

@section('content')
<!---- Content Start ---->
<section id="content" style="padding-bottom:60px;">
	<div class="title-head">
		<div class="container">
			<div class="row">
				<div class="col-lg-12  col-xs-12 col-sm-12">
					<h3>Hubungi Kami</h3>
				</div>
			</div>
		</div>		
	</div>
</section>
<section id="Tentang-kami" style="padding-bottom:60px;">
<div class="row">
		<div class="col-lg-10 col-lg-offset-1 col-md-10 col-md-offset-1">
			<div class="col-lg-3">
				<h3 style="margin-top:0px;"><strong>KREASI2SHOP OFFICE</strong></h3>
				<hr>
				<a href="{{url('faq/kenapa-beli')}}"><p>Kenapa Beli Di Kreasi2Shop?</p></a>
				<hr>
				<a href="{{url('faq/hubungi-kami')}}"><p>Hubungi Kami</p></a>
				<hr>
				<a href="{{url('faq/mitra-kami')}}"><p>Lokasi mitra Kami</p></a>
				<hr>
				<a href="{{url('faq/service-center')}}"><p>Lokasi Service Center</p></a>
			</div>
			<div class="col-lg-9">
				<div>
				<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1983.3738513200942!2d106.7780628!3d-6.1645329!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f64efb78e6c7%3A0x5c3b7f07b8e1733f!2sJl.+Daan+Mogot+No.111%2C+Wijaya+Kesuma%2C+Grogol+petamburan%2C+Kota+Jakarta+Barat%2C+Daerah+Khusus+Ibukota+Jakarta!5e0!3m2!1sid!2sid!4v1461231736631" width="75%" height="200" frameborder="0" style="border:0" allowfullscreen=""></iframe>
				<h5>COME TO OUR OFFICE</h5>
				<hr>
				<p>
				Kreasi2Shop
				Jl.Daan Mogot No.111
				Grogol Petamburan
				Jakarta Barat
				11460
				</p>
				<p>(021) - 2256 1357</p>
				<p>cs@kreasiduashop.com</p>
				 <div style="display:inline-flex; margin-top: 15px; text-align: center;">
				<a href="#" class="socials-2" style="padding-right:5px;"><i class="fa fa-facebook"></i></a> <a href="#" class="socials-2" style="padding-right:5px;"><i class="fa fa-twitter"></i></a> <a href="#" class="socials-2" style="padding-right:5px;"><i class="fa fa-instagram"></i></a> <a href="#" class="socials-2" style="padding-right:5px;"><i class="fa fa-youtube"></i></a> <a href="#" class="socials-2" style="padding-right:5px;"><i class="fa fa-google-plus"></i></a>
				</div>
				</div>	
			</div>
			<hr>
		</div>
</div>
</section>
<!-- Content End-->
@include('component.front.footer')
@endsection

@section('script')

@endsection