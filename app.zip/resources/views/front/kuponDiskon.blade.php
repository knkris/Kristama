@extends('layouts.front')

@section('title')
	Form Retur
@endsection

@section('head')

@endsection

@section('content')
<!---- Content Start ---->
<section id="content" style="padding-bottom:60px;">
	<div class="title-head">
		<div class="container">
			<div class="row">
				<div class="col-lg-12  col-xs-12 col-sm-12">
					<h3>Form Retur / Refund</h3>
				</div>
			</div>
		</div>		
	</div>
</section>
<section id="Pertanyaan-Umum" style="padding-bottom:60px;">
<div class="row">
		<div class="col-lg-10 col-lg-offset-1 col-md-10 col-md-offset-1">
			<div class="page-title">
			<h1>Promosi - Diskon</h1>
			</div>
			<div class="std"><div>
			<div class="content">&nbsp;
			<p><a title="Kreasi2shop First Anniversary" href="#" target="_self"><img class="kupon-diskon"alt="" src="{{ url('images/September_Kreasi_Bday_1.jpg') }}"></a></p>
			</div>
			<div class="content">&nbsp;</div>
			<div class="content"><b>Syarat dan Ketentuan :<br></b>
			<ul style="padding-left: 20px;">
			<li>Masa Berlaku Kode Voucher adalah dari tanggal 27 September 2017 - 11 Oktober 2017</li>
			<li>Produk yang bekerja sama dengan Kode Voucher ini adalah Brand Turbo</li>
			<li>Untuk setiap pembelian Produk Philips, Graco, dan Aprica akan mendapatkan merchandise menarik sesuai dengan produk yang dibeli</li>
			<li>Untuk Produk yang mengkuti promosi hanya yang tertera di halaman Promo Anniversary Kreasi2shop<a title="Promo Anniversary Kreasi2shop" href="https://kreasi2shop.com/kreasibday.html" target="_self"><img alt=""></a></li>
			<li>1 (Satu) Customer hanya dapat menggunakan kode voucher 1 (Satu) kali untuk setiap Order.</li>
			<li>Harga bisa berubah sewaktu-waktu tanpa pemberitahuan terlebih dahulu.</li>
			<li>Persediaan stok Merchandise TERBATAS.</li>
			</ul>
			<div class="content"><b>Kupon Diskon :<br></b>
			<ul style="padding-left: 20px;">
			<li>Voucher dapat digunakan untuk mendapatkan potongan harga di Kreasi2shop</li>
			<li>Untuk mendapatkan potongan harga yang diselenggarakan Kreasi2shop, konsumen cukup meng klik banner yang berada di layar utama Kreasi2shop</li>
			<li>Minimum transaksi voucher mengacu pada Syarat &amp; Ketentuan yang telah tertera dalam keterangan Voucher</li>
			</ul>
			<p><strong>Petunjuk penggunaan Voucher:</strong></p>
			<ul style="padding-left: 20px;">
			<li>Klik BELI untuk membeli produk yang diinginkan.</li>
			<li>Lalu klik Lanjutkan ke Pembayaran.</li>
			<li>Periksa kembali pesanan Anda.</li>
			<li>Masukkan kode voucher yang tertera pada halaman banner voucher.</li>
			<li>Jumlah nilai pembelian akan berkurang sesuai dengan nilai promo yang diberikan.</li>
			<li>Lanjutkan ke proses pembayaran / proceed to check out.</li>
			</ul>
			</div>
			</div>
			</div>
			</div> 
		</div>
</div>
</section>
<!-- Content End-->
@include('component.front.footer')
@endsection

@section('script')

@endsection