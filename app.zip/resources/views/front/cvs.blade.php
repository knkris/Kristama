<div class="ui buttons no-print">
          <button class="ui button" onclick="window.history.go(-1);"><i class="arrow left icon"></i> Kembali</button>
          <div class="or"></div>
          <button class="ui positive button" onclick="window.print()"><i class="print icon"></i> Cetak</button>
        </div>
      <div class="ui segment">
        <h2 class="ui header dividing">Informasi Pembayaran</h2>
        <div class="ui icon message">
          <i class="wait icon"></i>
          <div class="content">
            <div class="header">
              Pastikan anda mentransfer dana sebelum masa berlaku habis
            </div>
            <p>dan dengan nominal yang tepat</p>
          </div>
        </div>

        <table class="ui collapsing table celled selectable teal">
          <tbody>
            <tr>
              <td><div class="ui ribbon label teal">Nomor Pembayaran</div></td>
              <td>{{ $nt->va_number }}</td>
            </tr>
            <tr>
              <td><div class="ui ribbon label teal">Mitra</div></td>
              <td>{{ $store->bank }}</td>
            </tr>
            <tr>
              <td><div class="ui ribbon label teal">Nominal</div></td>
              <td>{{ currency_format($store->total, 'IDR') }}</td>
            </tr>
            <tr>
              <td><div class="ui ribbon label teal">Nama</div></td>
              <td>{{ $store->name }}</td>
            </tr>
            <tr>
              <td><div class="ui ribbon label teal">Nomor Invoice</div></td>
              <td>{{ $store->invoice }}</td>
            </tr>
            <tr>
              <td><div class="ui ribbon label teal">Masa Berlaku</div></td>
              <td>{{ \Carbon\Carbon::parse($store->created_at)->addDay()->format('d/m/Y / H:i:s') }}</td>
            </tr>
          </tbody>
        </table>

        