@extends('layouts.front')

@section('title')
	Cart
@endsection

@section('head')
<link type="text/css" rel="stylesheet" href="{{ asset('css/style.css') }}" />
@endsection

@section('content')
<!---- Content Start ---->
<section id="content" class=" bg-none">
	<div class="title-head">
		<div class="container">
			<div class="row">
				<div class="col-lg-12  col-xs-12 col-sm-12">
					<h3>My Cart </h3>
				</div>
			</div>
		</div>		
	</div>

	<section class="ic-cart-wrapper">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="ic-cart-header">
						<div class="ic-single-ch">
							<div class="ic-check">
								{{-- <label> Check all
									<input id="ckbCheckAll" type="checkbox" name="pmethod">
									<span class="checkmark"></span>
								</label> --}}
							</div>
						</div>
						<div class="ic-single-ch">
							<span>Product name</span>
						</div>
						<div class="ic-single-ch">
							<span>Price</span>
						</div>
						<div class="ic-single-ch ic-xs-none">
							<span>Qty</span>
						</div>
					</div>
					<?php
					$nettotal=0;
					?>
					@if(count($cart))
					<div class="ic-cart-body">
						@foreach($cart as $key => $value)
						<?php
						$product=$value->Product;
						//$productStock=\App\Models\ProductStock::find($value->product_stock_id);
						$subtotal=$product->finalPrice(Auth::user()->customer_group_id,$value->qty)*$value->qty;
                        $nettotal+=$subtotal;
						?>
					    

					    <div id="cart-item-{{$value->id}}" class="ic-single-cart">
							<!-- <div class="ic-sc-detail ic-12-per">
								<div class="ic-check">
									{{-- <label>
										<input class="checkBoxClass" type="checkbox" name="pmethod">
										<span class="checkmark"></span>
									</label> --}}
								</div>
							</div> -->
							<div class="ic-sc-detail ic-20-per ic-product-fig">
								<img src="{{ $product->Image->first()->image }}" alt="{{ $product->name }}">
							</div>
							<div class="ic-sc-detail ic-xsm">
								<a href="{{ url($product->slug) }}"><h4>{{ $product->name }} </h4></a><br>
								<span class="ic-abc-id" style="font-size:18px;">{{ $product->model }}</span><br>
								
							</div>
							<div class="ic-sc-detail">
								<i class="fa fa-spinner fa-spin loading-{{$value->id}}" style="display: none;"></i>
								<span id="subtotal-{{$value->id}}" class="ic-selling-price">{{ currency_format($product->finalPrice(Auth::user()->customer_group_id,$value->qty)*$value->qty,'IDR') }}</span>
								<span id="subtotal-old-{{$value->id}}" class="ic-old-price">{{ currency_format($product->price*$value->qty,'IDR') }}</span>
							</div>
							<div class="ic-sc-detail ic-xs-none">
								{{-- <form id='increamentDecreament' class="ic-plus-min-btn ic-xs-none" method='POST' action='#'> --}}
									<input type='button' value='-' class='qtyminus' field='quant-{{ $value->id }}' />
									<input type='text' id="quant-{{ $value->id }}" name="quant[{{$value->id}}]" value='{{ $value->qty }}' class='qty cart-item-qty' data-id="{{$value->id}}"  min="1" max="{{ $product->qty }}"/>
									<input type='button' value='+' class='qtyplus' field='quant-{{ $value->id }}' />
								{{-- </form> --}}
							</div>
							<div class="ic-delete remove-item" data-id="{{$value->id}}" data-name="{{$value->name}}" >x</div>
						</div>
					    @endforeach

						
					</div>
					@else
					    	<div class="text-center">Cart Anda Kosong, Ayo Mulai <a href="{{ url('/') }}">Belanja</a></div>
				    @endif
				    <div class="field flush" style="padding: 20px 0">
				    	<div class="col-xs-12 text-right" style="padding-bottom: 20px;">
				    		<label style="font-size:24px;">Total : </label>
				    		<span id="nettotal" style="left: 0; font-size:26px;"> {{ currency_format($nettotal, 'IDR') }} </span>
			    		</div>
						<div class="col-lg-6 col-sm-6 col-xs-6">
							<button type="button"  style="width: 120px;" onclick="window.history.go(-1); return false;">Back</button>
						</div>
						<div class="col-lg-6 text-right col-sm-6 col-xs-6 flush">
							<button type="button" onclick="clearCart()">Clear Cart</button> <button type="button" id="checkout" style="width: 120px;">Checkout</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

</section>
@include('component.front.fixbottom')
<!---- Content End ---->

@include('component.front.footer')
@endsection

@section('script')
<script>
if(performance.navigation.type == 2){
   location.reload(true);
   console.log('reload by history check');
}
function clearCart(){
	swal({
          title: 'Kosongkan Keranjang?',
          text: "Hapus semua barang dalam keranjang Anda?",
          type: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Ya, kosongkan'
        }).then((result) => {
          if (result.value) {
            window.location.href="{{ route('cart.clear') }}";
          }
        })
}

function checkCartTotal(){
		$.get("{{ route('cart.total') }}", function(data, status){
			$('.total-item').text(data);
		})
	}

function updateCart() {
        $.get('{{ url('update-cart-xhr') }}', function(data) {
            $('.ic-cart-items').html(data);
        })
    }

$('.btn-number').click(function(e){
    e.preventDefault();
    
    fieldName = $(this).attr('data-field');
    type      = $(this).attr('data-type');
    var input = $("input[name='"+fieldName+"']");
    var currentVal = parseInt(input.val());
    if (!isNaN(currentVal)) {
        if(type == 'minus') {
            
            if(currentVal > input.attr('min')) {
                input.val(currentVal - 1).change();
            } 
            if(parseInt(input.val()) == input.attr('min')) {
                $(this).attr('disabled', true);
            }

        } else if(type == 'plus') {

            if(currentVal < input.attr('max')) {
                input.val(currentVal + 1).change();
            }
            if(parseInt(input.val()) == input.attr('max')) {
                $(this).attr('disabled', true);
            }

        }
    } else {
        input.val(0);
    }
});
$('.input-number').focusin(function(){
   $(this).data('oldValue', $(this).val());
});
$('.input-number').change(function() {
    
    minValue =  parseInt($(this).attr('min'));
    maxValue =  parseInt($(this).attr('max'));
    valueCurrent = parseInt($(this).val());
    
    name = $(this).attr('name');
    if(valueCurrent >= minValue) {
        $(".btn-number[data-type='minus'][data-field='"+name+"']").removeAttr('disabled')
    } else {
        alert('Sorry, the minimum value was reached');
        $(this).val($(this).data('oldValue'));
    }
    if(valueCurrent <= maxValue) {
        $(".btn-number[data-type='plus'][data-field='"+name+"']").removeAttr('disabled')
    } else {
        alert('Sorry, the maximum value was reached');
        $(this).val($(this).data('oldValue'));
    }
    
    
});
$(".input-number").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 190]) !== -1 ||
             // Allow: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) || 
             // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
$('.cart-item-qty').on('change', function(e){
	$this=$(this);
	$id=$this.data('id');
	$('.loading-'+$id).show();
	$qty=$(this).val();
	if($qty == 0) {
		$('.loading-'+$id).hide();
		$('input[name="quant['+$id+']').val(1);
		$(this).parent().next(".remove-item").trigger( "click" );
	}else{
		var formData = new FormData();
		formData.append('cart_id', $id);
		formData.append('qty', $qty);
		formData.append('_token', '{{csrf_token()}}');
		$.ajax({
		    url: '{{ url('update-cart') }}',
		    data: formData,
		    type: 'POST',
		    contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
			processData: false, // NEEDED, DON'T OMIT THIS
		    success: function(data){  
		    	$('#price-'+$id).html(data.formated_price);
		    	$('#subtotal-'+$id).html(data.formated_subtotal);
		    	$('#subtotal-old-'+$id).html(data.formated_subtotal_old);
		    	$('#nettotal').html(data.cart_nettotal);
		    	checkCartTotal()
		    	updateCart()
		        // Display a success toast, with a title
				//toastr.success('Cart Updated!', 'Success!')  
				$('.loading-'+$id).hide();
		    },
		    error: function(XMLHttpRequest, textStatus, errorThrown) { 
		    	$('.loading-'+$id).hide();
		    	if ( XMLHttpRequest.status== 401 ) {
			      toastr.error('You must login first!', 'Error!') 
			    }else if ( XMLHttpRequest.status== 404 ) {
			      toastr.error(XMLHttpRequest.responseJSON['error'], 'Error!')  
			    }else{
			        // Display a error toast, with a title
					toastr.error(XMLHttpRequest.responseJSON.errors[Object.keys(XMLHttpRequest.responseJSON.errors)[0]], 'Error!')  
				}
		    }    
		    // ... Other options like success and etc
		});
	}
})

$('.update-cart').on('click', function(e){
	e.preventDefault();
	$this=$(this);
	$id=$this.data('id');
	$qty=$('input[name="quant['+$id+']').val();
	if($qty == 0) {
		$('input[name="quant['+$id+']').val(1);
		$(this).next(".remove-item").trigger( "click" );
	}else{
		var formData = new FormData();
		formData.append('cart_id', $id);
		formData.append('qty', $qty);
		formData.append('_token', '{{csrf_token()}}');
		$.ajax({
		    url: '{{ url('update-cart') }}',
		    data: formData,
		    type: 'POST',
		    contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
			processData: false, // NEEDED, DON'T OMIT THIS
		    success: function(data){  
		    	$('#price-'+$id).html(data.formated_price);
		    	$('#subtotal-'+$id).html(data.formated_subtotal);
		    	$('#subtotal-old-'+$id).html(data.formated_subtotal_old);
		    	checkCartTotal()
		    	updateCart()
		        // Display a success toast, with a title
				toastr.success('Cart Updated!', 'Success!')  
		    },
		    error: function(XMLHttpRequest, textStatus, errorThrown) { 
		    	if ( XMLHttpRequest.status== 401 ) {
			      toastr.error('You must login first!', 'Error!') 
			    }else if ( XMLHttpRequest.status== 404 ) {
			      toastr.error(XMLHttpRequest.responseJSON['error'], 'Error!')  
			    }else{
			        // Display a error toast, with a title
					toastr.error(XMLHttpRequest.responseJSON.errors[Object.keys(XMLHttpRequest.responseJSON.errors)[0]], 'Error!')  
				}
		    }    
		    // ... Other options like success and etc
		});
	}
})

function removeCartItem($id,$name){
	var formData = new FormData();
	formData.append('cart_id', $id);
	formData.append('_token', '{{csrf_token()}}');
	$.ajax({
	    url: '{{ url('remove-cart-item') }}',
	    data: formData,
	    type: 'POST',
	    contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
		processData: false, // NEEDED, DON'T OMIT THIS
	    success: function(data){  
	    	$('#cart-item-'+$id).remove();
	    	checkCartTotal()
	    	updateCart()
	        // Display a success toast, with a title
			//toastr.success(data+' deleted from your cart!', 'Success!')  
	    },
	    error: function(XMLHttpRequest, textStatus, errorThrown) { 
	    	if ( XMLHttpRequest.status== 401 ) {
		      toastr.error('You must login first!', 'Error!') 
		    }else if ( XMLHttpRequest.status== 404 ) {
		      toastr.error(XMLHttpRequest.responseJSON['error'], 'Error!')  
		    }else{
		        // Display a error toast, with a title
				toastr.error(XMLHttpRequest.responseJSON.errors[Object.keys(XMLHttpRequest.responseJSON.errors)[0]], 'Error!')  
			}
	    }    
	    // ... Other options like success and etc
	});
}

$('.qtyplus').click(function(e){
        // Stop acting like a button
        e.preventDefault();
        // Get the field name
        fieldName = $(this).attr('field');
        // Get its current value
        var currentVal = parseInt($('#'+fieldName).val());
        // If is not undefined
        if (!isNaN(currentVal)) {
            // Increment
            $('#'+fieldName).val(currentVal + 1);
        } else {
            // Otherwise put a 0 there
            $('#'+fieldName).val(0);
        }
        $(this).prev(".cart-item-qty").trigger( "change" );
    });
    // This button will decrement the value till 0
    $(".qtyminus").click(function(e) {
        // Stop acting like a button
        e.preventDefault();
        // Get the field name
        fieldName = $(this).attr('field');
        // Get its current value
        var currentVal = parseInt($('#'+fieldName).val());
        // If it isn't undefined or its greater than 0
        if (!isNaN(currentVal) && currentVal > 0) {
            // Decrement one
            $('#'+fieldName).val(currentVal - 1);
        } else {
            // Otherwise put a 0 there
            $('#'+fieldName).val(0);
        }
        $(this).next(".cart-item-qty").trigger( "change" );
    });
$('.remove-item').on('click', function(e){
	e.preventDefault();
	$this=$(this);
	$id=$this.data('id');
	$name=$this.data('name');
	swal({
          title: 'Delete Item?',
          text: "Delete "+$name+" from your cart?",
          type: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
          if (result.value) {
            removeCartItem($id,$name)
          }
        })
})

$('#checkout').on('click', function(){
	window.location="{{ route('checkout') }}";
})

</script>
@endsection