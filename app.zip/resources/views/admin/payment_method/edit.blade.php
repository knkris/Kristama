@extends('layouts.admin')

@section('title')
    Edit Shipping Method
@endsection

@section('head')
    <!-- include summernote css/js-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.18/jquery.datetimepicker.min.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.min.css">

    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.css"/>

    <style type="text/css">
        textarea {
            overflow-x: hidden;
        }
    </style>
@endsection

@section('content')
     <div id="page-wrapper">
        <form role="form" action="{{ url('admin/shipping-method/edit/'.$results->id) }}" class="form-horizontal" enctype="multipart/form-data" method="post">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Edit Shipping Method
                        <div class="pull-right">
                            <button type="submit" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Save" aria-describedby="tooltip815756">
                                <i class="fa fa-save"></i>
                            </button>
                            <a href="{{ url('admin/shipping-method') }}" class="btn btn-default" data-original-title="Cancel">
                                <i class="fa fa-reply"></i>
                            </a>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/shipping-method') }}">Shipping Method</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-pencil"></i> Edit Shipping Method
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">                            
                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="customer_group_id">
                                    Customer Group
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control select2" name="customer_group_id" id="customer_group_id">
                                        <option></option>
                                        @foreach($customergroup as $val)
                                            <option value="{{ $val->id }}" @if(old('customer_group_id')==$val->id) selected @elseif($results->customer_group_id==$val->id) selected @endif>{{ $val->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                @if ($errors->has('customer_group_id'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('customer_group_id') }}</strong>
                                    </span>
                                @endif
                            </div>


                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="name">
                                    Name
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" name="name" value="{{ old('name') ?: $results->name }}" placeholder="Shipping Method Name" id="name" class="form-control">
                                </div>
                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="status">
                                    Status
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="status" id="status">
                                        <option value="1" @if(old('status')=='1') selected @elseif($results->status=='1') selected @endif>enabled</option>
                                        <option value="0" @if(old('status')=='0') selected @elseif($results->status=='0') selected @endif>disabled</option>
                                    </select>
                                </div>
                                @if ($errors->has('status'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('status') }}</strong>
                                    </span>
                                @endif
                            </div>
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            </form>

            @if($results->id==1)
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-list"></i> Shipping Courier List
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="table">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                
                            </table>
                            <!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            @endif

            @if($results->id==2)
            <form id="form" role="form" action="{{ url('admin/free-shipping/trash') }}" class="form-horizontal" enctype="multipart/form-data" method="post">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-list"></i> Free Shipping Rule
                            <div class="pull-right">
                                <a href="{{ url('admin/free-shipping/create') }}" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Add New" aria-describedby="tooltip23863">
                                    <i class="fa fa-plus"></i>
                                </a> 
                                <button id="delete" type="button" data-toggle="tooltip" title="" class="btn btn-danger" data-original-title="Delete">
                                    <i class="fa fa-trash-o"></i>
                                </button>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="table">
                                <thead>
                                    <tr>
                                        <th>
                                            <input type="checkbox" onclick="$('input[name*=\'selected\']').prop('checked', this.checked);">
                                        </th>
                                        <th>Name</th>
                                        <th>Minimum Order</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                            </table>
                            <!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            </form>
            @endif
        </div>
        <!-- /#page-wrapper -->
@endsection

@section('script')
    <!-- include summernote css/js-->
    <script src="{{ asset('js/summernote.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.18/jquery.datetimepicker.full.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.summernote').summernote({
                height: 200
            });
            $('.select2').select2();

            $('.datepicker').datetimepicker({
             timepicker:false,
             format:'d-m-Y'
            });

            @if($results->id==1)
            $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax":{
                         "url": "{{ url('admin/shipping-courier/'.$results->id) }}",
                         "dataType": "json",
                         "type": "POST",
                         "data":{ _token: "{{csrf_token()}}"}
                       },
                "columns": [
                    { "data": "name" },
                    { "data": "status",
                      "className": "selectable"
                    },
                ]    

            });
            @endif

            @if($results->id==2)
            $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax":{
                         "url": "{{ url('admin/free-shipping') }}",
                         "dataType": "json",
                         "type": "POST",
                         "data":{ _token: "{{csrf_token()}}"}
                       },
                "columns": [
                    { "data": "id",
                      "orderable": false
                    },
                    { "data": "name" },
                    { "data": "subtotal" },
                    { "data": "status",
                      "className": "selectable"
                    },
                    { "data": "action",
                      "orderable": false
                    }
                ]    

            });
            @endif
        });

        @if($results->id==1)
        // Activate an inline edit on click of a table cell
        $('#table').on( 'click', 'tbody td.selectable', function (e) {
            if(!$(this).hasClass('editing')){
                $(this).addClass('editing');
                $id=$(this).children().data('id');
                $val=$(this).children().text();
                $type=$(this).children().data('type');
                if($val==="enabled"){
                    $(this).html("<select class='form-control selectable-box' name='val' data-id='"+$id+"' data-type='"+$type+"'><option value='1' selected>enabled</option><option value='0'>disabled</option></select> ");
                }else{
                    $(this).html("<select class='form-control selectable-box' name='val' data-id='"+$id+"' data-type='"+$type+"'><option value='1'>enabled</option><option value='0' selected>disabled</option></select> ");
                }
                $('.selectable-box').focus();
            }
        } );

        $(document).on("change", '.selectable-box', function(event) { 
            $this=$(this);
            $id=$(this).data('id');
            $val=$(this).val();

            $(this).attr('disabled','disabled');
            $.ajax({
                url: "{{ url('admin/shipping-method') }}/"+$id,
                type: "post",
                data: {
                    id: $id,
                    value: $val,
                    _token: "{{csrf_token()}}"
                } ,
                success: function (response) {
                   // you will get response from your php page (what you echo or print)                 
                   console.log(response);
                   $newstatus=response.html_status;
                   //$parent=$this.parent("td");
                   $this.parent("td").removeClass('editing');
                   $this.parent("td").empty().html($newstatus);
                   //swal('Success!', response.name+" price updated", 'success');
                }.bind($this),
                error: function(jqXHR, textStatus, errorThrown) {
                   console.log(jqXHR, textStatus, errorThrown);
                   swal('Error!', jqXHR.responseJSON.errors.value[0], 'error');
                   $(this).removeAttr('disabled');

                }.bind($this)
            });


        });
        @endif

        @if($results->id==2)
        $('#delete').on('click',function(){
            swal({
                  title: 'Are you sure?',
                  text: "You won't be able to revert this!",
                  type: 'warning',
                  showCancelButton: true,
                  confirmButtonColor: '#3085d6',
                  cancelButtonColor: '#d33',
                  confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                  if (result.value) {
                    $('#form').submit();
                  }
                })
        });

        // Activate an inline edit on click of a table cell
        $('#table').on( 'click', 'tbody td.selectable', function (e) {
            if(!$(this).hasClass('editing')){
                $(this).addClass('editing');
                $id=$(this).children().data('id');
                $val=$(this).children().text();
                $type=$(this).children().data('type');
                if($val==="enabled"){
                    $(this).html("<select class='form-control selectable-box' name='val' data-id='"+$id+"' data-type='"+$type+"'><option value='1' selected>enabled</option><option value='0'>disabled</option></select> ");
                }else{
                    $(this).html("<select class='form-control selectable-box' name='val' data-id='"+$id+"' data-type='"+$type+"'><option value='1'>enabled</option><option value='0' selected>disabled</option></select> ");
                }
                $('.selectable-box').focus();
            }
        } );

        $(document).on("change", '.selectable-box', function(event) { 
            $this=$(this);
            $id=$(this).data('id');
            $val=$(this).val();

            $(this).attr('disabled','disabled');
            $.ajax({
                url: "{{ url('admin/free-shipping') }}/"+$id,
                type: "post",
                data: {
                    id: $id,
                    value: $val,
                    _token: "{{csrf_token()}}"
                } ,
                success: function (response) {
                   // you will get response from your php page (what you echo or print)                 
                   console.log(response);
                   $newstatus=response.html_status;
                   //$parent=$this.parent("td");
                   $this.parent("td").removeClass('editing');
                   $this.parent("td").empty().html($newstatus);
                   //swal('Success!', response.name+" price updated", 'success');
                }.bind($this),
                error: function(jqXHR, textStatus, errorThrown) {
                   console.log(jqXHR, textStatus, errorThrown);
                   swal('Error!', jqXHR.responseJSON.errors.value[0], 'error');
                   $(this).removeAttr('disabled');

                }.bind($this)
            });


        });
        @endif
    </script>
@endsection