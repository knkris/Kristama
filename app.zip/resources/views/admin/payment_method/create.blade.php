@extends('layouts.admin')

@section('title')
    Add Shipping Method
@endsection

@section('head')
    <!-- include summernote css/js-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.18/jquery.datetimepicker.min.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.min.css">

    <style type="text/css">
        textarea {
            overflow-x: hidden;
        }
    </style>
@endsection

@section('content')
     <div id="page-wrapper">
        <form role="form" action="{{ url('admin/shipping-method/store') }}" class="form-horizontal" enctype="multipart/form-data" method="post">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Add Shipping Method
                        <div class="pull-right">
                            <button type="submit" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Save" aria-describedby="tooltip815756">
                                <i class="fa fa-save"></i>
                            </button>
                            <a href="{{ url('admin/shipping-method') }}" class="btn btn-default" data-original-title="Cancel">
                                <i class="fa fa-reply"></i>
                            </a>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/shipping-method') }}">Shipping Method</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-pencil"></i> Add Shipping Method
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">                            
                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="customer_group_id">
                                    Customer Group
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control select2" name="customer_group_id" id="customer_group_id">
                                        <option></option>
                                        @foreach($customergroup as $val)
                                            <option value="{{ $val->id }}" @if(old('customer_group_id')==$val->id) selected @endif>{{ $val->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                @if ($errors->has('customer_group_id'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('customer_group_id') }}</strong>
                                    </span>
                                @endif
                            </div>


                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="name">
                                    Name
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" name="name" value="{{ old('name') }}" placeholder="Shipping Method Name" id="name" class="form-control">
                                </div>
                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="status">
                                    Status
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="status" id="status">
                                        <option value="1" @if(old('status')=='1') selected @endif>enabled</option>
                                        <option value="0" @if(old('status')=='0') selected @endif>disabled</option>
                                    </select>
                                </div>
                                @if ($errors->has('status'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('status') }}</strong>
                                    </span>
                                @endif
                            </div>
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            </form>
        </div>
        <!-- /#page-wrapper -->
@endsection

@section('script')
    <!-- include summernote css/js-->
    <script src="{{ asset('js/summernote.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.18/jquery.datetimepicker.full.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.summernote').summernote({
                height: 200
            });
            $('.select2').select2();

            $('.datepicker').datetimepicker({
             timepicker:false,
             format:'d-m-Y'
            });
        });
    </script>
@endsection