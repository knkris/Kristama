<script>
var dropZone = document.getElementById('dropZone');
var outer = document.getElementById('outer');

function showDropZone() {
    outer.style.visibility = "visible";
    $('.inner > h1').css('z-index',1000);
}
function hideDropZone() {
    outer.style.visibility = "hidden";
    $('.inner > h1').css('z-index',0);
}

function allowDrag(e) {
    if (true) {  // Test that the item being dragged is a valid one
        e.dataTransfer.dropEffect = 'copy';
        e.preventDefault();
    }
}

function handleDrop(e) {
    e.preventDefault();
    var files = e.target.files || (e.dataTransfer && e.dataTransfer.files);
    document.getElementById('file_input').files = files;
    //e.preventDefault();
    hideDropZone();
    console.log($('#file_input').val());
    //alert('Drop!');

    importform=document.getElementById('excel-import');
    importform.submit();
}

// 1
window.addEventListener('dragenter', function(e) {
    showDropZone();
});

// 2
dropZone.addEventListener('dragenter', allowDrag);
dropZone.addEventListener('dragover', allowDrag);

// 3
dropZone.addEventListener('dragleave', function(e) {
    hideDropZone();
});

// 4
dropZone.addEventListener('drop', handleDrop);

</script>