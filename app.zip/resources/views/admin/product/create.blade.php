@extends('layouts.admin')

@section('title')
    Add Product
@endsection

@section('head')
    <!-- include summernote css/js-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.min.css">

    <style type="text/css">
        textarea {
            overflow-x: hidden;
        }
        .my-group .form-control{
            width:50%;
        }
        #ui-id-1{
            top:450px !important;
        }
    </style>
@endsection

@section('content')
     <div id="page-wrapper">
        <form role="form" action="{{ url('admin/product/store') }}" class="form-horizontal" enctype="multipart/form-data" method="post">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Add Product
                        <div class="pull-right">
                            <button type="submit" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Save" aria-describedby="tooltip815756">
                                <i class="fa fa-save"></i>
                            </button>
                            <a href="{{ url('admin/product') }}" class="btn btn-default" data-original-title="Cancel">
                                <i class="fa fa-reply"></i>
                            </a>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/product') }}">Product</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-pencil"></i> Add Product
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">  
                            <ul class="nav nav-tabs">
                                <li class="active">
                                    <a href="#tab-general" data-toggle="tab" aria-expanded="true">General</a>
                                </li>
                                <li class="">
                                    <a href="#tab-attribute" data-toggle="tab" aria-expanded="false">Attribute</a>
                                </li>
                                <li class="">
                                    <a href="#tab-discount" data-toggle="tab" aria-expanded="false">Discount</a>
                                </li>
                                <li class="">
                                    <a href="#tab-special" data-toggle="tab" aria-expanded="false">Special</a>
                                </li>
                            </ul>     
                    <div class="tab-content">     
                        <div class="tab-pane active" id="tab-general">                           
                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="name">
                                    Product Name
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" name="name" value="{{ old('name') }}" placeholder="Product Name" id="name" class="form-control">
                                </div>
                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="sku">
                                    SKU
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" id="sku" name="sku" value="{{ old('sku') }}" placeholder="SKU" id="sku" class="form-control">
                                </div>
                                @if ($errors->has('sku'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('sku') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="model">
                                    Model
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" id="model" name="model" value="{{ old('model') }}" placeholder="Product Model" id="model" class="form-control">
                                </div>
                                @if ($errors->has('model'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('model') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="desc">
                                    Description
                                </label>
                                <div class="col-sm-10">
                                    <textarea name="desc" placeholder="Description" id="description" class="form-control summernote">{{ old('desc') }}</textarea>
                                </div>
                                @if ($errors->has('desc'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('desc') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="short_desc">
                                    Short Description
                                </label>
                                <div class="col-sm-10">
                                    <textarea name="short_desc" placeholder="Description" id="short_description" class="form-control">{{ old('short_desc') }}</textarea>
                                </div>
                                @if ($errors->has('short_desc'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('short_desc') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="seo">
                                    SEO
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" name="seo" value="{{ old('seo') }}" placeholder="SEO URL" id="seo" class="form-control">
                                </div>
                                @if ($errors->has('seo'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('seo') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="category">
                                    Category
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control select2" name="category[]" id="category" multiple="multiple">
                                        <option value=""></option>
                                        @foreach($category as $cat)
                                        <option value="{{$cat->id}}" @if(old('category')) @if(in_array($cat->id, old('category'))) selected @endif @endif>{{$cat->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                @if ($errors->has('category'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('category') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="manufacturer">
                                    Manufacturer
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="manufacturer" id="manufacturer">
                                        <option value=""></option>
                                        @foreach($manufacturer as $val)
                                        <option value="{{$val->id}}" @if(old('manufacturer')==$val->id) selected @endif>{{$val->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                @if ($errors->has('manufacturer'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('manufacturer') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="manufacturer">
                                    Related Product
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="related_product[]" id="related-product" multiple="multiple">
                                        @if(old('related_product'))
                                        @foreach(old('related_product') as $val)
                                        <?php
                                        $bi=\App\Models\Product::find($val);
                                        ?>
                                        <option value="{{$bi->id}}" ><span><img src="{{$bi->Image ? $bi->Image->first()->image : ''}}" style="max-width: 25px;" /> {{$bi->name}}</span></option>
                                        @endforeach
                                        @endif
                                    </select>
                                </div>
                                @if ($errors->has('related_product'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('related_product') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="price">
                                    Old Price
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" name="price" value="{{ old('price') }}" placeholder="Old Price" id="price" class="form-control">
                                </div>
                                @if ($errors->has('price'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('price') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="price_filter">
                                    New Price 
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" name="price_filter" value="{{ old('price_filter') }}" placeholder="New Price" id="price_filter" class="form-control">
                                </div>
                                @if ($errors->has('price_filter'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('price_filter') }}</strong>
                                    </span>
                                @endif
                            </div>


                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="status">
                                    Status
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="status" id="status">
                                        <option value="1" @if(old('status')=='1') selected @endif>enabled</option>
                                        <option value="0" @if(old('status')=='0') selected @endif>disabled</option>
                                    </select>
                                </div>
                                @if ($errors->has('status'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('status') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="weight">
                                    Weight
                                </label>
                                <div class="col-sm-10">
                                    <div class="input-group my-group"> 

                                        <input type="number" class="form-control" name="weight" placeholder="weight" value="{{ old('weight')?:0 }}">
                                        <select class="form-control" name="weight_class">
                                            @foreach($weightclass as $val)
                                            <option value="{{$val->id}}" @if(old('weight_class')==$val->id) selected @endif>{{$val->unit}}</option>
                                            @endforeach
                                        </select> 

                                    </div>
                                </div>
                                @if ($errors->has('weight'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('weight') }}</strong>
                                    </span>
                                @endif
                                @if ($errors->has('weight_class'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('weight_class') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="length">
                                    Length
                                </label>
                                <div class="col-sm-10">
                                    <div class="input-group my-group"> 

                                        <input type="number" class="form-control" name="length" placeholder="length" value="{{ old('length')?:0 }}">
                                        <select class="form-control length-class" name="length_class">
                                            @foreach($lengthclass as $val)
                                            <option value="{{$val->id}}" @if(old('length_class')==$val->id) selected @endif>{{$val->unit}}</option>
                                            @endforeach
                                        </select> 

                                    </div>
                                </div>
                                @if ($errors->has('length'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('length') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="width">
                                    Width
                                </label>
                                <div class="col-sm-10">
                                    <div class="input-group my-group"> 

                                        <input type="number" class="form-control" name="width" placeholder="width" value="{{ old('width')?:0 }}">
                                        <select class="form-control length-class" name="width_class">
                                            @foreach($lengthclass as $val)
                                            <option value="{{$val->id}}" @if(old('width')==$val->id) selected @endif>{{$val->unit}}</option>
                                            @endforeach
                                        </select> 

                                    </div>
                                </div>
                                @if ($errors->has('width'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('width') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="height">
                                    Height
                                </label>
                                <div class="col-sm-10">
                                    <div class="input-group my-group"> 

                                        <input type="number" class="form-control" name="height" placeholder="height" value="{{ old('height')?:0 }}">
                                        <select class="form-control length-class" name="height_class">
                                            @foreach($lengthclass as $val)
                                            <option value="{{$val->id}}" @if(old('height')==$val->id) selected @endif>{{$val->unit}}</option>
                                            @endforeach
                                        </select> 

                                    </div>
                                </div>
                                @if ($errors->has('height'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('height') }}</strong>
                                    </span>
                                @endif
                                @if ($errors->has('length_class'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('length_class') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="qty">
                                    Quantity
                                </label>
                                <div class="col-sm-10">
                                    <input type="number" name="qty" value="{{ old('qty')?:0 }}" placeholder="qty" id="qty" class="form-control">
                                </div>
                                @if ($errors->has('qty'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('qty') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="stock_status">
                                    <span data-toggle="tooltip" title="" data-original-title="Status shown when a product is out of stock">Out Of Stock Status</span>
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="stock_status" id="stock_status">
                                        @foreach($stockstatus as $val)
                                        <option value="{{$val->id}}" @if(old('stock_status')==$val->id) selected @endif>{{$val->name_en}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                @if ($errors->has('stock_status'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('stock_status') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="substract">
                                    Substract Stock
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="substract" id="substract">
                                        <option value="1" @if(old('substract')=='1') selected @endif>Yes</option>
                                        <option value="0" @if(old('substract')=='0') selected @endif>No</option>
                                    </select>
                                </div>
                                @if ($errors->has('substract'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('substract') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="minimum">
                                    <span data-toggle="tooltip" data-placement="top" title="Force a minimum ordered amount">Minimum Quantity</span>
                                </label>
                                <div class="col-sm-10">
                                    <input type="number" name="minimum" value="{{ old('minimum')?:1 }}" placeholder="minimum" id="minimum" class="form-control">
                                </div>
                                @if ($errors->has('minimum'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('minimum') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="sort_order">
                                    Sort Order
                                </label>
                                <div class="col-sm-10">
                                    <input type="number" name="sort_order" value="{{ old('sort_order')?:0 }}" placeholder="sort_order" id="sort_order" class="form-control">
                                </div>
                                @if ($errors->has('sort_order'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('sort_order') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="shipping">
                                    Require Shipping
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="shipping" id="shipping">
                                        <option value="1" @if(old('shipping')=='1') selected @endif>Yes</option>
                                        <option value="0" @if(old('shipping')=='0') selected @endif>No</option>
                                    </select>
                                </div>
                                @if ($errors->has('shipping'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('shipping') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="image">
                                   Image
                                </label>
                                <div class="col-sm-10">
                                    <input type="file" id="image" name="image[]" class="form-control" multiple />
                                </div>
                                @if ($errors->has('image'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('image') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group">
                                <div id="image_preview" class="col-sm-12">
                                    
                                </div>
                            </div>
                            </div>

                             @include('admin.product.addattribute')
                             @include('admin.product.adddiscount')
                             @include('admin.product.addspecial')

                     </div>

                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Add Product Option
                        <div class="pull-right">
                            <button type="button" id="addProductOption" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Save" aria-describedby="tooltip815756">
                                Add Product Option
                            </button>
                        </div>
                    </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-pencil"></i> Add Product Option
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">                            
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="option">
                                    Option
                                </label>
                                <div class="col-sm-10">
                                    <select name="option" placeholder="Option" id="option" class="form-control option"></select>
                                </div>
                                
                            </div>

                          {{--   <div class="form-group required">
                                <label class="col-sm-2 control-label" for="required">
                                    Required
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="required" id="required">
                                        <option value="1">Yes</option>
                                        <option value="0">No</option>
                                    </select>
                                </div>
                            </div>
 --}}
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <div id="container-col">
                <?php $count=count(old('productoption')); ?>
                @if($count>0)
                    @foreach(old('productoption') as $key=>$value)
                    <?php
                    $getoption=\App\Models\Option::find($key);
                    ?>
                    <div id="box-{{$key}}" class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <i class="fa fa-pencil"></i> Add Product Option {{$getoption->name}}
                                    <div class="pull-right">
                                        <a class="remove-box" data-box="{{$key}}">X</a>
                                    </div>
                                </div>
                                <div class="panel-body">
                                    <input type="hidden" name="productoption[{{$key}}][option_id]" value="{{$value['option_id']}}" />
                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="stock_enabled{{$key}}">
                                            Stock Enabled
                                        </label>
                                        <div class="col-sm-10">
                                            <select class="form-control" name="productoption[{{$key}}][stock_enabled]" id="stock_enabled{{$key}}">
                                                <option value="1" @if($value['stock_enabled']==1) selected @endif>Yes</option>
                                                <option value="0" @if($value['stock_enabled']==0) selected @endif>No</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="required"+x+"">
                                            Required
                                        </label>
                                        <div class="col-sm-10">
                                            <select class="form-control" name="productoption[{{$key}}][required]" id="required{{$key}}">
                                                <option value="1" @if($value['required']==1) selected @endif>Yes</option>
                                                <option value="0" @if($value['required']==0) selected @endif>No</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <td class="col-md-3">
                                                        <strong>Option Value</strong>
                                                    </td>
                                                    <td class="col-md-3">
                                                        <strong>Quantity</strong>
                                                    </td>
                                                    <td class="col-md-3">
                                                        <strong>Substract Stock</strong>
                                                    </td>
                                                    <td class="col-md-3">
                                                        <strong>Price</strong>
                                                    </td>
                                                    <td></td>
                                                </tr>
                                            </thead>
                                            <tbody id="optiontab-{{$key}}">
                                                @foreach($value['option'] as $key2=>$val)
                                                <?php
                                                $getoptionvalue=\App\Models\OptionValue::whereOption_id($key)->get();
                                                ?>
                                                <tr id="tr-{{$key}}-{{$key2}}">
                                                    <td class="col-md-3">
                                                        <select name="productoption[{{$key}}][option][{{$key2}}][option_value_id]" value=" placeholder="Option" id="optionvalue{{$key2}}" class="form-control optionvalue">
                                                            @foreach($getoptionvalue as $gov)
                                                            <option value="{{$gov->id}}" @if($val['option_value_id']==$gov->id) selected @endif>{{$gov->name}}</option>
                                                            @endforeach
                                                        </select>
                                                    </td>
                                                    <td class="col-md-3">
                                                        <input type="number" name="productoption[{{$key}}][option][{{$key2}}][qty]" placeholder="Quantity" id="qty{{$key2}}" value="{{$val['qty']}}" class="form-control">
                                                    </td>
                                                    <td class="col-md-3">
                                                        <select class="form-control" name="productoption[{{$key}}][option][{{$key2}}][substract]" id="substract{{$key2}}">
                                                            <option value="1" @if($val['substract']=='1') selected @endif>Yes</option>
                                                            <option value="0" @if($val['substract']=='0') selected @endif>No</option>
                                                        </select>
                                                        {{-- <input type="number" name="productoption[{{$key}}][option][{{$key2}}][substract]" value="{{$val['substract']}}" placeholder="Substract" id="substract{{$key2}}" class="form-control"> --}}
                                                    </td>
                                                    <td class="col-md-3">
                                                        <input type="text" name="productoption[{{$key}}][option][{{$key2}}][price]" value="{{$val['price']}}" placeholder="Price" id="price{{$key2}}" class="form-control">
                                                    </td>
                                                    <td>
                                                        <a class="remove-select-option" data-x="{{$key}}"" data-y="{{$key2}}"" style="cursor: pointer">Remove</a>
                                                    </td>
                                                </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                        <div>
                                            <button type="button" class="button btn-primary add-select-option" data-x="{{$key}}" data-y="{{$key2}}"" data-option_id="{{$key}}" data-option="{{$getoption->name}}" data-required="{{$value['required']}}">
                                                Add row
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    @endforeach
                @endif
            </div>

            </form>
        </div>
        <!-- /#page-wrapper -->
@endsection

@section('script')
    <!-- include summernote css/js-->
    <script src="{{ asset('js/summernote.js') }}"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js"></script>
    <script>
        var x={{$count}};
        var ov_count=new Array();
        var optionvalue=new Array();
        <?php if($count>0){ ?>
        @foreach(old('productoption') as $key=>$value)
        $.get('{{ url('admin/optionvalue/'.$key.'/'.$key) }}', function(data){
                optionvalue[{{$key}}]=data;
            });
        ov_count[{{$key}}]={{count($value)}};
        @endforeach
        <?php } ?>
        function appendoption2(x,option_id,option,option_value){
            console.log(x,option_id,option,option_value);
            optionvalue[option_id]=option_value;
            ov_count[option_id]=0;
            $('#container-col').append("<div id='box-"+x+"' class='row'><div class='col-lg-12'><div class='panel panel-default'><div class='panel-heading'><i class='fa fa-pencil'></i> Add Product Option "+option+"<div class='pull-right'><a class='remove-box' data-box='"+x+"'>X</a></div></div><div class='panel-body'><input type='hidden' name='productoption["+option_id+"][option_id]' value='"+option_id+"' /><div class='form-group required'><label class='col-sm-2 control-label' for='stock_enabled"+x+"''>Stock Enabled</label><div class='col-sm-10'><select class='form-control' name='productoption["+option_id+"][stock_enabled]' id='stock_enabled"+x+"''><option value='1'>Yes</option><option value='0'>No</option></select></div></div><div class='form-group required'><label class='col-sm-2 control-label' for='required"+x+"''>Required</label><div class='col-sm-10'><select class='form-control' name='productoption["+option_id+"][required]' id='required"+x+"'><option value='1'>Yes</option><option value='0'>No</option></select></div></div><div class='table-responsive'><table class='table'><thead><tr><td class='col-md-3'><strong>Option Value</strong></td><td class='col-md-3'><strong>Quantity</strong></td><td class='col-md-3'><strong>Substract Stock</strong></td><td class='col-md-3'><strong>Price</strong></td><td></td></tr></thead><tbody id='optiontab-"+x+"'><tr id='tr-"+ov_count[option_id]+"'><td class='col-md-3'><select name='productoption["+option_id+"][option]["+ov_count[option_id]+"][option_value_id]' value='' placeholder='Option' id='optionvalue"+ov_count[option_id]+"' class='form-control optionvalue'>"+option_value+"</select></td><td class='col-md-3'><input type='number' name='productoption["+option_id+"][option]["+ov_count[option_id]+"][qty]' value='0' placeholder='Quantity' id='qty"+ov_count[option_id]+"' class='form-control'></td><td class='col-md-3'><select class='form-control' name='productoption["+option_id+"][option]["+ov_count[option_id]+"][substract]' id='substract"+ov_count[option_id]+"'><option value='1'>Yes</option><option value='0'>No</option></select>{{-- <input type='number' name='productoption["+option_id+"][option]["+ov_count[option_id]+"][substract]' value='0' placeholder='Substract' id='substract"+ov_count[option_id]+"' class='form-control'> --}}</td><td class='col-md-3'><input type='text' name='productoption["+option_id+"][option]["+ov_count[option_id]+"][price]' value='0' placeholder='Price' id='price"+ov_count[option_id]+"' class='form-control'></td><td><a class='remove-select-option'  data-x='"+x+"' data-y='"+ov_count[option_id]+"' style='cursor: pointer'>Remove</a></td></tr></tbody></table><div><button type='button' class='button btn-primary add-select-option' data-x='"+x+"' data-y='"+ov_count[option_id]+"'data-option_id='"+option_id+"' data-option='"+option+"' >Add row</button></div></div></div></div></div>");
            ov_count[option_id]=ov_count[option_id]+1;
        }

        function appendmoreoption(x,y,option_id,option){
            console.log(option+" "+ov_count[option_id]+" "+ optionvalue[option_id]);
             $('#optiontab-'+x).append("<tr id='tr-"+option_id+"-"+ov_count[option_id]+"'><td class='col-md-3'><select name='productoption["+option_id+"][option]["+ov_count[option_id]+"][option_value_id]' value='' placeholder='Option' id='optionvalue"+ov_count[option_id]+"' class='form-control optionvalue'>"+optionvalue[option_id]+"</select></td><td class='col-md-3'><input type='number' name='productoption["+option_id+"][option]["+ov_count[option_id]+"][qty]' value='0' placeholder='Quantity' id='qty"+ov_count[option_id]+"' class='form-control'></td><td class='col-md-3'><select class='form-control' name='productoption["+option_id+"][option]["+ov_count[option_id]+"][substract]' id='substract"+ov_count[option_id]+"'><option value='1'>Yes</option><option value='0'>No</option></select>{{-- <input type='number' name='productoption["+option_id+"][option]["+ov_count[option_id]+"][substract]' value='0' placeholder='Substract' id='substract"+ov_count[option_id]+"' class='form-control'> --}}</td><td class='col-md-3'><input type='text' name='productoption["+option_id+"][option]["+ov_count[option_id]+"][price]' value='0' placeholder='Price' id='price"+ov_count[option_id]+"' class='form-control'></td><td><a class='remove-select-option' data-x='"+x+"' data-y='"+ov_count[option_id]+"' style='cursor: pointer'>Remove</a></td></tr>");
             ov_count[option_id]=ov_count[option_id]+1;
        }
      
                          

        $('#addProductOption').on('click',function(){
            var option_id=$('#option').val();
            if(optionvalue[option_id]!==undefined){
                swal('Error','Option Already Exist!','error');
            }else{
                var option=$('#option option:selected').text();
                //var required=$('#required').val();
                var option_value="";
                if(option_id!=null){

                    $.get('{{ url('admin/optionvalue') }}/'+option_id+'/'+x, function(data){
                        //$('#option-value-'+x).html(data);
                        option_value=data;
                        console.log(x,option_id,option,option_value);
                        appendoption2(x,option_id,option,option_value);
                    });
                }else{
                    swal('Error!','Please Select Option Before Add Product Option!','error');
                }
            }

            
            

            
            x++;

            {{-- $('.option').select2({
                placeholder: "Choose Option...",
                ajax: {
                    url: '{{ url('admin/option/search')}}',
                    dataType: 'json',
                    data: function (params) {
                        return {
                            q: $.trim(params.term)
                        };
                    },
                    processResults: function (data) {
                        return {
                            results: data
                        };
                    },
                    cache: true
                }
            }); --}}
        });


        {{-- $(document).on("change", '.option', function(e) { 
            var data = $(this).val();
            console.log(data);
            var index = $(this).data('index');
            $.get('{{ url('admin/optionvalue') }}/'+data+'/'+index, function(data){
                $('#option-value-'+index).html(data);
            });
        }); --}}

        $(document).on("click", '.add-select-option', function(event) { 
            $x=$(this).data('x');
            $y=$(this).data('y');
            $option_id=$(this).data('option_id');
            $option=$(this).data('option');
            console.log($x,$y,$option_id,$option);
            appendmoreoption($x,$y,$option_id,$option);
        });

        $(document).on("click", '.remove-select-option', function(event) { 
            $x=$(this).data('x');
            $y=$(this).data('y');
            $('#tr-'+$x+'-'+$y).remove();
        });

        $(document).on("click", '.remove-box', function(event) { 
            $('#box-'+$(this).data('box')).remove();
        });

        $('.length-class').on('change',function(){
            $('.length-class').val($(this).val());
        });

        $("#image").change(function(){

             $('#image_preview').html("");

             var total_file=document.getElementById("image").files.length;

             for(var i=0;i<total_file;i++)

             {

              $('#image_preview').append("<div class='col-xs-2'><img src='"+URL.createObjectURL(event.target.files[i])+"' class='img-responsive'></div>");

             }

        });

        function formatData (data) {
              if (!data.id) { return data.text; }
              var $result= $(
                '<span><img src="'+data.image+'" style="max-width:25px;"/> ' + data.text + '</span>'
              );
              return $result;
            };
        
        $(document).ready(function() {
            $('.summernote').summernote({
                height: 200
            });
            $('.select2').select2();
            $("#related-product").select2({
              templateResult: formatData,
              templateSelection: formatData,
              placeholder: "Related Product...",
                ajax: {
                    url: '{{ url('admin/related-product/search')}}',
                    dataType: 'json',
                    data: function (params) {
                        return {
                            q: $.trim(params.term)
                        };
                    },
                    processResults: function (data) {
                        return {
                            results: data
                        };
                    },
                    cache: true
                }

            });
            $('.option').select2({
                placeholder: "Choose Option...",
                ajax: {
                    url: '{{ url('admin/option/search')}}',
                    dataType: 'json',
                    data: function (params) {
                        return {
                            q: $.trim(params.term)
                        };
                    },
                    processResults: function (data) {
                        return {
                            results: data
                        };
                    },
                    cache: true
                }
            });
            $( "#model" ).autocomplete({
              source: "{{ url('admin/search/model') }}",
              minLength: 1,
              select: function(event, ui) {
                $('#model').val(ui.item.value);
              }
            });
        });
    </script>

    <script type="text/javascript">
    var attribute_row = 0;

    function addAttribute() {
        html  = '<tr id="attribute-row' + attribute_row + '">';
        html += '  <td class="text-left" style="width: 20%;"><select name="product_attribute[' + attribute_row + '][name]" placeholder="Attribute" class="form-control select2" /><input type="hidden" name="product_attribute[' + attribute_row + '][attribute_id]" value="" ></select></td>';
        html += '  <td class="text-left">';
        html += '<textarea name="product_attribute[' + attribute_row + '][value]" rows="5" placeholder="Value" class="form-control"></textarea>';
        html += '  </td>';
        html += '  <td class="text-right"><button type="button" onclick="$(\'#attribute-row' + attribute_row + '\').remove();" data-toggle="tooltip" title="Remove" class="btn btn-danger"><i class="fa fa-minus-circle"></i></button></td>';
        html += '</tr>';

        $('#attribute tbody').append(html);

        attributeautocomplete(attribute_row);

        attribute_row++;
    }

    function attributeautocomplete(attribute_row) {
        $('select[name=\'product_attribute[' + attribute_row + '][name]\']').select2({
                placeholder: "Choose Attribute...",
                ajax: {
                    url: '{{ url('admin/attribute/search-attribute')}}',
                    dataType: 'json',
                    data: function (params) {
                        return {
                            q: $.trim(params.term)
                        };
                    },
                    processResults: function (data) {
                        return {
                            results: data
                        };
                    },
                    cache: true
                }
            });
    }

    $('#attribute tbody tr').each(function(index, element) {
        attributeautocomplete(index);
    });
    </script>

    <script type="text/javascript">
        var discount_row = 0;

        function addDiscount() {
            html  = '<tr id="discount-row' + discount_row + '">';
            html += '  <td class="text-left"><select name="product_discount[' + discount_row + '][customer_group_id]" class="form-control">';
                @foreach($customergroup as $key => $value)
                html += '    <option value="{{$value->id}}">{{$value->name}}</option>';
                @endforeach
                html += '  </select></td>';
            html += '  <td class="text-right"><input type="text" name="product_discount[' + discount_row + '][quantity]" value="" placeholder="Quantity" class="form-control" /></td>';
            html += '  <td class="text-right"><input type="text" name="product_discount[' + discount_row + '][priority]" value="" placeholder="Priority" class="form-control" /></td>';
            html += '  <td class="text-right"><input type="text" name="product_discount[' + discount_row + '][price]" value="" placeholder="Price" class="form-control" /></td>';
            html += '  <td class="text-left" style="width: 20%;"><input type="text" name="product_discount[' + discount_row + '][date_start]" value="" placeholder="Date Start" class="form-control datepicker" /></td>';
            html += '  <td class="text-left" style="width: 20%;"><input type="text" name="product_discount[' + discount_row + '][date_end]" value="" placeholder="Date End" class="form-control datepicker" /></td>';
            html += '  <td class="text-left"><button type="button" onclick="$(\'#discount-row' + discount_row + '\').remove();" data-toggle="tooltip" title="Remove" class="btn btn-danger"><i class="fa fa-minus-circle"></i></button></td>';
            html += '</tr>';

            $('#discount tbody').append(html);

            $('.datepicker').datetimepicker({
                timepicker:false,
                format:'d-m-Y'
            });

            discount_row++;
        }
        </script>


        <script type="text/javascript">
            var special_row = 0;

            function addSpecial() {
                html  = '<tr id="special-row' + special_row + '">';
                html += '  <td class="text-left"><select name="product_special[' + special_row + '][customer_group_id]" class="form-control">';
                    @foreach($customergroup as $key => $value)
                    html += '    <option value="{{$value->id}}">{{$value->name}}</option>';
                    @endforeach
                    html += '  </select></td>';
                html += '  <td class="text-right"><input type="text" name="product_special[' + special_row + '][priority]" value="" placeholder="Priority" class="form-control" /></td>';
                html += '  <td class="text-right"><input type="text" name="product_special[' + special_row + '][price]" value="" placeholder="Price" class="form-control" /></td>';
                html += '  <td class="text-left" style="width: 20%;"><input type="text" name="product_special[' + special_row + '][date_start]" value="" placeholder="Date Start" class="form-control datepicker" /></td>';
                html += '  <td class="text-left" style="width: 20%;"><input type="text" name="product_special[' + special_row + '][date_end]" value="" placeholder="Date End" class="form-control datepicker" /></td>';
                html += '  <td class="text-left"><button type="button" onclick="$(\'#special-row' + special_row + '\').remove();" data-toggle="tooltip" title="Remove" class="btn btn-danger"><i class="fa fa-minus-circle"></i></button></td>';
                html += '</tr>';

                $('#special tbody').append(html);

                $('.datepicker').datetimepicker({
                    timepicker:false,
                    format:'d-m-Y'
                });

                special_row++;
            }
        </script>

@endsection