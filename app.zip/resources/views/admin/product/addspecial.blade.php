<div class="tab-pane" id="tab-special">
	<div class="table-responsive">
		<table id="special" class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<td class="text-left">Customer Group</td>
					<td class="text-right">Priority</td>
					<td class="text-right">Price</td>
					<td class="text-left">Date Start</td>
					<td class="text-left">Date End</td>
					<td></td>
				</tr>
			</thead>
			<tbody>
			</tbody>
			<tfoot>
				<tr>
					<td colspan="5"></td>
					<td class="text-left">
						<button type="button" onclick="addSpecial();" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Add Special">
							<i class="fa fa-plus-circle"></i>
						</button>
					</td>
				</tr>
			</tfoot>
		</table>
	</div>
</div>