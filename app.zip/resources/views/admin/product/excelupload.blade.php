<div id="outer" class="outer">
  <div class="middle">
    <div class="inner">
      <div id="dropZone">
      	<form id="excel-import" action="{{ url('admin/product/import-with-excel') }}" method="post" enctype="multipart/form-data">
      		{{ csrf_field() }}
      	<input id="file_input" name="file_input" type='file' style='position: absolute; opacity: 0; filter: alpha(opacity = 0);'/>
    	<span style='position: absolute'>Drop Here</span>
    	</form>
      </div>
    </div>
  </div>
</div>