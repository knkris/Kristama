<div class="tab-pane" id="tab-attribute">
	<div class="table-responsive">
		<table id="attribute" class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<td class="text-left">Attribute</td>
					<td class="text-left">Text</td>
					<td></td>
				</tr>
			</thead>
			<tbody>
				@if(count(old('product_attribute'))>0)
                    @foreach(old('product_attribute') as $key => $value)
					<tr id="attribute-row{{$key}}">
						<td class="text-left" style="width: 20%;">
							<select name="product_attribute[{{$key}}][name]" placeholder="Attribute" class="form-control select2">
								<option value="{{$value['name']}}">{{ \App\Models\Attribute::find($value['name'])->name }}</option>
							</select>
						</td>
						<td class="text-left">
							<textarea name="product_attribute[{{$key}}][value]" rows="5" placeholder="Text" class="form-control">{{ $value['value'] }}</textarea>
						</td>
						<td class="text-right">
							<button type="button" onclick="$('#attribute-row{{$key}}').remove();" data-toggle="tooltip" title="Remove" class="btn btn-danger">
								<i class="fa fa-minus-circle"></i>
							</button>
						</td>
					</tr>
					@endforeach
				@else
                    @foreach($results->ProductAttribute as $key => $value)
                    <tr id="attribute-row{{$key}}">
						<td class="text-left" style="width: 20%;">
							<select name="product_attribute[{{$key}}][name]" placeholder="Attribute" class="form-control select2">
								<option value="{{$value->attribute_id}}">{{ \App\Models\Attribute::find($value->attribute_id)->name }}</option>
							</select>
						</td>
						<td class="text-left">
							<textarea name="product_attribute[{{$key}}][value]" rows="5" placeholder="Text" class="form-control">{{ $value->value }}</textarea>
						</td>
						<td class="text-right">
							<button type="button" onclick="$('#attribute-row{{$key}}').remove();" data-toggle="tooltip" title="Remove" class="btn btn-danger">
								<i class="fa fa-minus-circle"></i>
							</button>
						</td>
					</tr>
					
					@endforeach
				@endif
			</tbody>
			<tfoot>
				<tr>
					<td colspan="2"></td>
					<td class="text-right">
						<button type="button" onclick="addAttribute();" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Add Attribute">
							<i class="fa fa-plus-circle"></i>
						</button>
					</td>
				</tr>
			</tfoot>
		</table>
	</div>
</div>