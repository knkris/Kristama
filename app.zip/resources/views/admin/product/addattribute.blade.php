<div class="tab-pane" id="tab-attribute">
	<div class="table-responsive">
		<table id="attribute" class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<td class="text-left">Attribute</td>
					<td class="text-left">Text</td>
					<td></td>
				</tr>
			</thead>
			<tbody>
			</tbody>
			<tfoot>
				<tr>
					<td colspan="2"></td>
					<td class="text-right">
						<button type="button" onclick="addAttribute();" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Add Attribute">
							<i class="fa fa-plus-circle"></i>
						</button>
					</td>
				</tr>
			</tfoot>
		</table>
	</div>
</div>