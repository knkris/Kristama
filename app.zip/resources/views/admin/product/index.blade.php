@extends('layouts.admin')

@section('title')
    Product
@endsection

@section('head')
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.css"/>

    <link rel="stylesheet" type="text/css" href="{{ asset('css/excelupload.css') }}">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.min.css">
@endsection

@section('content')
    @include('admin.product.excelupload')
    <form id="form" role="form" action="{{ url('admin/product/trash') }}" class="form-horizontal" enctype="multipart/form-data" method="post">
        {{ csrf_field() }}
     <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Product
                        <div class="pull-right">
                            <button type="button" id="button-export" onclick="exportToExcel()" data-toggle="tooltip" title="" class="btn btn-info" data-original-title="Export to Excel"><i class="fa fa-file-excel-o"></i></button>
                            <a href="{{ url('admin/product/create') }}" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Add New" aria-describedby="tooltip23863">
                                <i class="fa fa-plus"></i>
                            </a> 
                            <button id="delete" type="button" data-toggle="tooltip" title="" class="btn btn-danger" data-original-title="Delete">
                                <i class="fa fa-trash-o"></i>
                            </button>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/product') }}">Product</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-list"></i> Product List
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="table">
                                <thead>
                                    <tr>
                                        <th>
                                            <input type="checkbox" onclick="$('input[name*=\'selected\']').prop('checked', this.checked);">
                                        </th>
                                        <th>Image</th>
                                        <th>Name</th>
                                        <th>Model</th>
                                        <th>Price</th>
                                        <th>Qty</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                            </table>
                            <!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-list"></i> Recommended Product
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                           <form id="form" role="form" action="{{ url('admin/product/recommended-product') }}" class="form-horizontal" enctype="multipart/form-data" method="post">
                            {{ csrf_field() }}
                            <select class="form-control" name="recommended_product[]" id="recommended-product" multiple="multiple">
                                        
                                    </select>

                                    <button type="button" onclick="updateRecommended()" class="btn btn-primary">Submit</button>
                            </form>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            
        </div>
        <!-- /#page-wrapper -->
    </form>

    @if (session('import'))
        <?php $res=session('import'); ?>
            <form id="confirm-import" method="post" action="{{ url('admin/product/confirm-import-with-excel') }}">
              {{ csrf_field() }}
              <input name="token" value="{{$res->token}}" type="hidden">
            </form>
        @endif
@endsection

@section('script')
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js"></script>

    @include('admin.product.exceluploadscript')
    <script>
        @if (session('import'))
        <?php $res=session('import'); ?>
            swal({
              title: 'Excel Import',
              type: 'info',
              html:
                'Modified Product : {{ $res->product_modified }}<br>' +
                'Modified Product Option : {{ $res->option_modified }}<br>' +
                'Modified Product Option Value : {{ $res->option_detail_modified }}<br>' +
                'New Product : {{ $res->product_new }}<br>' +
                'New Product Option : {{ $res->option_new }}<br>' +
                'New Product Option Value : {{ $res->option_detail_new }}<br>' +
                @if($res->deleted_product>0)
                'Removed Product : {{ $res->deleted_product }}' +
                @endif
                @if($res->deleted_option>0)
                'Removed Product Option : {{ $res->deleted_option }}' +
                @endif
                @if($res->deleted_option_detail>0)
                'Removed Product Option Detail : {{ $res->deleted_option_detail }}' +
                @endif
                'Total Product : {{ $res->count_product }}<br>' +
                {{-- 'Total Product Option : {{ $res->count_option }}<br>' +
                'Total Product Option Value : {{ $res->count_option_detail }}<br>' + --}}
                '<h2 class="swal2-title">Detail : </h2> ' +
                '<textarea class="form-control" disabled="disabled" rows="5" style="font-size:11px;">'+
                @foreach($res->log as $log)
                  '{{{ str_replace("\n"," ",$log) }}}\n' +
                @endforeach  
                '</textarea><br>',
              showCancelButton: true,
              focusConfirm: false,
              confirmButtonText:
                'Execute',
              cancelButtonText:
              'cancel',
              allowOutsideClick: false
            }).then((result) => {
              if (result.value) {
                $('#confirm-import').submit();
              }
            });
        @endif
        function exportToExcel()
        {
            form=document.getElementById('form');
            form.action='{{url('admin/product/export-to-excel')}}';
            form.submit();
        }
        function updateRecommended()
        {
            form=document.getElementById('form');
            form.action='{{url('admin/product/recommended-product')}}';
            form.submit();
        }
        $('#delete').on('click',function(){
            swal({
                  title: 'Are you sure?',
                  text: "You won't be able to revert this!",
                  type: 'warning',
                  showCancelButton: true,
                  confirmButtonColor: '#3085d6',
                  cancelButtonColor: '#d33',
                  confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                  if (result.value) {
                    $('#form').submit();
                  }
                })
        });

        $(document).ready(function () {
            $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax":{
                         "url": "{{ url('admin/product') }}",
                         "dataType": "json",
                         "type": "POST",
                         "data":{ _token: "{{csrf_token()}}"}
                       },
                "columns": [
                    { "data": "id",
                      "orderable": false
                    },
                    { "data": "image",
                      "orderable": false
                    },
                    { "data": "name",
                      "className": "editable"
                    },
                    { "data": "model",
                      "className": "editable"
                    },
                    { "data": "price",
                      "className": "editable"
                    },
                    { "data": "qty",
                      "className": "editable"
                    },
                    { "data": "status",
                      "className": "selectable"
                    },
                    { "data": "action",
                      "orderable": false
                    }
                ]    

            });
        });

        

        // Activate an inline edit on click of a table cell
        $('#table').on( 'click', 'tbody td.editable', function (e) {
            if(!$(this).hasClass('editing')){
                $(this).addClass('editing');
                $id=$(this).children().data('id');
                $val=$(this).children().text();
                $type=$(this).children().data('type');
                if($type==="price"){
                    $price=$(this).children().data('price');
                    $(this).html("<input type='text' class='form-control editable-box' name='val' value='"+$price+"' data-id='"+$id+"' data-type='"+$type+"'> ");
                }else{
                    $(this).html("<input type='text' class='form-control editable-box' name='val' value='"+$val+"' data-id='"+$id+"' data-type='"+$type+"'> ");
                }
                $('.editable-box').focus();
            }
        } );

        // Activate an inline edit on click of a table cell
        $('#table').on( 'click', 'tbody td.selectable', function (e) {
            if(!$(this).hasClass('editing')){
                $(this).addClass('editing');
                $id=$(this).children().data('id');
                $val=$(this).children().text();
                $type=$(this).children().data('type');
                if($val==="enabled"){
                    $(this).html("<select class='form-control selectable-box' name='val' data-id='"+$id+"' data-type='"+$type+"'><option value='1' selected>enabled</option><option value='0'>disabled</option></select> ");
                }else{
                    $(this).html("<select class='form-control selectable-box' name='val' data-id='"+$id+"' data-type='"+$type+"'><option value='1'>enabled</option><option value='0' selected>disabled</option></select> ");
                }
                $('.selectable-box').focus();
            }
        } );

        $(document).on("blur", '.editable-box', function(event) { 
            $this=$(this);
            $id=$(this).data('id');
            $val=$(this).val();
            $type=$(this).data('type');

            $(this).attr('disabled','disabled');
            $.ajax({
                url: "{{ url('admin/product') }}/"+$type+"/"+$id,
                type: "post",
                data: {
                    id: $id,
                    value: $val,
                    _token: "{{csrf_token()}}"
                } ,
                success: function (response) {
                   // you will get response from your php page (what you echo or print)                 
                   console.log(response);
                   var type=$(this).data('type');
                   console.log(response.type);
                   $newid=response.id;
                   $newname=response.name;
                   $newmodel=response.model;
                   $newprice=response.price;
                   $newqty=response.qty;
                   //$parent=$this.parent("td");
                   $this.parent("td").removeClass('editing');
                   if(type=='name'){
                       $this.parent("td").empty().html("<p data-id='"+$newid+"' data-type='name'>"+$newname+"</p>");
                   }else if(type=='model'){
                       $this.parent("td").empty().html("<p data-id='"+$newid+"' data-type='model'>"+$newmodel+"</p>");
                   }else if(type=='price'){
                    $rpprice=response.rp_price;
                       $this.parent("td").empty().html($rpprice);
                   }
                   else if(type=='qty'){
                    if($newqty>0){
                       $this.parent("td").empty().html("<span class='label label-success' data-id='"+$newid+"' data-type='qty'>"+$newqty+"</span>");
                    }else{
                       $this.parent("td").empty().html("<span class='label label-warning' data-id='"+$newid+"' data-type='qty'>"+$newqty+"</span>");
                    }
                   }
                   //swal('Success!', response.name+" price updated", 'success');
                   
                }.bind($this),
                error: function(jqXHR, textStatus, errorThrown) {
                   console.log(jqXHR, textStatus, errorThrown);
                   swal('Error!', jqXHR.responseJSON.errors.value[0], 'error');
                   $(this).removeAttr('disabled');

                }.bind($this)
            });


        });

        $(document).on("keypress", '.editable-box', function(event) { 
            if(event.which == 13) {
                $this=$(this);
                $id=$(this).data('id');
                $val=$(this).val();
                $type=$(this).data('type');

                $(this).attr('disabled','disabled');
                $.ajax({
                    url: "{{ url('admin/product') }}/"+$type+"/"+$id,
                    type: "post",
                    data: {
                        id: $id,
                        value: $val,
                        _token: "{{csrf_token()}}"
                    } ,
                    success: function (response) {
                       // you will get response from your php page (what you echo or print)                 
                       console.log(response);
                       var type=$(this).data('type');
                       console.log(response.type);
                       $newid=response.id;
                       $newname=response.name;
                       $newmodel=response.model;
                       $newprice=response.price;
                       $newqty=response.qty;
                       //$parent=$this.parent("td");
                       $this.parent("td").removeClass('editing');
                       if(type=='name'){
                           $this.parent("td").empty().html("<p data-id='"+$newid+"' data-type='name'>"+$newname+"</p>");
                       }else if(type=='model'){
                           $this.parent("td").empty().html("<p data-id='"+$newid+"' data-type='model'>"+$newmodel+"</p>");
                       }else if(type=='price'){
                        $rpprice=response.rp_price;
                           $this.parent("td").empty().html($rpprice);
                       }
                       else if(type=='qty'){
                        if($newqty>0){
                           $this.parent("td").empty().html("<span class='label label-success' data-id='"+$newid+"' data-type='qty'>"+$newqty+"</span>");
                        }else{
                           $this.parent("td").empty().html("<span class='label label-warning' data-id='"+$newid+"' data-type='qty'>"+$newqty+"</span>");
                        }
                       }
                       //swal('Success!', response.name+" price updated", 'success');
                       
                    }.bind($this),
                    error: function(jqXHR, textStatus, errorThrown) {
                       console.log(jqXHR, textStatus, errorThrown);
                       swal('Error!', jqXHR.responseJSON.errors.value[0], 'error');
                       $(this).removeAttr('disabled');

                    }.bind($this)
                });
            }
        });

        $(document).on("change", '.selectable-box', function(event) { 
            $this=$(this);
            $id=$(this).data('id');
            $val=$(this).val();
            $type=$(this).data('type');

            $(this).attr('disabled','disabled');
            $.ajax({
                url: "{{ url('admin/product') }}/"+$type+"/"+$id,
                type: "post",
                data: {
                    id: $id,
                    value: $val,
                    _token: "{{csrf_token()}}"
                } ,
                success: function (response) {
                   // you will get response from your php page (what you echo or print)                 
                   console.log(response);
                   var type=$(this).data('type');
                   console.log(response.type);
                   $newid=response.id;
                   $newname=response.name;
                   $newmodel=response.model;
                   $newprice=response.price;
                   $newqty=response.qty;
                   $newstatus=response.html_status;
                   //$parent=$this.parent("td");
                   $this.parent("td").removeClass('editing');
                   $this.parent("td").empty().html($newstatus);
                    {{-- if($newstatus==1){
                       $this.parent("td").empty().html("enabled");
                    }else{
                       $this.parent("td").empty().html("disabled");
                    } --}}
                   //swal('Success!', response.name+" price updated", 'success');
                }.bind($this),
                error: function(jqXHR, textStatus, errorThrown) {
                   console.log(jqXHR, textStatus, errorThrown);
                   swal('Error!', jqXHR.responseJSON.errors.value[0], 'error');
                   $(this).removeAttr('disabled');

                }.bind($this)
            });


        });
        function formatData (data) {
              if (!data.id) { return data.text; }
              var $result= $(
                '<span><img src="'+data.image+'" style="max-width:25px;"/> ' + data.text + '</span>'
              );
              return $result;
            };

        function processData(data) {
          var mapdata = $.map(data, function (obj) {      
            obj.id = obj.id;
            obj.image = obj.image;
            obj.text = obj.text;
            return obj;
          });
          console.log(mapdata)
          return { results: mapdata }; 
        }

        $("#recommended-product").select2({
              templateResult: formatData,
              templateSelection: formatData,
              placeholder: "Recommended Product...",
                ajax: {
                    url: '{{ url('admin/recommended-product/search')}}',
                    dataType: 'json',
                    data: function (params) {
                        return {
                            q: $.trim(params.term)
                        };
                    },
                    processResults: processData,
                    cache: true
                },
                @if(count($recommended)>0)
                data: processData([
                    
                        @foreach($recommended as $val)
                        <?php
                        $bi=\App\Models\Product::find($val->product_id);
                        ?>
                        @if($loop->last)
                        { "id": "{{$bi->id}}", "image": "{{$bi->Image ? $bi->Image->first()->image : ''}}", "text": "{{$bi->name}}", "selected": true }
                        @else
                        { "id": "{{$bi->id}}", "image": "{{$bi->Image ? $bi->Image->first()->image : ''}}", "text": "{{$bi->name}}", "selected": true },
                        @endif
                        @endforeach
                    ]).results
                @endif

            });
    </script>
@endsection