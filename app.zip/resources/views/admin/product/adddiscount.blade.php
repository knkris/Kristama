<div class="tab-pane" id="tab-discount">
	<div class="table-responsive">
		<table id="discount" class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<td class="text-left">Customer Group</td>
					<td class="text-right">Quantity</td>
					<td class="text-right">Priority</td>
					<td class="text-right">Price</td>
					<td class="text-left">Date Start</td>
					<td class="text-left">Date End</td>
					<td></td>
				</tr>
			</thead>
			<tbody>
				
			</tbody>
			<tfoot>
				<tr>
					<td colspan="6"></td>
					<td class="text-left">
						<button type="button" onclick="addDiscount();" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Add Discount">
							<i class="fa fa-plus-circle"></i>
						</button>
					</td>
				</tr>
			</tfoot>
		</table>
	</div>
</div>