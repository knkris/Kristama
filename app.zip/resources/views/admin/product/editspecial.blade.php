<div class="tab-pane" id="tab-special">
	<div class="table-responsive">
		<table id="special" class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<td class="text-left">Customer Group</td>
					<td class="text-right">Priority</td>
					<td class="text-right">Price</td>
					<td class="text-left">Date Start</td>
					<td class="text-left">Date End</td>
					<td></td>
				</tr>
			</thead>
			<tbody>
				@if(count(old('product_special'))>0)
                    @foreach(old('product_special') as $key => $value)
					<tr id="discount-row{{$key}}">
						<td class="text-left">
							<select name="product_special[{{$key}}][customer_group_id]" class="form-control">
								<option value="1" selected="selected">Default</option>
							</select>
						</td>
						<td class="text-right">
							<input type="text" name="product_special[{{$key}}][priority]" value="{{ $value['priority'] }}" placeholder="Priority" class="form-control">
						</td>
						<td class="text-right">
							<input type="text" name="product_special[{{$key}}][price]" value="{{ $value['price'] }}" placeholder="Price" class="form-control">
						</td>
						<td class="text-left" style="width: 20%;">
							<input type="text" name="product_special[{{$key}}][date_start]" value="{{ $value['date_start'] }}" placeholder="Date Start" class="form-control datepicker">
						</td>
						<td class="text-left" style="width: 20%;">
							<input type="text" name="product_special[{{$key}}][date_end]" value="{{ $value['date_end'] }}" placeholder="Date End" class="form-control datepicker">
						</td>
						<td class="text-left">
							<button type="button" onclick="$('#discount-row{{$key}}').remove();" data-toggle="tooltip" title="" class="btn btn-danger" data-original-title="Remove">
								<i class="fa fa-minus-circle"></i>
							</button>
						</td>
					</tr>
					@endforeach
				@else
                    @foreach($results->ProductDiscount as $key => $value)
					<tr id="discount-row{{$key}}">
						<td class="text-left">
							<select name="product_special[{{$key}}][customer_group_id]" class="form-control">
								<option value="1" selected="selected">Default</option>
							</select>
						</td>
						<td class="text-right">
							<input type="text" name="product_special[{{$key}}][priority]" value="{{ $value->priority }}" placeholder="Priority" class="form-control">
						</td>
						<td class="text-right">
							<input type="text" name="product_special[{{$key}}][price]" value="{{ $value->price }}" placeholder="Price" class="form-control">
						</td>
						<td class="text-left" style="width: 20%;">
							<input type="text" name="product_special[{{$key}}][date_start]" value="{{ $value->start ? \Carbon\Carbon::parse($value->start)->format('d-m-Y') : ''}}" placeholder="Date Start" class="form-control datepicker">
						</td>
						<td class="text-left" style="width: 20%;">
							<input type="text" name="product_special[{{$key}}][date_end]" value="{{ $value->start ? \Carbon\Carbon::parse($value->end)->format('d-m-Y') : '' }}" placeholder="Date End" class="form-control datepicker">
						</td>
						<td class="text-left">
							<button type="button" onclick="$('#discount-row{{$key}}').remove();" data-toggle="tooltip" title="" class="btn btn-danger" data-original-title="Remove">
								<i class="fa fa-minus-circle"></i>
							</button>
						</td>
					</tr>
					@endforeach
				@endif
			</tbody>
			<tfoot>
				<tr>
					<td colspan="5"></td>
					<td class="text-left">
						<button type="button" onclick="addSpecial();" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Add Special">
							<i class="fa fa-plus-circle"></i>
						</button>
					</td>
				</tr>
			</tfoot>
		</table>
	</div>
</div>