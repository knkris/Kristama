@extends('layouts.admin')

@section('title')
    Edit Voucher Theme
@endsection

@section('head')
    <!-- include summernote css/js-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.min.css">

    <style type="text/css">
        textarea {
            overflow-x: hidden;
        }
    </style>
@endsection

@section('content')
     <div id="page-wrapper">
        <form role="form" action="{{ url('admin/voucher-theme/edit/'.$results->id) }}" class="form-horizontal" enctype="multipart/form-data" method="post">
            {{ csrf_field() }}
            {!! Form::hidden('url',url('upload_image'), array('class'=>'url') ) !!}
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Edit Voucher Theme
                        <div class="pull-right">
                            <button type="submit" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Save" aria-describedby="tooltip815756">
                                <i class="fa fa-save"></i>
                            </button>
                            <a href="{{ url('admin/voucher-theme') }}" class="btn btn-default" data-original-title="Cancel">
                                <i class="fa fa-reply"></i>
                            </a>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/voucher-theme') }}">Voucher Theme</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-pencil"></i> Edit Voucher Theme
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">                            
                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="name">
                                    Voucher Theme Name
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" name="name" value="{{ $results->name }}" placeholder="Voucher Theme Name" id="name" class="form-control">
                                </div>
                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="image">
                                    Image
                                </label>
                                @if($results->image==null)
                                <div class="col-sm-10">
                                    <input type="file" name="image" value="{{ old('image') }}" id="image" class="form-control">
                                </div>
                                @else
                                    <a href="{{ url('admin/voucher-theme/delete-image/'.$results->id) }}">
                                        <img src="{{ $results->image }}" style="width:100px;height:auto;">
                                    </a> 
                                @endif
                                @if ($errors->has('image'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('image') }}</strong>
                                    </span>
                                @endif
                            </div>

                            
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            </form>
        </div>
        <!-- /#page-wrapper -->
@endsection

@section('script')
    <!-- include summernote css/js-->
    <script src="{{ asset('js/summernote.js') }}"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.summernote').summernote({
                height: 200
            });
            $('.select2').select2();
        });
    </script>
@endsection