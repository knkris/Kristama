@extends('layouts.admin')

@section('title')
    Attribute
@endsection

@section('head')
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.css"/>
@endsection

@section('content')
    <form id="form" role="form" action="{{ url('admin/attribute/trash') }}" class="form-horizontal" enctype="multipart/form-data" method="post">
        {{ csrf_field() }}
     <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Attribute
                        <div class="pull-right">
                            <a href="{{ url('admin/attribute/create') }}" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Add New" aria-describedby="tooltip23863">
                                <i class="fa fa-plus"></i>
                            </a> 
                            <button id="delete" type="button" data-toggle="tooltip" title="" class="btn btn-danger" data-original-title="Delete">
                                <i class="fa fa-trash-o"></i>
                            </button>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/attribute') }}">Attribute</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-list"></i> Attribute List
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="table">
                                <thead>
                                    <tr>
                                        <th>
                                            <input type="checkbox" onclick="$('input[name*=\'selected\']').prop('checked', this.checked);">
                                        </th>
                                        <th>Name</th>
                                        <th>Attribute Group</th>
                                        <th>Sort Order</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                            </table>
                            <!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            
        </div>
        <!-- /#page-wrapper -->
    </form>
@endsection

@section('script')
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.js"></script>

    <script>
        $('#delete').on('click',function(){
            swal({
                  title: 'Are you sure?',
                  text: "You won't be able to revert this!",
                  type: 'warning',
                  showCancelButton: true,
                  confirmButtonColor: '#3085d6',
                  cancelButtonColor: '#d33',
                  confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                  if (result.value) {
                    $('#form').submit();
                  }
                })
        });

        $(document).ready(function () {
            $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax":{
                         "url": "{{ url('admin/attribute') }}",
                         "dataType": "json",
                         "type": "POST",
                         "data":{ _token: "{{csrf_token()}}"}
                       },
                "columns": [
                    { "data": "id",
                      "orderable": false
                    },
                    { "data": "name" },
                    { "data": "attribute_group" },
                    { "data": "sort_order" },
                    { "data": "action",
                      "orderable": false
                    }
                ]    

            });
        });
    </script>
@endsection