@extends('layouts.admin')

@section('title')
    Add Customer
@endsection

@section('head')
    <!-- include summernote css/js-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.min.css">

    <style type="text/css">
        textarea {
            overflow-x: hidden;
        }
    </style>
@endsection

@section('content')
     <div id="page-wrapper">
        <form role="form" action="{{ url('admin/customer/store') }}" class="form-horizontal" enctype="multipart/form-data" method="post">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Add Customer
                        <div class="pull-right">
                            <button type="submit" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Save" aria-describedby="tooltip815756">
                                <i class="fa fa-save"></i>
                            </button>
                            <a href="{{ url('admin/customer') }}" class="btn btn-default" data-original-title="Cancel">
                                <i class="fa fa-reply"></i>
                            </a>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/customer') }}">Customer</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">
                                <i class="fa fa-pencil"></i> Add Customer
                            </h3>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-sm-2">
                                    <ul class="nav nav-pills nav-stacked" id="address">
                                        <li>
                                            <a href="#tab-customer" data-toggle="tab" aria-expanded="false">
                                                General
                                            </a>
                                        </li>
                                    @if(count(old('address'))>0)
                                        @foreach(old('address') as $key => $value)
                                        <li>
                                            <a href="#tab-address{{$key}}" data-toggle="tab" aria-expanded="true">
                                                <i class="fa fa-minus-circle" onclick="$('#address a:first').tab('show'); $('a[href=\'#tab-address{{$key}}\']').parent().remove(); $('#tab-address1').remove();"></i> Address 1
                                            </a>
                                        </li>
                                        @endforeach
                                    @endif
                                        <li id="address-add">
                                            <a onclick="addAddress();">
                                                <i class="fa fa-plus-circle"></i> Add Address
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-sm-10">
                                    <div class="tab-content">
                                        <div class="tab-pane active" id="tab-customer">
                                            <fieldset>
                                                <legend>Customer Details</legend>
                                                <div class="form-group {{ $errors->has('customer_group_id') ? ' has-error' : '' }}">
                                                    <label class="col-sm-2 control-label" for="input-customer-group">
                                                        Customer Group
                                                    </label>
                                                    <div class="col-sm-10">
                                                        <select name="customer_group_id" id="input-customer-group" class="form-control">
                                                            @foreach($customergroup as $val)
                                                            <option value="{{$val->id}}" @if(old('customer_group_id')==$val->id) selected="selected" @endif>{{$val->name}}</option>
                                                            @endforeach
                                                        </select>
                                                        @if ($errors->has('customer_group_id'))
                                                            <span class="help-block">
                                                                <strong>{{ $errors->first('customer_group_id') }}</strong>
                                                            </span>
                                                        @endif
                                                    </div>
                                                </div>

                                                <div class="form-group required {{ $errors->has('name') ? ' has-error' : '' }}">
                                                    <label class="col-sm-2 control-label" for="input-name">Name</label>
                                                    <div class="col-sm-10">
                                                        <input type="text" name="name" value="{{ old('name') }}" placeholder="Name" id="input-name" class="form-control">
                                                        @if ($errors->has('name'))
                                                            <span class="help-block">
                                                                <strong>{{ $errors->first('name') }}</strong>
                                                            </span>
                                                        @endif
                                                    </div>
                                                </div>

                                                
                                                <div class="form-group required {{ $errors->has('email') ? ' has-error' : '' }}">
                                                    <label class="col-sm-2 control-label" for="input-email">E-Mail</label>
                                                    <div class="col-sm-10">
                                                        <input type="text" name="email" value="{{ old('email') }}" placeholder="E-Mail" id="input-email" class="form-control">
                                                        @if ($errors->has('email'))
                                                            <span class="help-block">
                                                                <strong>{{ $errors->first('email') }}</strong>
                                                            </span>
                                                        @endif
                                                    </div>
                                                </div>

                                                <div class="form-group required {{ $errors->has('telephone') ? ' has-error' : '' }}">
                                                    <label class="col-sm-2 control-label" for="input-telephone">Telephone</label>
                                                    <div class="col-sm-10">
                                                        <input type="text" name="telephone" value="{{ old('telephone') }}" placeholder="Telephone" id="input-telephone" class="form-control">
                                                        @if ($errors->has('telephone'))
                                                            <span class="help-block">
                                                                <strong>{{ $errors->first('telephone') }}</strong>
                                                            </span>
                                                        @endif
                                                    </div>
                                                </div>
                                            </fieldset>
                                            <fieldset>
                                                <legend>Password</legend>
                                                <div class="form-group required {{ $errors->has('password') ? ' has-error' : '' }}">
                                                    <label class="col-sm-2 control-label" for="input-password">Password</label>
                                                    <div class="col-sm-10">
                                                        <input type="password" name="password" value="" placeholder="Password" id="input-password" class="form-control" autocomplete="off">
                                                        @if ($errors->has('password'))
                                                            <span class="help-block">
                                                                <strong>{{ $errors->first('password') }}</strong>
                                                            </span>
                                                        @endif
                                                    </div>
                                                </div>

                                                <div class="form-group required {{ $errors->has('password_confirmation') ? ' has-error' : '' }}">
                                                    <label class="col-sm-2 control-label" for="input-confirm">Confirm</label>
                                                    <div class="col-sm-10">
                                                        <input type="password" name="password_confirmation" value="" placeholder="Confirm" autocomplete="off" id="input-confirm" class="form-control">
                                                        @if ($errors->has('password_confirmation'))
                                                            <span class="help-block">
                                                                <strong>{{ $errors->first('password_confirmation') }}</strong>
                                                            </span>
                                                        @endif
                                                    </div>
                                                </div>
                                            </fieldset>
                                            <fieldset>
                                                <legend>Other</legend>
                                                <div class="form-group {{ $errors->has('newsletter') ? ' has-error' : '' }}">
                                                    <label class="col-sm-2 control-label" for="input-newsletter">Newsletter</label>
                                                    <div class="col-sm-10">
                                                        <select name="newsletter" id="input-newsletter" class="form-control">
                                                            <option value="1" @if(old('newsletter')==1) selected="selected" @endif>Enabled</option>
                                                            <option value="0" @if(old('newsletter')==0) selected="selected" @elseif(strlen(old('newsletter'))==0) selected="selected" @endif>Disabled</option>
                                                        </select>
                                                        @if ($errors->has('newsletter'))
                                                            <span class="help-block">
                                                                <strong>{{ $errors->first('newsletter') }}</strong>
                                                            </span>
                                                        @endif
                                                    </div>
                                                </div>

                                                <div class="form-group {{ $errors->has('status') ? ' has-error' : '' }}">
                                                    <label class="col-sm-2 control-label" for="input-status">Status</label>
                                                    <div class="col-sm-10">
                                                        <select name="status" id="input-status" class="form-control">
                                                            <option value="1" @if(old('status')==1) selected="selected" @elseif(strlen(old('status'))==0) selected="selected" @endif>Enabled</option>
                                                            <option value="0" @if(old('status')==0) selected="selected" @endif>Disabled</option>
                                                        </select>
                                                        @if ($errors->has('status'))
                                                            <span class="help-block">
                                                                <strong>{{ $errors->first('status') }}</strong>
                                                            </span>
                                                        @endif
                                                    </div>
                                                </div>

                                                <div class="form-group {{ $errors->has('safe') ? ' has-error' : '' }}">
                                                    <label class="col-sm-2 control-label" for="input-safe">Safe</label>
                                                    <div class="col-sm-10">
                                                        <select name="safe" id="input-safe" class="form-control">
                                                            <option value="1"  @if(old('safe')==1) selected="selected" @endif>Yes</option>
                                                            <option value="0" @if(old('safe')==0) selected="selected" @elseif(strlen(old('safe'))==0) selected="selected" @endif>No</option>
                                                        </select>
                                                        @if ($errors->has('safe'))
                                                            <span class="help-block">
                                                                <strong>{{ $errors->first('safe') }}</strong>
                                                            </span>
                                                        @endif
                                                    </div>
                                                </div>
                                            </fieldset>
                                        </div>

                                    @if(count(old('address'))>0)
                                        @foreach(old('address') as $key => $value)
                                        <div class="tab-pane" id="tab-address{{$key}}">
                                            <input type="hidden" name="address[{{$key}}][address_id]" value="">
                                            <div class="form-group required {{ $errors->has('address.'.$key.'.name') ? ' has-error' : '' }}">
                                                <label class="col-sm-2 control-label" for="input-name{{$key}}">
                                                    Name
                                                </label>
                                                <div class="col-sm-10">
                                                    <input type="text" name="address[{{$key}}][name]" value="{{ $value['name'] }}" placeholder="Name" id="input-name{{$key}}" class="form-control">
                                                </div>
                                                @if ($errors->has('address.'.$key.'.name'))
                                                    <span class="help-block">
                                                        <strong>{{ $errors->first('address.'.$key.'.name') }}</strong>
                                                    </span>
                                                @endif
                                            </div>

                                            <div class="form-group {{ $errors->has('address.'.$key.'.company') ? ' has-error' : '' }}">
                                                <label class="col-sm-2 control-label" for="input-company{{$key}}">
                                                    Company
                                                </label>
                                                <div class="col-sm-10">
                                                    <input type="text" name="address[{{$key}}][company]" value="{{ $value['company'] }}" placeholder="Company" id="input-company{{$key}}" class="form-control">
                                                    @if ($errors->has('address.'.$key.'.company'))
                                                        <span class="help-block">
                                                            <strong>{{ $errors->first('address.'.$key.'.company') }}</strong>
                                                        </span>
                                                    @endif
                                                </div>
                                            </div>

                                            <div class="form-group required {{ $errors->has('address.'.$key.'.address') ? ' has-error' : '' }}">
                                                <label class="col-sm-2 control-label" for="input-address{{$key}}">
                                                    Address
                                                </label>
                                                <div class="col-sm-10">
                                                    <textarea name="address[{{$key}}][address]" placeholder="Address" id="input-address{{$key}}" class="form-control">{{ $value['address'] }}</textarea>
                                                    @if ($errors->has('address.'.$key.'.address'))
                                                        <span class="help-block">
                                                            <strong>{{ $errors->first('address.'.$key.'.address') }}</strong>
                                                        </span>
                                                    @endif
                                                </div>
                                            </div>

                                            <div class="form-group required {{ $errors->has('address.'.$key.'.city') ? ' has-error' : '' }}">
                                                <label class="col-sm-2 control-label" for="input-city{{$key}}">
                                                    City
                                                </label>
                                                <div class="col-sm-10">
                                                    <select name="address[{{$key}}][city]" value="" placeholder="City" id="input-city{{$key}}" class="form-control city"></select>
                                                    @if ($errors->has('address.'.$key.'.city'))
                                                        <span class="help-block">
                                                            <strong>{{ $errors->first('address.'.$key.'.city') }}</strong>
                                                        </span>
                                                    @endif
                                                </div>
                                            </div>

                                            <div class="form-group required {{ $errors->has('address.'.$key.'.postcode') ? ' has-error' : '' }}">
                                                <label class="col-sm-2 control-label" for="input-postcode{{$key}}">
                                                    Postcode
                                                </label>
                                                <div class="col-sm-10">
                                                    <input type="text" name="address[{{$key}}][postcode]" value="{{ $value['postcode'] }}" placeholder="Postcode" id="input-postcode{{$key}}" class="form-control">
                                                    @if ($errors->has('address.'.$key.'.postcode'))
                                                        <span class="help-block">
                                                            <strong>{{ $errors->first('address.'.$key.'.postcode') }}</strong>
                                                        </span>
                                                    @endif
                                                </div>
                                            </div>

                                            <div class="form-group required {{ $errors->has('address.'.$key.'.telephone') ? ' has-error' : '' }}">
                                                <label class="col-sm-2 control-label" for="input-telephone{{$key}}">
                                                    Telephone
                                                </label>
                                                <div class="col-sm-10">
                                                    <input type="text" name="address[{{$key}}][telephone]" value="{{ $value['telephone'] }}" placeholder="Telephone" id="input-telephone{{$key}}" class="form-control">
                                                    <div class="{{ $errors->has('address.'.$key.'.telephone') ? ' has-error' : '' }}">
                                                      <div class="checkbox">
                                                        <label>
                                                          <input type="checkbox" id="checkbox-telephone{{$key}}" class="checkbox-telephone" data-key="{{$key}}" value="1">
                                                          Use User Telephone
                                                        </label>
                                                      </div>
                                                    </div>
                                                    @if ($errors->has('address.'.$key.'.telephone'))
                                                        <span class="help-block">
                                                            <strong>{{ $errors->first('address.'.$key.'.telephone') }}</strong>
                                                        </span>
                                                    @endif
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label class="col-sm-2 control-label">
                                                    Default Address
                                                </label>
                                                <div class="col-sm-10">
                                                    <label class="radio">
                                                        <input type="radio" name="address[{{$key}}][default]" value="1" @if(array_key_exists('default',$value)) @if($value['default']==1) checked="checked" @endif @endif>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        @endforeach
                                    @endif
                                        
                                </div>
                            </div>

                        </div>
            
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            </form>
        </div>
        <!-- /#page-wrapper -->
@endsection

@section('script')
    <!-- include summernote css/js-->
    <script src="{{ asset('js/summernote.js') }}"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.full.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.summernote').summernote({
                height: 200
            });
        });

        var address_row = {{ old('address') ? count(old('address')) : 1 }};

        function reinit(a){
            console.log(a);
            $(a).select2({
                    placeholder: "Choose city...",
                    ajax: {
                        url: '{{ url('admin/user/search-city')}}',
                        dataType: 'json',
                        quietMillis: 1000,
                        data: function (params) {
                            return {
                                q: $.trim(params.term)
                            };
                        },
                        processResults: function (data) {
                            return {
                                results: data
                            };
                        },
                        cache: true
                    }
                });
            $('.checkbox-telephone').on('click', function(){
                $key=$(this).data('key');
                $tel=$('#input-telephone').val();
                $('#input-telephone'+ $key).val($tel);
            });
        }


  function addAddress() {
    html  = '<div class="tab-pane" id="tab-address' + address_row + '">';
    html += '  <input type="hidden" name="address[' + address_row + '][address_id]" value="" />';

    html += '  <div class="form-group required">';
    html += '    <label class="col-sm-2 control-label" for="input-name' + address_row + '">Name</label>';
    html += '    <div class="col-sm-10"><input type="text" name="address[' + address_row + '][name]" value="" placeholder="Name" id="input-name' + address_row + '" class="form-control" /></div>';
    html += '  </div>';

    html += '  <div class="form-group">';
    html += '    <label class="col-sm-2 control-label" for="input-company' + address_row + '">Company</label>';
    html += '    <div class="col-sm-10"><input type="text" name="address[' + address_row + '][company]" value="" placeholder="Company" id="input-company' + address_row + '" class="form-control" /></div>';
    html += '  </div>';

    html += '  <div class="form-group required">';
    html += '    <label class="col-sm-2 control-label" for="input-address' + address_row + '">Address</label>';
    html += '    <div class="col-sm-10"><textarea name="address[' + address_row + '][address]" placeholder="Address" id="input-address' + address_row + '" class="form-control" /></textarea></div>';
    html += '  </div>';

    html += '  <div class="form-group required">';
    html += '    <label class="col-sm-2 control-label" for="input-city' + address_row + '">City</label>';
    html += '    <div class="col-sm-10"><select name="address[' + address_row + '][city]" value="" placeholder="City" id="input-city' + address_row + '" class="form-control city" /></select></div>';
    html += '  </div>';

    html += '  <div class="form-group required">';
    html += '    <label class="col-sm-2 control-label" for="input-postcode' + address_row + '">Postcode</label>';
    html += '    <div class="col-sm-10"><input type="text" name="address[' + address_row + '][postcode]" value="" placeholder="Postcode" id="input-postcode' + address_row + '" class="form-control" /></div>';
    html += '  </div>';

    html += '  <div class="form-group required">';
    html += '    <label class="col-sm-2 control-label" for="input-telephone' + address_row + '">Telephone</label>';
    html += '    <div class="col-sm-10"><input type="text" name="address[' + address_row + '][telephone]" value="" placeholder="Telephone" id="input-telephone' + address_row + '" class="form-control" />';
    html +='<div class=""> <div class="checkbox">';
    html +='    <label> <input type="checkbox" id="checkbox-telephone' + address_row + '"  class="checkbox-telephone" data-key="' + address_row + '" value="1">  Use User Telephone  </label> </div> </div>';
    html +=' </div>';
    html += '  </div>';

    

    // Custom Fields
    
    html += '  <div class="form-group">';
    html += '    <label class="col-sm-2 control-label">Default Address</label>';
    html += '    <div class="col-sm-10"><label class="radio"><input type="radio" name="address[' + address_row + '][default]" value="1" /></label></div>';
    html += '  </div>';

    html += '</div>';

    $('.tab-content').append(html);

    $('select[name=\'customer_group_id\']').trigger('change');

    $('select[name=\'address[' + address_row + '][country_id]\']').trigger('change');

    $('#address-add').before('<li><a href="#tab-address' + address_row + '" data-toggle="tab"><i class="fa fa-minus-circle" onclick="$(\'#address a:first\').tab(\'show\'); $(\'a[href=\\\'#tab-address' + address_row + '\\\']\').parent().remove(); $(\'#tab-address' + address_row + '\').remove();"></i> Address ' + address_row + '</a></li>');

    $('#address a[href=\'#tab-address' + address_row + '\']').tab('show');


    $('#tab-address' + address_row + ' .form-group[data-sort]').detach().each(function() {
        if ($(this).attr('data-sort') >= 0 && $(this).attr('data-sort') <= $('#tab-address' + address_row + ' .form-group').length) {
            $('#tab-address' + address_row + ' .form-group').eq($(this).attr('data-sort')).before(this);
        }
        
        if ($(this).attr('data-sort') > $('#tab-address' + address_row + ' .form-group').length) {
            $('#tab-address' + address_row + ' .form-group:last').after(this);
        }
        
        if ($(this).attr('data-sort') < -$('#tab-address' + address_row + ' .form-group').length) {
            $('#tab-address' + address_row + ' .form-group:first').before(this);
        }
    });

    //setInterval(reinit('#input-city'+address_row), 5000);

    address_row++;
  }
  $(document).on('shown.bs.tab', 'a[data-toggle="tab"]', function (e) {
    var tab = $(e.target);
    var contentId = tab.attr("href");
    reinit('#input-city'+address_row);

});

    </script>
@endsection