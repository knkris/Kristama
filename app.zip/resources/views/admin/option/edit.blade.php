@extends('layouts.admin')

@section('title')
    Edit Option
@endsection

@section('head')
    <!-- include summernote css/js-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.min.css">

    <style type="text/css">
        textarea {
            overflow-x: hidden;
        }
    </style>
@endsection

@section('content')
     <div id="page-wrapper">
        <form role="form" action="{{ url('admin/option/edit/'.$results->id) }}" class="form-horizontal" enctype="multipart/form-data" method="post">
            {{ csrf_field() }}
            {!! Form::hidden('url',url('upload_image'), array('class'=>'url') ) !!}
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Edit Option
                        <div class="pull-right">
                            <button type="submit" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Save" aria-describedby="tooltip815756">
                                <i class="fa fa-save"></i>
                            </button>
                            <a href="{{ url('admin/option') }}" class="btn btn-default" data-original-title="Cancel">
                                <i class="fa fa-reply"></i>
                            </a>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/option') }}">Option</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-pencil"></i> Edit Option
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">                            
                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="name">
                                    Option Name
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" name="name" value="{{ $results->name }}" placeholder="Option Name" id="name" class="form-control">
                                </div>
                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <?php /*<div class="form-group required">
                                <label class="col-sm-2 control-label" for="type">
                                    type
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control select2" name="type" id="type">
                                        <option value="select" @if(old('type')=='select') selected @endif>{{ $cat->name }}</option>
                                    </select>
                                </div>
                                @if ($errors->has('type'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('type') }}</strong>
                                    </span>
                                @endif
                            </div>*/ ?>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="required">
                                    Required
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="required" id="required">
                                        <option value="1" @if($results->required=='1') selected @endif>Yes</option>
                                        <option value="0" @if($results->required=='0') selected @endif>No</option>
                                    </select>
                                </div>
                                @if ($errors->has('required'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('required') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="sort_order">
                                    Sort Order
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" name="sort_order" value="{{ $results->sort_order }}" placeholder="Sort Order" id="sort_order" class="form-control">
                                </div>
                                @if ($errors->has('sort_order'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('sort_order') }}</strong>
                                    </span>
                                @endif
                            </div>

                            
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Edit Option Value
                        <div class="pull-right">
                            <button type="button" id="addOptionValue" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Save" aria-describedby="tooltip815756">
                                Add Option Value
                            </button>
                        </div>
                    </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <div id="container-col">
                <?php $optionvalue=$results->OptionValue;$count=count($optionvalue); ?>
                @if($count>0)
                    @foreach($optionvalue as $key=>$val)
                    <div id="box-{{$key}}" class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <i class="fa fa-pencil"></i> Edit Option Value
                                    <div class="pull-right">
                                        <a class="remove-box" data-box="{{$key}}">X</a>
                                    </div>
                                </div>
                                <!-- /.panel-heading -->
                                <div class="panel-body">                            
                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="name{{$key}}">
                                            Option Name
                                        </label>
                                        <div class="col-sm-10">
                                            <input type="text" name="optionvalue[{{$val->id}}][name]" value="{{ $val->name }}" placeholder="Option Name" id="name{{$key}}" class="form-control">
                                        </div>
                                        @if ($errors->has(old("optionvalue[".$val->id."]['name']")))
                                            <span class="help-block">
                                                <strong>{{ $errors->first("optionvalue[".$val->id."]['name']") }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    

                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="sort_order{{$val->id}}">
                                            Sort Order
                                        </label>
                                        <div class="col-sm-10">
                                            <input type="text" name="optionvalue[{{$val->id}}][sort_order]" value="{{ $val->sort_order }}" placeholder="Sort Order" id="sort_order{{$val->id}}" class="form-control">
                                        </div>
                                        @if ($errors->has("optionvalue[".$val->id."]['sort_order']"))
                                            <span class="help-block">
                                                <strong>{{ $errors->first("optionvalue[".$val->id."]['sort_order']") }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    
                                    
                                </div>
                                <!-- /.panel-body -->
                            </div>
                            <!-- /.panel -->
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                    @endforeach
                @endif
            </div>

            </form>
        </div>
        <!-- /#page-wrapper -->
@endsection

@section('script')
    <!-- include summernote css/js-->
    <script src="{{ asset('js/summernote.js') }}"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js"></script>
    <script>

        var x={{$count}};
        $('#addOptionValue').on('click',function(){
            $('#container-col').append("<div id='box-"+x+"' class='row'><div class='col-lg-12'><div class='panel panel-default'><div class='panel-heading'><i class='fa fa-pencil'></i> Add Option Value<div class='pull-right'><a class='remove-box' data-box='"+x+"'>X</a></div></div><div class='panel-body'><div class='form-group required'><label class='col-sm-2 control-label' for='name"+x+"'>Option Name</label><div class='col-sm-10'><input type='text' name='optionvalue["+x+"][name]' value='' placeholder='Option Name' id='name"+x+"' class='form-control'></div></div><div class='form-group required'><label class='col-sm-2 control-label' for='sort_order"+x+"'>Sort Order</label><div class='col-sm-10'><input type='text' name='optionvalue["+x+"][sort_order]' value='' placeholder='Sort Order' id='sort_order"+x+"' class='form-control'></div></div></div></div></div></div>");
            x++;
        });
        $(document).on("click", '.remove-box', function(event) { 
            $('#box-'+$(this).data('box')).remove();
        });
        $(document).ready(function() {
            $('.summernote').summernote({
                height: 200
            });
            $('.select2').select2();
            
        });
    </script>
@endsection