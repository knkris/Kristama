@extends('layouts.admin')

@section('title')
    Add Coupon
@endsection

@section('head')
    <!-- include summernote css/js-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.18/jquery.datetimepicker.min.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.min.css">

    <style type="text/css">
        textarea {
            overflow-x: hidden;
        }
    </style>
@endsection

@section('content')
     <div id="page-wrapper">
        <form role="form" action="{{ url('admin/coupon/store') }}" class="form-horizontal" enctype="multipart/form-data" method="post">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Add Coupon
                        <div class="pull-right">
                            <button type="submit" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Save" aria-describedby="tooltip815756">
                                <i class="fa fa-save"></i>
                            </button>
                            <a href="{{ url('admin/coupon') }}" class="btn btn-default" data-original-title="Cancel">
                                <i class="fa fa-reply"></i>
                            </a>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/coupon') }}">Coupon</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-pencil"></i> Add Coupon
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">                            
                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="name">
                                    Coupon Name
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" name="name" value="{{ old('name') }}" placeholder="10% off" id="name" class="form-control">
                                </div>
                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="code">
                                    Code
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" name="code" value="{{ old('code') }}" placeholder="DISC10" id="code" class="form-control">
                                </div>
                                @if ($errors->has('code'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('code') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="type">
                                    Type
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control select2" name="type" id="type">    
                                        <option value="P" @if(old('type')==="P") selected @endif>Percentage</option>
                                        <option value="F" @if(old('type')==="F") selected @endif>Fixed Amount</option>
                                    </select>
                                </div>
                                @if ($errors->has('type'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('type') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="discount">
                                    Discount
                                </label>
                                <div class="col-sm-10">
                                    <input type="number" name="discount" value="{{ old('discount') }}" placeholder="50000" id="discount" class="form-control">
                                </div>
                                @if ($errors->has('discount'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('discount') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group max-discount-box required">
                                <label class="col-sm-2 control-label" for="max_discount">
                                    Max Discount
                                </label>
                                <div class="col-sm-10">
                                    <input type="number" name="max_discount" value="{{ old('max_discount') }}" placeholder="50000" id="max_discount" class="form-control">
                                </div>
                                @if ($errors->has('max_discount'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('max_discount') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required"">
                                <label class="col-sm-2 control-label" for="min_order">
                                    Min Order
                                </label>
                                <div class="col-sm-10">
                                    <input type="number" name="min_order" value="{{ old('min_order') }}" placeholder="50000" id="min_order" class="form-control">
                                </div>
                                @if ($errors->has('min_order'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('min_order') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="shipping">
                                    Free Shipping
                                </label>
                                <div class="col-sm-10">
                                    <label class="radio-inline">
                                        <input type="radio" name="shipping" value="1">Yes
                                    </label>
                                    <label class="radio-inline">
                                        <input type="radio" name="shipping" value="0" checked="checked">No
                                    </label>
                                </div>
                                @if ($errors->has('shipping'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('shipping') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="product">
                                    Product
                                </label>
                                <div class="col-sm-10">
                                    <select name="rel_product[]" placeholder="Product" id="product" class="form-control product" multiple="multiple"></select>
                                </div>
                                
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="category">
                                    Category
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control select2" name="category[]" id="category" multiple="multiple">
                                        <option value=""></option>
                                        @foreach($category as $cat)
                                        <option value="{{$cat->id}}" @if(old('category')) @if(in_array($cat->id, old('category'))) selected @endif @endif>{{$cat->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                @if ($errors->has('category'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('category') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="start_date">
                                    Start Date
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" name="start_date" value="{{ old('start_date') }}" id="start_date" class="form-control datepicker">
                                </div>
                                @if ($errors->has('start_date'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('start_date') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="end_date">
                                    End Date
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" name="end_date" value="{{ old('end_date') }}" id="end_date" class="form-control datepicker">
                                </div>
                                @if ($errors->has('end_date'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('end_date') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="uses_total">
                                    Uses per Coupon
                                </label>
                                <div class="col-sm-10">
                                    <input type="number" name="uses_total" value="{{ old('uses_total') }}" placeholder="100" id="uses_total" class="form-control">
                                </div>
                                @if ($errors->has('uses_total'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('uses_total') }}</strong>
                                    </span>
                                @endif
                            </div>
                            
                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="uses_customer">
                                    Uses per Customer
                                </label>
                                <div class="col-sm-10">
                                    <input type="number" name="uses_customer" value="{{ old('uses_customer') }}" placeholder="100" id="uses_customer" class="form-control">
                                </div>
                                @if ($errors->has('uses_customer'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('uses_customer') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="input-status">
                                    Status
                                </label>
                                <div class="col-sm-10">
                                    <select name="status" id="input-status" class="form-control">
                                        <option value="1" selected="selected">Enabled</option>
                                        <option value="0">Disabled</option>
                                    </select>
                                </div>
                            </div>
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            </form>
        </div>
        <!-- /#page-wrapper -->
@endsection

@section('script')
    <!-- include summernote css/js-->
    <script src="{{ asset('js/summernote.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.18/jquery.datetimepicker.full.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js"></script>
    <script>
        $('#type').on('change', function(){
            if($(this).val()=="P")
                $('.max-discount-box').show();
            if($(this).val()=="F")
                $('.max-discount-box').hide();
        });
        $(document).ready(function() {
            $('.summernote').summernote({
                height: 200
            });
            $('.select2').select2();

            $('.datepicker').datetimepicker({
             timepicker:false,
             format:'d-m-Y'
            });

            $('.product').select2({
                placeholder: "Choose Option...",
                ajax: {
                    url: '{{ url('admin/product/search')}}',
                    dataType: 'json',
                    data: function (params) {
                        return {
                            q: $.trim(params.term)
                        };
                    },
                    processResults: function (data) {
                        return {
                            results: data
                        };
                    },
                    cache: true
                }
            });
        });
    </script>
@endsection