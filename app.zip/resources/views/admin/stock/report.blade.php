
<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
<meta charset="UTF-8" />
<title>Stock Report</title>
<link href="{{ asset('sbadmin2/vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="{{ asset('sbadmin2/vendor/bootstrap/js/bootstrap.min.js') }}"></script>
<link href="{{ asset('sbadmin2/vendor/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="{{ asset('css/custom.css') }}">
</head>

<body>
<div class="container" style="margin-top: 10px;">

	
<form id="form" action="{{ url('admin/stock/excel-report') }}" method="post">
	{{csrf_field()}}
<input type="hidden" name="stock_module_report_limit" value="{{ $limit ?: 3 }}"/>	
</form>
<button id="xl_report_button" class="btn btn-primary pull-right"><i class="fa fa-file-excel-o"> </i> Download in Excel format</button>
	


<h1>Stock availability (<{{$limit}} items)</h1>
			@foreach($products as $prod)  
				<table class="table table-bordered">
					<tr class="heading">
						<td width="60%"><strong>52 - GM EVOLUTION - EMOTICON #4 - GM EVOLUTION - EMOTICON #4</strong></td>
						<td width="20%" align="center"><strong>SKU</strong></td>  
						<td width="20%" align="center"><strong>Quantity</strong></td>  
					</tr>

					@foreach($product_stock as $index => $stock)
                      @if($stock->product_id==$prod->id)
                      <?php
                        $option_detail_name="";
                      
                        $stock_detail=$stock->ProductStockDetail;
                        foreach($stock_detail as $key => $sd){
                          $pod=$sd->ProductOptionDetail;
                          if($key==0){
                            $option_detail_name.=$pod->OptionValue->name;
                          }else{
                            $option_detail_name.=' / '.$pod->OptionValue->name;
                          }
                        }
                      ?>

					<tr>
						<td width="60%">
							{{$option_detail_name}}
						</td>
						<td width="20%" align="center">{{$stock->sku}}</td>  
						<td width="20%" align="center">{{$stock->qty}}</td>  
					</tr>

					  @endif
					@endforeach
					
				</table>
			@endforeach
				
				
		
<script type="text/javascript">
	$('#xl_report_button').click(function() {
		$('#form').submit();
	});
</script>

</body>
</html>