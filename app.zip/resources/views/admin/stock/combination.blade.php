@extends('layouts.admin')

@section('title')
    Stock Combination
@endsection

@section('head')
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.css"/>

    <style type="text/css">
      
      .product-row {
        background-color: #1e91cf; color: #fff; font-weight: bold;  
      }
      .browse-icon {
        border: 1px solid #1978ab; border-radius: 3px; padding:1px 5px; margin: 0px 3px; color:#fff;  
      }
      .save-icon {
      border: 1px solid #d6bfa9; border-radius: 3px; background-color:#ffa54d; display:none; padding:0px 5px; color:#fff; margin-right: 5px;
      }
      .cancel-icon {
        border: 1px solid #d6bfa9; border-radius: 3px; background-color:#ffa54d; display:none; padding:0px 4px; color:#fff; margin-right: 5px;
      }
      .edit-icon {
        padding:0px 5px; color:#fff;
      }
      .load-icon {
        color:#fff; font-size: 14px;
      }
      .combinations-td {
        padding: 5px; /*10px;*/
      }
      .combinations-table > thead > tr {
        background-color: #e2f2f9 !important;
      }

      .combinations-table {
        /*border:0px; padding:0px; margin:0px;*/
        margin-bottom: 0px;
      }
      .combinations-table td {
        /*padding:4px !important;*/
      }
      .combinations-table input[type="text"] {
        /*border: 1px solid #ddd;
        padding: 1px 2px;
        margin: 2px 2px;*/
        padding: 0px 13px;
        width: 70%;
        display: inline-block;
        height:26px;
      }
      .ibold { font-weight: bold;}
      .right {
        text-align: right;  
      }
      .text-error { color: #ff0000; }
      .text-warning { color: #ff7f00; }
      .text-success { color: #00cc00; }
      .save-success {
        background-color: #00cc00;
        border: 1px solid #00cc00;
      }
      .alert-small {
        /*margin-bottom: 10px;
        padding: 5px 10px;  */
      }
    
    </style>
@endsection

@section('content')
  
     <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Stock Combination
                        <div class="pull-right">
                            {{--  --}}

                            <a style="margin-top:-3px;" href="{{ url('admin/stock') }}" data-original-title="Back to Stock" data-toggle="tooltip" type="button" class="btn btn-default">
                               <i class="fa fa-reply"></i>
                            </a>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/stock') }}">Stock</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/combination') }}">Stock Combination</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-list"></i> Stock Combination List
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                          <form id="form-report" role="form" action="{{ url('admin/combination') }}" class="" enctype="multipart/form-data" method="get">
                          
                          <div class="well">
                              <div class="row">
                          <div class="col-sm-4">
                            <div class="form-group">
                              <label class="control-label" for="input-name">Product Name</label>
                              <input type="text" name="filter_name" value="{{ \Request::get('filter_name') }}" placeholder="Product Name" id="input-name" class="form-control" autocomplete="off"><ul class="dropdown-menu"></ul>
                            </div>
                                  <div class="form-group">
                                    <label class="control-label" for="input-option-value">Option value</label>
                                    <input type="text" name="filter_option" value="{{ \Request::get('filter_option') }}" placeholder="Option value" id="input-option-value" class="form-control" autocomplete="off"><ul class="dropdown-menu"></ul>
                                  </div>
                          </div>
                          <div class="col-sm-4">
                            <div class="form-group">
                              <label class="control-label" for="input-model">Product Model</label>
                              <input type="text" name="filter_model" value="{{ \Request::get('filter_model') }}" placeholder="Product Model" id="input-model" class="form-control" autocomplete="off"><ul class="dropdown-menu"></ul>
                            </div>
                            <div class="form-group">
                              <label class="control-label" for="input-comb-quantity">Combination Quantity (≤)</label>
                              <input type="text" name="filter_comb_quantity" value="{{ \Request::get('filter_comb_quantity') }}" placeholder="Combination Quantity" id="input-comb-quantity" class="form-control">
                                  </div>
                          </div>
                          <div class="col-sm-4">
                            <div class="form-group">
                              <label class="control-label" for="input-quantity">Product Quantity (≤)</label>
                              <input type="text" name="filter_quantity" value="{{ \Request::get('filter_quantity') }}" placeholder="Product Quantity" id="input-quantity" class="form-control">
                            </div>
                            <button type="submit" id="button-filter" class="btn btn-primary pull-right"><i class="fa fa-search"></i> Filter</button>
                          </div>
                          </form>
                              </div>
                            </div>

                            <table class="table table-bordered">
                              <thead>
                                <tr>
                                  <td width="35%" class="text-left">                <a href="https://www.helmku.com/admin/index.php?route=catalog/stock/combinations&amp;token=Ts4OBFaQSch4KQy6LogQ4f36hh47rDDs&amp;sort=pd.name&amp;order=DESC" class="asc">Product Name</a>
                                    </td>
                                  <td width="35%" class="text-left">                <a href="https://www.helmku.com/admin/index.php?route=catalog/stock/combinations&amp;token=Ts4OBFaQSch4KQy6LogQ4f36hh47rDDs&amp;sort=p.model&amp;order=DESC">Model</a>
                                    </td>
                                  <td width="15%" class="text-left">                <a href="https://www.helmku.com/admin/index.php?route=catalog/stock/combinations&amp;token=Ts4OBFaQSch4KQy6LogQ4f36hh47rDDs&amp;sort=p.quantity&amp;order=DESC">Quantity</a>
                                    </td>
                                  <td width="15%" class="text-right">Action</td>
                                </tr>
                              </thead>
                              <tbody>
                              @foreach($products as $prod)  
                                <tr id="product-{{$prod->id}}" class="product-row">
                                  <td class="text-left">
                                    <a class="browse-icon" href="#" data-original-title="Collapse" data-toggle="tooltip"><i class="ibold fa fa-angle-down"></i></a>
                                    {{$prod->name}}
                                  </td>
                                  <td class="text-left">{{$prod->model}}</td>
                                  <td class="text-center">{{$prod->qty}}</td>
                                  <td class="text-right" nowrap="">
                                    <i style="display:none;" class="fa fa-spinner"></i>
                                    <a class="cancel-icon" href="#" data-original-title="Cancel" data-toggle="tooltip"><i class="fa fa-reply"></i></a>
                                    <a class="save-icon" href="#" data-original-title="Save" data-toggle="tooltip"><i class="fa fa-save"></i></a>
                                    <a class="edit-icon" href="#" data-original-title="Edit" data-toggle="tooltip"><i class="fa fa-pencil"></i></a>
                                  </td>
                                </tr>
                                @if($prod->ProductStock()->count())
                                <?php 
                                  $stock=$prod->ProductStock()->first();
                                  $option_name="";
                                    
                                  $stock_detail=$stock->ProductStockDetail;
                                  foreach($stock_detail as $key => $sd){
                                    $pod=$sd->ProductOptionDetail;
                                    if($key==0){
                                      $option_name.=$pod->Option->name;
                                    }else{
                                      $option_name.=' / '.$pod->Option->name;
                                    }
                                  }
                                ?>
                                <tr id="product-{{$prod->id}}-combinations">
                                  <td colspan="4" class="text-left combinations-td">
                                    <table class="combinations-table table table-striped table-bordered">
                                    <thead>
                                      <tr>
                                        <td style="display:none"><input type="hidden" name="product_id" value="{{$prod->id}}"></td>
                                        <td width="70%" class="left">{{$option_name}}</td>
                                        <td width="15%" class="text-left">Quantity</td>
                                        <td width="15%" class="text-left">SKU</td>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      @foreach($product_stock as $index => $stock)
                                      @if($stock->product_id==$prod->id)
                                      <?php
                                        $option_detail_name="";
                                      
                                        $stock_detail=$stock->ProductStockDetail;
                                        foreach($stock_detail as $key => $sd){
                                          $pod=$sd->ProductOptionDetail;
                                          if($key==0){
                                            $option_detail_name.=$pod->OptionValue->name;
                                          }else{
                                            $option_detail_name.=' / '.$pod->OptionValue->name;
                                          }
                                        }
                                      ?>
                                      <tr id="{{$stock->id}}">
                                        <td style="display:none">{{csrf_field()}}<input type="hidden" name="product_combinations[{{$index}}][combination_id]" value="{{$stock->id}}"></td>
                                        <td class="left">{{$option_detail_name}}</td>
                                        <td class="text-left">
                                          <span class="text-field ">{{$stock->qty}}</span>
                                          <input style="display:none;" class="right input-field form-control" type="text" name="product_combinations[{{$index}}][quantity]" value="{{$stock->qty}}">
                                        </td>  
                                        <td class="text-left">
                                          <span class="text-field">{{$stock->sku}}</span>
                                          <input style="display:none;" class="right input-field form-control" type="text" name="product_combinations[{{$index}}][sku]" value="{{$stock->sku}}">
                                        </td>             
                                      </tr>
                                      @endif
                                      @endforeach
                                      
                                    </tbody>
                                    </table>
                                  </td>
                                </tr>
                                @endif
                              @endforeach

                              
                                            
                                            </tbody>
                                </table>
                                </td></tr>
                                                      </tbody>
                            </table>
                            <!-- /.table-responsive -->

                            {{ $product_stock->appends(['filter_name' => \Request::get('filter_name'), 'filter_option' => \Request::get('filter_option'), 'filter_model' => \Request::get('filter_model'), 'filter_comb_quantity' => \Request::get('filter_comb_quantity'), 'filter_quantity' => \Request::get('filter_quantity')])->links() }}
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            
        </div>
        <!-- /#page-wrapper -->
    
@endsection

@section('script')
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.js"></script>

    <script>
        $('#delete').on('click',function(){
            swal({
                  title: 'Are you sure?',
                  text: "You won't be able to revert this!",
                  type: 'warning',
                  showCancelButton: true,
                  confirmButtonColor: '#3085d6',
                  cancelButtonColor: '#d33',
                  confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                  if (result.value) {
                    $('#form').submit();
                  }
                })
        });

        $(document).ready(function () {
            
        });

        
        
    </script>

    <script>
          
      function showError(e, error) {
        e.before('<div class="alert alert-danger alert-small"><i class="fa fa-exclamation-circle"></i> ' + 
        error + 
        '<button data-dismiss="alert" class="close" type="button">&times;</button></div>');
      }

      function switchFields(combinations, showText, copyValues) {
        var textFields = combinations.find('.text-field');
        var inputFields = combinations.find('.input-field');
        
        if (showText) {
          if (copyValues) {
            inputFields.each(function(index) {
              var value = $(this).val();
              $(this).prev().html(value);
            });
          }
          
          textFields.show();
          inputFields.hide(); 
        } else {
          if (copyValues) {
            textFields.each(function(index) {
              var value = $(this).html();
              $(this).next().val(value);
            });
          }
          
          textFields.hide();
          inputFields.show(); 
        }
      }
      
      //$('.text-field, .input-field').show();

      function combinationsFromIcon(icon) {
          var tr = icon.closest('tr');
          var combsId = tr.attr('id') + '-combinations';
          return $('#' + combsId);
        }

        $('.browse-icon').click(function(e) {
          e.preventDefault();
          var icon = $(this);
          icon.blur();
          var i = icon.find('i:first');
          
        var expanded = i.hasClass('fa-angle-down');
        if (expanded) {
            icon.attr('data-original-title', 'Expand');
            combinationsFromIcon(icon).hide();
          } else {
            icon.attr('data-original-title', 'Collapse');
            combinationsFromIcon(icon).show();
          }
        
        i.toggleClass('fa-angle-down');
        i.toggleClass('fa-angle-right');

          return false;
        });
      
      $('.cancel-icon').click(function(e) {
        e.preventDefault();
        
        var icon = $(this);
        icon.blur();
        icon.hide();
        
        $('.alert').hide();
        $('.text-error').hide();
        icon.parent().find('.save-icon').hide();
        icon.parent().find('.edit-icon').removeClass('open');
      
        var combs = combinationsFromIcon(icon);
        
        switchFields(combs, true, false); // show text and hide edit (don't copy values)
        return false;
      });
      
      $('.edit-icon').click(function(e) {
        e.preventDefault();
        var icon = $(this);
        icon.blur();
        if (icon.hasClass('open')) {
          return false; 
        }
        
        var saveIcon = icon.parent().find('.save-icon');
        saveIcon.removeClass('save-success');
        saveIcon.stop().animate({'opacity': '100'});
        saveIcon.show();
        
        icon.parent().find('.cancel-icon').show();
        
        var combs = combinationsFromIcon(icon);
        
        switchFields(combs, false, true); // show edit and hide text. copy values from text to edit fields
        
        icon.addClass('open');
        
        return false;
      });
      
      $('.save-icon').click(function(e) {
        e.preventDefault();
        var icon = $(this);
        icon.blur();
        
        var loadingIcon = icon.parent().find('i:first');
        var combs = combinationsFromIcon(icon);
        var input=combs.find('input');
        
        console.log(input);
      
        $.ajax({
        url: '{{ url('admin/update-combination') }}',
        dataType: 'json',
        data: combs.find('input'),
        type: 'post',
        beforeSend: function() {
          loadingIcon.toggleClass("fa-spin"); // start spinning loading icon
          loadingIcon.show();
        },
        complete: function(data) {
          loadingIcon.hide();
          loadingIcon.toggleClass("fa-spin");   // remove loading icon
          console.log(data);
        },
        success: function(json) {
          combs.find('.text-error').remove(); // remove red asterisks beside text fields if any
          combs.find('.alert').remove();    // remove error message if any
          if (json['error']) { 
            showError(combs.find('table'), json['error']); // add error message
            
            // loop to display asterisks beside the correct field
            if (json['error_quantity']) {
              var inputs = combs.find('table input[name*="quantity"]');
              inputs.each( function(index) {
                var exists = $.inArray(index, json['error_quantity']) != -1;
                if (exists) {
                  $(this).after('<span class="text-error">***</span>');
                }
              });
            }
          } else {
            switchFields(combs, true, true); // show text and hide edit. copy values from edit to text fields
            icon.parent().find('.cancel-icon').hide();
            icon.parent().find('.edit-icon').removeClass('open');
              icon.toggleClass('save-success');
              icon.fadeOut(1500, function() {icon.toggleClass('save-success');} );
              var quantity = icon.parent().prev()
              quantity.html(json['product_quantity']);
            }
        },
        error: function(xhr, ajaxOptions, thrownError) {
          combs.find('.alert').remove();
          var error = 'Unexpected error (tr): ' + thrownError + " Status:" + xhr.statusText + " Response:" + xhr.responseText;
          showError(combs.find('table'), error);
        }
      });
        
        return false;
      });
    </script>
@endsection