@extends('layouts.admin')

@section('title')
    Edit Stock
@endsection

@section('head')
    <!-- include summernote css/js-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.min.css">

    <style type="text/css">
        textarea {
            overflow-x: hidden;
        }
        .my-group .form-control{
            width:50%;
        }
    </style>
@endsection

@section('content')
     <div id="page-wrapper">
        <form role="form" action="{{ url('admin/stock/edit/'.$results->id) }}" class="form-horizontal" enctype="multipart/form-data" method="post">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Edit Stock
                        <div class="pull-right">
                            <button type="submit" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Save" aria-describedby="tooltip815756">
                                <i class="fa fa-save"></i>
                            </button>
                            <a href="{{ url('admin/stock') }}" class="btn btn-default" data-original-title="Cancel">
                                <i class="fa fa-reply"></i>
                            </a>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/stock') }}">Stock</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-pencil"></i> Edit Stock {{ $results->name }}
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">                            
                            <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    @foreach($results->ProductOption as $po)
                                                    <td>
                                                        <strong>{{$po->Option->name}}</strong>
                                                    </td>
                                                    @endforeach
                                                    <td>
                                                        <strong>Quantity</strong>
                                                    </td>
                                                    <td>
                                                        <strong>SKU</strong>
                                                    </td>
                                                    <td></td>
                                                </tr>
                                            </thead>
                                            <tbody id="table-body">
                                                <?php 
                                                //$product_stock=\App\Models\ProductStock::has('ProductStockDetail')->whereProduct_id($results->id)->get();
                                                //$count=count($product_stock);
                                                $count=count($results->ProductStock);
                                                ?>
                                                @foreach($results->ProductStock as $key=>$val)
                                                <tr  id='row-{{$key}}'>
                                                    @foreach($results->ProductOption as $po)
                                                    <?php
                                                    $getval=\App\Models\ProductStockDetail::whereProduct_stock_id($val->id)->pluck('product_option_detail_id')->toArray();
                                                    ?>
                                                    <td>
                                                        <input type="hidden" name="product_stock[{{$key}}][product_stock_id]" value="{{$val->id}}">
                                                        <select name="product_stock[{{$key}}][product_option_detail_id][{{$po->id}}]" value=" placeholder="Option" id="optionvalue" class="form-control optionvalue">
                                                            @foreach($po->ProductOptionDetail as $pod)
                                                            <option value="{{$pod->id}}" @if(in_array($pod->id,$getval)) selected @endif>{{$pod->OptionValue->name}}</option>
                                                            @endforeach
                                                        </select>
                                                    </td>
                                                    @endforeach
                                                    <td class="col-md-3">
                                                        <input type="number" name="product_stock[{{$key}}][qty]" placeholder="Quantity" id="qty{{$key}}" value="{{$val->qty}}" class="form-control">
                                                    </td>
                                                    
                                                    <td class="col-md-3">
                                                        <input type="text" name="product_stock[{{$key}}][sku]" id="sku{{$key}}" value="{{$val->sku}}" class="form-control">
                                                    </td>
                                                    <td>
                                                        <a class="remove-select-option" data-x="{{$key}}" style="cursor: pointer">Remove</a>
                                                    </td>
                                                </tr> 
                                                @endforeach
                                            </tbody>
                                        </table>
                                        <div>
                                            <button type="button" class="button btn-primary add-row" data-x="{{$count}}">
                                                Add row
                                            </button>
                                        </div>
                                    </div>


                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            

            </form>
        </div>
        <!-- /#page-wrapper -->
@endsection

@section('script')
    <!-- include summernote css/js-->
    <script src="{{ asset('js/summernote.js') }}"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js"></script>
    <script>
        var x={{$count}};

        function addRow(x){
            $('#table-body').append("<tr id='row-"+x+"'>@foreach($results->ProductOption as $po)<td><input type='hidden' name='product_stock["+x+"][product_stock_id]' value='0'><select name='product_stock["+x+"][product_option_detail_id][{{$po->id}}]' id='optionvalue"+x+"' class='form-control optionvalue'>@foreach($po->ProductOptionDetail as $pod)<option value='{{$pod->id}}'>{{$pod->OptionValue->name}}</option>@endforeach</select></td>@endforeach<td><input type='number' name='product_stock["+x+"][qty]' placeholder='Quantity' value='0' id='qty"+x+"' class='form-control'></td><td><input type='text' name='product_stock["+x+"][sku]' id='sku"+x+"' class='form-control'></td><td><a class='remove-select-option' data-x='"+x+"' style='cursor: pointer'>Remove</a></td></tr>");

        }

        $('.add-row').on('click',function(){
            addRow(x);
            x++;
        });

        $(document).on("click", '.remove-select-option', function(event) { 
            $x=$(this).data('x');
            $('#row-'+$x).remove();
        });
        
        
        $(document).ready(function() {
            $('.summernote').summernote({
                height: 200
            });
            $('.select2').select2();
            
        });
    </script>

@endsection