@extends('layouts.admin')

@section('title')
    Stock
@endsection

@section('head')
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.css"/>
@endsection

@section('content')
    <form id="form-report" role="form" action="{{ url('admin/stock/report') }}" class="form-horizontal" enctype="multipart/form-data" method="post" target="_blank">
        {{ csrf_field() }}
     <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Stock
                        <div class="pull-right">
                            <label style="font-weight: 100;font-size: 14px;">
                              Combinations having stock less than:  
                            </label>      
                            <input class="form-control" style="width:50px;display:inline;text-align:right;" name="stock_module_report_limit" type="text" size="2" value="3">

                            <button style="margin-top:-3px;" type="submit" form="form-report" data-toggle="tooltip" data-original-title="Generate report" class="btn btn-primary">
                              <i class="fa fa-bar-chart"></i>
                            </button>

                            <a style="margin-top:-3px;" href="{{ url('admin/combination') }}" data-original-title="Combinations" data-toggle="tooltip" type="button" class="btn btn-primary">
                               <i class="fa fa-table"></i>
                            </a>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/stock') }}">Stock</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-list"></i> Stock List
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="table">
                                <thead>
                                    <tr>
                                        <th>
                                            <input type="checkbox" onclick="$('input[name*=\'selected\']').prop('checked', this.checked);">
                                        </th>
                                        <th>Image</th>
                                        <th>Name</th>
                                        <th>Model</th>
                                        <th>Price</th>
                                        <th>Qty</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                            </table>
                            <!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            
        </div>
        <!-- /#page-wrapper -->
    </form>
@endsection

@section('script')
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.js"></script>

    <script>
        $('#delete').on('click',function(){
            swal({
                  title: 'Are you sure?',
                  text: "You won't be able to revert this!",
                  type: 'warning',
                  showCancelButton: true,
                  confirmButtonColor: '#3085d6',
                  cancelButtonColor: '#d33',
                  confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                  if (result.value) {
                    $('#form').submit();
                  }
                })
        });

        $(document).ready(function () {
            $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax":{
                         "url": "{{ url('admin/stock') }}",
                         "dataType": "json",
                         "type": "POST",
                         "data":{ _token: "{{csrf_token()}}"}
                       },
                "columns": [
                    { "data": "id",
                      "orderable": false
                    },
                    { "data": "image",
                      "orderable": false
                    },
                    { "data": "name", },
                    { "data": "model", },
                    { "data": "price", },
                    { "data": "qty", },
                    { "data": "status", },
                    { "data": "action",
                      "orderable": false
                    }
                ]    

            });
        });

        

        // Activate an inline edit on click of a table cell
        $('#table').on( 'click', 'tbody td.editable', function (e) {
            if(!$(this).hasClass('editing')){
                $(this).addClass('editing');
                $id=$(this).children().data('id');
                $val=$(this).children().text();
                $type=$(this).children().data('type');
                if($type==="price"){
                    $price=$(this).children().data('price');
                    $(this).html("<input type='text' class='form-control editable-box' name='val' value='"+$price+"' data-id='"+$id+"' data-type='"+$type+"'> ");
                }else{
                    $(this).html("<input type='text' class='form-control editable-box' name='val' value='"+$val+"' data-id='"+$id+"' data-type='"+$type+"'> ");
                }
                $('.editable-box').focus();
            }
        } );

        // Activate an inline edit on click of a table cell
        $('#table').on( 'click', 'tbody td.selectable', function (e) {
            if(!$(this).hasClass('editing')){
                $(this).addClass('editing');
                $id=$(this).children().data('id');
                $val=$(this).children().text();
                $type=$(this).children().data('type');
                if($val==="enabled"){
                    $(this).html("<select class='form-control selectable-box' name='val' data-id='"+$id+"' data-type='"+$type+"'><option value='1' selected>enabled</option><option value='0'>disabled</option></select> ");
                }else{
                    $(this).html("<select class='form-control selectable-box' name='val' data-id='"+$id+"' data-type='"+$type+"'><option value='1'>enabled</option><option value='0' selected>disabled</option></select> ");
                }
                $('.selectable-box').focus();
            }
        } );

        $(document).on("blur", '.editable-box', function(event) { 
            $this=$(this);
            $id=$(this).data('id');
            $val=$(this).val();
            $type=$(this).data('type');

            $(this).attr('disabled','disabled');
            $.ajax({
                url: "{{ url('admin/product') }}/"+$type+"/"+$id,
                type: "post",
                data: {
                    id: $id,
                    value: $val,
                    _token: "{{csrf_token()}}"
                } ,
                success: function (response) {
                   // you will get response from your php page (what you echo or print)                 
                   console.log(response);
                   var type=$(this).data('type');
                   console.log(response.type);
                   $newid=response.id;
                   $newname=response.name;
                   $newmodel=response.model;
                   $newprice=response.price;
                   $newqty=response.qty;
                   //$parent=$this.parent("td");
                   $this.parent("td").removeClass('editing');
                   if(type=='name'){
                       $this.parent("td").empty().html("<p data-id='"+$newid+"' data-type='name'>"+$newname+"</p>");
                   }else if(type=='model'){
                       $this.parent("td").empty().html("<p data-id='"+$newid+"' data-type='model'>"+$newmodel+"</p>");
                   }else if(type=='price'){
                    $rpprice=response.rp_price;
                       $this.parent("td").empty().html($rpprice);
                   }
                   else if(type=='qty'){
                    if($newqty>0){
                       $this.parent("td").empty().html("<span class='label label-success' data-id='"+$newid+"' data-type='qty'>"+$newqty+"</span>");
                    }else{
                       $this.parent("td").empty().html("<span class='label label-warning' data-id='"+$newid+"' data-type='qty'>"+$newqty+"</span>");
                    }
                   }
                   //swal('Success!', response.name+" price updated", 'success');
                   
                }.bind($this),
                error: function(jqXHR, textStatus, errorThrown) {
                   console.log(jqXHR, textStatus, errorThrown);
                   swal('Error!', jqXHR.responseJSON.errors.value[0], 'error');
                   $(this).removeAttr('disabled');

                }.bind($this)
            });


        });

        $(document).on("change", '.selectable-box', function(event) { 
            $this=$(this);
            $id=$(this).data('id');
            $val=$(this).val();
            $type=$(this).data('type');

            $(this).attr('disabled','disabled');
            $.ajax({
                url: "{{ url('admin/product') }}/"+$type+"/"+$id,
                type: "post",
                data: {
                    id: $id,
                    val: $val,
                    _token: "{{csrf_token()}}"
                } ,
                success: function (response) {
                   // you will get response from your php page (what you echo or print)                 
                   console.log(response);
                   var type=$(this).data('type');
                   console.log(response.type);
                   $newid=response.id;
                   $newname=response.name;
                   $newmodel=response.model;
                   $newprice=response.price;
                   $newqty=response.qty;
                   $newstatus=response.status;
                   //$parent=$this.parent("td");
                   $this.parent("td").removeClass('editing');
                   
                    if($newstatus==1){
                       $this.parent("td").empty().html("enabled");
                    }else{
                       $this.parent("td").empty().html("disabled");
                    }
                   //swal('Success!', response.name+" price updated", 'success');
                }.bind($this),
                error: function(jqXHR, textStatus, errorThrown) {
                   console.log(jqXHR, textStatus, errorThrown);
                   swal('Error!', jqXHR.responseJSON.errors.value[0], 'error');
                   $(this).removeAttr('disabled');

                }.bind($this)
            });


        });
    </script>
@endsection