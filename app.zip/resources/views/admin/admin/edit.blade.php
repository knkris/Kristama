@extends('layouts.admin')

@section('title')
    Edit Admin
@endsection

@section('head')
    <!-- include summernote css/js-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/css/bootstrap-select.min.css">


    <style type="text/css">
        textarea {
            overflow-x: hidden;
        }
    </style>
@endsection

@section('content')
     <div id="page-wrapper">
        <form role="form" action="{{ url('admin/admin/edit/'.$results->id) }}" class="form-horizontal" enctype="multipart/form-data" method="post">
            {{ csrf_field() }}
            {!! Form::hidden('url',url('upload_image'), array('class'=>'url') ) !!}
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Add Admin
                        <div class="pull-right">
                            <button type="submit" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Save" aria-describedby="tooltip815756">
                                <i class="fa fa-save"></i>
                            </button>
                            <a href="{{ url('admin/admin') }}" class="btn btn-default" data-original-title="Cancel">
                                <i class="fa fa-reply"></i>
                            </a>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/admin') }}">Admin</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-pencil"></i> Add Admin
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">                            
                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="name">
                                    Admin Name
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" name="name" value="{{ $results->name }}" placeholder="Admin Name" id="name" class="form-control">
                                </div>
                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="username">
                                    Username
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" name="username" value="{{ $results->username }}" placeholder="Username" id="username" class="form-control">
                                </div>
                                @if ($errors->has('username'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('username') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="email">
                                    Email
                                </label>
                                <div class="col-sm-10">
                                    <input type="email" name="email" value="{{ $results->email }}" placeholder="Admin Name" id="email" class="form-control">
                                </div>
                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="permission">
                                    Permissions
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control select2" name="permission[]" id="permission" multiple="multiple" data-actions-box="true">
                                        <option value=""></option>
                                        @foreach($permission_group as $val)
                                        <optgroup label="{{ $val->name }}">
                                            @foreach(\App\Models\PermissionGroup::whereName($val->name)->get() as $per)
                                                <option value="{{ $per->Permission->name }}" @if(in_array($per->Permission->id, $permission_id )) selected @endif>{{$per->Permission->name}} </option>
                                            @endforeach
                                        </optgroup>
                                        @endforeach
                                        <?php /*
                                        @foreach($permission as $cat)
                                        <option value="{{$cat->name}}" @if(in_array($cat->id, $permission_id )) selected @endif>{{$cat->name}} </option>
                                        @endforeach
                                        */ ?>
                                    </select>
                                </div>
                                @if ($errors->has('permission'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('permission') }}</strong>
                                    </span>
                                @endif
                            </div>
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            </form>
        </div>
        <!-- /#page-wrapper -->
@endsection

@section('script')
    <!-- include summernote css/js-->
    <script src="{{ asset('js/summernote.js') }}"></script>

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/js/bootstrap-select.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.summernote').summernote({
                height: 200
            });
            $('#permission').selectpicker();
            {{-- $('.select2').select2({
                placeholder: "Select Permission(s)...",
                dropdownAdapter: $.fn.select2.amd.require('select2/selectAllAdapter')
            }); --}}
        });

        {{-- $.fn.select2.amd.define('select2/selectAllAdapter', [
            'select2/utils',
            'select2/dropdown',
            'select2/dropdown/attachBody'
        ], function (Utils, Dropdown, AttachBody) {

            function SelectAll() { }
            SelectAll.prototype.render = function (decorated) {
                var self = this,
                    $rendered = decorated.call(this),
                    $selectAll = $(
                        '<button class="btn btn-xs btn-default" type="button" style="margin-left:6px;"><i class="fa fa-check-square-o"></i> Select All</button>'
                    ),
                    $unselectAll = $(
                        '<button class="btn btn-xs btn-default" type="button" style="margin-left:6px;"><i class="fa fa-square-o"></i> Unselect All</button>'
                    ),
                    $btnContainer = $('<div style="margin-top:3px;">').append($selectAll).append($unselectAll);
                if (!this.$element.prop("multiple")) {
                    // this isn't a multi-select -> don't add the buttons!
                    return $rendered;
                }
                $rendered.find('.select2-dropdown').prepend($btnContainer);
                $selectAll.on('click', function (e) {
                    var $results = $rendered.find('.select2-results__option[aria-selected=false]');
                    $results.each(function () {
                        self.trigger('select', {
                            data: $(this).data('data')
                        });
                    });
                    self.trigger('close');
                });
                $unselectAll.on('click', function (e) {
                    var $results = $rendered.find('.select2-results__option[aria-selected=true]');
                    $results.each(function () {
                        self.trigger('unselect', {
                            data: $(this).data('data')
                        });
                    });
                    self.trigger('close');
                });
                return $rendered;
            };

            return Utils.Decorate(
                Utils.Decorate(
                    Dropdown,
                    AttachBody
                ),
                SelectAll
            ); 

        });--}}
    </script>
@endsection