
<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
<meta charset="UTF-8" />
<title>Shipping Label</title>
<base href="https://www.purplejadebutik.com/admin/" />
<link href="{{ asset('sbadmin2/vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ asset('css/shippinglabel.css') }}" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="{{ asset('sbadmin2/vendor/bootstrap/js/bootstrap.min.js') }}"></script>
<link href="{{ asset('sbadmin2/vendor/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet" type="text/css">
<style>
/*.highlight {
    background-color: none !important;
color:white !important;
font-size:13px !important;
    -webkit-print-color-adjust: exact; 
}
@media print {
.highlight {
    background-color: purple !important;
color:white !important;
font-size:13px !important;
    -webkit-print-color-adjust: exact; 
}
}*/
</style>
</head>
<body>
<div >
    <div style="width:100%; float:left;">
	@foreach($orders as $key=>$order)
    <table class="table table-bordered">
      <thead>
        <tr>
          <td>Order Details-Invoice #{{ $order->invoice }} ({{ $order->shipping_courier." - ".$order->courier_service}}) {{ Carbon\Carbon::parse($order->created_at)->format('d M Y') }}</td>
          
        </tr>
      </thead>
      <tbody>
        <tr>
          <td> <address>
            
            
            
            <?php
              if($order->payment_custom_field){
                $from=unserialize($order->payment_custom_field);
              }
              if($order->shipping_custom_field){
                $to=unserialize($order->shipping_custom_field);
              }
            ?>
            <strong>{{env('APP_NAME', 'Laravel')}}</strong>
                        <br>
            <b>Telephone:</b> {{env('APP_PHONE', '021-1234356')}}<br>
                        <b>E-Mail:</b> {{env('APP_EMAIL', 'cs@app.com')}}<br>
            <b>Web Site:</b> <a href="{{url('/')}}">{{url('/')}}</a><br><br>

            
            

            <b>Kepada:</b>
          <address>
            {{ $order->shipping_name }}<br />
            {{ $order->shipping_address }}<br />
            {{ $order->shipping_city }}<br />
            {{ $order->shipping_province }}<br />
            Indonesia<br />
            Telephone: {{ $order->shipping_telephone }}
          </address>
        </td>
        </tr>
      </tbody>
    </table>
    <b>Daftar Produk</b>
    <table class="table table-bordered">
      <tbody>
        <?php
            $orderdetail=$order->OrderDetail;
        ?>
      	@foreach($orderdetail as $od)
        <?php
        $product=$od->Product;
        $stocks=$od->ProductStock;
        ?>
                <tr>
          <td colspan="4" style="padding:0;">
            {{ $product->quantity }} Buah              {{ $product->name }}                        <br />
            &nbsp;
            @foreach($stocks->ProductStockDetail as $stock)
              <?php   
                  $ov=$stock->ProductOptionDetail->OptionValue;
              ?>
																	<small class="highlight" >
																	<b>{{$ov->Option->name}}: {{$ov->name}}<b>
																	</small>
																	@endforeach
                                    </td>                   
        </tr>
        @endforeach
                
                
              </tbody>
    </table>
    @endforeach
      </div>
  </div>
</body>
</html>