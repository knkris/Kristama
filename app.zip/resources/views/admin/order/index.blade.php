@extends('layouts.admin')

@section('title')
    Order
@endsection

@section('head')
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.css"/>

    <!-- Include Date Range Picker -->
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css" />
@endsection

@section('content')
    <form id="form" role="form" action="{{ url('admin/order/trash') }}" enctype="multipart/form-data" method="post">
        {{ csrf_field() }}
     <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Order
                        <div class="pull-right">
                            <button type="submit" id="button-export" onclick="exportToExcel()" data-toggle="tooltip" title="" class="btn btn-info" data-original-title="Export to Excel"><i class="fa fa-file-excel-o"></i></button>
                            <button type="submit" id="button-shipping" onclick="printShippingLabel()" data-toggle="tooltip" title="" class="btn btn-info" data-original-title="Print Shipping List"><i class="fa fa-truck"></i></button>
                            <button type="button" id="button-invoice" onclick="printInvoice()" data-toggle="tooltip" title="" class="btn btn-info" data-original-title="Print Invoice"><i class="fa fa-print"></i></button>
                            <a href="{{ url('admin/order/create') }}" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Add New" aria-describedby="tooltip23863">
                                <i class="fa fa-plus"></i>
                            </a> 
                            <button id="delete" type="button" data-toggle="tooltip" title="" class="btn btn-danger" data-original-title="Delete">
                                <i class="fa fa-trash-o"></i>
                            </button>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/order') }}">Order</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-list"></i> Order List
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">

                            @include('admin.order.filter')

                            <table width="100%" class="table table-striped table-bordered table-hover" id="table">
                                <thead>
                                    <tr>
                                        <th>
                                            <input type="checkbox" onclick="$('input[name*=\'selected\']').prop('checked', this.checked);">
                                        </th>
                                        <th>Invoice</th>
                                        <th>Name</th>
                                        <th>Status</th>
                                        <th>Total</th>
                                        <th>Created At</th>
                                        <th>Updated At</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                            </table>
                            <!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            
        </div>
        <!-- /#page-wrapper -->
    </form>
@endsection

@section('script')
    <script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.js"></script>

    <script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>

    <script>
        function printShippingLabel()
        {
            form=document.getElementById('form');
            form.target='_blank';
            form.action='{{url('admin/order/print-shipping-label')}}';
            form.submit();
        }
        function printInvoice()
        {
            form=document.getElementById('form');
            form.target='_blank';
            form.action='{{url('admin/order/print-invoice')}}';
            form.submit();
        }
        function exportToExcel()
        {
            form=document.getElementById('form');
            form.action='{{url('admin/order/export-to-excel')}}';
            form.submit();
        }
        function format ( d ) {
            console.log(d);
            // `d` is the original data object for the row
            var statushistory='order-status-history'+d.order_id;
            var statusnotify='order-status-notify'+d.order_id;
            var statuscomment='order-status-comment'+d.order_id;
            return "<table cellpadding='5' cellspacing='0' border='0' style='padding-left:50px;width:100%;'>"+
                "<tr>"+
                    "<td>Order Status</td>"+
                    "<td>"+
                    "<select id='"+statushistory+"' class='form-control'>"+
                    "<option value=''></option>"+
                    @foreach($order_status as $os)
                    "<option value='{{$os->id}}'>{{$os->name_en}}</option>"+
                    @endforeach
                    "</select>"+
                    "</td>"+
                "</tr>"+
                "<tr>"+
                    "<td>Notify</td>"+
                    "<td><input type='checkbox' id='"+statusnotify+"' value='1'></td>"+
                "</tr>"+
                "<tr>"+
                    "<td>Comment</td>"+
                    "<td><textarea name='comment' placeholder='comment' id='"+statuscomment+"' class='form-control'></textarea></td>"+
                "</tr>"+
                "<tr>"+
                    "<td></td>"+
                    "<td><button type='button' id='add-order-history"+d.order_id+"' class='btn btn-primary add-order-history' data-id='"+d.order_id+"'>Add Order History</button></td>"+
                "</tr>"+
            "</table>";

        }

            $(document).on('click', 'td.details-control', function () {

                var tr = $(this).closest('tr');
                var row = $('#table').DataTable().row( tr );
         
                if ( row.child.isShown() ) {
                    // This row is already open - close it
                    row.child.hide();
                    tr.removeClass('shown');
                }
                else {
                    // Open this row
                    row.child( format(row.data()) ).show();
                    tr.addClass('shown');

                    $('#order-status-history'+row.data().order_id).val(row.data().order_status_id);
                }
            } );

            $(document).on('click', '.add-order-history', function () {
                var id = $(this).data('id');
                var order_status_id = $('#order-status-history'+id).val();
                var notify = $('#order-status-notify'+id).val();
                var comment = $('#order-status-comment'+id).val();
         
                var data={
                    order_status_id: order_status_id,
                    notify: notify,
                    comment: comment,
                    _token: '{{csrf_token()}}'
                };
                console.log(data);
                $.post("{{url('admin/order/quick-add-order-history') }}/"+id, data, function(data){
                    console.log(data);
                    var daterange=$('#input-date-range').val();
                    var os=$('#input-order-status').val();
                    $('#table').DataTable().destroy();
                    var table=$('#table').DataTable({
                        "processing": true,
                        "serverSide": true,
                        "ajax":{
                                 "url": "{{ url('admin/order') }}",
                                 "dataType": "json",
                                 "type": "POST",
                                 "data":{ 
                                    _token: "{{csrf_token()}}",
                                    date_range: daterange,
                                    order_status_id: os
                                    }
                               },
                        "columns": [
                            { "data": "id",
                              "orderable": false
                            },
                            { "data": "invoice",
                              "className": 'details-control'
                            },
                            { "data": "name", },
                            { "data": "status", },
                            { "data": "total", },
                            { "data": "created_at", },
                            { "data": "updated_at", },
                            { "data": "action",
                              "orderable": false
                            }
                        ],
                        "createdRow": function( row, data, dataIndex){
                            if( data.status ==  `complete`){
                                $(row).addClass('info');
                            }else if( data.status ==  `pending`){
                                $(row).addClass('warning');
                            }else if( data.status ==  `processing` ||  data.status ==  `processed`){
                                $(row).addClass('success');
                            }
                        }      

                    });
                });
            });
        

        $( "input:checked" ).val()
        $('#delete').on('click',function(){
            swal({
                  title: 'Are you sure?',
                  text: "You won't be able to revert this!",
                  type: 'warning',
                  showCancelButton: true,
                  confirmButtonColor: '#3085d6',
                  cancelButtonColor: '#d33',
                  confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                  if (result.value) {
                    $('#form').submit();
                  }
                })
        });

        $(document).ready(function () {
            $('.date-range').daterangepicker({
                "autoUpdateInput": false,
                timePicker: true,
                timePickerIncrement: 30,
                locale: {
                    format: 'MM/DD/YYYY h:mm A'
                }
            });
            
        });

        var table=$('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax":{
                         "url": "{{ url('admin/order') }}",
                         "dataType": "json",
                         "type": "POST",
                         "data":{ _token: "{{csrf_token()}}"}
                       },
                "columns": [
                    { "data": "id",
                      "orderable": false
                    },
                    { "data": "invoice",
                      "className": 'details-control'
                    },
                    { "data": "name", },
                    { "data": "status", },
                    { "data": "total", },
                    { "data": "created_at", },
                    { "data": "updated_at", },
                    { "data": "action",
                      "orderable": false
                    }
                ],
                "createdRow": function( row, data, dataIndex){
                    if( data.status ==  `complete`){
                        $(row).addClass('info');
                    }else if( data.status ==  `pending`){
                        $(row).addClass('warning');
                    }else if( data.status ==  `processing` ||  data.status ==  `processed`){
                        $(row).addClass('success');
                    }
                }   

            });

            

        var start = moment().subtract(1, 'years');
        var end = moment();

        function cb(start, end) {
            $('#set-date-range span').html(start.format('MM/DD/YYYY h:mm A') + ' - ' + end.format('MM/DD/YYYY h:mm A'));
            $('.date-range').val(start.format('MM/DD/YYYY h:mm A') + ' - ' + end.format('MM/DD/YYYY h:mm A'));
            var daterange=$('.date-range').val();
            var os=$('#input-order-status').val();
            $('#table').DataTable().destroy();
            var table=$('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax":{
                         "url": "{{ url('admin/order') }}",
                         "dataType": "json",
                         "type": "POST",
                         "data":{ 
                            _token: "{{csrf_token()}}",
                            date_range: daterange,
                            order_status_id: os
                            }
                       },
                "columns": [
                    { "data": "id",
                      "orderable": false
                    },
                    { "data": "invoice",
                      "className": 'details-control'
                    },
                    { "data": "name", },
                    { "data": "status", },
                    { "data": "total", },
                    { "data": "created_at", },
                    { "data": "updated_at", },
                    { "data": "action",
                      "orderable": false
                    }
                ],
                "createdRow": function( row, data, dataIndex){
                    if( data.status ==  `complete`){
                        $(row).addClass('info');
                    }else if( data.status ==  `pending`){
                        $(row).addClass('warning');
                    }else if( data.status ==  `processing` ||  data.status ==  `processed`){
                        $(row).addClass('success');
                    }
                }      

            });
            
        }

        $('#set-date-range').daterangepicker({
            "autoUpdateInput": false,
             "showCustomRangeLabel": false,
            startDate: start,
            endDate: end,
            ranges: {
               '< 12 Hour': [moment().subtract(12, 'hours'), moment()],
               '< 24 Hour': [moment().subtract(24, 'hours'), moment()],
               '> 24 Hour': [moment().subtract(1, 'years'), moment()]
               {{-- 'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
               'Last 7 Days': [moment().subtract(6, 'days'), moment()],
               'Last 30 Days': [moment().subtract(29, 'days'), moment()],
               'This Month': [moment().startOf('month'), moment().endOf('month')],
               'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')] --}}
            }
        }, cb);

        $('#set-date-range span').html(start.format('MM/DD/YYYY h:mm A') + ' - ' + end.format('MM/DD/YYYY h:mm A'));

        $('.date-range').on('apply.daterangepicker', function(ev, picker){
            $(this).val(picker.startDate.format('MM/DD/YYYY h:mm A') + ' - ' + picker.endDate.format('MM/DD/YYYY h:mm A'));
            console.log($(this).val());
            var daterange=$(this).val();
            var os=$('#input-order-status').val();
            $('#table').DataTable().destroy();
            var table=$('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax":{
                         "url": "{{ url('admin/order') }}",
                         "dataType": "json",
                         "type": "POST",
                         "data":{ 
                            _token: "{{csrf_token()}}",
                            date_range: daterange,
                            order_status_id: os
                            }
                       },
                "columns": [
                    { "data": "id",
                      "orderable": false
                    },
                    { "data": "invoice",
                      "className": 'details-control'
                    },
                    { "data": "name", },
                    { "data": "status", },
                    { "data": "total", },
                    { "data": "created_at", },
                    { "data": "updated_at", },
                    { "data": "action",
                      "orderable": false
                    }
                ],
                "createdRow": function( row, data, dataIndex){
                    if( data.status ==  `complete`){
                        $(row).addClass('info');
                    }else if( data.status ==  `pending`){
                        $(row).addClass('warning');
                    }else if( data.status ==  `processing` ||  data.status ==  `processed`){
                        $(row).addClass('success');
                    }
                }      

            });
            
        });

        $('#input-order-status').on('change', function(){
            var daterange=$('#input-date-range').val();
            var os=$(this).val();
            $('#table').DataTable().destroy();
            var table=$('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax":{
                         "url": "{{ url('admin/order') }}",
                         "dataType": "json",
                         "type": "POST",
                         "data":{ 
                            _token: "{{csrf_token()}}",
                            date_range: daterange,
                            order_status_id: os
                            }
                       },
                "columns": [
                    { "data": "id",
                      "orderable": false
                    },
                    { "data": "invoice",
                      "className": 'details-control'
                    },
                    { "data": "name", },
                    { "data": "status", },
                    { "data": "total", },
                    { "data": "created_at", },
                    { "data": "updated_at", },
                    { "data": "action",
                      "orderable": false
                    }
                ],
                "createdRow": function( row, data, dataIndex){
                    if( data.status ==  `complete`){
                        $(row).addClass('info');
                    }else if( data.status ==  `pending`){
                        $(row).addClass('warning');
                    }else if( data.status ==  `processing` ||  data.status ==  `processed`){
                        $(row).addClass('success');
                    }
                }     

            });
            
        });





    </script>
@endsection