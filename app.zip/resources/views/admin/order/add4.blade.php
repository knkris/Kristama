
<div class="tab-pane fade" id="shipping">
    <div class="form-group required">
        <label class="col-sm-2 control-label" for="shipping_address_id">
            Choose Address
        </label>
        <div class="col-sm-10">
            <select name="shipping_address_id" id="shipping_address_id" class="form-control address">
                <option></option>
                                                             
            </select>
        </div>
        @if ($errors->has('shipping_address_id'))
            <span class="help-block">
                <strong>{{ $errors->first('shipping_address_id') }}</strong>
            </span>
        @endif
    </div>

    <div class="form-group required">
        <label class="col-sm-2 control-label" for="shipping_name">
            Name
        </label>
        <div class="col-sm-10">
            <input type="text" name="shipping_name" value="{{ old('shipping_name') }}" placeholder="Name" id="shipping_name" class="form-control">
        </div>
        @if ($errors->has('shipping_name'))
            <span class="help-block">
                <strong>{{ $errors->first('shipping_name') }}</strong>
            </span>
        @endif
    </div>

    <div class="form-group required">
        <label class="col-sm-2 control-label" for="shipping_company">
            Company
        </label>
        <div class="col-sm-10">
            <input type="text" name="shipping_company" value="{{ old('shipping_company') }}" placeholder="shipping_Company" id="shipping_company" class="form-control">
        </div>
        @if ($errors->has('shipping_company'))
            <span class="help-block">
                <strong>{{ $errors->first('shipping_company') }}</strong>
            </span>
        @endif
    </div>

    <div class="form-group required">
        <label class="col-sm-2 control-label" for="shipping_address">
            Address
        </label>
        <div class="col-sm-10">
            <textarea name="shipping_address" placeholder="shipping_address" id="shipping_address" class="form-control">{{ old('shipping_address') }}</textarea>
        </div>
        @if ($errors->has('shipping_address'))
            <span class="help-block">
                <strong>{{ $errors->first('shipping_address') }}</strong>
            </span>
        @endif
    </div>

    <div class="form-group required">
        <label class="col-sm-2 control-label" for="shipping_city">
            City
        </label>
        <div class="col-sm-10">
            <select name="shipping_city" id="shipping_city" class="form-control city">
                @if(old('shipping_city'))
                <option value="{{ old('shipping_city') }}" selected>{{ old('shipping_city') }}</option>
                @endif
            </select>
        </div>
        @if ($errors->has('shipping_city'))
            <span class="help-block">
                <strong>{{ $errors->first('shipping_city') }}</strong>
            </span>
        @endif
    </div>

    <div class="form-group required">
        <label class="col-sm-2 control-label" for="shipping_postal_code">
            Postal Code
        </label>
        <div class="col-sm-10">
            <input type="text" name="shipping_postal_code" value="{{ old('shipping_postal_code') }}" placeholder="postal code" id="shipping_postal_code" class="form-control">
        </div>
        @if ($errors->has('shipping_postal_code'))
            <span class="help-block">
                <strong>{{ $errors->first('shipping_postal_code') }}</strong>
            </span>
        @endif
    </div>

    <div class="form-group required">
        <label class="col-sm-2 control-label" for="shipping_province">
            Province
        </label>
        <div class="col-sm-10">
            <select name="shipping_province" placeholder="province" id="shipping_province" class="form-control">
                @foreach($province as $key=>$value)
                    <option value="{{$value->name}}" @if(old('shipping_province')==$value->name) selected @endif>{{$value->name}}</option>
                @endforeach
            </select>
        </div>
        @if ($errors->has('shipping_province'))
            <span class="help-block">
                <strong>{{ $errors->first('shipping_province') }}</strong>
            </span>
        @endif
    </div>

    <div class="form-group required">
        <label class="col-sm-2 control-label" for="shipping_telephone">
            Telephone
        </label>
        <div class="col-sm-10">
            <input type="text" name="shipping_telephone" value="{{ old('shipping_telephone') }}" placeholder="telephone" id="shipping_telephone" class="form-control">
        </div>
        @if ($errors->has('shipping_telephone'))
            <span class="help-block">
                <strong>{{ $errors->first('shipping_telephone') }}</strong>
            </span>
        @endif
    </div>

    <br><br>
    <div class="row">
        <div class="col-xs-12">
            <button type="button" data-page="payment" data-from="shipping" data-type="back" class="btn btn-default nav-btn">Back</button>
            <div class="pull-right">
                <button type="button" data-page="total" data-from="shipping" data-type="next" class="btn btn-primary nav-btn">Continue</button>
            </div>
        </div>
    </div>


</div>
                                
                            