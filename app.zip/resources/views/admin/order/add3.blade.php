
<div class="tab-pane fade" id="payment">
    <div class="form-group required">
        <label class="col-sm-2 control-label" for="payment_address_id">
            Choose Address
        </label>
        <div class="col-sm-10">
            <select name="payment_address_id" id="payment_address_id" class="form-control address">
                <option></option>
                                                             
            </select>
        </div>
        @if ($errors->has('payment_address_id'))
            <span class="help-block">
                <strong>{{ $errors->first('payment_address_id') }}</strong>
            </span>
        @endif
    </div>

    <div class="form-group required">
        <label class="col-sm-2 control-label" for="payment_name">
            Name
        </label>
        <div class="col-sm-10">
            <input type="text" name="payment_name" value="{{ old('payment_name') }}" placeholder="Name" id="payment_name" class="form-control">
        </div>
        @if ($errors->has('payment_name'))
            <span class="help-block">
                <strong>{{ $errors->first('payment_name') }}</strong>
            </span>
        @endif
    </div>

    <div class="form-group required">
        <label class="col-sm-2 control-label" for="payment_company">
            Company
        </label>
        <div class="col-sm-10">
            <input type="text" name="payment_company" value="{{ old('payment_company') }}" placeholder="payment_Company" id="payment_company" class="form-control">
        </div>
        @if ($errors->has('payment_company'))
            <span class="help-block">
                <strong>{{ $errors->first('payment_company') }}</strong>
            </span>
        @endif
    </div>

    <div class="form-group required">
        <label class="col-sm-2 control-label" for="payment_address">
            Address
        </label>
        <div class="col-sm-10">
            <textarea name="payment_address" placeholder="payment_address" id="payment_address" class="form-control">{{ old('payment_address') }}</textarea>
        </div>
        @if ($errors->has('payment_address'))
            <span class="help-block">
                <strong>{{ $errors->first('payment_address') }}</strong>
            </span>
        @endif
    </div>

    <div class="form-group required">
        <label class="col-sm-2 control-label" for="payment_city">
            City
        </label>
        <div class="col-sm-10">
            <select name="payment_city" id="payment_city" class="form-control city">
                @if(old('payment_city'))
                <option value="{{ old('payment_city') }}" selected>{{ old('payment_city') }}</option>
                @endif
            </select>
        </div>
        @if ($errors->has('payment_city'))
            <span class="help-block">
                <strong>{{ $errors->first('payment_city') }}</strong>
            </span>
        @endif
    </div>

    <div class="form-group required">
        <label class="col-sm-2 control-label" for="payment_postal_code">
            Postal Code
        </label>
        <div class="col-sm-10">
            <input type="text" name="payment_postal_code" value="{{ old('payment_postal_code') }}" placeholder="postal code" id="payment_postal_code" class="form-control">
        </div>
        @if ($errors->has('payment_postal_code'))
            <span class="help-block">
                <strong>{{ $errors->first('payment_postal_code') }}</strong>
            </span>
        @endif
    </div>

    <div class="form-group required">
        <label class="col-sm-2 control-label" for="payment_province">
            Province
        </label>
        <div class="col-sm-10">
            <select name="payment_province" placeholder="province" id="payment_province" class="form-control">
                @foreach($province as $key=>$value)
                    <option value="{{$value->name}}" @if(old('payment_province')==$value->name) selected @endif>{{$value->name}}</option>
                @endforeach
            </select>
        </div>
        @if ($errors->has('payment_province'))
            <span class="help-block">
                <strong>{{ $errors->first('payment_province') }}</strong>
            </span>
        @endif
    </div>

    <div class="form-group required">
        <label class="col-sm-2 control-label" for="payment_telephone">
            Telephone
        </label>
        <div class="col-sm-10">
            <input type="text" name="payment_telephone" value="{{ old('payment_telephone') }}" placeholder="telephone" id="payment_telephone" class="form-control">
        </div>
        @if ($errors->has('payment_telephone'))
            <span class="help-block">
                <strong>{{ $errors->first('payment_telephone') }}</strong>
            </span>
        @endif
    </div>

    <br><br>
    <div class="row">
        <div class="col-xs-12">
            <button type="button" data-page="product" data-from="payment" data-type="back" class="btn btn-default nav-btn">Back</button>
            <div class="pull-right">
                <button type="button" data-page="shipping" data-from="payment" data-type="next" class="btn btn-primary nav-btn">Continue</button>
            </div>
        </div>
    </div>


</div>
                                
                            