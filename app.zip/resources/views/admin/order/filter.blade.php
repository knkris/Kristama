<div class="well">
          <div class="row">
            <div class="col-sm-4">
              <div class="form-group">
                <label class="control-label" for="input-date-range">Date</label>
                  <input type="text" name="filter_date_modified" value="" placeholder="Date Range" id="input-date-range" class="form-control date-range">
              </div>
            </div>
            <div class="col-sm-4">
              <div class="form-group">
                <label class="control-label" for="input-order-status">Order Status</label>
                <select name="filter_order_status" id="input-order-status" class="form-control">
                  <option value=""></option>
                  @foreach($order_status as $key => $value)
                    <option value="{{$value->id}}">{{$value->name_en}}</option>
                  @endforeach
                </select>
              </div>
            </div>
            <div class="col-sm-4">
              <div class="form-group">
                <label class="control-label" for="set-date-range">Range</label>
                  <div id="set-date-range" class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; width: 100%">
                    <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
                    <span></span> <b class="caret"></b>
                </div>
              </div>
            </div>
            {{-- <div class="col-sm-4">
            </div>
            <div class="col-sm-12">
              <button type="button" id="button-filter" class="btn btn-primary pull-right"><i class="fa fa-filter"></i> Filter</button>
            </div> --}}
          </div>
        </div>