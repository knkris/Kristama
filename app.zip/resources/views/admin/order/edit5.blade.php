@extends('layouts.admin')

@section('title')
    Edit Order
@endsection

@section('head')
    <!-- include summernote css/js-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.min.css">

    

    <style type="text/css">
        textarea {
            overflow-x: hidden;
        }
        .my-group .form-control{
            width:50%;
        }
        .nav-tabs {
            margin-bottom: 25px;
        }
        .loader-small {
            border: 16px solid #f3f3f3; /* Light grey */
            border-top: 16px solid #3498db; /* Blue */
            border-radius: 50%;
            width: 30px;
            height: 30px;
            animation: spin 2s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
@endsection

@section('content')
     <div id="page-wrapper">
        <form id="form" role="form" action="{{ url('admin/order/edit/5',$results->id) }}" class="form-horizontal" enctype="multipart/form-data" method="post">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Edit Order
                        <div class="pull-right">
                            <button type="submit" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Save" aria-describedby="tooltip815756">
                                <i class="fa fa-save"></i>
                            </button>
                            <a href="{{ url('admin/order') }}" class="btn btn-default" data-original-title="Cancel">
                                <i class="fa fa-reply"></i>
                            </a>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/order') }}">Order</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-pencil"></i> Edit Order {{ $results->id }}
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">   

                            <!-- /.panel-heading -->
                        <div class="panel-body">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs nav-justified">
                                <li class=""><a href="{{url('admin/order/edit/1',$results->id)}}">1.Customer Details</a>
                                </li>
                                <li><a href="{{url('admin/order/edit/2',$results->id)}}">2.Products</a>
                                </li>
                                <li class=""><a href="{{url('admin/order/edit/3',$results->id)}}">3.Payment Details</a>
                                </li>
                                <li class=""><a href="{{url('admin/order/edit/4',$results->id)}}">4.Shipping Details</a>
                                </li>
                                <li class="active"><a href="{{url('admin/order/edit/5',$results->id)}}">5.Totals</a>
                                </li>
                            </ul>

                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane fade in active" id="product">
                                    <div class="table-responsive">
                                        <table class="table table-bordered">
                                          <thead>
                                            <tr>
                                              <td class="text-left">Product</td>
                                              <td class="text-left">Model</td>
                                              <td class="text-right">Qty</td>
                                              <td class="text-right">Unit Price</td>
                                              <td class="text-right">Total</td>
                                            </tr>
                                          </thead>
                                          <tbody id="cart">
                                            <?php
                                                $subtotal=0;
                                            ?>
                                            @foreach($orderdetail as $key=>$od)
                                            <?php 
                                                $product=$od->Product;
                                                //$stocks=$od->ProductStock;
                                            ?>
                                            <tr id="tr-{{$od->id}}">
                                              <td class="text-left">
                                                {{$product->name}} 
                                                {{-- <span class="text-danger">***</span> --}}
                                                <br>
                                                
                                                <?php /*
                                                @foreach($stocks->ProductStockDetail as $stock)
                                                <?php   
                                                    $ov=$stock->ProductOptionDetail->OptionValue;
                                                ?>
                                                  - <small>{{$ov->Option->name}}: {{$ov->name}}</small><br>
                                                  
                                                @endforeach 
                                                */ ?>
                                              </td>  
                                              <td class="text-left">
                                                  {{$product->model}}
                                              </td>  
                                              <td class="text-right">
                                                {{$od->qty}}
                                              </td>  
                                              <td class="text-right" id="price{{$od->id}}">{{currency_format($od->price,'IDR')}}</td>  
                                              <td class="text-right" id="total{{$od->id}}">{{currency_format($od->price*$od->qty,'IDR')}}</td>  
                                              <?php
                                                $subtotal=$subtotal+$od->price*$od->qty;
                                              ?>
                                            </tr>
                                            @endforeach
                                            <tr>
                                              <td class="text-right" colspan="4">
                                                  Sub-Total:
                                              </td>  
                                              <td class="text-right">
                                                  {{currency_format($subtotal,'IDR')}}
                                              </td>
                                          </tr>
                                          <tr>  
                                            <td class="text-right" colspan="4">
                                                Transfer Code:
                                            </td>  
                                            <td class="text-right">{{currency_format($results->transfer_code,'IDR')}}</td>
                                          </tr>
                                          <tr>
                                            <td class="text-right" colspan="4">
                                                Total:
                                            </td>  
                                            <td class="text-right">{{currency_format($subtotal+$results->transfer_code,'IDR')}}</td>
                                          </tr>
                                          </tbody>
                                        </table>
                                      </div>

                                  <legend>Order Detail</legend>

                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="shipping_method">
                                            Shipping Method
                                        </label>
                                        <div class="col-sm-10">
                                            <select name="shipping_method" id="shipping_method" class="form-control">
                                                {!! $shipping_option !!}
                                            </select>
                                        </div>
                                        @if ($errors->has('shipping_method'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('shipping_method') }}</strong>
                                            </span>
                                        @endif
                                    </div>


                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="payment_method">
                                            Payment Method
                                        </label>
                                        <div class="col-sm-10">
                                            <select name="payment_method" id="payment_method" class="form-control">
                                                @foreach($payment_method as $key => $value)
                                                    <option value="{{$value->name}}" @if($results->payment_method==$value->name) selected @endif>{{$value->name}}</option>
                                                @endforeach
                                                {{-- <option value="bank transfer" @if($results->payment_method=='bank transfer') selected @endif>Bank Transfer</option> --}}
                                            </select>
                                        </div>
                                        @if ($errors->has('payment_method'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('payment_method') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="order_status">
                                            Order Status
                                        </label>
                                        <div class="col-sm-10">
                                            <select name="order_status" id="order_status" class="form-control">
                                                @foreach($orderstatus as $os)
                                                <option value="{{$os->id}}" @if($results->order_status_id==$os->id) selected @endif>{{ $os->name_en }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        @if ($errors->has('order_status'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('order_status') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="comment">
                                            Comment
                                        </label>
                                        <div class="col-sm-10">
                                            <textarea name="comment" placeholder="comment" id="comment" class="form-control">{{ $results->comment }}</textarea>
                                        </div>
                                        @if ($errors->has('comment'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('comment') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                </div>
                                
                            </div>
                        </div>
                        <!-- /.panel-body -->                         
                            

                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            

            </form>
        </div>
        <!-- /#page-wrapper -->
@endsection

@section('script')
    <!-- include summernote css/js-->
    <script src="{{ asset('js/summernote.js') }}"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js"></script>
    <script>
        
        
        $(document).ready(function() {
            $('#shipping_method').val('{{$results->shipping_courier."_".$results->courier_service."_".floatval($results->shipping_cost)}}');
            $('.summernote').summernote({
                height: 200
            });
            $('.select2').select2();
            $('.product').select2({
                placeholder: "Choose Product...",
                ajax: {
                    url: '{{ url('admin/order/search-product')}}',
                    dataType: 'json',
                    data: function (params) {
                        return {
                            q: $.trim(params.term)
                        };
                    },
                    processResults: function (data) {
                        return {
                            results: data
                        };
                    },
                    cache: true
                }
            });

            
            
            
        });

        

        
    </script>

@endsection