@extends('layouts.admin')

@section('title')
    View Order
@endsection

@section('head')
@endsection

@section('content')
     <div id="page-wrapper">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        View Order
                        <div class="pull-right">
                            <button type="submit" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Save" aria-describedby="tooltip815756">
                                <i class="fa fa-save"></i>
                            </button>
                            <a href="{{ url('admin/order') }}" class="btn btn-default" data-original-title="Cancel">
                                <i class="fa fa-reply"></i>
                            </a>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/order') }}">Order</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <div class="row">
                <div class="col-md-6">
                    <div class="panel panel-default">
                      <div class="panel-heading">
                        <h3 class="panel-title"><i class="fa fa-shopping-cart"></i> Order Detail</h3>
                      </div>
                      <table class="table">
                        <tbody>
                          <tr>
                            <td style="width: 1%;"><button data-toggle="tooltip" title="" class="btn btn-info btn-xs" data-original-title="Store"><i class="fa fa-shopping-cart fa-fw"></i></button></td>
                            <td><a href="{{url('/')}}" target="_blank">{{ env('APP_NAME', 'Laravel') }}</a></td>
                          </tr>
                          <tr>
                            <td><button data-toggle="tooltip" title="" class="btn btn-info btn-xs" data-original-title="Tanggal :"><i class="fa fa-calendar fa-fw"></i></button></td>
                            <td>{{\Carbon\Carbon::parse($results->created_at)->format('d/m/Y H:i:s')}}</td>
                          </tr>
                          <tr>
                            <td><button data-toggle="tooltip" title="" class="btn btn-info btn-xs" data-original-title="Metode Pembayaran:"><i class="fa fa-credit-card fa-fw"></i></button></td>
                            <td>{{ucfirst($results->payment_method)}}</td>
                          </tr>
                                        <tr>
                            <td><button data-toggle="tooltip" title="" class="btn btn-info btn-xs" data-original-title="Metode Pengiriman:"><i class="fa fa-truck fa-fw"></i></button></td>
                            <td>{{$results->shipping_courier." - ".$results->courier_service}}</td>
                          </tr>
                                      </tbody>
                      </table>
                    </div>
                  </div>               

                <div class="col-md-6">
                    <div class="panel panel-default">
                      <div class="panel-heading">
                        <h3 class="panel-title"><i class="fa fa-user"></i> Customer Details</h3>
                      </div>
                      <table class="table">
                        <tbody><tr>
                          <td style="width: 1%;"><button data-toggle="tooltip" title="" class="btn btn-info btn-xs" data-original-title="Customer:"><i class="fa fa-user fa-fw"></i></button></td>
                          <td>                <a href="#" target="_blank">{{$user->name}}</a>
                            </td>
                        </tr>
                        <tr>
                          <td><button data-toggle="tooltip" title="" class="btn btn-info btn-xs" data-original-title="Customer Group:"><i class="fa fa-group fa-fw"></i></button></td>
                          <td>{{$user->CustomerGroup->name}}</td>
                        </tr>
                        <tr>
                          <td><button data-toggle="tooltip" title="" class="btn btn-info btn-xs" data-original-title="E-Mail:"><i class="fa fa-envelope-o fa-fw"></i></button></td>
                          <td><a href="mailto:{{$user->email}}">{{$user->email}}</a></td>
                        </tr>
                        <tr>
                          <td><button data-toggle="tooltip" title="" class="btn btn-info btn-xs" data-original-title="Telp:"><i class="fa fa-phone fa-fw"></i></button></td>
                          <td>{{$user->telephone}}</td>
                        </tr>
                      </tbody></table>
                    </div>
                  </div>
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                      <div class="panel-heading">
                        <h3 class="panel-title"><i class="fa fa-info-circle"></i> Order Detail</h3>
                      </div>
                      <div class="panel-body">
                        <table class="table table-bordered">
                          <thead>
                            <tr>
                              <td style="width: 50%;" class="text-left">Payment Address</td>
                            <td style="width: 50%;" class="text-left">Shipping Address</td>
                          </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td class="text-left">
                                {{$results->payment_name}}<br>
                                {{$results->payment_address}}<br>
                                {{$results->payment_city}} {{$results->payment_postal_code}}<br>
                                {{$results->payment_province}}<br>
                                Indonesia
                              </td>
                              <td class="text-left">
                                {{$results->shipping_name}}<br>
                                {{$results->shipping_address}}<br>
                                {{$results->shipping_city}} {{$results->shipping_postal_code}}<br>
                                {{$results->shipping_province}}<br>
                                Indonesia
                              </td>
                            </tr>
                          </tbody>
                        </table>
                        <table class="table table-bordered">
                          <thead>
                            <tr>
                              <td class="text-left">Product</td>
                              <td class="text-left">Model</td>
                              <td class="text-right">Qty</td>
                              <td class="text-right">Unit Price</td>
                              <td class="text-right">Total</td>
                            </tr>
                          </thead>
                          <tbody>
                            <?php
                                $od=$results->OrderDetail;
                            ?>
                            @foreach($od as $value)
                            <?php
                            $product=$value->Product()->withTrashed()->first();
                            //$stocks=$value->ProductStock;
                            ?>
                            @if($product)
                            <tr>
                              <td class="text-left">
                                <a href="#">
                                    {{$product->name}}
                                </a><?php /* <br>
                                @foreach($stocks->ProductStockDetail as $stock)
                                <?php   
                                    $ov=$stock->ProductOptionDetail->OptionValue;
                                ?>
                                  - <small>{{$ov->Option->name}}: {{$ov->name}}</small><br>
                                  
                                @endforeach  */ ?>
                              </td>
                              <td class="text-left">{{$product->model}}</td>
                              <td class="text-right">{{$value->qty}}</td>
                              <td class="text-right">{{currency_format($value->price,'IDR')}}</td>
                              <td class="text-right">{{currency_format($value->qty*$value->price,'IDR')}}</td>
                            </tr>
                            @endif
                            @endforeach
                                                                <tr>
                              <td colspan="4" class="text-right">Sub-Total</td>
                              <td class="text-right">{{currency_format($results->subtotal,'IDR')}}</td>
                            </tr>
                                        <tr>
                              <td colspan="4" class="text-right">{{$results->shipping_courier." - ".$results->courier_service}}</td>
                              <td class="text-right">{{currency_format($results->shipping_cost,'IDR')}}</td>
                            </tr>
                                        <tr>
                              <td colspan="4" class="text-right">Transfer Code</td>
                              <td class="text-right">{{currency_format($results->transfer_code,'IDR')}}</td>
                            </tr>
                                        <tr>
                              <td colspan="4" class="text-right">Total</td>
                              <td class="text-right">{{currency_format($results->total,'IDR')}}</td>
                            </tr>
                                      </tbody>
                        </table>

                        @if(strlen($results->comment)>0)
                        <table class="table table-bordered">
                          <thead>
                            <tr>
                              <td>Comment:</td>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>{{$results->comment}}</td>
                            </tr>
                          </tbody>
                        </table>
                        @endif
                              </div>
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <div class="row">
                <form role="form" action="{{ url('admin/order/add-history/'.$results->id) }}" class="form-horizontal" enctype="multipart/form-data" method="post">
                {{ csrf_field() }}
                <div class="col-lg-12">
                    <div class="panel panel-default">
                      <div class="panel-heading">
                        <h3 class="panel-title"><i class="fa fa-comment"></i> Order Detail</h3>
                      </div>
                      <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <td class="text-left">Date Added</td>
                                        <td class="text-left">Comment</td>
                                        <td class="text-left">Status</td>
                                        <td class="text-left">Customer Notified</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $orderhistory=$results->OrderHistory()->orderBy('created_at')->get();
                                    ?>
                                    @foreach($orderhistory as $oh)
                                    <tr>
                                        <td class="text-left">{{\Carbon\Carbon::parse($oh->created_at)->format('d/m/Y H:i:s')}}</td>
                                        <td class="text-left">{{$oh->comment}}</td>
                                        <td class="text-left">{{$oh->OrderStatus()->withTrashed()->first()->name_en}}</td>
                                        <td class="text-left">
                                            {{ $oh->notify==1 ? 'Yes' : 'No' }}
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        <legend>Add Order History</legend>

                        <div class="form-group required">
                            <label class="col-sm-2 control-label" for="order_status">
                                Order Status
                            </label>
                            <div class="col-sm-10">
                                <select name="order_status" id="order_status_id" class="form-control order_status">
                                    <option></option>
                                    @foreach($orderstatus as $key=>$value)
                                        <option value="{{$value->id}}">{{ $value->name_en }}</option>
                                    @endforeach                                                
                                </select>
                            </div>
                            @if ($errors->has('order_status'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('order_status') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="form-group">
                            <label class="col-sm-2 control-label" for="input-notify">
                                Notify Customer
                            </label>
                            <div class="col-sm-10">
                                <input type="checkbox" name="notify" value="1" id="input-notify">
                            </div>
                        </div>

                        <div class="form-group required">
                            <label class="col-sm-2 control-label" for="comment">
                                Comment
                            </label>
                            <div class="col-sm-10">
                                <textarea name="comment" placeholder="comment" id="comment" class="form-control"></textarea>
                            </div>
                            @if ($errors->has('comment'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('comment') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="text-right">
                            <button type="submit" id="button-history" data-loading-text="Loading..." class="btn btn-primary">
                                <i class="fa fa-plus-circle"></i> Add History
                            </button>
                        </div>

                      </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
                </form>
            </div>
            <!-- /.row -->

            

            </form>
        </div>
        <!-- /#page-wrapper -->
@endsection

@section('script')
    

@endsection