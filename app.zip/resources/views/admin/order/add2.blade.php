
<div class="tab-pane fade" id="product">
    <div class="table-responsive">
        <table class="table table-bordered">
          <thead>
            <tr>
              <td class="text-left">Product</td>
              <td class="text-left">Model</td>
              <td class="text-right">Qty</td>
              <td class="text-right">Unit Price</td>
              <td class="text-right">Total</td>
              <td>Action</td>
            </tr>
          </thead>
          <tbody id="cart">
            <?php $count=count(old('product')); ?>
                @if($count>0)
                    @foreach(old('product') as $key=>$value)
                    <?php
                    $product=\App\Models\Product::find($value['id']);
                    $stock=\App\Models\ProductStock::find($value['product_stock_id']);
                    $stockDetail=$stock->ProductStockDetail;
                    ?>
                    <tr id='tr-{{$key}}'>
                        <td class='text-left'>
                            {{$product->name}}<br>
                            @foreach($stockDetail as $sd)
                            <?php $ov=$sd->ProductOptionDetail->OptionValue; ?>
                            - <small>{{$ov->Option->name.": ".$ov->name}}</small><br>
                            @endforeach
                        </td>
                        <td class='text-left'>
                            {{$product->model}}
                        </td>
                        <td class='text-right'>
                            <div class='input-group btn-block' style='max-width: 200px;'>
                                <input type='hidden' name='product[{{$key}}][id]' value='{{$value['id']}}'>
                                <input type='hidden' name='product[{{$key}}][product_stock_id]' value='{{$value['product_stock_id']}}'>
                                <input type='text' name='product[{{$key}}][quantity]' value='{{$value['quantity']}}' id='qty{{$key}}' class='form-control'>
                                <span class='input-group-btn'>
                                    <button type='button' id='qty-refresh{{$key}}' data-id='{{$key}}' data-toggle='tooltip' title=' data-loading-text='Loading...' class='btn btn-primary qty-refresh' data-original-title='Refresh'>
                                        <i class='fa fa-refresh'></i>
                                    </button>
                                </span>
                            </div>
                        </td>
                        <td class='text-right' id='price{{$key}}' data-price='{{$product->price}}'>
                            {{currency_format($product->price,'IDR')}}
                        </td>
                        <td class='text-right total' id='total{{$key}}' data-total='{{$product->price*$value['quantity']}}'>
                            {{currency_format($product->price*$value['quantity'],'IDR')}}
                        </td>
                        <td class='text-center' style='width: 3px;'>
                            <button type='button' data-id='{{$key}}' data-toggle='tooltip' title=' data-loading-text='Loading...' class='btn btn-danger remove-od' data-original-title='Remove'>
                                <i class='fa fa-minus-circle'></i>
                            </button>
                        </td>
                    </tr>
                    @endforeach
                @endif
          </tbody>
        </table>
      </div>

  <legend>Add Product(s)</legend>

    <div class="form-group required">
        <label class="col-sm-2 control-label" for="product">
            Choose Product
        </label>
        <div class="col-sm-10">
            <select name="product_id" id="product_id" class="form-control product">
                
            </select>
        </div>
        @if ($errors->has('product'))
            <span class="help-block">
                <strong>{{ $errors->first('product') }}</strong>
            </span>
        @endif
    </div>


    <div class="form-group required">
        <label class="col-sm-2 control-label" for="qty">
            Quantity
        </label>
        <div class="col-sm-10">
            <input type="number" name="qty" value="1" placeholder="Quantity" id="qty" class="form-control">
            <input type="hidden" name="product_stock_id" id="product_stock_id" value="">
        </div>
        @if ($errors->has('qty'))
            <span class="help-block">
                <strong>{{ $errors->first('qty') }}</strong>
            </span>
        @endif
    </div>

    <div class="form-group required">
        <label class="col-sm-2 control-label" for="product">
            Available Stock
            <input type="hidden" id="available-stock" value="0">
        </label>
        <div class="col-sm-10 available-stock">
            
        </div>
       
    </div>

    <div id="product-option"></div>

    
    <div class="pull-right add-product-box">
        <button type="button" id="add-product" class="btn btn-primary">Add Product</button>
    </div>

    <br><br>
    <div class="row">
        <div class="col-xs-12">
            <button type="button" data-page="customer" data-from="product" data-type="back" class="btn btn-default nav-btn">Back</button>
            <div class="pull-right">
                <button type="button" data-page="payment" data-from="product" data-type="next" class="btn btn-primary nav-btn">Continue</button>
            </div>
        </div>
    </div>

</div>
                            