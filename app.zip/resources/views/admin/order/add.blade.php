@extends('layouts.admin')

@section('title')
    Add Order
@endsection

@section('head')
    <!-- include summernote css/js-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.min.css">

    <style type="text/css">
        textarea {
            overflow-x: hidden;
        }
        .my-group .form-control{
            width:50%;
        }
        .nav-tabs {
            margin-bottom: 25px;
        }
        .select2-container{
            width:100% !important;
        }
        .loader-small {
            border: 16px solid #f3f3f3; /* Light grey */
            border-top: 16px solid #3498db; /* Blue */
            border-radius: 50%;
            width: 30px;
            height: 30px;
            animation: spin 2s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
@endsection

@section('content')
     <div id="page-wrapper">
        <form id="form" role="form" action="{{ url('admin/order/store') }}" class="form-horizontal" enctype="multipart/form-data" method="post">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Add Order
                        <div class="pull-right">
                            <button id="form-submit" type="submit" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Save" aria-describedby="tooltip815756" disabled="disabled">
                                <i class="fa fa-save"></i>
                            </button>
                            <a href="{{ url('admin/order') }}" class="btn btn-default" data-original-title="Cancel">
                                <i class="fa fa-reply"></i>
                            </a>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/order') }}">Order</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-pencil"></i> Add Order
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">   

                            <!-- /.panel-heading -->
                        <div class="panel-body">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs nav-justified">
                                <li id="customer-page" class="active"><a aria-expanded="false">1.Customer Details</a>
                                </li>
                                <li id="product-page" class="disabled"><a aria-expanded="false">2.Products</a>
                                </li>
                                <li id="payment-page" class="disabled"><a aria-expanded="false">3.Payment Details</a>
                                </li>
                                <li id="shipping-page" class="disabled"><a aria-expanded="false">4.Shipping Details</a>
                                </li>
                                <li id="total-page" class="disabled"><a aria-expanded="false">5.Totals</a>
                                </li>
                            </ul>

                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane fade in active" id="customer">
                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="customer">
                                            Customer
                                        </label>
                                        <div class="col-sm-10">
                                            <select name="customer" id="customer_id" class="form-control customer">
                                               
                                            </select>
                                        </div>
                                        @if ($errors->has('customer'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('customer') }}</strong>
                                            </span>
                                        @endif
                                    </div>


                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="customer_group">
                                            Customer Group
                                        </label>
                                        <div class="col-sm-10">
                                            <select name="customer_group" id="customer_group" class="form-control">
                                                @foreach($customer_group as $cg)
                                                <option value="{{$cg->id}}" @if(old('customer_group')==$cg->id) selected @endif>{{$cg->name}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        @if ($errors->has('customer_group'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('customer_group') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="name">
                                            Name
                                        </label>
                                        <div class="col-sm-10">
                                            <input type="text" name="name" value="{{ old('name') }}" placeholder="Customer Name" id="name" class="form-control">
                                        </div>
                                        @if ($errors->has('name'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('name') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="email">
                                            Email
                                        </label>
                                        <div class="col-sm-10">
                                            <input type="text" name="email" value="{{ old('email') }}" placeholder="Customer email" id="email" class="form-control">
                                        </div>
                                        @if ($errors->has('email'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('email') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="telephone">
                                            Telephone
                                        </label>
                                        <div class="col-sm-10">
                                            <input type="text" name="telephone" value="{{ old('telephone') }}" placeholder="Telephone" id="telephone" class="form-control">
                                        </div>
                                        @if ($errors->has('telephone'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('telephone') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="fax">
                                            Fax
                                        </label>
                                        <div class="col-sm-10">
                                            <input type="text" name="fax" value="{{ old('fax') }}" placeholder="Fax" id="fax" class="form-control">
                                        </div>
                                        @if ($errors->has('fax'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('fax') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    <div class="pull-right">
                                        <button type="button"" data-page="product" data-type="next" data-from="customer" class="btn btn-primary nav-btn">Continue</button>
                                    </div>

                                    




                                </div>

                                @include('admin.order.add2')
                                @include('admin.order.add3')
                                @include('admin.order.add4')
                                @include('admin.order.add5')
                                
                            </div>
                        </div>
                        <!-- /.panel-body -->                         
                            

                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            

            </form>
        </div>
        <!-- /#page-wrapper -->
@endsection

@section('script')
    <!-- include summernote css/js-->
    <script src="{{ asset('js/summernote.js') }}"></script>
    <script src="{{ asset('js/jquery.serialize-object.min.js') }}"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js"></script>
    <script>
        @if(old('product'))
        var cart={{count(old('product'))}};
        @else
        var cart=0;
        @endif
        @if(old('name'))
        <?php $user_id=\App\Models\User::whereName(old('name'))->first()->id; ?>
        var cust_id={{$user_id}};
        @else
        var cust_id=0;
        @endif
        
        var transfer_code={{old('transfer_code')?:$transfer_code}};
        function init(){
            $('.summernote').summernote({
                height: 200
            });
            $('.select2').select2();
            $('.customer').select2({
                placeholder: "Choose Option...",
                ajax: {
                    url: '{{ url('admin/order/search-user')}}',
                    dataType: 'json',
                    data: function (params) {
                        return {
                            q: $.trim(params.term)
                        };
                    },
                    processResults: function (data) {
                        return {
                            results: data
                        };
                    },
                    cache: true
                }
            });
            $('.product').select2({
                    placeholder: "Choose Product...",
                    ajax: {
                        url: '{{ url('admin/order/search-product')}}',
                        dataType: 'json',
                        data: function (params) {
                            return {
                                q: $.trim(params.term)
                            };
                        },
                        processResults: function (data) {
                            return {
                                results: data
                            };
                        },
                        cache: true
                    }
                });
            
            $('.city').select2({
                placeholder: "Choose Option...",
                ajax: {
                    url: '{{ url('admin/order/search-city')}}',
                    dataType: 'json',
                    quietMillis: 1000,
                    data: function (params) {
                        return {
                            q: $.trim(params.term)
                        };
                    },
                    processResults: function (data) {
                        return {
                            results: data
                        };
                    },
                    cache: true
                }
            });
            initAdd()
        }

        function initAdd(cust_id){
            $('.address').select2({
                placeholder: "Choose Option...",
                ajax: {
                    url: '{{ url('admin/order/search-address-by-user')}}/'+cust_id,
                    dataType: 'json',
                    quietMillis: 1000,
                    data: function (params) {
                        return {
                            q: $.trim(params.term)
                        };
                    },
                    processResults: function (data) {
                        return {
                            results: data
                        };
                    },
                    cache: true
                }
            });   
        }

        function activaTab(tab){
            $('.nav-tabs a[href="#' + tab + '"]').tab('show');
        };

        function isEmail(email) {
          var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
          return regex.test(email);
        }

        function validateCustomer(){
            var customer=$('#customer_id').val();
            cust_id=customer;
            var customer_group=$('#customer_group').val();
            var name=$('#name').val();
            var email=$('#email').val();
            var telephone=$('#telephone').val();
            var fax=$('#fax').val();
            console.log(customer, customer_group, name, email, telephone, fax);
            
            if(customer_group==""){
                swal('Error!', 'Please select customer group', 'error');
                return true;
            }
            if(name==""){
                swal('Error!', 'Name is required', 'error');
                return true;
            }
            if(email==""){
                swal('Error!', 'Email is required', 'error');
                return true;
            }else if(!isEmail(email)){
                swal('Error!', 'Please enter a valid email', 'error');
                return true;
            }
            if(telephone==""){
                swal('Error!', 'Telephone is required', 'error');
                return true;
            }
            
            return false;
        }

        function validateCart(){
            
            if(cart<1){
                swal('Error!', 'Please add at least 1 product', 'error');
                console.log($("input[name='product[]']").length);
                return true;
            }
            
            return false;
        }

        function validatePayment(){
            var payment_address_id=$('#payment_address_id').val();
            var payment_name=$('#payment_name').val();
            var payment_company=$('#payment_company').val();
            var payment_address=$('#payment_address').val();
            var payment_city=$('#payment_city').val();
            var payment_postal_code=$('#payment_postal_code').val();
            var payment_province=$('#payment_province').val();
            var payment_telephone=$('#payment_telephone').val();
            console.log(customer, customer_group, name, email, telephone, fax);
            
            if(payment_name==""){
                swal('Error!', 'Name is required', 'error');
                return true;
            }
            if(payment_company==""){
                swal('Error!', 'Company is required', 'error');
                return true;
            }
            if(payment_address==""){
                swal('Error!', 'Address is required', 'error');
                return true;
            }
            if(payment_city==""){
                swal('Error!', 'City is required', 'error');
                return true;
            }
            if(payment_postal_code==""){
                swal('Error!', 'Postal Code is required', 'error');
                return true;
            }
            if(payment_province==""){
                swal('Error!', 'Province is required', 'error');
                return true;
            }
            if(payment_telephone==""){
                swal('Error!', 'Telephone is required', 'error');
                return true;
            }
            
            return false;
        }

        function validateShipping(){
            var shipping_address_id=$('#shipping_address_id').val();
            var shipping_name=$('#shipping_name').val();
            var shipping_company=$('#shipping_company').val();
            var shipping_address=$('#shipping_address').val();
            var shipping_city=$('#shipping_city').val();
            var shipping_postal_code=$('#shipping_postal_code').val();
            var shipping_province=$('#shipping_province').val();
            var shipping_telephone=$('#shipping_telephone').val();
            console.log(customer, customer_group, name, email, telephone, fax);
            
            if(shipping_name==""){
                swal('Error!', 'Name is required', 'error');
                return true;
            }
            if(shipping_company==""){
                swal('Error!', 'Company is required', 'error');
                return true;
            }
            if(shipping_address==""){
                swal('Error!', 'Address is required', 'error');
                return true;
            }
            if(shipping_city==""){
                swal('Error!', 'City is required', 'error');
                return true;
            }
            if(shipping_postal_code==""){
                swal('Error!', 'Postal Code is required', 'error');
                return true;
            }
            if(shipping_province==""){
                swal('Error!', 'Province is required', 'error');
                return true;
            }
            if(shipping_telephone==""){
                swal('Error!', 'Telephone is required', 'error');
                return true;
            }
            
            return false;
        }

        $('.customer').on("change", function(e) { 
                $('.loader-box').show(); 
                $val=$(this).val();
               $.get("{{url('admin/order/get-user') }}/"+$val, function(data){
                console.log(data);
                $('.loader-box').hide();
                $('#customer_group').val(data.customer_group_id);
                $('#name').val(data.name);
                $('#email').val(data.email);
                $('#telephone').val(data.telephone);
                $('#fax').val(data.fax);
               });
            });
        
        $(document).ready(function() {
            init();
            $(".nav-tabs a[data-toggle=tab]").on("click", function(e) {
              if ($(this).hasClass("disabled")) {
                e.preventDefault();
                return false;
              }
            });
            
            
            
        });

        $(document).on("click", '.nav-btn', function(event) { 
            var page=$(this).data('page');
            var type=$(this).data('type');
            var from=$(this).data('from');
            var error=false;
            if(from=="customer"){
                error=validateCustomer();
            }
            if(from=="product"){
                error=validateCart();
            }
            if(from==="payment"){
                error=validatePayment();
            }
            if(from==="shipping"){
                error=validateShipping();
            }
                if(error==false){
                $('#'+page+'-page').removeClass('disabled');
                $('#'+page+'-page').children().attr('href','#'+page);
                $('#'+page+'-page').children().attr('data-toggle','tab');
                activaTab(page,function(){
                    init();
                });
                if(page==="total"){
                    getCost();
                    $('#form-submit').removeAttr('disabled');
                }else{
                    $('#form-submit').attr('disabled','disabled');
                }
                if(page==="payment" || page==="shipping"){
                    initAdd(cust_id);
                }

                if(from==="product"){ calculateTotal(); }

                $('#'+from+"-page").addClass('disabled');
                $('#'+from+"-page").children().removeAttr('href');
                $('#'+from+"-page").children().removeAttr('data-toggle');
            }
        });
    </script>

    <script> //product page
            

            function rupiah(bilangan){
                var reverse = bilangan.toString().split('').reverse().join(''),
                    ribuan  = reverse.match(/\d{1,3}/g);
                    ribuan  = ribuan.join('.').split('').reverse().join('');
                return ribuan;
            }

            function addRow(product,qty,product_stock_id,url){
                var flag=false;
                var ids=[];
                for(x=0;x<cart;x++){
                    if($("input[name='product["+x+"][id]'").val()==product.id && $("input[name='product["+x+"][product_stock_id]'").val()==product_stock_id){
                        flag=true;
                        var currentval=$('#qty'+x).val();
                        $('#qty'+x).val(parseInt(currentval)+parseInt(qty));
                        $( '#qty-refresh'+x ).trigger( "click" );
                    }
                    if($("input[name='product["+x+"][id]'").val()==product.id){
                        ids.push(x);
                    }
                }
                if(flag==false){
                    var options="";
                    for(i=0;i<product.options.length;i++){
                        options=options+"  - <small>"+product.options[i]+"</small><br>";
                    }
                    var content="<tr id='tr-"+cart+"'><td class='text-left'>"+product.name+"<br>"+options+"</td><td class='text-left'>"+product.model+"</td><td class='text-right'><div class='input-group btn-block' style='max-width: 200px;'><input type='hidden' name='product["+cart+"][id]' class='store-product-id' value='"+product.id+"' data-id='"+cart+"'><input type='hidden' name='product["+cart+"][product_stock_id]' value='"+product_stock_id+"'><input type='hidden' name='product["+cart+"][price]' value='"+product.price+"'><input type='hidden' name='product["+cart+"][subtotal]' value='"+product.subtotal+"'><input type='text' name='product["+cart+"][quantity]' value='"+qty+"' id='qty"+cart+"' class='form-control'><span class='input-group-btn'><button type='button' id='qty-refresh"+cart+"' data-id='"+cart+"' data-toggle='tooltip' title=' data-loading-text='Loading...' class='btn btn-primary qty-refresh' data-href='"+url+"' data-original-title='Refresh'><i class='fa fa-refresh'></i></button></span></div></td><td class='text-right' id='price"+cart+"' data-price='"+product.price+"'>"+product.price_idr+"</td><td class='text-right total' id='total"+cart+"' data-total='"+(qty*product.price)+"'>"+product.subtotal_idr+"</td><td class='text-center' style='width: 3px;'><button type='button' data-id='"+cart+"' data-toggle='tooltip' title=' data-loading-text='Loading...' class='btn btn-danger remove-od' data-original-title='Remove'><i class='fa fa-minus-circle'></i></button></td></tr>";
                    var contenttotal="<tr id='tr-total-"+cart+"'><td class='text-left'>"+product.name+"<br>"+options+"</td><td class='text-left'>"+product.model+"</td><td class='text-right' id='qty-total"+cart+"'>"+qty+"</td><td class='text-right' id='price-total"+cart+"' data-price='"+product.price+"'>"+product.price_idr+"</td><td class='text-right subtotal' id='subtotal"+cart+"' data-total='"+(qty*product.price)+"'>"+product.subtotal_idr+"</td></tr>";
                    $('#cart').append(content);
                    $('#cart-total').append(contenttotal);
                    cart++;
                }

                ids.forEach(function(item,index){
                    $( '#qty-refresh'+item ).trigger( "click" );
                    console.log(item);
                })
                
            }

            function generateOptions(index,data){
                var options="";
                var x;
                for (x = 0; x < data.options.length; ++x) {
                    options+="<option value='"+data.options[x].id+"'>"+data.options[x].name+"</option>";
                }
                $('#product-option').append("<div class='form-group required'><label class='col-sm-2 control-label' for='option["+index+"]'>"+data.name+"</label><div class='col-sm-10'><select name='option["+index+"]' id='option["+index+"]' class='form-control check-stock'>"+options+"</select></div></div>");
            }

            function calculateTotal(){
                var total=0;
                $(".total").each(function(){
                    total+=$(this).data('total');
                });
                $('#subtotal-foot').html('Rp'+rupiah(total));
                $('#total-foot').html('Rp'+rupiah(total+transfer_code));
            }

            function getCost(){
                $('.loader-box').show();
                var formData=$('#form').serializeObject();
                formData._token='{{csrf_token()}}';
                console.log(formData);
                $.post('{{ url('admin/order/get-cost') }}', formData, function(data){
                    console.log(data);
                    $('#shipping_method').html(data);
                    $('.loader-box').hide();
                });
            }

            

            $('.product').on("change", function(e) { 
                $('.loader-box').show(); 
                $val=$(this).val();
                console.log(e);
               $.get("{{url('admin/order/get-product-option') }}/"+$val, function(data){
                console.log(data);
                $('.loader-box').hide();
                //$('.available-stock').html(data[0].product.qty);
                if(data.length>0){
                    var index=0;
                    $('#product-option').html('');
                    $('#product-option').append("<legend>Choose Option(s)</legend>");
                    for (index = 0; index < data.length; ++index) {
    
                        
                        generateOptions(index,data[index]);
                        
                    }
                }
                checkStock();
               });
            });

            $('#add-product').on('click', function(){
                $('.loader-box').show();
                var product=$('#product_id').val();
                var qty=$('#qty').val();
                var total_same_prod=parseInt(qty);
                $(".store-product-id").each(function(){
                    $val=$(this).val();
                    $id=$(this).data('id');
                    $qty=$('#qty'+$id).val();
                    if($val==product){
                        total_same_prod=total_same_prod+parseInt($qty);
                    }
                });
                var qty=$('#qty').val();
                var available_stock=$('#available-stock').val();
                var product_stock_id=$('#product_stock_id').val();
                var customer_group_id=$('#customer_group').val();
                var url='{{url('admin/order/get-product') }}/'+customer_group_id+'/'+product+'/'+product_stock_id+'/';
                console.log(product,qty,product_stock_id,available_stock);
                if(parseInt(qty)<=parseInt(available_stock)){
                    $.get('{{url('admin/order/get-product') }}/'+customer_group_id+'/'+product+'/'+product_stock_id+'/'+qty+'/'+total_same_prod, { 
                       
                    },function(data){
                        console.log(data);
                        addRow(data,qty,product_stock_id,url);
                        $('.loader-box').hide();
                    }).fail(function(data) {
                        
                        $('.loader-box').hide();
                   });
               }else{
                   swal('Error!','Quantity cannot more than available stock!','error');
                   $('.loader-box').hide();
               }
               
            });


        

        function checkStock(){
            $('.available-stock').html("<div class='loader-small'></div>");
            var combination=[];
            $('.check-stock').each(function(){
                combination.push($(this).val());
            });
            console.log(combination);
            $.get("{{url('admin/order/check-stock') }}", { combination: combination })
              .done(function( data ) {
                console.log(data);
                if (data.hasOwnProperty('qty')){
                    $('.available-stock').html(data.qty);
                    $('#available-stock').val(data.qty);
                    $('#product_stock_id').val(data.id);
                    
                }else{
                    $('.available-stock').html(0);
                }
                $('.loader-box').hide();
              });
              
        }

        $(document).on("change", '.check-stock', function(event) { 
            checkStock();
        });

       $(document).on("click", '.qty-refresh', function(event) { 

            $(".qty-refresh").each(function(){
                var id=$(this).data('id');
                var total_same_prod=0;
                var product=$("input[name='product["+id+"][id]'").val();

                var href=$(this).data('href');
                var qty=$('#qty'+id).val();
                var available_stock=$('#available-stock').val();
                var price=$('#price'+id).data('price');
                var btn=$(this);
                btn.button('loading');

                $(".store-product-id").each(function(){
                    $val=$(this).val();
                    $id=$(this).data('id');
                    $qty=$('#qty'+$id).val();
                    if($val==product){
                        total_same_prod=total_same_prod+parseInt($qty);
                    }

                });
                
                
                $.get(href+qty+'/'+total_same_prod, { 
                       
                    },function(data){
                        console.log(data);
                        if(parseInt(qty)<=parseInt(available_stock)){
                            var sum=qty*price;
                            console.log(sum);
                            $('#total'+id).data('total',sum);
                            //$('#total'+id).html(data.price_idr);
                            $('#price'+id).html(data.price_idr);
                            $('#total'+id).html(data.subtotal_idr);
                            $('#qty-total'+id).html(qty);
                            $('#subtotal'+id).data('total',sum);
                            $('#subtotal'+id).html(data.subtotal_idr);
                            calculateTotal();
                        }else{
                           swal('Error!','Quantity cannot more than available stock!','error');
                           $('.loader-box').hide();
                        }
                        btn.button('reset');
                    }).fail(function(data) {
                        console.log(data);
                   });

               });
                
            });

        $(document).on("click", '.remove-od', function(event) { 
            var id=$(this).data('id');
            $('#tr-'+id).remove();
            $('#tr-total-'+id).remove();
        });
    </script>
    <script>
        $('#payment_address_id').on("change", function(e) { 
                $val=$(this).val();
                if($val!=""){
                $('.loader-box').show();
                   $.get("{{url('admin/order/get-address-by-user') }}/"+cust_id, { id: $val }, function(data){
                    console.log(data);
                    $('.loader-box').hide();
                    $('#payment_name').val(data.name);
                    $('#payment_company').val(data.company);
                    $('#payment_address').val(data.address);
                    $('#payment_postal_code').val(data.postal_code);
                    $('#payment_province').val(data.province);
                    $('#payment_telephone').val(data.telephone);
                    $('#payment_city').append("<option value='"+data.city+"'>"+data.city+"</option>");
                    $('#payment_city').val(data.city).trigger('change.select2');
                   });
                }
            });
    </script>
    <script>
        $('#shipping_address_id').on("change", function(e) { 
                $val=$(this).val();
                if($val!=""){
                $('.loader-box').show();
                   $.get("{{url('admin/order/get-address-by-user') }}/"+cust_id, { id: $val }, function(data){
                    console.log(data);
                    $('.loader-box').hide();
                    $('#shipping_name').val(data.name);
                    $('#shipping_company').val(data.company);
                    $('#shipping_address').val(data.address);
                    $('#shipping_postal_code').val(data.postal_code);
                    $('#shipping_province').val(data.province);
                    $('#shipping_telephone').val(data.telephone);
                    $('#shipping_city').append("<option value='"+data.city+"'>"+data.city+"</option>");
                    $('#shipping_city').val(data.city).trigger('change.select2');
                   });
                }
            });
    </script>

@endsection