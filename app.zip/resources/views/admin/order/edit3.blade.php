@extends('layouts.admin')

@section('title')
    Edit Order
@endsection

@section('head')
    <!-- include summernote css/js-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.min.css">

    <style type="text/css">
        textarea {
            overflow-x: hidden;
        }
        .my-group .form-control{
            width:50%;
        }
        .nav-tabs {
            margin-bottom: 25px;
        }
    </style>
@endsection

@section('content')
     <div id="page-wrapper">
        <form role="form" action="{{ url('admin/order/edit/3/'.$results->id) }}" class="form-horizontal" enctype="multipart/form-data" method="post">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Edit Order
                        <div class="pull-right">
                            <button type="submit" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Save" aria-describedby="tooltip815756">
                                <i class="fa fa-save"></i>
                            </button>
                            <a href="{{ url('admin/order') }}" class="btn btn-default" data-original-title="Cancel">
                                <i class="fa fa-reply"></i>
                            </a>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/order') }}">Order</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-pencil"></i> Edit Order {{ $results->id }}
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">   

                            <!-- /.panel-heading -->
                        <div class="panel-body">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs nav-justified">
                                <li><a href="{{url('admin/order/edit/1',$results->id)}}">1.Customer Details</a>
                                </li>
                                <li class=""><a href="{{url('admin/order/edit/2',$results->id)}}">2.Products</a>
                                </li>
                                <li class="active"><a href="{{url('admin/order/edit/3',$results->id)}}">3.Payment Details</a>
                                </li>
                                <li class=""><a href="{{url('admin/order/edit/4',$results->id)}}">4.Shipping Details</a>
                                </li>
                                <li class=""><a href="{{url('admin/order/edit/5',$results->id)}}">5.Totals</a>
                                </li>
                            </ul>

                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane fade in active" id="payment">
                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="address">
                                            Choose Address
                                        </label>
                                        <div class="col-sm-10">
                                            <select name="address" id="address_id" class="form-control address">
                                                <option></option>
                                                @foreach($address as $key=>$value)
                                                    <option value="{{$value->id}}">{{ $value->name.', '.$value->address.', '.$value->city.', '.$value->province }}</option>
                                                @endforeach                                                
                                            </select>
                                        </div>
                                        @if ($errors->has('address'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('address') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="name">
                                            Name
                                        </label>
                                        <div class="col-sm-10">
                                            <input type="text" name="name" value="{{ $results->payment_name }}" placeholder="Name" id="name" class="form-control">
                                        </div>
                                        @if ($errors->has('name'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('name') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="company">
                                            Company
                                        </label>
                                        <div class="col-sm-10">
                                            <input type="text" name="company" value="{{ $results->payment_company }}" placeholder="Company" id="company" class="form-control">
                                        </div>
                                        @if ($errors->has('company'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('company') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="address">
                                            Address
                                        </label>
                                        <div class="col-sm-10">
                                            <textarea name="address" placeholder="address" id="address" class="form-control">{{ $results->payment_address }}</textarea>
                                        </div>
                                        @if ($errors->has('address'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('address') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="city">
                                            City
                                        </label>
                                        <div class="col-sm-10">
                                            <select name="city" id="city" class="form-control city">
                                                <option value="{{ $results->payment_city }}">{{ $results->payment_city }}
                                            </select>
                                        </div>
                                        @if ($errors->has('city'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('city') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="postal_code">
                                            Postal Code
                                        </label>
                                        <div class="col-sm-10">
                                            <input type="text" name="postal_code" value="{{ $results->payment_postal_code }}" placeholder="postal_code" id="postal_code" class="form-control">
                                        </div>
                                        @if ($errors->has('postal_code'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('postal_code') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="province">
                                            Province
                                        </label>
                                        <div class="col-sm-10">
                                            <select name="province" placeholder="province" id="province" class="form-control">
                                                @foreach($province as $key=>$value)
                                                    <option value="{{$value->name}}" @if($results->payment_province==$value->name) selected @endif>{{$value->name}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        @if ($errors->has('province'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('province') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="telephone">
                                            Telephone
                                        </label>
                                        <div class="col-sm-10">
                                            <input type="text" name="telephone" value="{{ $results->payment_telephone }}" placeholder="telephone" id="telephone" class="form-control">
                                        </div>
                                        @if ($errors->has('telephone'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('telephone') }}</strong>
                                            </span>
                                        @endif
                                    </div>


                                </div>
                                
                            </div>
                        </div>
                        <!-- /.panel-body -->                         
                            

                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            

            </form>
        </div>
        <!-- /#page-wrapper -->
@endsection

@section('script')
    <!-- include summernote css/js-->
    <script src="{{ asset('js/summernote.js') }}"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.full.min.js"></script>
    <script>
        var order_id={{ $results->id }};
        $('.address').on("change", function(e) { 
                 
                $val=$(this).val();
                if($val!=""){
                $('.loader-box').show();
                   $.get("{{url('admin/order/get-address') }}/"+order_id, { id: $val }, function(data){
                    console.log(data);
                    $('.loader-box').hide();
                    $('#name').val(data.name);
                    $('#company').val(data.company);
                    $('#address').val(data.address);
                    $('#postal_code').val(data.postal_code);
                    $('#province').val(data.province);
                    $('#telephone').val(data.telephone);
                    $('#city').append("<option value='"+data.city+"'>"+data.city+"</option>");
                    $('#city').val(data.city).trigger('change.select2');
                   });
                }
            });

        
        
        $(document).ready(function() {
            $('.summernote').summernote({
                height: 200
            });
            $('.select2').select2();
            

            $('.city').select2({
                placeholder: "Choose Option...",
                ajax: {
                    url: '{{ url('admin/order/search-city')}}',
                    dataType: 'json',
                    quietMillis: 1000,
                    data: function (params) {
                        return {
                            q: $.trim(params.term)
                        };
                    },
                    processResults: function (data) {
                        return {
                            results: data
                        };
                    },
                    cache: true
                }
            });
            
        });
    </script>

@endsection