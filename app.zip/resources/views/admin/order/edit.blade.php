@extends('layouts.admin')

@section('title')
    Edit Order
@endsection

@section('head')
    <!-- include summernote css/js-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.min.css">

    <style type="text/css">
        textarea {
            overflow-x: hidden;
        }
        .my-group .form-control{
            width:50%;
        }
        .nav-tabs {
            margin-bottom: 25px;
        }
    </style>
@endsection

@section('content')
     <div id="page-wrapper">
        <form role="form" action="{{ url('admin/order/edit/1/'.$results->id) }}" class="form-horizontal" enctype="multipart/form-data" method="post">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Edit Order
                        <div class="pull-right">
                            <button type="submit" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Save" aria-describedby="tooltip815756">
                                <i class="fa fa-save"></i>
                            </button>
                            <a href="{{ url('admin/order') }}" class="btn btn-default" data-original-title="Cancel">
                                <i class="fa fa-reply"></i>
                            </a>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/order') }}">Order</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-pencil"></i> Edit Order {{ $results->id }}
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">   

                            <!-- /.panel-heading -->
                        <div class="panel-body">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs nav-justified">
                                <li class="active"><a href="{{url('admin/order/edit/1',$results->id)}}">1.Customer Details</a>
                                </li>
                                <li class=""><a href="{{url('admin/order/edit/2',$results->id)}}">2.Products</a>
                                </li>
                                <li class=""><a href="{{url('admin/order/edit/3',$results->id)}}">3.Payment Details</a>
                                </li>
                                <li class=""><a href="{{url('admin/order/edit/4',$results->id)}}">4.Shipping Details</a>
                                </li>
                                <li class=""><a href="{{url('admin/order/edit/5',$results->id)}}">5.Totals</a>
                                </li>
                            </ul>

                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane fade in active" id="customer">
                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="customer">
                                            Customer
                                        </label>
                                        <div class="col-sm-10">
                                            <select name="customer" id="customer" class="form-control customer">
                                                <option value="{{$results->user_id}}" selected>{{$results->User->name}}</option>
                                            </select>
                                        </div>
                                        @if ($errors->has('customer'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('customer') }}</strong>
                                            </span>
                                        @endif
                                    </div>


                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="customer_group">
                                            Customer Group
                                        </label>
                                        <div class="col-sm-10">
                                            <select name="customer_group" id="customer_group" class="form-control">
                                                @foreach($customer_group as $cg)
                                                <option value="{{$cg->id}}" @if($cg->id==$results->customer_group_id) selected @endif>{{$cg->name}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        @if ($errors->has('customer_group'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('customer_group') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="name">
                                            Name
                                        </label>
                                        <div class="col-sm-10">
                                            <input type="text" name="name" value="{{ $results->name }}" placeholder="Customer Name" id="name" class="form-control">
                                        </div>
                                        @if ($errors->has('name'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('name') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="email">
                                            Email
                                        </label>
                                        <div class="col-sm-10">
                                            <input type="text" name="email" value="{{ $results->email }}" placeholder="Customer email" id="email" class="form-control">
                                        </div>
                                        @if ($errors->has('email'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('email') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="telephone">
                                            Telephone
                                        </label>
                                        <div class="col-sm-10">
                                            <input type="text" name="telephone" value="{{ $results->telephone }}" placeholder="Telephone" id="telephone" class="form-control">
                                        </div>
                                        @if ($errors->has('telephone'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('telephone') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="fax">
                                            Fax
                                        </label>
                                        <div class="col-sm-10">
                                            <input type="text" name="fax" value="{{ $results->fax }}" placeholder="Fax" id="fax" class="form-control">
                                        </div>
                                        @if ($errors->has('fax'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('fax') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    


                                </div>
                                
                            </div>
                        </div>
                        <!-- /.panel-body -->                         
                            

                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            

            </form>
        </div>
        <!-- /#page-wrapper -->
@endsection

@section('script')
    <!-- include summernote css/js-->
    <script src="{{ asset('js/summernote.js') }}"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js"></script>
    <script>
        $('.customer').on("change", function(e) { 
                $('.loader-box').show(); 
                $val=$(this).val();
               $.get("{{url('admin/order/get-user') }}/"+$val, function(data){
                console.log(data);
                $('.loader-box').hide();
                $('#customer_group').val(data.customer_group_id);
                $('#name').val(data.name);
                $('#email').val(data.email);
                $('#telephone').val(data.telephone);
                $('#fax').val(data.fax);
               });
            });
        
        $(document).ready(function() {
            $('.summernote').summernote({
                height: 200
            });
            $('.select2').select2();
            $('.customer').select2({
                placeholder: "Choose Option...",
                ajax: {
                    url: '{{ url('admin/order/search-user')}}',
                    dataType: 'json',
                    data: function (params) {
                        return {
                            q: $.trim(params.term)
                        };
                    },
                    processResults: function (data) {
                        return {
                            results: data
                        };
                    },
                    cache: true
                }
            });
            
        });
    </script>

@endsection