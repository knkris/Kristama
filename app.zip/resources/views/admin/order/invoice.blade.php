<html dir="ltr" lang="en"><head>
<meta charset="UTF-8">
<title>Invoice</title>
<base href="https://www.helmku.com/admin/">
<link href="{{ asset('sbadmin2/vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ asset('css/invoice.css') }}" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="{{ asset('sbadmin2/vendor/bootstrap/js/bootstrap.min.js') }}"></script>
<link href="{{ asset('sbadmin2/vendor/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet" type="text/css">
</head>
<body>
<div class="container">
    @foreach($orders as $results)
    <div style="page-break-after: always;">
    <h1>Invoice #{{$results->invoice}}</h1>
    <table class="table table-bordered">
      <thead>
        <tr>
          <td colspan="2">Order Detail</td>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td style="width: 50%;"><address>
            <strong>{{env('APP_NAME', 'Laravel')}}</strong><br>
            -------------            </address>
            <b>Telp:</b> {{env('APP_PHONE', '021-1234356')}}<br>
                        <b>E-Mail:</b> {{env('APP_EMAIL', 'cs@app.com')}}<br>
            <b>Web Site:</b> <a href="{{url('/')}}">{{url('/')}}</a></td>
          <td style="width: 50%;"><b>Date :</b> {{ \Carbon\Carbon::parse($results->created_at)->format('d/m/Y H:i:s') }}<br>
                        <b>Order ID:</b> {{$results->id}}<br>
            <b>Payment Method:</b> {{ucwords($results->payment_method)}}<br>
                        <b>Shipping Method:</b> {{$results->shipping_courier}} - {{$results->courier_service}}<br>
            </td>
        </tr>
      </tbody>
    </table>
    <table class="table table-bordered">
      <thead>
        <tr>
          <td style="width: 50%;"><b>Payment Address</b></td>
          <td style="width: 50%;"><b>Shipping Address</b></td>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <address>
              {{$results->payment_name}}<br>
              {{$results->payment_address}}<br>
              {{$results->payment_city}} {{$results->payment_postal_code}}<br>
              {{$results->payment_province}}<br>
              Indonesia<br>
              Telephone: {{ $results->payment_telephone }}            
            </address>
          </td>
          <td>
            <address>
              {{$results->shipping_name}}<br>
              {{$results->shipping_address}}<br>
              {{$results->shipping_city}} {{$results->shipping_postal_code}}<br>
              {{$results->shipping_province}}<br>
              Indonesia<br>
              Telephone: {{ $results->shipping_telephone }}            
            </address>
          </td>
        </tr>
      </tbody>
    </table>
    <table class="table table-bordered">
      <thead>
        <tr>
          <td><b>Product</b></td>
          <td><b>Model</b></td>
          <td class="text-right"><b>Qty</b></td>
          <td class="text-right"><b>Unit Price</b></td>
          <td class="text-right"><b>Total</b></td>
        </tr>
      </thead>
      <tbody>
        <?php
            $od=$results->OrderDetail;
        ?>
        @foreach($od as $value)
        <?php
        $product=$value->Product;
        $stocks=$value->ProductStock;
        ?>
          <tr>
            <td>
                {{$product->name}}<br>
              @foreach($stocks->ProductStockDetail as $stock)
              <?php   
                  $ov=$stock->ProductOptionDetail->OptionValue;
              ?>
                - <small>{{$ov->Option->name}}: {{$ov->name}}</small><br>
                
              @endforeach 
            </td>
            <td>{{$product->model}}</td>
            <td class="text-right">{{$value->qty}}</td>
            <td class="text-right">{{currency_format($value->price,'IDR')}}</td>
            <td class="text-right">{{currency_format($value->qty*$value->price,'IDR')}}</td>
          </tr>
        @endforeach
                                <tr>
          <td class="text-right" colspan="4"><b>Sub-Total</b></td>
          <td class="text-right">{{currency_format($results->subtotal,'IDR')}}</td>
        </tr>
                <tr>
          <td class="text-right" colspan="4"><b>{{ $results->shipping_courier." - ".$results->courier_service }}</b></td>
          <td class="text-right">{{currency_format($results->shipping_cost,'IDR')}}</td>
        </tr>
                <tr>
          <td class="text-right" colspan="4"><b>Transfer Code</b></td>
          <td class="text-right">{{currency_format($results->transfer_code,'IDR')}}</td>
        </tr>
                <tr>
          <td class="text-right" colspan="4"><b>Total</b></td>
          <td class="text-right">{{currency_format($results->total,'IDR')}}</td>
        </tr>
              </tbody>
    </table>

        @if(strlen($results->comment)>0)
        <table class="table table-bordered">
          <thead>
            <tr>
              <td>Comment:</td>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>{{$results->comment}}</td>
            </tr>
          </tbody>
        </table>
        @endif

    </div>
    @endforeach
  </div>

</body></html>