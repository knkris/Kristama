@extends('layouts.admin')

@section('title')
    Edit Order
@endsection

@section('head')
    <!-- include summernote css/js-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.min.css">

    

    <style type="text/css">
        textarea {
            overflow-x: hidden;
        }
        .my-group .form-control{
            width:50%;
        }
        .nav-tabs {
            margin-bottom: 25px;
        }
        .loader-small {
            border: 16px solid #f3f3f3; /* Light grey */
            border-top: 16px solid #3498db; /* Blue */
            border-radius: 50%;
            width: 30px;
            height: 30px;
            animation: spin 2s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
@endsection

@section('content')
     <div id="page-wrapper">
        <form id="form" role="form" action="{{ url('admin/order/edit/2'.$results->id) }}" class="form-horizontal" enctype="multipart/form-data" method="post">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Edit Order
                        <div class="pull-right">
                            <a href="{{ url('admin/order/edit/3',$results->id) }}" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Save" aria-describedby="tooltip815756">
                                <i class="fa fa-save"></i>
                            </a>
                            <a href="{{ url('admin/order') }}" class="btn btn-default" data-original-title="Cancel">
                                <i class="fa fa-reply"></i>
                            </a>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/order') }}">Order</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-pencil"></i> Edit Order {{ $results->id }}
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">   

                            <!-- /.panel-heading -->
                        <div class="panel-body">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs nav-justified">
                                <li class=""><a href="{{url('admin/order/edit/1',$results->id)}}">1.Customer Details</a>
                                </li>
                                <li class="active"><a href="{{url('admin/order/edit/2',$results->id)}}">2.Products</a>
                                </li>
                                <li class=""><a href="{{url('admin/order/edit/3',$results->id)}}">3.Payment Details</a>
                                </li>
                                <li class=""><a href="{{url('admin/order/edit/4',$results->id)}}">4.Shipping Details</a>
                                </li>
                                <li class=""><a href="{{url('admin/order/edit/5',$results->id)}}">5.Totals</a>
                                </li>
                            </ul>

                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane fade in active" id="product">
                                    <div class="table-responsive">
                                        <table class="table table-bordered">
                                          <thead>
                                            <tr>
                                              <td class="text-left">Product</td>
                                              <td class="text-left">Model</td>
                                              <td class="text-right">Qty</td>
                                              <td class="text-right">Unit Price</td>
                                              <td class="text-right">Total</td>
                                              <td>Action</td>
                                            </tr>
                                          </thead>
                                          <tbody id="cart">
                                            @foreach($orderdetail as $key=>$od)
                                            <?php 
                                                $product=$od->Product;
                                                /*$stocks=$od->ProductStock; */
                                            ?>
                                            <tr id="tr-{{$od->id}}">
                                              <td class="text-left">
                                                {{$product->name}} 
                                                {{-- <span class="text-danger">***</span> --}}
                                                <br>
                                                
                                                <?php /*@foreach($stocks->ProductStockDetail as $stock)
                                                <?php   
                                                    $ov=$stock->ProductOptionDetail->OptionValue;
                                                ?>
                                                  - <small>{{$ov->Option->name}}: {{$ov->name}}</small><br>
                                                  
                                                @endforeach */ ?>
                                              </td>  
                                              <td class="text-left">
                                                  {{$product->model}}
                                              </td>  
                                              <td class="text-right">
                                                <div class="input-group btn-block" style="max-width: 200px;">
                                                    <input type="text" name="product[{{$key}}][quantity]" value="{{$od->qty}}" id="qty{{$od->id}}" class="form-control">
                                                    <span class="input-group-btn">
                                                        <button type="button" data-id="{{$od->id}}" data-toggle="tooltip" title="" data-loading-text="Loading..." class="btn btn-primary qty-refresh" data-original-title="Refresh">
                                                            <i class="fa fa-refresh"></i>
                                                        </button>
                                                    </span>
                                                </div>
                                              </td>  
                                              <td class="text-right" id="price{{$od->id}}">{{currency_format($od->price,'IDR')}}</td>  
                                              <td class="text-right" id="total{{$od->id}}">{{currency_format($od->price*$od->qty,'IDR')}}</td>  
                                              <td class="text-center" style="width: 3px;">
                                                <button type="button" data-id="{{$od->id}}" data-toggle="tooltip" title="" data-loading-text="Loading..." class="btn btn-danger remove-od" data-original-title="Remove">
                                                    <i class="fa fa-minus-circle"></i>
                                                </button>
                                              </td>
                                            </tr>
                                            @endforeach
                                          </tbody>
                                        </table>
                                      </div>

                                  <legend>Add Product(s)</legend>

                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="product">
                                            Choose Product
                                        </label>
                                        <div class="col-sm-10">
                                            <select name="product" id="product_id" class="form-control product">
                                                
                                            </select>
                                        </div>
                                        @if ($errors->has('product'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('product') }}</strong>
                                            </span>
                                        @endif
                                    </div>


                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="qty">
                                            Quantity
                                        </label>
                                        <div class="col-sm-10">
                                            <input type="number" name="qty" value="1" placeholder="Quantity" id="qty" class="form-control">
                                            <input type="hidden" name="product_stock_id" id="product_stock_id" value="">
                                        </div>
                                        @if ($errors->has('qty'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('qty') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    <div class="form-group required">
                                        <label class="col-sm-2 control-label" for="product">
                                            Available Stock
                                        </label>
                                        <div class="col-sm-10 available-stock">
                                            
                                        </div>
                                       
                                    </div>

                                    <div id="product-option"></div>

                                    
                                    <div class="pull-right add-product-box">
                                        <button type="button" id="add-product" class="btn btn-primary">Add Product</button>
                                    </div>

                                </div>
                                
                            </div>
                        </div>
                        <!-- /.panel-body -->                         
                            

                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            

            </form>
        </div>
        <!-- /#page-wrapper -->
@endsection

@section('script')
    <!-- include summernote css/js-->
    <script src="{{ asset('js/summernote.js') }}"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js"></script>
    <script>
        
        
        $(document).ready(function() {
            $('.summernote').summernote({
                height: 200
            });
            $('.select2').select2();
            $('.product').select2({
                placeholder: "Choose Product...",
                ajax: {
                    url: '{{ url('admin/order/search-product')}}',
                    dataType: 'json',
                    data: function (params) {
                        return {
                            q: $.trim(params.term)
                        };
                    },
                    processResults: function (data) {
                        return {
                            results: data
                        };
                    },
                    cache: true
                }
            });

            function generateOptions(index,data){
                var options="";
                var x;
                for (x = 0; x < data.options.length; ++x) {
                    options+="<option value='"+data.options[x].id+"'>"+data.options[x].name+"</option>";
                }
                $('#product-option').append("<div class='form-group required'><label class='col-sm-2 control-label' for='option["+index+"]'>"+data.name+"</label><div class='col-sm-10'><select name='option["+index+"]' id='option["+index+"]' class='form-control check-stock'>"+options+"</select></div></div>");
            }

            

            $('.product').on("change", function(e) { 
                $('.loader-box').show(); 
                $val=$(this).val();
                console.log(e);
               $.get("{{url('admin/order/get-product-option') }}/"+$val, function(data){
                console.log(data);
                $('.loader-box').hide();
                //$('.available-stock').html(data[0].product.qty);
                if(data.length>0){
                    var index=0;
                    $('#product-option').html('');
                    $('#product-option').append("<legend>Choose Option(s)</legend>");
                    for (index = 0; index < data.length; ++index) {
    
                        
                        generateOptions(index,data[index]);
                        
                    }
                }
                checkStock();
               });
            });

            $('#add-product').on('click', function(){
                $('.loader-box').show();
                var product=$('#product_id').val();
                var qty=$('#qty').val();
                var product_stock_id=$('#product_stock_id').val();
                console.log(product,qty,product_stock_id);
                $.post('{{url('admin/order/edit/2',$results->id)}}', { 
                    product: product,
                    qty: qty,
                    product_stock_id: product_stock_id,
                    _token: '{{csrf_token()}}'
                },function(data){
                    location.reload();
                }).fail(function(data) {
                    var data=data;
                    var error=data.responseJSON.errors;
                    swal( "Error!",error[Object.keys(error)[0]][0],'error' );
                    $('.loader-box').hide();
               });
            });
            
            
        });

        $('.qty-refresh').on('click', function(){
            var id=$(this).data('id');
            var qty=$('#qty'+id).val();
            var btn=$(this);
            btn.button('loading');
            $.post('{{url('admin/order/update-qty')}}/'+id, {
                    qty: qty,
                    _token: '{{csrf_token()}}'
                },function(data){
                    btn.button('reset');
                    console.log(data);
                    $('#price'+id).html(data.price_idr);
                    $('#total'+id).html(data.total_idr);
                    if($('#product_id').val()>0){
                        checkStock();
                    }
                }).fail(function(data) {
                    var data=data;
                    var error=data.responseJSON.errors;
                    swal( "Error!",error[Object.keys(error)[0]][0],'error' );
                    btn.button('reset');
               });
        });

        $('.remove-od').on('click', function(){
            var id=$(this).data('id');
            swal({
                  title: 'Are you sure?',
                  text: "You won't be able to revert this!",
                  type: 'warning',
                  showCancelButton: true,
                  confirmButtonColor: '#3085d6',
                  cancelButtonColor: '#d33',
                  confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                  if (result.value) {
                    $.post('{{url('admin/order/delete-detail')}}/'+id, {
                        _token: '{{csrf_token()}}'
                    },function(data){
                        console.log(data);
                        $('#tr-'+id).remove();
                        if($('#product_id').val()>0){
                            checkStock();
                        }
                    });
                  }
                })
        });

        function checkStock(){
            $('.available-stock').html("<div class='loader-small'></div>");
            var combination=[];
            $('.check-stock').each(function(){
                combination.push($(this).val());
            });
            console.log(combination);
            $.get("{{url('admin/order/check-stock') }}", { combination: combination })
              .done(function( data ) {
                console.log(data);
                $('.available-stock').html(data.qty);
                $('#product_stock_id').val(data.id);
                $('.loader-box').hide();
              });
              
        }

        $(document).on("change", '.check-stock', function(event) { 
            checkStock();
        });
    </script>

@endsection