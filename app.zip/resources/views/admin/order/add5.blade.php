

<div class="tab-pane fade" id="total">
    <div class="table-responsive">
        <table class="table table-bordered">
          <thead>
            <tr>
              <td class="text-left">Product</td>
              <td class="text-left">Model</td>
              <td class="text-right">Qty</td>
              <td class="text-right">Unit Price</td>
              <td class="text-right">Total</td>
            </tr>
          </thead>
          <tbody id="cart-total">
            <?php $count=count(old('product')); ?>
                @if($count>0)
                    @foreach(old('product') as $key=>$value)
                    <?php
                    $product=\App\Models\Product::find($value['id']);
                    $stock=\App\Models\ProductStock::find($value['product_stock_id']);
                    $stockDetail=$stock->ProductStockDetail;
                    ?>
                    <tr id='tr-total-{{$key}}'>
                        <td class='text-left'>
                            {{$product->name}}<br>
                            @foreach($stockDetail as $sd)
                            <?php $ov=$sd->ProductOptionDetail->OptionValue; ?>
                            - <small>{{$ov->Option->name.": ".$ov->name}}</small><br>
                            @endforeach
                        </td>
                        <td class='text-left'>
                            {{$product->model}}
                        </td>
                        <td class='text-right' id='qty-total{{$key}}'>
                            {{$value['quantity']}}
                        </td>
                        <td class='text-right' id='price-total{{$key}}' data-price='"+product.price+"'>
                            {{currency_format($product->price,'IDR')}}
                        </td>
                        <td class='text-right subtotal' id='subtotal{{$key}}' data-total='{{$product->price*$value['quantity']}}'>
                            {{currency_format($product->price*$value['quantity'],'IDR')}}
                        </td>
                    </tr>
                    
                    @endforeach
                @endif
          </tbody>  
          <tfoot> 
            <tr>
              <td class="text-right" colspan="4">
                  Sub-Total:
              </td>  
              <td id="subtotal-foot" class="text-right">
                  
              </td>
              </tr>
              <tr>  
                <td class="text-right" colspan="4">
                    Transfer Code:
                </td>  
                <td id="transfer_code" class="text-right">
                    <input type="hidden" name="transfer_code" value="{{old('transfer_code')?:$transfer_code}}">
                    {{ old('transfer_code')? currency_format(old('transfer_code'),'IDR') : currency_format($transfer_code,'IDR') }}
                </td>
              </tr>
              <tr>
                <td class="text-right" colspan="4">
                    Total:
                </td>  
                <td id="total-foot" class="text-right"></td>
              </tr>
          </tfoot>
          
        </table>
      </div>

  <legend>Order Detail</legend>

    <div class="form-group required">
        <label class="col-sm-2 control-label" for="shipping_method">
            Shipping Method
        </label>
        <div class="col-sm-10">
            <select name="shipping_method" id="shipping_method" class="form-control">
                
            </select>
        </div>
        @if ($errors->has('shipping_method'))
            <span class="help-block">
                <strong>{{ $errors->first('shipping_method') }}</strong>
            </span>
        @endif
    </div>


    <div class="form-group required">
        <label class="col-sm-2 control-label" for="payment_method">
            Payment Method
        </label>
        <div class="col-sm-10">
            <select name="payment_method" id="payment_method" class="form-control">
                @foreach($payment_method as $key => $value)
                    <option value="{{$value->name}}">{{$value->name}}</option>
                @endforeach
            </select>
        </div>
        @if ($errors->has('payment_method'))
            <span class="help-block">
                <strong>{{ $errors->first('payment_method') }}</strong>
            </span>
        @endif
    </div>

    <div class="form-group required">
        <label class="col-sm-2 control-label" for="order_status">
            Order Status
        </label>
        <div class="col-sm-10">
            <select name="order_status" id="order_status" class="form-control">
                @foreach($orderstatus as $os)
                <option value="{{$os->id}}" @if(old('order_status')==$os->id) selected @endif>{{ $os->name_en }}</option>
                @endforeach
            </select>
        </div>
        @if ($errors->has('order_status'))
            <span class="help-block">
                <strong>{{ $errors->first('order_status') }}</strong>
            </span>
        @endif
    </div>

    <div class="form-group required">
        <label class="col-sm-2 control-label" for="comment">
            Comment
        </label>
        <div class="col-sm-10">
            <textarea name="comment" placeholder="comment" id="comment" class="form-control">{{ old('comment') }}</textarea>
        </div>
        @if ($errors->has('comment'))
            <span class="help-block">
                <strong>{{ $errors->first('comment') }}</strong>
            </span>
        @endif
    </div>

    <br><br>
    <div class="row">
        <div class="col-xs-12">
            <button type="button" data-page="shipping" data-from="total" data-type="back" class="btn btn-default nav-btn">Back</button>
            
        </div>
    </div>

</div>
                                
 