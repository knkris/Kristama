@extends('layouts.admin')

@section('title')
    Add Kreasi2go Rule
@endsection

@section('head')
    <!-- include summernote css/js-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.18/jquery.datetimepicker.min.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.min.css">

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/css/bootstrap-select.min.css">


    <style type="text/css">
        textarea {
            overflow-x: hidden;
        }
    </style>
@endsection

@section('content')
     <div id="page-wrapper">
        <form role="form" action="{{ url('admin/kreasi2go/store') }}" class="form-horizontal" enctype="multipart/form-data" method="post">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Add Kreasi2go Rule
                        <div class="pull-right">
                            <button type="submit" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Save" aria-describedby="tooltip815756">
                                <i class="fa fa-save"></i>
                            </button>
                            <a href="{{ url('admin/shipping-method/edit/3') }}" class="btn btn-default" data-original-title="Cancel">
                                <i class="fa fa-reply"></i>
                            </a>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/shipping-method') }}">Shipping Method</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/kreasi2go') }}">Kreasi2go Rule</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-pencil"></i> Add Kreasi2go Rule
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">                            
                            


                            <div class="form-group required {{ $errors->has('name') ? ' has-error' : '' }}">
                                <label class="col-sm-2 control-label" for="name">
                                    Name
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" name="name" value="{{ old('name') }}" placeholder="Shipping Method Name" id="name" class="form-control">
                                </div>
                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group {{ $errors->has('province') ? ' has-error' : '' }}">
                                <label class="col-sm-2 control-label" for="province">
                                    Province
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control select2" name="province[]" id="province" multiple="multiple" data-actions-box="true">
                                        <option value=""></option>
                                        @foreach($province as $cat)
                                        <option value="{{$cat->id}}" @if(count(old('province'))>0) @if(in_array($cat->id, old('province'))) selected @endif @endif>{{$cat->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                @if ($errors->has('province'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('province') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group {{ $errors->has('category') ? ' has-error' : '' }}">
                                <label class="col-sm-2 control-label" for="category">
                                    Category
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control select2" name="category[]" id="category" multiple="multiple" data-actions-box="true">
                                        <option value=""></option>
                                        @foreach($category as $cat)
                                        <option value="{{$cat->id}}" @if(count(old('category'))>0) @if(in_array($cat->id, old('category'))) selected @endif @endif>{{$cat->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                @if ($errors->has('category'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('category') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group {{ $errors->has('product') ? ' has-error' : '' }}">
                                <label class="col-sm-2 control-label" for="product">
                                    Product
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control product" name="product[]" id="product" multiple="multiple">
                                        <option value=""></option>
                                        @if(count(old('product'))>0)
                                        <?php $prod=\App\Models\Product::whereIn('id', old('product'))->get(); ?>
                                            @foreach($prod as $pro)
                                            <option value="{{$pro->id}}" selected>{{$pro->name}}</option>
                                            @endforeach
                                        @endif
                                    </select>
                                </div>
                                @if ($errors->has('product'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('product') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group {{ $errors->has('subtotal') ? ' has-error' : '' }}">
                                <label class="col-sm-2 control-label" for="subtotal">
                                    Minimum Order
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" name="subtotal" value="{{ old('subtotal') ?: 0 }}" placeholder="subtotal" id="subtotal" class="form-control">
                                </div>
                                @if ($errors->has('subtotal'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('subtotal') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group {{ $errors->has('status') ? ' has-error' : '' }}">
                                <label class="col-sm-2 control-label" for="status">
                                    Status
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="status" id="status">
                                        <option value="1" @if(old('status')=='1') selected @endif>enabled</option>
                                        <option value="0" @if(old('status')=='0') selected @endif>disabled</option>
                                    </select>
                                </div>
                                @if ($errors->has('status'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('status') }}</strong>
                                    </span>
                                @endif
                            </div>
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            </form>
        </div>
        <!-- /#page-wrapper -->
@endsection

@section('script')
    <!-- include summernote css/js-->
    <script src="{{ asset('js/summernote.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.18/jquery.datetimepicker.full.min.js"></script>

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/js/bootstrap-select.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js"></script>

    <script>
        $(document).ready(function() {
            $('.summernote').summernote({
                height: 200
            });
            $('.select2').selectpicker();

            $('.datepicker').datetimepicker({
             timepicker:false,
             format:'d-m-Y'
            });

            $('.product').select2({
                placeholder: "Choose Product...",
                ajax: {
                    url: '{{ url('admin/order/search-product')}}',
                    dataType: 'json',
                    data: function (params) {
                        return {
                            q: $.trim(params.term)
                        };
                    },
                    processResults: function (data) {
                        return {
                            results: data
                        };
                    },
                    cache: true
                }
            });
        });
    </script>
@endsection