@extends('layouts.admin')

@section('title')
    Shipping Method
@endsection

@section('head')
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.css"/>
@endsection

@section('content')
    <form id="form" role="form" action="{{ url('admin/shipping-method/trash') }}" class="form-horizontal" enctype="multipart/form-data" method="post">
        {{ csrf_field() }}
     <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Shipping Method
                        {{-- <div class="pull-right">
                            <a href="{{ url('admin/shipping-method/create') }}" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Add New" aria-describedby="tooltip23863">
                                <i class="fa fa-plus"></i>
                            </a> 
                            <button id="delete" type="button" data-toggle="tooltip" title="" class="btn btn-danger" data-original-title="Delete">
                                <i class="fa fa-trash-o"></i>
                            </button>
                        </div> --}}
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/shipping-method') }}">Shipping Method</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-list"></i> Shipping Method List
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="table">
                                <thead>
                                    <tr>
                                        <th>
                                            <input type="checkbox" onclick="$('input[name*=\'selected\']').prop('checked', this.checked);">
                                        </th>
                                        <th>Customer Group</th>
                                        <th>Name</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                            </table>
                            <!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            
        </div>
        <!-- /#page-wrapper -->
    </form>
@endsection

@section('script')
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.js"></script>

    <script>
        $('#delete').on('click',function(){
            swal({
                  title: 'Are you sure?',
                  text: "You won't be able to revert this!",
                  type: 'warning',
                  showCancelButton: true,
                  confirmButtonColor: '#3085d6',
                  cancelButtonColor: '#d33',
                  confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                  if (result.value) {
                    $('#form').submit();
                  }
                })
        });

        $(document).ready(function () {
            $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax":{
                         "url": "{{ url('admin/shipping-method') }}",
                         "dataType": "json",
                         "type": "POST",
                         "data":{ _token: "{{csrf_token()}}"}
                       },
                "columns": [
                    { "data": "id",
                      "orderable": false
                    },
                    { "data": "customer_group_id" },
                    { "data": "name" },
                    { "data": "status",
                      "className": "selectable"
                    },
                    { "data": "action",
                      "orderable": false
                    }
                ]    

            });
        });

        // Activate an inline edit on click of a table cell
        $('#table').on( 'click', 'tbody td.selectable', function (e) {
            if(!$(this).hasClass('editing')){
                $(this).addClass('editing');
                $id=$(this).children().data('id');
                $val=$(this).children().text();
                $type=$(this).children().data('type');
                if($val==="enabled"){
                    $(this).html("<select class='form-control selectable-box' name='val' data-id='"+$id+"' data-type='"+$type+"'><option value='1' selected>enabled</option><option value='0'>disabled</option></select> ");
                }else{
                    $(this).html("<select class='form-control selectable-box' name='val' data-id='"+$id+"' data-type='"+$type+"'><option value='1'>enabled</option><option value='0' selected>disabled</option></select> ");
                }
                $('.selectable-box').focus();
            }
        } );

        $(document).on("change", '.selectable-box', function(event) { 
            $this=$(this);
            $id=$(this).data('id');
            $val=$(this).val();

            $(this).attr('disabled','disabled');
            $.ajax({
                url: "{{ url('admin/shipping-method') }}/"+$id,
                type: "post",
                data: {
                    id: $id,
                    value: $val,
                    _token: "{{csrf_token()}}"
                } ,
                success: function (response) {
                   // you will get response from your php page (what you echo or print)                 
                   console.log(response);
                   $newstatus=response.html_status;
                   //$parent=$this.parent("td");
                   $this.parent("td").removeClass('editing');
                   $this.parent("td").empty().html($newstatus);
                   //swal('Success!', response.name+" price updated", 'success');
                }.bind($this),
                error: function(jqXHR, textStatus, errorThrown) {
                   console.log(jqXHR, textStatus, errorThrown);
                   swal('Error!', jqXHR.responseJSON.errors.value[0], 'error');
                   $(this).removeAttr('disabled');

                }.bind($this)
            });


        });
    </script>
@endsection