@extends('layouts.admin')

@section('title')
    Add Blog
@endsection

@section('head')
    <!-- include summernote css/js-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.min.css">

    <style type="text/css">
        textarea {
            overflow-x: hidden;
        }
    </style>
@endsection

@section('content')
     <div id="page-wrapper">
        <form role="form" action="{{ url('admin/blog/store') }}" class="form-horizontal" enctype="multipart/form-data" method="post">
            {{ csrf_field() }}
            {!! Form::hidden('url',url('upload_image'), array('class'=>'url') ) !!}
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Add Blog
                        <div class="pull-right">
                            <button type="submit" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Save" aria-describedby="tooltip815756">
                                <i class="fa fa-save"></i>
                            </button>
                            <a href="{{ url('admin/blog') }}" class="btn btn-default" data-original-title="Cancel">
                                <i class="fa fa-reply"></i>
                            </a>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/blog') }}">Blog</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-pencil"></i> Add Blog
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">                            
                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="title">
                                    Blog Name
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" name="title" value="{{ old('title') }}" placeholder="Blog Name" id="title" class="form-control">
                                </div>
                                @if ($errors->has('title'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('title') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="category">
                                    Blog Category
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" name="category" value="{{ old('category') }}" placeholder="Blog Category" id="category" class="form-control">
                                </div>
                                @if ($errors->has('category'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('category') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="description">
                                    Content
                                </label>
                                <div class="col-sm-10">
                                    <textarea name="content" placeholder="Content" id="description" class="form-control summernote">{{ old('content') }}</textarea>
                                </div>
                                @if ($errors->has('content'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('content') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="image">
                                    Image
                                </label>
                                <div class="col-sm-10">
                                    <input type="file" name="image" value="{{ old('image') }}" id="image" class="form-control">
                                </div>
                                @if ($errors->has('image'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('image') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="cover">
                                    Cover
                                </label>
                                <div class="col-sm-10">
                                    <input type="file" name="cover" value="{{ old('cover') }}" id="cover" class="form-control">
                                </div>
                                @if ($errors->has('cover'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('cover') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="product">
                                    Related Product
                                </label>
                                <div class="col-sm-10">
                                    <select name="related_product[]" id="related_product" class="form-control product" multiple="multiple">
                                        @if(old('related_product') != NULL)
                                            @foreach(old('related_product') as $value)
                                            <option value="{{$value}}" selected>{{\App\Models\Product::where('id', intval($value))->first()->name}}</option>
                                            @endforeach
                                        @endif
                                    </select>
                                </div>
                                @if ($errors->has('product'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('product') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="blog">
                                    Related Blog
                                </label>
                                <div class="col-sm-10">
                                    <select name="related_blog[]" id="related_blog" class="form-control blog" multiple="multiple">
                                        @if(old('related_blog') != NULL)
                                            @foreach(old('related_blog') as $value)
                                            <option value="{{$value}}" selected>{{\App\Models\Blog::where('id', intval($value))->first()->title}}</option>
                                            @endforeach
                                        @endif
                                    </select>
                                </div>
                                @if ($errors->has('blog'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('blog') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="meta_title">
                                    Meta Title
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" name="meta_title" value="{{ old('meta_title') }}" placeholder="Meta Title" id="meta_title" class="form-control">
                                </div>
                                @if ($errors->has('meta_title'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('meta_title') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="meta_description">
                                    Meta Description
                                </label>
                                <div class="col-sm-10">
                                    <textarea name="meta_description" placeholder="Meta Description" id="meta_description" class="form-control">{{ old('meta_description') }}</textarea>
                                </div>
                                @if ($errors->has('meta_description'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('meta_description') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="meta_keyword">
                                    Meta Keyword
                                </label>
                                <div class="col-sm-10">
                                    <textarea name="meta_keyword" placeholder="Meta Keyword" id="meta_keyword" class="form-control">{{ old('meta_keyword') }}</textarea>
                                </div>
                                @if ($errors->has('meta_keyword'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('meta_keyword') }}</strong>
                                    </span>
                                @endif
                            </div>


                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            </form>
        </div>
        <!-- /#page-wrapper -->
@endsection

@section('script')
    <!-- include summernote css/js-->
    <script src="{{ asset('js/summernote.js') }}"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.summernote').summernote({
                height: 200
            });
            $('.select2').select2();
            $('.blog').select2({
                placeholder: "Choose Option...",
                ajax: {
                    url: '{{ url('admin/order/search-blog')}}',
                    dataType: 'json',
                    data: function (params) {
                        return {
                            q: $.trim(params.term)
                        };
                    },
                    processResults: function (data) {
                        return {
                            results: data
                        };
                    },
                    cache: true
                }
            });
            $('.product').select2({
                    placeholder: "Choose Product...",
                    ajax: {
                        url: '{{ url('admin/order/search-product')}}',
                        dataType: 'json',
                        data: function (params) {
                            return {
                                q: $.trim(params.term)
                            };
                        },
                        processResults: function (data) {
                            return {
                                results: data
                            };
                        },
                        cache: true
                    }
                });

            $( "#category" ).autocomplete({
              source: "{{ url('admin/search/blog-category') }}",
              minLength: 1,
              select: function(event, ui) {
                $('#category').val(ui.item.value);
              }
            });
        });
    </script>
@endsection