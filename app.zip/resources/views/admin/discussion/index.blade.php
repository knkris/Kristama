@extends('layouts.admin')

@section('title')
    Discussion
@endsection

@section('head')
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.css"/>

    <style type="text/css">
        .post-footer-option li{
            float:left;
            margin-right:50px;
            padding-bottom:15px;
        }

        .post-footer-option li a{
            color:#AFB4BD;
            font-weight:500;
            font-size:1.3rem;
        }

        .photo-profile{
            border:1px solid #DDD;    
        }

        .anchor-username h4{
            font-weight:bold;    
        }

        .anchor-time{
            color:#ADB2BB;
            font-size:1.2rem;
        }

        .post-footer-comment-wrapper{
            background-color:#F6F7F8;
            padding-left:15px;
        }
    </style>
@endsection

@section('content')
    <form id="form" role="form" action="{{ url('admin/discussion/trash') }}" class="form-horizontal" enctype="multipart/form-data" method="post">
        {{ csrf_field() }}
     <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Discussion
                        <div class="pull-right">
                            <a href="{{ url('admin/discussion/create') }}" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Add New" aria-describedby="tooltip23863">
                                <i class="fa fa-plus"></i>
                            </a> 
                            <button id="delete" type="button" data-toggle="tooltip" title="" class="btn btn-danger" data-original-title="Delete">
                                <i class="fa fa-trash-o"></i>
                            </button>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/discussion') }}">Discussion</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-list"></i> Discussion List
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="table">
                                <thead>
                                    <tr>
                                        <th>
                                            <input type="checkbox" onclick="$('input[name*=\'selected\']').prop('checked', this.checked);">
                                        </th>
                                        <th>Product</th>
                                        <th>User</th>
                                        <th>Text</th>
                                        <th>Created At</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                            </table>
                            <!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            
        </div>
        <!-- /#page-wrapper -->
    </form>

    <!-- Modal -->
    <div class="modal fade" id="reply" role="dialog">
        <div class="modal-dialog">
            <form id="reply-form" action="{{ url('admin/discussion/post-reply') }}" method="post">
                {{ csrf_field() }}
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Conversation</h4>
                    </div>
                    <div class="modal-body">

                    </div>
                    <div class="modal-footer">
                        <button type="submit" id="reply-button" class="btn btn-primary">Reply</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection

@section('script')
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.js"></script>

    <script>
        $('#delete').on('click',function(){
            swal({
                  title: 'Are you sure?',
                  text: "You won't be able to revert this!",
                  type: 'warning',
                  showCancelButton: true,
                  confirmButtonColor: '#3085d6',
                  cancelButtonColor: '#d33',
                  confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                  if (result.value) {
                    $('#form').submit();
                  }
                })
        });

        $(document).on("click", '.conversation', function(event) { 
            $('.modal-title').text('On Product : '+$(this).data('product'));
            $('.modal-body').load('{{ url('admin/discussion/conversation')}}/'+ $(this).data('id'),function(){
                $('#reply').modal({show:true});
            });
        });

        $(document).ready(function () {
            $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax":{
                         "url": "{{ url('admin/discussion') }}",
                         "dataType": "json",
                         "type": "POST",
                         "data":{ _token: "{{csrf_token()}}"}
                       },
                "columns": [
                    { "data": "id",
                      "orderable": false
                    },
                    { "data": "product_id" },
                    { "data": "user_id" },
                    { "data": "text" },
                    { "data": "created_at" },
                    { "data": "action",
                      "orderable": false
                    }
                ]    

            });
        });
    </script>
@endsection