@extends('layouts.admin')

@section('title')
    Edit Product Group
@endsection

@section('head')
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.css"/>
    <!-- include summernote css/js-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.18/jquery.datetimepicker.min.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.min.css">

    <style type="text/css">
        textarea {
            overflow-x: hidden;
        }
    </style>
@endsection

@section('content')
     <div id="page-wrapper">
        <form role="form" action="{{ url('admin/product-group/edit', $results->id) }}" class="form-horizontal" enctype="multipart/form-data" method="post">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Edit Product Group
                        <div class="pull-right">
                            <button type="submit" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Save" aria-describedby="tooltip815756">
                                <i class="fa fa-save"></i>
                            </button>
                            <a href="{{ url('admin/product-group') }}" class="btn btn-default" data-original-title="Cancel">
                                <i class="fa fa-reply"></i>
                            </a>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/product-group') }}">Product Group</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-pencil"></i> Edit Product Group
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">                            
                            

                            <div class="form-group required {{ $errors->has('name') ? ' has-error' : '' }}">
                                <label class="col-sm-2 control-label" for="name">
                                    Name
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" name="name" value="{{ old('name') ?: $results->name }}" placeholder="Product Group Name" id="name" class="form-control">
                                </div>
                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>


                            <div class="form-group required {{ $errors->has('description') ? ' has-error' : '' }}">
                                <label class="col-sm-2 control-label" for="description">
                                    Description
                                </label>
                                <div class="col-sm-10">
                                    <textarea name="description" placeholder="Description" id="description" class="form-control" rows="5">{{ old('description') ?: $results->desc }}</textarea>
                                </div>
                                @if ($errors->has('description'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('description') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group {{ $errors->has('customer_group') ? ' has-error' : '' }}">
                                <label class="col-sm-2 control-label" for="customer_group">
                                    Customer Group
                                </label>
                                <div class="col-sm-10">
                                    <select name="customer_group" id="customer_group" class="form-control">
                                        <option value="">All</option>
                                        @foreach($customer_group as $cg)
                                        <option value="{{$cg->id}}" @if(old('customer_group') ?: $results->customer_group_id==$cg->id) selected @endif>{{$cg->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                @if ($errors->has('customer_group'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('customer_group') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group {{ $errors->has('timed_discount') ? ' has-error' : '' }}">
                                <label class="col-sm-2 control-label">Timed Discount</label>
                                <div class="col-sm-10">
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="timed_discount" id="timed_discount1" value="0" class="timed_discount" @if(old('timed_discount') ?: $results->timed_discount==0) checked @endif>No
                                        </label>
                                    </div>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="timed_discount" id="timed_discount2" value="1" class="timed_discount" @if(old('timed_discount') ?: $results->timed_discount==1) checked @endif>Yes
                                        </label>
                                    </div>  
                                </div>
                            </div>


                            <div id="timed_discount_box" style="display:none;">
                                <div class="form-group required {{ $errors->has('start') ? ' has-error' : '' }}">
                                    <label class="col-sm-2 control-label" for="start">
                                        Start
                                    </label>
                                    <div class="col-sm-10">
                                        <input type="text" name="start" value="{{ old('start') ?: \Carbon\Carbon::parse($results->start)->format('d-m-Y H:i') }}" id="start" class="form-control datepicker">
                                    </div>
                                    @if ($errors->has('start'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('start') }}</strong>
                                        </span>
                                    @endif
                                </div>

                                <div class="form-group required {{ $errors->has('end') ? ' has-error' : '' }}">
                                    <label class="col-sm-2 control-label" for="end">
                                        End
                                    </label>
                                    <div class="col-sm-10">
                                        <input type="text" name="end" value="{{ old('end') ?: \Carbon\Carbon::parse($results->end)->format('d-m-Y H:i') }}" id="end" class="form-control datepicker">
                                    </div>
                                    @if ($errors->has('end'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('end') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group {{ $errors->has('group_discount') ? ' has-error' : '' }}">
                                <label class="col-sm-2 control-label">Group Discount</label>
                                <div class="col-sm-10">
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="group_discount" id="group_discount1" value="0" class="group_discount" @if(old('group_discount') ?: $results->group_discount==0) checked @endif>No
                                        </label>
                                    </div>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="group_discount" id="group_discount2" value="1" class="group_discount" @if(old('group_discount') ?: $results->group_discount==1) checked @endif>Yes
                                        </label>
                                    </div>  
                                </div>
                            </div>

                            <div id="group_discount_box">

                                <div class="form-group {{ $errors->has('bind_to') ? ' has-error' : '' }}">
                                    <label class="col-sm-2 control-label">Bind To</label>
                                    <div class="col-sm-10">
                                        <div class="radio">
                                            <label>
                                                <input type="radio" name="bind_to" id="bind_to1" value="0" class="bind_to" @if(old('bind_to') ?: $results->bind_to==0) checked @endif>All Product
                                            </label>
                                        </div>
                                        <div class="radio">
                                            <label style="width:100%;">
                                                <input type="radio" name="bind_to" id="bind_to2" value="1" class="bind_to" @if(old('bind_to') ?: $results->bind_to==1) checked @endif> 
                                                <select class="form-control category" name="category[]" id="category" multiple="multiple">
                                                    <option value=""></option>
                                                    @foreach($category as $cat)
                                                    <option value="{{$cat->id}}" @if(old('category')) @if(in_array($cat->id, old('category'))) selected @endif @else @if(in_array($cat->id, $results->ProductGroupToCategory()->pluck('category_id')->toArray() )) selected @endif @endif>{{$cat->name}}</option>
                                                    @endforeach
                                                </select>
                                            </label>
                                        </div>
                                        <div class="radio">
                                            <label>
                                                <input type="radio" name="bind_to" id="bind_to3" value="2" class="bind_to" @if(old('bind_to') ?: $results->bind_to==2) checked @endif>Custom
                                            </label>
                                        </div>  
                                    </div>
                                </div>

                                <div class="form-group required {{ $errors->has('discount_type') ? ' has-error' : '' }}">
                                    <label class="col-sm-2 control-label" for="discount_type">
                                        Discount Type
                                    </label>
                                    <div class="col-sm-10">
                                        <select name="discount_type" id="discount_type" class="form-control">
                                            <option value=""></option>
                                            @foreach($discount_type as $dis)
                                            <option value="{{$dis->id}}" @if(old('discount_type')) @if(old('discount_type')==$dis->id) selected @endif @else @if($results->discount_type_id==$dis->id) selected @endif @endif>{{$dis->name}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    @if ($errors->has('discount_type'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('discount_type') }}</strong>
                                        </span>
                                    @endif
                                </div>

                                <div class="form-group required {{ $errors->has('discount') ? ' has-error' : '' }}">
                                    <label class="col-sm-2 control-label" for="discount">
                                        Discount
                                    </label>
                                    <div class="col-sm-10">
                                        <input type="number" name="discount" value="{{ old('discount') ?: (int) ($results->discount+0) }}" placeholder="Discount" id="discount" class="form-control">
                                    </div>
                                    @if ($errors->has('discount'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('discount') }}</strong>
                                        </span>
                                    @endif
                                </div>

                                <div class="form-group required percentage-box" style="display:none;">
                                    <label class="col-sm-2 control-label" for="max_discount">
                                        Max Discount
                                    </label>
                                    <div class="col-sm-10">
                                        <input type="number" name="max_discount" value="{{ old('max_discount') ?: (int) ($results->max_discount+0) }}" placeholder="Max Discount" id="max_discount" class="form-control">
                                    </div>
                                    @if ($errors->has('max_discount'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('max_discount') }}</strong>
                                        </span>
                                    @endif
                                </div>

                                <div class="form-group required {{ $errors->has('minimum') ? ' has-error' : '' }}">
                                    <label class="col-sm-2 control-label" for="minimum">
                                        Minimum Quantity per Product
                                    </label>
                                    <div class="col-sm-10">
                                        <input type="number" name="minimum" value="{{ old('minimum') ?: $results->minimum }}" placeholder="Minimum Quantity per Product" id="minimum" class="form-control">
                                    </div>
                                    @if ($errors->has('minimum'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('minimum') }}</strong>
                                        </span>
                                    @endif
                                </div>

                                <div class="form-group required {{ $errors->has('maximum') ? ' has-error' : '' }}">
                                    <label class="col-sm-2 control-label" for="maximum">
                                        Maximum Quantity per Product
                                    </label>
                                    <div class="col-sm-10">
                                        <input type="number" name="maximum" value="{{ old('maximum') ?: $results->maximum }}" placeholder="Maximum Quantity per Product" id="maximum" class="form-control">
                                    </div>
                                    @if ($errors->has('maximum'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('maximum') }}</strong>
                                        </span>
                                    @endif
                                </div>

                            </div>

                            <div class="form-group {{ $errors->has('status') ? ' has-error' : '' }}">
                                <label class="col-sm-2 control-label" for="status">
                                    Status
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="status" id="status">
                                    @if(old('status'))
                                        <option value="1" @if(old('status')=='1') selected @endif>enabled</option>
                                        <option value="0" @if(old('status')=='0') selected @endif>disabled</option>
                                    @else
                                        <option value="1" @if($results->status=='1') selected @endif>enabled</option>
                                        <option value="0" @if($results->status=='0') selected @endif>disabled</option>
                                    @endif
                                    </select>
                                </div>
                                @if ($errors->has('status'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('status') }}</strong>
                                    </span>
                                @endif
                            </div>
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            @if($results->group_discount==1)

            @if($results->bind_to!=0)
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-list"></i> Product List
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="table">
                                <thead>
                                    <tr>
                                        <th>
                                            <input type="checkbox" onclick="$('input[name*=\'selected\']').prop('checked', this.checked);">
                                        </th>
                                        <th>Image</th>
                                        <th>Name</th>
                                        <th>Discount</th>
                                        <th>Min/Max Order</th>
                                        <th>Final Price</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                            </table>
                            <!-- /.table-responsive -->

                            <fieldset>
                                <legend>Add Product to Product Group</legend>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label" for="product">
                                        Choose Product
                                    </label>
                                    <div class="col-sm-10">
                                        <select name="product_id" id="product_id" class="form-control product">
                                            
                                        </select>
                                    </div>
                                    @if ($errors->has('product'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('product') }}</strong>
                                        </span>
                                    @endif
                                </div>
                                
                            </fieldset>
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            @endif

            @else
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-list"></i> Product List
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="table">
                                <thead>
                                    <tr>
                                        <th>
                                            <input type="checkbox" onclick="$('input[name*=\'selected\']').prop('checked', this.checked);">
                                        </th>
                                        <th>Image</th>
                                        <th>Name</th>
                                        <th>Discount</th>
                                        <th>Min/Max Order</th>
                                        <th>Final Price</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                            </table>
                            <!-- /.table-responsive -->

                            <fieldset>
                                <legend>Add Product to Product Group</legend>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label" for="product">
                                        Choose Product
                                    </label>
                                    <div class="col-sm-10">
                                        <select name="product_id" id="product_id" class="form-control product">
                                            
                                        </select>
                                    </div>
                                    @if ($errors->has('product'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('product') }}</strong>
                                        </span>
                                    @endif
                                </div>

                                <div class="form-group required">
                                    <label class="col-sm-2 control-label" for="product_discount_type">
                                        Discount Type
                                    </label>
                                    <div class="col-sm-10">
                                        <select name="product_discount_type" id="product_discount_type" class="form-control select2">
                                            <option value=""></option>
                                            @foreach($discount_type as $dis)
                                            <option value="{{$dis->id}}" @if(old('product_discount_type')==$dis->id) selected @endif>{{$dis->name}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    @if ($errors->has('product_discount_type'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('product_discount_type') }}</strong>
                                        </span>
                                    @endif
                                </div>

                                <div class="form-group required">
                                    <label class="col-sm-2 control-label" for="product_discount">
                                        Discount
                                    </label>
                                    <div class="col-sm-10">
                                        <input type="number" name="product_discount" value="{{ old('product_discount') ?: 0 }}" placeholder="Discount" id="product_discount" class="form-control">
                                    </div>
                                    @if ($errors->has('product_discount'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('product_discount') }}</strong>
                                        </span>
                                    @endif
                                </div>

                                <div class="form-group required product_percentage-box" style="display:none;">
                                    <label class="col-sm-2 control-label" for="product_max_discount">
                                        Max Discount
                                    </label>
                                    <div class="col-sm-10">
                                        <input type="number" name="product_max_discount" value="{{ old('product_max_discount') ?: 0 }}" placeholder="Max Discount" id="product_max_discount" class="form-control">
                                    </div>
                                    @if ($errors->has('product_max_discount'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('product_max_discount') }}</strong>
                                        </span>
                                    @endif
                                </div>

                                <div class="form-group required">
                                    <label class="col-sm-2 control-label" for="product_minimum">
                                        Minimum Quantity per Product
                                    </label>
                                    <div class="col-sm-10">
                                        <input type="number" name="product_minimum" value="{{ old('product_minimum') ?: 1 }}" placeholder="Minimum Quantity per Product" id="product_minimum" class="form-control">
                                    </div>
                                    @if ($errors->has('product_minimum'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('product_minimum') }}</strong>
                                        </span>
                                    @endif
                                </div>

                                <div class="form-group required">
                                    <label class="col-sm-2 control-label" for="product_maximum">
                                        Maximum Quantity per Product
                                    </label>
                                    <div class="col-sm-10">
                                        <input type="number" name="product_maximum" value="{{ old('product_maximum') ?: 1 }}" placeholder="Maximum Quantity per Product" id="product_maximum" class="form-control">
                                    </div>
                                    @if ($errors->has('product_maximum'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('product_maximum') }}</strong>
                                        </span>
                                    @endif
                                </div>

                                <div class="form-group">
                                    <button type="button" id="addProduct" class="btn btn-primary pull-right">Add Product</div>
                                </div>
                                
                            </fieldset>
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            @endif

            </form>
        </div>
        <!-- /#page-wrapper -->
@endsection

@section('script')
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.js"></script>
    <!-- include summernote css/js-->
    <script src="{{ asset('js/summernote.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.18/jquery.datetimepicker.full.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js"></script>
    <script>
        var note=0;
        function timedDiscount(){
            if(document.getElementById('timed_discount1').checked) {
              $('#timed_discount_box').hide();
            }else if(document.getElementById('timed_discount2').checked) {
              $('#timed_discount_box').show();
            }
        }

        function groupDiscount(){
            if(document.getElementById('group_discount1').checked) {
              $('#group_discount_box').hide();
            }else if(document.getElementById('group_discount2').checked) {
              $('#group_discount_box').show();
            }
        }

        function percentage(){
            $val=$('#discount_type').val();
            if($val==1){
                $('.percentage-box').show();
            }else{
                $('.percentage-box').hide();
            }
        }

        function product_percentage(){
            $val=$('#product_discount_type').val();
            if($val==1){
                $('.product_percentage-box').show();
            }else{
                $('.product_percentage-box').hide();
            }
        }
        

        $(document).ready(function() {
            $('.summernote').summernote({
                height: 200
            });
            $('.select2').select2();
            $('.category').select2({
                placeholder: "Select Category"
            });

            $('.datepicker').datetimepicker({
             format:'d-m-Y H:i'
            });
            timedDiscount();
            groupDiscount();

            @if($results->group_discount==1)

            $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax":{
                         "url": "{{ url('admin/product-group/product',$results->id) }}",
                         "dataType": "json",
                         "type": "POST",
                         "data":{ _token: "{{csrf_token()}}"}
                       },
                "columns": [
                    { "data": "id",
                      "orderable": false
                    },
                    { "data": "image",
                      "orderable": false
                    },
                    { "data": "name",
                      "orderable": false
                    },
                    { "data": "discount" },
                    { "data": "maximum" },
                    { "data": "final",
                      "orderable": false
                    },
                    { "data": "action",
                      "orderable": false
                    }
                ]    

            });

            @else

            $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax":{
                         "url": "{{ url('admin/product-group-1/product',$results->id) }}",
                         "dataType": "json",
                         "type": "POST",
                         "data":{ _token: "{{csrf_token()}}"}
                       },
                "columns": [
                    { "data": "id",
                      "orderable": false
                    },
                    { "data": "image",
                      "orderable": false
                    },
                    { "data": "name",
                      "orderable": false
                    },
                    { "data": "discount" },
                    { "data": "maximum" },
                    { "data": "final",
                      "orderable": false
                    },
                    { "data": "action",
                      "orderable": false
                    }
                ]    

            });

            @endif

            $('.product').select2({
                    placeholder: "Choose Product...",
                    ajax: {
                        url: '{{ url('admin/product-group/search-product', $results->id)}}',
                        dataType: 'json',
                        data: function (params) {
                            return {
                                q: $.trim(params.term)
                            };
                        },
                        processResults: function (data) {
                            return {
                                results: data
                            };
                        },
                        cache: true
                    }
                });

        });

        $('.timed_discount').on('click', function(){
            timedDiscount();
        });

        $('.group_discount').on('click', function(){
            if(note==0){
                swal('Information','Updating group discount will remove all assigned product','warning');
                note++;
            }
            groupDiscount();
        });

        $('#discount_type').on('change', function(){
            percentage();
        });

        $('#product_discount_type').on('change', function(){
            product_percentage();
        });

        @if($results->group_discount==1)

        $('.product').on("change", function(e) { 
            $('.loader-box').show(); 
            $val=$(this).val();
            var data={
                product_id: $val,
                _token: '{{csrf_token()}}'
            };
            console.log(data);
            $.post("{{url('admin/product-group/add-product',$results->id) }}", data, function(data){
            console.log(data);
            $('#table').DataTable().destroy();
            $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax":{
                         "url": "{{ url('admin/product-group/product',$results->id) }}",
                         "dataType": "json",
                         "type": "POST",
                         "data":{ _token: "{{csrf_token()}}"}
                       },
                "columns": [
                    { "data": "id",
                      "orderable": false
                    },
                    { "data": "image",
                      "orderable": false
                    },
                    { "data": "name",
                      "orderable": false
                    },
                    { "data": "discount" },
                    { "data": "maximum" },
                    { "data": "final",
                      "orderable": false
                    },
                    { "data": "action",
                      "orderable": false
                    }
                ]    

            });
            $('.loader-box').hide();
           });
        });

        @endif

        $(document).on("click", '.delete-product', function(event) { 
            $url=$(this).data('href');
            swal({
                  title: 'Are you sure?',
                  text: "You won't be able to revert this!",
                  type: 'warning',
                  showCancelButton: true,
                  confirmButtonColor: '#3085d6',
                  cancelButtonColor: '#d33',
                  confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                  if (result.value) {
                    window.location=$url;
                  }
                })
        });

        $(document).on("click", '#addProduct', function(event) { 
            $('.loader-box').show(); 
            $prod_id=$('#product_id').val();
            $discount_type=$('#product_discount_type').val();
            $discount=$('#product_discount').val();
            $max_discount=$('#product_max_discount').val();
            $minimum=$('#product_minimum').val();
            $maximum=$('#product_maximum').val();
            var data={
                product_id: $prod_id,
                discount_type: $discount_type,
                discount: $discount,
                max_discount: $max_discount,
                minimum: $minimum,
                maximum: $maximum,
                _token: '{{csrf_token()}}'
            };
            console.log(data);
            $.post("{{url('admin/product-group-1/add-product',$results->id) }}", data, function(data){
            console.log(data);
            $('#table').DataTable().destroy();
            $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax":{
                         "url": "{{ url('admin/product-group-1/product',$results->id) }}",
                         "dataType": "json",
                         "type": "POST",
                         "data":{ _token: "{{csrf_token()}}"}
                       },
                "columns": [
                    { "data": "id",
                      "orderable": false
                    },
                    { "data": "image",
                      "orderable": false
                    },
                    { "data": "name",
                      "orderable": false
                    },
                    { "data": "discount" },
                    { "data": "maximum" },
                    { "data": "final",
                      "orderable": false
                    },
                    { "data": "action",
                      "orderable": false
                    }
                ]    

            });
            $('.loader-box').hide();
           })
           .fail(function(data) {
                    var data=data;
                    var error=data.responseJSON.errors;
                    swal( "Error!",error[Object.keys(error)[0]][0],'error' );
                    $('.loader-box').hide();
               });
        });
    </script>
@endsection