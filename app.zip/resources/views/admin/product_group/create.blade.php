@extends('layouts.admin')

@section('title')
    Add Product Group
@endsection

@section('head')
    <!-- include summernote css/js-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.18/jquery.datetimepicker.min.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.min.css">

    <style type="text/css">
        textarea {
            overflow-x: hidden;
        }
    </style>
@endsection

@section('content')
     <div id="page-wrapper">
        <form role="form" action="{{ url('admin/product-group/store') }}" class="form-horizontal" enctype="multipart/form-data" method="post">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Add Product Group
                        <div class="pull-right">
                            <button type="submit" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Save" aria-describedby="tooltip815756">
                                <i class="fa fa-save"></i>
                            </button>
                            <a href="{{ url('admin/product-group') }}" class="btn btn-default" data-original-title="Cancel">
                                <i class="fa fa-reply"></i>
                            </a>
                        </div>
                    </h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="{{ url('admin/home') }}">Home</a>
                        </li>
                        <li>
                            <a href="{{ url('admin/product-group') }}">Product Group</a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-pencil"></i> Add Product Group
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">                            
                            

                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="name">
                                    Name
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" name="name" value="{{ old('name') }}" placeholder="Product Group Name" id="name" class="form-control">
                                </div>
                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>


                            <div class="form-group required">
                                <label class="col-sm-2 control-label" for="description">
                                    Description
                                </label>
                                <div class="col-sm-10">
                                    <textarea name="description" placeholder="Description" id="description" class="form-control" rows="5">{{ old('description') }}</textarea>
                                </div>
                                @if ($errors->has('description'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('description') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="customer_group">
                                    Customer Group
                                </label>
                                <div class="col-sm-10">
                                    <select name="customer_group" id="customer_group" class="form-control">
                                        <option value="">All</option>
                                        @foreach($customer_group as $cg)
                                        <option value="{{$cg->id}}" @if(old('customer_group')==$cg->id) selected @endif>{{$cg->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                @if ($errors->has('customer_group'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('customer_group') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Timed Discount</label>
                                <div class="col-sm-10">
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="timed_discount" id="timed_discount1" value="0" class="timed_discount" checked>No
                                        </label>
                                    </div>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="timed_discount" id="timed_discount2" value="1" class="timed_discount">Yes
                                        </label>
                                    </div>  
                                </div>
                            </div>


                            <div id="timed_discount_box" style="display:none;">
                                <div class="form-group required">
                                    <label class="col-sm-2 control-label" for="start">
                                        Start
                                    </label>
                                    <div class="col-sm-10">
                                        <input type="text" name="start" value="{{ old('start') }}" id="start" class="form-control datepicker">
                                    </div>
                                    @if ($errors->has('start'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('start') }}</strong>
                                        </span>
                                    @endif
                                </div>

                                <div class="form-group required">
                                    <label class="col-sm-2 control-label" for="end">
                                        End
                                    </label>
                                    <div class="col-sm-10">
                                        <input type="text" name="end" value="{{ old('end') }}" id="end" class="form-control datepicker">
                                    </div>
                                    @if ($errors->has('end'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('end') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Group Discount</label>
                                <div class="col-sm-10">
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="group_discount" id="group_discount1" value="0" class="group_discount" checked>No
                                        </label>
                                    </div>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="group_discount" id="group_discount2" value="1" class="group_discount">Yes
                                        </label>
                                    </div>  
                                </div>
                            </div>

                            <div id="group_discount_box">

                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Bind To</label>
                                    <div class="col-sm-10">
                                        <div class="radio">
                                            <label>
                                                <input type="radio" name="bind_to" id="bind_to1" value="0" class="bind_to" checked>All Product
                                            </label>
                                        </div>
                                        <div class="radio">
                                            <label style="width:100%;">
                                                <input type="radio" name="bind_to" id="bind_to2" value="1" class="bind_to">
                                                <select class="form-control category" name="category[]" id="category" multiple="multiple">
                                                    <option value=""></option>
                                                    @foreach($category as $cat)
                                                    <option value="{{$cat->id}}" @if(old('category')) @if(in_array($cat->id, old('category'))) selected @endif @endif>{{$cat->name}}</option>
                                                    @endforeach
                                                </select>
                                            </label>
                                        </div>
                                        <div class="radio">
                                            <label>
                                                <input type="radio" name="bind_to" id="bind_to3" value="2" class="bind_to" checked>Custom
                                            </label>
                                        </div>  
                                    </div>
                                </div>

                                <div class="form-group required">
                                    <label class="col-sm-2 control-label" for="discount_type">
                                        Discount Type
                                    </label>
                                    <div class="col-sm-10">
                                        <select name="discount_type" id="discount_type" class="form-control">
                                            <option value=""></option>
                                            @foreach($discount_type as $dis)
                                            <option value="{{$dis->id}}" @if(old('discount_type')==$dis->id) selected @endif>{{$dis->name}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    @if ($errors->has('discount_type'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('discount_type') }}</strong>
                                        </span>
                                    @endif
                                </div>

                                <div class="form-group required">
                                    <label class="col-sm-2 control-label" for="discount">
                                        Discount
                                    </label>
                                    <div class="col-sm-10">
                                        <input type="number" name="discount" value="{{ old('discount') ?: 0 }}" placeholder="Discount" id="discount" class="form-control">
                                    </div>
                                    @if ($errors->has('discount'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('discount') }}</strong>
                                        </span>
                                    @endif
                                </div>

                                <div class="form-group required percentage-box" style="display:none;">
                                    <label class="col-sm-2 control-label" for="max_discount">
                                        Max Discount
                                    </label>
                                    <div class="col-sm-10">
                                        <input type="number" name="max_discount" value="{{ old('max_discount') ?: 0 }}" placeholder="Max Discount" id="max_discount" class="form-control">
                                    </div>
                                    @if ($errors->has('max_discount'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('max_discount') }}</strong>
                                        </span>
                                    @endif
                                </div>

                                <div class="form-group required">
                                    <label class="col-sm-2 control-label" for="minimum">
                                        Minimum Quantity per Product
                                    </label>
                                    <div class="col-sm-10">
                                        <input type="number" name="minimum" value="{{ old('minimum') ?: 1 }}" placeholder="Minimum Quantity per Product" id="minimum" class="form-control">
                                    </div>
                                    @if ($errors->has('minimum'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('minimum') }}</strong>
                                        </span>
                                    @endif
                                </div>

                                <div class="form-group required">
                                    <label class="col-sm-2 control-label" for="maximum">
                                        Maximum Quantity per Product
                                    </label>
                                    <div class="col-sm-10">
                                        <input type="number" name="maximum" value="{{ old('maximum') ?: 1 }}" placeholder="Maximum Quantity per Product" id="maximum" class="form-control">
                                    </div>
                                    @if ($errors->has('maximum'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('maximum') }}</strong>
                                        </span>
                                    @endif
                                </div>

                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="status">
                                    Status
                                </label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="status" id="status">
                                        <option value="1" @if(old('status')=='1') selected @endif>enabled</option>
                                        <option value="0" @if(old('status')=='0') selected @endif>disabled</option>
                                    </select>
                                </div>
                                @if ($errors->has('status'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('status') }}</strong>
                                    </span>
                                @endif
                            </div>
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            </form>
        </div>
        <!-- /#page-wrapper -->
@endsection

@section('script')
    <!-- include summernote css/js-->
    <script src="{{ asset('js/summernote.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.18/jquery.datetimepicker.full.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js"></script>
    <script>
        function timedDiscount(){
            if(document.getElementById('timed_discount1').checked) {
              $('#timed_discount_box').hide();
            }else if(document.getElementById('timed_discount2').checked) {
              $('#timed_discount_box').show();
            }
        }

        function groupDiscount(){
            if(document.getElementById('group_discount1').checked) {
              $('#group_discount_box').hide();
            }else if(document.getElementById('group_discount2').checked) {
              $('#group_discount_box').show();
            }
        }

        function percentage(){
            $val=$('#discount_type').val();
            if($val==1){
                $('.percentage-box').show();
            }else{
                $('.percentage-box').hide();
            }
        }
        

        $(document).ready(function() {
            $('.summernote').summernote({
                height: 200
            });
            $('.select2').select2();
            $('.category').select2({
                placeholder: "Select Category"
            });

            $('.datepicker').datetimepicker({
             format:'d-m-Y H:i'
            });
            timedDiscount();
            groupDiscount();

        });

        $('.timed_discount').on('click', function(){
            timedDiscount();
        });

        $('.group_discount').on('click', function(){
            groupDiscount();
        });

        $('#discount_type').on('change', function(){
            percentage();
        });

        
    </script>
@endsection