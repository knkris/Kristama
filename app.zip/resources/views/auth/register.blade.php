@extends('layouts.front')

@section('title')
    Sign Up
@endsection

@section('content')
<!---- Content Start ---->
<section id="content" class="sign">
    <div class="title-head">
        <div class="container">
            <div class="row">
                <div class="col-lg-12  col-xs-12 col-sm-12">
                    <h3>Sign Up</h3>
                </div>
            </div>
        </div>      
    </div>
    <div class="container padding-bottom-80">
        <div class="row">
            <div class="col-lg-4 col-lg-offset-4 text-center col-xs-12 col-sm-12">
                @if($errors->any())
                    <div class="alert alert-danger" role="alert">
                        <ul style="text-align: left;margin-left: 20px;">
                          @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                          @endforeach
                        </ul>
                    </div>
                @endif
                <form class="space-side" method="POST" action="{{ route('register') }}">
                        {{ csrf_field() }}
                    <!-- <img class="bottom-m" src="img/logo-2.png" alt=""/> -->
                    <div class="field">
                        <input type="text" placeholder="First Name" name="firstname" value="{{ old('firstname') }}" required/>
                    </div>
                    <div class="field">
                        <input type="text" placeholder="Last Name" name="lastname" value="{{ old('lastname') }}"/>
                    </div>
                    <div class="field text-left">
                        <div class="col-lg-12 flush col-sm-12 col-xs-12">
                            <label>Date of Birth</label>
                        </div>
                        <div class="col-lg-3 text-center flush col-sm-3 col-xs-12">
                            <input type="text" placeholder="DD" name="date_of_birth" value="{{ old('date_of_birth') }}" required/>
                        </div>
                        <div class="col-lg-1 flush text-center  col-sm-1 col-xs-1">
                            <i class="fa fa-minus" aria-hidden="true"></i>
                        </div>
                        <div class="col-lg-3 text-center flush col-sm-3 col-xs-12">
                            <input type="text" placeholder="MM" name="month_of_birth" value="{{ old('month_of_birth') }}" required/>
                        </div>
                        <div class="col-lg-1 flush text-center  col-sm-1 col-xs-1"> 
                            <i class="fa fa-minus" aria-hidden="true"></i>
                        </div>
                        <div class="col-lg-4 text-center flush col-sm-4 col-xs-12">
                            <input type="text" placeholder="YYYY" name="year_of_birth" value="{{ old('year_of_birth') }}" required/>
                        </div>
                    </div>
                    <div class="field">
                        <select name="gender">
                            <option>Gender</option>
                            <option value="M" @if(old('gender')=="M") selected @endif>Male</option>
                            <option value="F" @if(old('gender')=="F") selected @endif>Female</option>
                        </select>
                    </div>
                    <div class="field">
                        <div class="col-lg-12 flush text-left col-sm-12 col-xs-12">
                            <label>Phone Number</label>
                        </div>
                        <input type="tel" placeholder="+62" name="phone" value="{{ old('phone')?: '+62' }}" required/>
                    </div>
                    <div class="field">
                        <input type="email" placeholder="Email Address" name="email" value="{{ old('email') }}" required/>
                    </div>
                    <div class="field">
                        <input type="password" placeholder="Password" name="password" />
                    </div>
                    <div class="field">
                        <input type="password" placeholder="Re-Type Password" name="password_confirmation"" />
                    </div>
                    <div class="field">
                        <label class="small-text"><input type="checkbox" name="newsletter" /> Sign up tp recieve special offers</label>
                    </div>
                    <div class="field">
                        <input class="t-b-space" type="submit" value="Sign Up"/>
                    </div>
                    <div class="field">
                        <label class="small-text">By creating an account, you agree to our <a href="#">terms</a></label>
                    </div>

                </form>
                
            </div>  
        </div>  
    </div>
</section>
<!-- <div class="fixed">
                    <ul>
                        <li><a href="{{ route('sign.up')}}" data-toggle="tooltip" data-placement="top" title="Sign Up"><img src="img/user-1-small.png" alt="" width="40px;" /></a></li>
                        <li><a href="{{ route('sign.in') }}" data-toggle="tooltip" data-placement="top" title="Sign In"><img src="img/user-2-small.png" alt="" width="40px;" /></a></li>
                    </ul>
                </div> -->
<!---- Content End ---->
@endsection
