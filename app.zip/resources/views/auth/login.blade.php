@extends('layouts.front')

@section('title')
    Sign In
@endsection

@section('content')
<!---- Content Start ---->
<section id="content" class="sign">
    <div class="title-head">
        <div class="container">
            <div class="row">
                <div class="col-lg-12  col-xs-12 col-sm-12">
                    <h3>Sign In</h3>
                </div>
            </div>
        </div>      
    </div>
    <div class="container" style="padding-bottom:80px;">
        <div class="row">
            <div class="col-lg-4 col-lg-offset-4 text-center col-xs-12 col-sm-12">
                 @if($errors->any())
                    <div class="alert alert-danger" role="alert">
                        <ul style="text-align: left;margin-left: 20px;">
                          @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                          @endforeach
                        </ul>
                    </div>
                @endif
                <form class="space-side" method="POST" action="{{ route('login') }}">
                    {{ csrf_field() }}
                    <input type="hidden" name="back_url" value="{{ url()->previous() }}">
                    <!-- <img class="bottom-m" src="img/logo-2.png" alt=""/> -->
                    <div class="field">
                        <input type="email" placeholder="Email" name="email" value="{{ old('email') }}" required autofocus/>
                    </div>
                    <div class="field">
                        <input type="password" placeholder="password" name="password" required/>
                    </div>
                    <div class="field">
                        <input type="submit" value="Sign In"/>
                    </div>
                    <!-- <div class="field">
                        <label>or Sign In with</label>
                    </div> -->
                    <div class="field">
                        <a class="link" href="{{ url('login/facebook') }}"><img src="img/facebook.png" alt=""/> Facebook</a>
                        <a class="link" href="{{ url('login/google') }}"><img src="img/google.png" alt=""/> Google</a>
                    </div>
                    <div class="field">
                        <label>haven't account yet?</label> <a style="color:#b62327" href="{{ url('sign-up') }}">sign up</a> now!
                    </div>
                </form>
            </div>  
        </div>  
    </div>
</section>
<!-- <div class="fixed">
	<ul>
		<li><a href="{{ route('sign.up')}}" data-toggle="tooltip" data-placement="top" title="Sign Up"><img src="img/user-1-small.png" alt="" width="40px;" /></a></li>
		<li><a href="{{ route('sign.in') }}" data-toggle="tooltip" data-placement="top" title="Sign In"><img src="img/user-2-small.png" alt="" width="40px;" /></a></li>
	</ul>
</div> -->
<!---- Content End ---->
@endsection
