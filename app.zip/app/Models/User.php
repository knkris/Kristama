<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Permission\Traits\HasRoles;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Countries;

class User extends Authenticatable
{
    use HasRoles, Notifiable;

    protected $guard_name = 'web';
    protected $table = 'users';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];
    protected $fillable = array('customer_group_id', 'name', 'firstname', 'lastname', 'gender', 'dob', 'email', 'password', 'remember_token', 'telephone', 'fax', 'newsletter', 'ip', 'status', 'confirmation_code', 'verify', 'safe', 'token', 'code', 'country_id', 'about', 'avatar');

    function getFullNameAttribute()
    {
      return $this->attributes['firstname'] . ' ' . $this->attributes['lastname'];
    }

    public function Wishlist()
    {
        return $this->hasMany('App\Models\Wishlist');
    }

    public function Cart()
    {
        return $this->hasMany('App\Models\Cart');
    }

    public function Order()
    {
        return $this->hasMany('App\Models\Order');
    }

    public function Address()
    {
        return $this->hasMany('App\Models\Address');
    }

    public function CustomerGroup()
    {
        return $this->belongsTo('App\Models\CustomerGroup');
    }

    public function Country()
    {
        $country=Countries::find($this->country_id);
        return $country;
    }

    public function ProductReview()
    {
        return $this->hasMany('App\Models\ProductReview');
    }

    public function ProductDiscussion()
    {
        return $this->hasMany('App\Models\ProductDiscussion');
    }

    public function ViewHistory()
    {
        return $this->hasMany('App\Models\ViewHistory');
    }

    public function EmailPreference()
    {
        return $this->hasOne('App\Models\EmailPreference');
    }

    public function CartQty()
    {
        $qty=0;
        foreach ($this->Cart as $key => $value) {
            $qty+=$value->qty;
        }

        return $qty;
    }

    public function getPhotoUrlAttribute()
    {
        return 'https://www.gravatar.com/avatar/'.md5(strtolower($this->email)).'.jpg?s=200&d=mm';
    }

}