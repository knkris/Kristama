<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProductOption extends Model
{
    protected $table = 'product_option';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];
    protected $fillable = array('product_id', 'option_id', 'value', 'required', 'stock_enabled');

    public function Option()
    {
        return $this->belongsTo('App\Models\Option', 'option_id');
    }

    public function Product()
    {
        return $this->belongsTo('App\Models\Product');
    }

    public function ProductOptionDetail()
    {
        return $this->hasMany('App\Models\ProductOptionDetail');
    }
}
