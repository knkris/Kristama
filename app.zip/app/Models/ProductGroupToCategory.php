<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductGroupToCategory extends Model
{
    protected $table = 'product_group_to_category';
    public $timestamps = false;

    protected $fillable = array('product_group_id', 'category_id');

    public function ProductGroup()
    {
        return $this->belongsTo('App\Models\ProductGroup');
    }

    public function Category()
    {
        return $this->belongsTo('App\Models\Category');
    }
}
