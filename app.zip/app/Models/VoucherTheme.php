<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VoucherTheme extends Model
{
    protected $table = 'voucher_theme';
    public $timestamps = true;

    protected $fillable = array('name', 'image');

    public function Voucher()
    {
        return $this->hasMany('App\Models\Voucher');
    }
}
