<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CustomerGroup extends Model 
{

    protected $table = 'customer_group';
    public $timestamps = true;
    protected $fillable = array('name', 'desc', 'sort_order');

    public function User()
    {
        return $this->hasMany('App\Models\User');
    }

}