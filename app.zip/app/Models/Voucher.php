<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Voucher extends Model
{
    protected $table = 'voucher';
    public $timestamps = true;

    protected $fillable = array('voucher_theme_id', 'code', 'value', 'order_id', 'user_id', 'message', 'status', 'created_by', 'expired_at');

    public function VoucherTheme()
    {
        return $this->belongsTo('App\Models\VoucherTheme');
    }
}
