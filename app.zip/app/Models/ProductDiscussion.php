<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProductDiscussion extends Model 
{

    protected $table = 'product_discussion';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];
    protected $fillable = array('product_id', 'user_id', 'text', 'parent_id', 'ip');

    public function Product()
    {
        return $this->belongsTo('App\Models\Product');
    }

    public function User()
    {
        return $this->belongsTo('App\Models\User');
    }

    public function getConversation()
    {
        $get=ProductDiscussion::whereParent_id($this->id)->get();
        return $get;
    }

}