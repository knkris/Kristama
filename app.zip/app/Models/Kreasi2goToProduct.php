<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Kreasi2goToProduct extends Model
{
    protected $table = 'kreasi2go_to_product';
    public $timestamps = false;

    protected $fillable = array('kreasi2go_id', 'product_id');

    public function Kreasi2go()
    {
        return $this->belongsTo('App\Models\Kreasi2go');
    }

    public function Product()
    {
        return $this->belongsTo('App\Models\Product');
    }
}
