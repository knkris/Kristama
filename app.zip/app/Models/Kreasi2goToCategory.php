<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Kreasi2goToCategory extends Model
{
    protected $table = 'kreasi2go_to_category';
    public $timestamps = false;

    protected $fillable = array('kreasi2go_id', 'category_id');

    public function Kreasi2go()
    {
        return $this->belongsTo('App\Models\Kreasi2go');
    }

    public function Category()
    {
        return $this->belongsTo('App\Models\Category');
    }
}
