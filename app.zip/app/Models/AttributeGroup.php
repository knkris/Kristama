<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AttributeGroup extends Model
{
    protected $table = 'attribute_group';
    public $timestamps = true;

    protected $fillable = array('name', 'sort_order');

    public function Attribute()
    {
        return $this->hasMany('App\Models\Attribute');
    }
}
