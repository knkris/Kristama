<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Subdistrict extends Model
{
    protected $table = 'subdistrict';
    public $timestamps = true;
    protected $fillable = array('province_id', 'city_id', 'province', 'city', 'type', 'name');

    public function Province()
    {
        return $this->belongsTo('App\Models\Province', 'province_id');
    }

    public function City()
    {
        return $this->belongsTo('App\Models\City', 'city_id');
    }
}
