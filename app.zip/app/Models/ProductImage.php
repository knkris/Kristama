<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProductImage extends Model 
{

    protected $table = 'product_image';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];
    protected $fillable = array('product_id', 'image', 'sort');

    public function Product()
    {
        return $this->belongsTo('App\Models\Product');
    }

}