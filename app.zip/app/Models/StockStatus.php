<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StockStatus extends Model 
{

    protected $table = 'stock_status';
    public $timestamps = true;
    protected $fillable = array('name_en', 'name_id');

}