<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Blog extends Model
{
    protected $table = 'blog';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];
    protected $fillable = array('title', 'image', 'cover', 'content', 'meta_title', 'meta_description', 'meta_keyword', 'slug', 'admin_id', 'hot', 'trending', 'category', 'viewed', 'shared');

    public function BlogToBlog()
    {
        return $this->hasMany('App\Models\BlogToBlog');
    }

    public function BlogToProduct()
    {
        return $this->hasMany('App\Models\BlogToProduct');
    }

    public function BlogLike()
    {
        return $this->hasMany('App\Models\BlogLike');
    }

    public function BlogComment()
    {
        return $this->hasMany('App\Models\BlogComment');
    }

    public function Admin()
    {
        return $this->belongsTo('App\Models\Admin');
    }
}
