<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductToProduct extends Model
{
    protected $table = 'product_to_product';
    public $timestamps = true;


    protected $fillable = array('to_product_id', 'product_id');

    public function ToProduct()
    {
        return $this->belongsTo('App\Models\Product', 'to_product_id');
    }

    public function Product()
    {
        return $this->belongsTo('App\Models\Product');
    }
}
