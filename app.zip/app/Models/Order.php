<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Order extends Model 
{

    protected $table = 'order';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];
    protected $fillable = array('invoice', 'user_id', 'name', 'email', 'telephone', 'fax', 'payment_name', 'payment_company', 'payment_address', 'payment_province', 'payment_city', 'payment_postal_code', 'payment_telephone', 'shipping_courier', 'courier_service', 'shipping_name', 'shipping_company', 'shipping_address', 'shipping_province', 'shipping_city', 'shipping_postal_code', 'shipping_telephone', 'order_status_id', 'shipping_city', 'coupon', 'subtotal', 'shipping_cost', 'transfer_code', 'total', 'comment', 'ip', 'forwarded_ip', 'user_agent', 'accept_language', 'dropship', 'bank_code', 'bank');

    public function CustomerGroup()
    {
        return $this->belongsTo('App\Models\CustomerGroup');
    }

    public function OrderDetail()
    {
        return $this->hasMany('App\Models\OrderDetail');
    }

    public function OrderHistory()
    {
        return $this->hasMany('App\Models\OrderHistory');
    }

     public function NicepayTransaction()
    {
        return $this->hasOne('App\Models\NicepayTransaction');
    }

    public function OrderReturn()
    {
        return $this->hasOne('App\Models\OrderReturn');
    }

    public function User()
    {
        return $this->belongsTo('App\Models\User');
    }

    public function OrderStatus()
    {
        return $this->belongsTo('App\Models\OrderStatus');
    }

    public function orderQty()
    {
        $qty=0;
        foreach ($this->OrderDetail as $key => $value) {
            $qty+=$value->qty;
        }

        return $qty;
    }

}