<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PermissionGroup extends Model
{
    protected $table = 'permission_group';
    public $timestamps = true;
    protected $fillable = array('name', 'permission_id');

    public function Permission()
    {
        return $this->belongsTo('\Spatie\Permission\Models\Permission');
    }
}
