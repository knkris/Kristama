<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductAttribute extends Model
{
    protected $table = 'product_attribute';
    public $timestamps = true;

    protected $fillable = array('product_id', 'attribute_id', 'value');

    public function Attribute()
    {
        return $this->belongsTo('App\Models\Attribute');
    }

    public function Product()
    {
        return $this->belongsTo('App\Models\Product');
    }
}
