<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RecommendedProduct extends Model
{
    protected $table = 'recommended_product';

    protected $fillable = array('product_id');

    public function Product()
    {
        return $this->belongsTo('App\Models\Product');
    }
}
