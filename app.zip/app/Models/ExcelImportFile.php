<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ExcelImportFile extends Model
{
    protected $table = 'excel_import_file';
    public $timestamps = true;

    protected $fillable = array('path', 'filename', 'imported', 'token');

}
