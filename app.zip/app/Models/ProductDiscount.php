<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductDiscount extends Model
{
    protected $table = 'product_discount';
    public $timestamps = true;
    protected $fillable = array('customer_group_id', 'product_id', 'price', 'priority', 'quantity', 'start', 'end');

    public function Product()
    {
        return $this->belongsTo('App\Models\Product');
    }

    public function CustomerGroup()
    {
        return $this->belongsTo('App\Models\CustomerGroup');
    }
}
