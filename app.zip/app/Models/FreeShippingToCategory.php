<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FreeShippingToCategory extends Model
{
    protected $table = 'free_shipping_to_category';
    public $timestamps = false;

    protected $fillable = array('free_shipping_id', 'category_id');

    public function FreeShipping()
    {
        return $this->belongsTo('App\Models\FreeShipping');
    }

    public function Category()
    {
        return $this->belongsTo('App\Models\Category');
    }
}
