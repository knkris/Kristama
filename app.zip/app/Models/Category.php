<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model 
{

    protected $table = 'category';
    public $timestamps = true;
    protected $fillable = array('name', 'desc', 'slug', 'image', 'parent_id', 'meta_title', 'meta_description', 'meta_keyword');

    public function Product()
    {
        return $this->hasMany('App\Models\Product');
    }

    public function ProductToCategory()
    {
        return $this->hasMany('App\Models\ProductToCategory');
    }

    public function parent()
    {
    	$par=Category::find($this->parent_id);
        return $par;
    }

    public function child()
    {
        $child=Category::whereParent_id($this->id)->get();
        return $child;
    }

    public function fullname()
    {
    	$parentname=""; 
        if($this->parent_id!=null){
            $parent=$this->parent();
            $parentname.=$parent->name." > ";
            if($parent->parent_id!=null){
                $parent2=$parent->parent();
                $parentname=$parent2->name." > ".$parentname;
            }
        }
        return $parentname.$this->name;
    }

}