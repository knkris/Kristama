<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\ProductGroup;
use App\Models\ProductGroupDetail;
use Carbon\Carbon;
use Nicolaslopezj\Searchable\SearchableTrait;

class Product extends Model 
{

    protected $table = 'product';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];
    protected $fillable = array('model', 'name', 'sku', 'desc', 'short_desc', 'slug', 'category', 'manufacturer_id', 'related', 'price', 'price_filter', 'qty', 'status', 'weight', 'weight_class_id', 'length', 'width', 'height', 'length_class_id', 'substract', 'minimum', 'sort_order', 'viewed', 'stock_status_id', 'shipping', 'point');

    use SearchableTrait;

    protected $searchable = [
        'columns' => [
            'product.name' => 10,
            'product.model' => 10,
            'product.desc' => 8
        ]
    ];

    // public function Category()
    // {
    //     return $this->belongsTo('App\Models\Category');
    // }

    public function Manufacturer()
    {
        return $this->belongsTo('App\Models\Manufacturer');
    }

    public function Image()
    {
        return $this->hasMany('App\Models\ProductImage');
    }

    public function WeightClass()
    {
        return $this->belongsTo('App\Models\WeightClass');
    }

    public function LengthClass()
    {
        return $this->belongsTo('App\Models\LengthClass');
    }

    public function StockStatus()
    {
        return $this->belongsTo('App\Models\StockStatus');
    }

    public function ProductAttribute()
    {
        return $this->hasMany('App\Models\ProductAttribute');
    }

    public function ProductDiscount()
    {
        return $this->hasMany('App\Models\ProductDiscount');
    }

    public function ProductSpecial()
    {
        return $this->hasMany('App\Models\ProductSpecial');
    }

    public function ProductReview()
    {
        return $this->hasMany('App\Models\ProductReview');
    }

    public function ProductDiscussion()
    {
        return $this->hasMany('App\Models\ProductDiscussion');
    }

    public function ProductOption()
    {
        return $this->hasMany('App\Models\ProductOption');
    }

     public function ProductStock()
    {
        return $this->hasMany('App\Models\ProductStock');
    }

    public function ViewHistory()
    {
        return $this->hasMany('App\Models\ViewHistory');
    }

    public function ProductToCategory()
    {
        return $this->hasMany('App\Models\ProductToCategory');
    }

    public function ProductToProduct()
    {
        return $this->hasMany('App\Models\ProductToProduct');
    }

    public function Star()
    {
        return $this->ProductReview()->whereStatus(1)->avg('rating');
    }

    public function Variant()
    {
        if($this->model!=null){
            return Product::whereModel($this->model)->where('id', '!=', $this->id)->get();
        }else{
            return [];
        }
    }

    public function finalPrice($cust_group,$qty=1)
    {
        $finalPrice=[];
        $finalPrice[]=$this->price_filter;
        //find grouped discount
        $product_group=ProductGroup::where('customer_group_id','=',$cust_group)
            ->orWhereNull('customer_group_id')
            ->where('bind_to','=',0)
            ->whereGroup_discount(1)
            ->where('minimum','>=',$qty)
            ->where('maximum','<=',$qty)
            ->whereStatus(1)
            ->get();
        if(count($product_group)>0){
            foreach($product_group as $pg){
                if($pg->timed_discount==1){
                    $now=Carbon::now();
                    $start=Carbon::parse($pg->start);
                    $end=Carbon::parse($pg->end);
                    if($now>$start && $end>$now){
                        switch ($pg->discount_type_id) {
                          case '1':
                            $initprice=$this->price_filter;
                            $disc=($initprice*(round($pg->discount)/100));
                            if($pg->max_discount>1){
                              if($disc>$pg->max_discount){
                                $disc=$pg->max_discount;
                              }
                            }
                            $final=$this->price_filter-$disc;
                            $finalPrice[]= $final;
                            break;

                          case '2':
                            $initprice=$this->price_filter;
                            $final=$this->price_filter-round($pg->discount);
                            $finalPrice[]= $final;
                            break;

                          case '3':
                            $final=$pg->discount;
                            $finalPrice[]= $final;
                            break;
                          
                        }
                    }
                }
            }
        }
        //find grouped in category
        $product_group=ProductGroup::where('customer_group_id','=',$cust_group)
            ->orWhereNull('customer_group_id')
            ->where('bind_to','=',1)
            ->whereGroup_discount(1)
            ->where('minimum','>=',$qty)
            ->where('maximum','<=',$qty)
            ->whereStatus(1)
            ->get();
        if(count($product_group)>0){
            foreach($product_group as $pg){
                $pg_to_cat=$pg->ProductGroupToCategory()->pluck('category_id')->toArray();
                $prod_to_cat=$this->ProductToCategory()->pluck('category_id')->toArray();
                $condition=false;
                foreach ($prod_to_cat as $key => $value) {
                    if(in_array($value, $pg_to_cat)){
                        $condition=true;
                    }
                }
                if($condition==true){
                    if($pg->timed_discount==1){
                        $now=Carbon::now();
                        $start=Carbon::parse($pg->start);
                        $end=Carbon::parse($pg->end);
                        if($now>$start && $end>$now){
                            switch ($pg->discount_type_id) {
                              case '1':
                                $initprice=$this->price_filter;
                                $disc=($initprice*(round($pg->discount)/100));
                                if($pg->max_discount>1){
                                  if($disc>$pg->max_discount){
                                    $disc=$pg->max_discount;
                                  }
                                }
                                $final=$this->price_filter-$disc;
                                $finalPrice[]= $final;
                                break;

                              case '2':
                                $initprice=$this->price_filter;
                                $final=$this->price_filter-round($pg->discount);
                                $finalPrice[]= $final;
                                break;

                              case '3':
                                $final=$pg->discount;
                                $finalPrice[]= $final;
                                break;
                              
                            }
                        }
                    }else{
                        switch ($pg->discount_type_id) {
                              case '1':
                                $initprice=$this->price_filter;
                                $disc=($initprice*(round($pg->discount)/100));
                                if($pg->max_discount>1){
                                  if($disc>$pg->max_discount){
                                    $disc=$pg->max_discount;
                                  }
                                }
                                $final=$this->price_filter-$disc;
                                $finalPrice[]= $final;
                                break;

                              case '2':
                                $initprice=$this->price_filter;
                                $final=$this->price_filter-round($pg->discount);
                                $finalPrice[]= $final;
                                break;

                              case '3':
                                $final=$pg->discount;
                                $finalPrice[]= $final;
                                break;
                              
                            }
                    }
                }else{ //look for self assigned product
                    // $product_group=ProductGroup::whereHas('ProductGroupDetail', function ($query) use ($this) {
                    //             $query->where('product_id','=',$this->id);
                    //         })
                    //         ->whereStatus(1)
                    //         ->get();
                    $pgd=$pg->ProductGroupDetail()->whereProduct_id($this->id)->count();
                    //foreach($product_group as $pg){
                    if($pgd>0){
                        if($pg->timed_discount==1){
                            $now=Carbon::now();
                            $start=Carbon::parse($pg->start);
                            $end=Carbon::parse($pg->end);
                            if($now>$start && $end>$now){
                                switch ($pg->discount_type_id) {
                                  case '1':
                                    $initprice=$this->price_filter;
                                    $disc=($initprice*(round($pg->discount)/100));
                                    if($pg->max_discount>1){
                                      if($disc>$pg->max_discount){
                                        $disc=$pg->max_discount;
                                      }
                                    }
                                    $final=$this->price_filter-$disc;
                                    $finalPrice[]= $final;
                                    break;

                                  case '2':
                                    $initprice=$this->price_filter;
                                    $final=$this->price_filter-round($pg->discount);
                                    $finalPrice[]= $final;
                                    break;

                                  case '3':
                                    $final=$pg->discount;
                                    $finalPrice[]= $final;
                                    break;
                                  
                                }
                            }
                        }else{
                            switch ($pg->discount_type_id) {
                                  case '1':
                                    $initprice=$this->price_filter;
                                    $disc=($initprice*(round($pg->discount)/100));
                                    if($pg->max_discount>1){
                                      if($disc>$pg->max_discount){
                                        $disc=$pg->max_discount;
                                      }
                                    }
                                    $final=$this->price_filter-$disc;
                                    $finalPrice[]= $final;
                                    break;

                                  case '2':
                                    $initprice=$this->price_filter;
                                    $final=$this->price_filter-round($pg->discount);
                                    $finalPrice[]= $final;
                                    break;

                                  case '3':
                                    $final=$pg->discount;
                                    $finalPrice[]= $final;
                                    break;
                                  
                                }
                        }
                    }
                }
            }
        }
        //find grouped in custom
        $prod=$this;
        $product_group=ProductGroup::whereHas('ProductGroupDetail', function ($query) use ($prod,$qty) {
                    $query->where('product_id','=',$prod->id);
                })
                ->where('customer_group_id','=',$cust_group)
                ->orWhereNull('customer_group_id')
                ->where('bind_to','=',2)
                ->whereGroup_discount(1)
                ->where('minimum','>=',$qty)
                ->where('maximum','<=',$qty)
                ->whereStatus(1)
                ->get();
        foreach($product_group as $pg){
            if($pg->timed_discount==1){
                $now=Carbon::now();
                $start=Carbon::parse($pg->start);
                $end=Carbon::parse($pg->end);
                if($now>$start && $end>$now){
                    switch ($pg->discount_type_id) {
                      case '1':
                        $initprice=$this->price_filter;
                        $disc=($initprice*(round($pg->discount)/100));
                        if($pg->max_discount>1){
                          if($disc>$pg->max_discount){
                            $disc=$pg->max_discount;
                          }
                        }
                        $final=$this->price_filter-$disc;
                        $finalPrice[]= $final;
                        break;

                      case '2':
                        $initprice=$this->price_filter;
                        $final=$this->price_filter-round($pg->discount);
                        $finalPrice[]= $final;
                        break;

                      case '3':
                        $final=$pg->discount;
                        $finalPrice[]= $final;
                        break;
                      
                    }
                }
            }
        }
        //find non grouped
        $prod=$this;
        $product_group=ProductGroup::whereHas('ProductGroupDetail', function ($query) use ($prod,$qty) {
                    $query->where('product_id','=',$prod->id);
                    $query->where('minimum','>=',$qty);
                    $query->where('maximum','<=',$qty);
                })
                ->where('customer_group_id','=',$cust_group)
                ->orWhereNull('customer_group_id')
                ->whereGroup_discount(0)
                ->whereStatus(1)
                ->get();
        foreach($product_group as $pg){
            $pgd=$pg->ProductGroupDetail()->whereProduct_id($this->id)->first();
            if($pg->timed_discount==1){
                $now=Carbon::now();
                $start=Carbon::parse($pg->start);
                $end=Carbon::parse($pg->end);
                if($now>$start && $end>$now){
                    switch ($pgd->discount_type_id) {
                      case '1':
                        $initprice=$this->price_filter;
                        $disc=($initprice*(round($pgd->discount)/100));
                        if($pgd->max_discount>1){
                          if($disc>$pgd->max_discount){
                            $disc=$pgd->max_discount;
                          }
                        }
                        $final=$this->price_filter-$disc;
                        $finalPrice[]= $final;
                        break;

                      case '2':
                        $initprice=$this->price_filter;
                        $final=$this->price_filter-round($pgd->discount);
                        $finalPrice[]= $final;
                        break;

                      case '3':
                        $final=$pgd->discount;
                        $finalPrice[]= $final;
                        break;
                      
                    }
                }
            }else{
                switch ($pgd->discount_type_id) {
                      case '1':
                        $initprice=$this->price_filter;
                        $disc=($initprice*(round($pgd->discount)/100));
                        if($pgd->max_discount>1){
                          if($disc>$pgd->max_discount){
                            $disc=$pgd->max_discount;
                          }
                        }
                        $final=$this->price_filter-$disc;
                        $finalPrice[]= $final;
                        break;

                      case '2':
                        $initprice=$this->price_filter;
                        $final=$this->price_filter-round($pgd->discount);
                        $finalPrice[]= $final;
                        break;

                      case '3':
                        $final=$pgd->discount;
                        $finalPrice[]= $final;
                        break;
                      
                    }
            }
        }
        //find product discount
        $prod_discount=$this->ProductDiscount()->where('quantity','<=',$qty)->get();
        if(count($prod_discount)>0){
            foreach($prod_discount as $pd){
                if($pd->start!=null && $pd->end!=null){
                    $now=Carbon::now();
                    $start=Carbon::parse($pd->start);
                    $end=Carbon::parse($pd->end);
                    if($now>$start && $end>$now){
                        $finalPrice[]=$pd->price;
                    }
                }else{
                    $finalPrice[]=$pd->price;
                }
            }
        }

        //find product Special
        $prod_special=$this->ProductSpecial()->get();
        if(count($prod_special)>0){
            foreach($prod_special as $pd){
                if($pd->start!=null && $pd->end!=null){
                    $now=Carbon::now();
                    $start=Carbon::parse($pd->start);
                    $end=Carbon::parse($pd->end);
                    if($now>$start && $end>$now){
                        $finalPrice[]=$pd->price;
                    }
                }else{
                    $finalPrice[]=$pd->price;
                }
            }
        }

        $lowestprice=min($finalPrice);
        return $lowestprice;
    }



}