<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ViewHistory extends Model 
{

    protected $table = 'view_history';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];
    protected $fillable = array('product_id', 'user_id');

    public function Product()
    {
        return $this->belongsTo('Product');
    }

    public function User()
    {
        return $this->belongsTo('User');
    }

}