<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NicepayTransaction extends Model
{
    protected $table = 'nicepay_transaction';
    public $timestamps = true;
    protected $fillable = array('order_id', 'txid', 'callbackurl', 'description', 'payment_date', 'payment_time', 'va_number', 'result_code', 'result_message', 'reference', 'payment_method', 'status');

    public function Order()
    {
        return $this->belongsTo('App\Models\Order');
    }
}
