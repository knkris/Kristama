<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Address extends Model 
{

    protected $table = 'address';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];
    protected $fillable = array('user_id', 'name', 'company', 'address', 'subdistrict_id', 'custom_field', 'telephone', 'postal_code');

    public function User()
    {
        return $this->belongsTo('App\Models\User');
    }

    public function Subdistrict()
    {
        return $this->belongsTo('App\Models\Subdistrict');
    }

    public function getCity()
    {
        $subdistrict=$this->Subdistrict;
        return $subdistrict->name.' - '.$subdistrict->city;
    }

}