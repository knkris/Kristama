<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FreeShippingToProduct extends Model
{
    protected $table = 'free_shipping_to_product';
    public $timestamps = false;

    protected $fillable = array('free_shipping_id', 'product_id');

    public function FreeShipping()
    {
        return $this->belongsTo('App\Models\FreeShipping');
    }

    public function Product()
    {
        return $this->belongsTo('App\Models\Product');
    }
}
