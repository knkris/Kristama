<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Attribute extends Model
{
    protected $table = 'attribute';
    public $timestamps = true;

    protected $fillable = array('attribute_group_id', 'name', 'sort_order');

    public function AttributeGroup()
    {
        return $this->belongsTo('App\Models\AttributeGroup');
    }

    public function ProductAttribute()
    {
        return $this->hasMany('App\Models\ProductAttribute');
    }
}
