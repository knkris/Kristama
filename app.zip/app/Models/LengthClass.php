<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LengthClass extends Model 
{

    protected $table = 'length_class';
    public $timestamps = true;
    protected $fillable = array('value', 'title', 'unit');

}