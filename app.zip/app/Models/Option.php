<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Option extends Model 
{

    protected $table = 'option';
    public $timestamps = true;
    protected $fillable = array('type', 'name', 'sort_order', 'required');

    public function OptionValue()
    {
        return $this->hasMany('App\Models\OptionValue');
    }

}