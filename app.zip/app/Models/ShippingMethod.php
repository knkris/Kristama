<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ShippingMethod extends Model
{
    protected $table = 'shipping_method';
    public $timestamps = true;

    protected $fillable = array('customer_group_id', 'name', 'price', 'status');

    public function CustomerGroup()
    {
        return $this->belongsTo('App\Models\CustomerGroup');
    }

    public function FreeShipping()
    {
        return $this->hasMany('App\Models\FreeShipping');
    }

    public function Kreasi2go()
    {
        return $this->hasMany('App\Models\Kreasi2go');
    }
}
