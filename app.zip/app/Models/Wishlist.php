<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Wishlist extends Model 
{

    protected $table = 'wishlist';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];
    protected $fillable = array('user_id', 'product_id');

    public function User()
    {
        return $this->belongsTo('App\Models\User');
    }

    public function Product()
    {
        return $this->belongsTo('App\Models\Product');
    }

}