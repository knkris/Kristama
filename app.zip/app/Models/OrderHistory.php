<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderHistory extends Model
{
    protected $table = 'order_history';
    public $timestamps = true;
    protected $fillable = array('order_id', 'order_status_id', 'notify', 'comment');

    public function Order()
    {
        return $this->belongsTo('App\Models\Order');
    }

    public function OrderStatus()
    {
        return $this->belongsTo('App\Models\OrderStatus');
    }
}
