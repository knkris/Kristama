<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProductGroupDetail extends Model 
{

    protected $table = 'product_group_detail';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];
    protected $fillable = array('product_group_id', 'product_id', 'discount', 'discount_type_id', 'minimum', 'maximum', 'max_discount');

    public function Product()
    {
        return $this->belongsTo('App\Models\Product');
    }

    public function ProductGroup()
    {
        return $this->belongsTo('App\Models\ProductGroup');
    }

    public function DiscountType()
    {
        return $this->belongsTo('App\Models\DiscountType');
    }

}