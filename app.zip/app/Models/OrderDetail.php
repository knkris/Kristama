<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class OrderDetail extends Model 
{

    protected $table = 'order_detail';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];
    protected $fillable = array('order_id', 'product_id', 'product_option_id', 'product_stock_id', 'qty', 'price', 'shipping_courier', 'courier_service', 'shipping_province', 'shipping_city', 'shipping_postal_code', 'note', 'reviewed');

    public function Order()
    {
        return $this->belongsTo('App\Models\Order');
    }

    public function Product()
    {
        return $this->belongsTo('App\Models\Product','product_id');
    }

    public function ProductStock()
    {
        return $this->belongsTo('App\Models\ProductStock', 'product_stock_id');
    }

}