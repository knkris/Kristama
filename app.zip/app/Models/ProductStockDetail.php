<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProductStockDetail extends Model
{
    protected $table = 'product_stock_detail';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];
    protected $fillable = array('product_stock_id', 'product_option_detail_id');

    public function ProductStock()
    {
        return $this->belongsTo('App\Models\ProductStock');
    }

    public function ProductOptionDetail()
    {
        return $this->belongsTo('App\Models\ProductOptionDetail', 'product_option_detail_id');
    }
}
