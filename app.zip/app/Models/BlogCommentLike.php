<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class BlogCommentLike extends Model
{
    protected $table = 'blog_comment_like';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];

    protected $fillable = array('blog_comment_id', 'user_id', 'up', 'down');

    public function BlogComment()
    {
        return $this->belongsTo('App\Models\BlogComment');
    }

    public function User()
    {
        return $this->belongsTo('App\Models\User');
    }
}
