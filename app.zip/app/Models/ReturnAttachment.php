<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ReturnAttachment extends Model
{
    protected $table = 'return_attachment';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];
    protected $fillable = array('return_id', 'path');

    public function OrderReturn()
    {
        return $this->belongsTo('App\Models\OrderReturn');
    }
}
