<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Cart extends Model 
{

    protected $table = 'cart';
    public $timestamps = true;
    protected $fillable = array('user_id', 'product_stock_id', 'qty', 'price', 'shipping_courier', 'address_id', 'note');

    public function Product()
    {
        return $this->belongsTo('App\Models\Product');
    }

    public function ProductStock()
    {
        return $this->belongsTo('App\Models\ProductStock');
    }

    public function User()
    {
        return $this->belongsTo('App\Models\User');
    }

}