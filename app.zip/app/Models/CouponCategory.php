<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CouponCategory extends Model
{
    protected $table = 'coupon_category';
    public $timestamps = true;


    protected $fillable = array('coupon_id', 'category_id');

    public function Coupon()
    {
        return $this->belongsTo('App\Models\Coupon');
    }

    public function Category()
    {
        return $this->belongsTo('App\Models\Category');
    }
}
