<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Coupon extends Model
{
    protected $table = 'coupon';
    public $timestamps = true;

    protected $fillable = array('name', 'code', 'type', 'discount', 'max_discount', 'free_shipping', 'min_order', 'start_date', 'end_date', 'uses_total', 'uses_customer', 'status');

    public function CouponProduct()
    {
        return $this->hasMany('App\Models\CouponProduct');
    }

    public function CouponCategory()
    {
        return $this->hasMany('App\Models\CouponCategory');
    }
}
