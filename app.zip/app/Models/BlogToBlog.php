<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BlogToBlog extends Model
{
    protected $table = 'blog_to_blog';
    public $timestamps = true;


    protected $fillable = array('blog_id', 'to_blog_id');

    public function Blog()
    {
        return $this->belongsTo('App\Models\Blog');
    }

    public function ToBlog()
    {
        return $this->belongsTo('App\Models\Blog','to_blog_id');
    }
}
