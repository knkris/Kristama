<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BlogToProduct extends Model
{
    protected $table = 'blog_to_product';
    public $timestamps = true;


    protected $fillable = array('blog_id', 'product_id');

    public function Blog()
    {
        return $this->belongsTo('App\Models\Blog');
    }

    public function Product()
    {
        return $this->belongsTo('App\Models\Product');
    }
}
