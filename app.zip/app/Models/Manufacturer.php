<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Manufacturer extends Model 
{

    protected $table = 'manufacturer';
    public $timestamps = true;
    protected $fillable = array('name', 'image', 'sort_order');

    public function Product()
    {
        return $this->hasMany('App\Models\Product');
    }

}