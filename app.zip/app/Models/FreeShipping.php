<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FreeShipping extends Model
{
    protected $table = 'free_shipping';
    public $timestamps = true;

    protected $fillable = array('shipping_method_id', 'name', 'subtotal', 'status');

    public function FreeShippingToProvince()
    {
        return $this->hasMany('App\Models\FreeShippingToProvince');
    }

    public function FreeShippingToCategory()
    {
        return $this->hasMany('App\Models\FreeShippingToCategory');
    }

    public function FreeShippingToProduct()
    {
        return $this->hasMany('App\Models\FreeShippingToProduct');
    }
}
