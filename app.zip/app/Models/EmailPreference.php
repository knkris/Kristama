<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmailPreference extends Model
{
    protected $table = 'email_preference';
    public $timestamps = true;
    protected $fillable = array('user_id', 'subscribe', 'special_events', 'product_updates', 'monthly newsletter', 'manual_email_blast', 'mail_frequency');


    public function User()
    {
        return $this->belongsTo('App\Models\User');
    }
}
