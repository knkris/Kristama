<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Province extends Model
{
    protected $table = 'province';
    public $timestamps = true;
    protected $fillable = array('id', 'name');

    public function City()
    {
        return $this->hasMany('App\Models\City');
    }
}
