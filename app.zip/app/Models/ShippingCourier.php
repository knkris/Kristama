<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ShippingCourier extends Model
{
    protected $table = 'shipping_courier';
    public $timestamps = true;

    protected $fillable = array('shipping_method_id', 'name', 'code', 'check_resi', 'status');

    public function ShippingMethod()
    {
        return $this->belongsTo('App\Models\ShippingMethod');
    }
}
