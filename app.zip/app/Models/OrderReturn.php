<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderReturn extends Model
{
    protected $table = 'return';
    public $timestamps = true;


    protected $fillable = array('order_id', 'product_id', 'reason', 'note', 'status');

    public function Order()
    {
        return $this->belongsTo('App\Models\Order');
    }

    public function Product()
    {
        return $this->belongsTo('App\Models\Product','product_id');
    }

    public function ReturnAttachment()
    {
        return $this->hasMany('App\Models\ReturnAttachment');
    }
}
