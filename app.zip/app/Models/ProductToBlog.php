<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductToBlog extends Model
{
    protected $table = 'product_to_blog';
    public $timestamps = true;


    protected $fillable = array('blog_id', 'product_id');

    public function Blog()
    {
        return $this->belongsTo('App\Models\Blog');
    }

    public function Product()
    {
        return $this->belongsTo('App\Models\Product');
    }
}
