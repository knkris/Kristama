<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FreeShippingToProvince extends Model
{
    protected $table = 'free_shipping_to_province';
    public $timestamps = false;

    protected $fillable = array('free_shipping_id', 'province_id');

    public function FreeShipping()
    {
        return $this->belongsTo('App\Models\FreeShipping');
    }

    public function Province()
    {
        return $this->belongsTo('App\Models\Province');
    }
}
