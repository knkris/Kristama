<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Issue extends Model
{
    protected $table = 'issue';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];
    protected $fillable = array('user_id', 'category', 'subcategory', 'subject', 'message', 'status', 'ip');

    public function IssueAttachment()
    {
        return $this->hasMany('App\Models\IssueAttachment');
    }
}
