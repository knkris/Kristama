<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Kreasi2go extends Model
{
    protected $table = 'kreasi2go';
    public $timestamps = true;

    protected $fillable = array('shipping_method_id', 'name', 'price', 'subtotal', 'status');

    public function Kreasi2goToProvince()
    {
        return $this->hasMany('App\Models\Kreasi2goToProvince');
    }

    public function Kreasi2goToCategory()
    {
        return $this->hasMany('App\Models\Kreasi2goToCategory');
    }

    public function Kreasi2goToProduct()
    {
        return $this->hasMany('App\Models\Kreasi2goToProduct');
    }
}
