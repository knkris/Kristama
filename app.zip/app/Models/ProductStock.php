<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProductStock extends Model
{
    protected $table = 'product_stock';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];
    protected $fillable = array('product_id', 'qty', 'sku');

    public function Product()
    {
        return $this->belongsTo('App\Models\Product');
    }

    public function ProductStockDetail()
    {
        return $this->hasMany('App\Models\ProductStockDetail');
    }
}
