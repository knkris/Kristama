<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class City extends Model 
{

    protected $table = 'city';
    public $timestamps = true;
    protected $fillable = array('province_id', 'province', 'type', 'name', 'postal_code');

    public function Province()
    {
        return $this->belongsTo('App\Models\Province', 'province_id');
    }

}