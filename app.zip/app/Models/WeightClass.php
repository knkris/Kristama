<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WeightClass extends Model 
{

    protected $table = 'weight_class';
    public $timestamps = true;
    protected $fillable = array('value', 'title', 'unit');

}