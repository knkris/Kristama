<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class BlogLike extends Model
{

    protected $table = 'blog_like';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];

    protected $fillable = array('blog_id', 'user_id');

    public function Blog()
    {
        return $this->belongsTo('App\Models\Blog');
    }

    public function User()
    {
        return $this->belongsTo('App\Models\User');
    }
}
