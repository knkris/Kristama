<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductSpecial extends Model
{
    protected $table = 'product_special';
    public $timestamps = true;
    protected $fillable = array('customer_group_id', 'product_id', 'price', 'priority', 'start', 'end');

    public function Product()
    {
        return $this->belongsTo('App\Models\Product');
    }

    public function CustomerGroup()
    {
        return $this->belongsTo('App\Models\CustomerGroup');
    }
}
