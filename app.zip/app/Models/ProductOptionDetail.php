<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProductOptionDetail extends Model 
{

    protected $table = 'product_option_detail';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];
    protected $fillable = array('product_id', 'product_option_id', 'option_id', 'option_value_id', 'qty', 'substract', 'price', 'point');

    public function Option()
    {
        return $this->belongsTo('App\Models\Option');
    }

    public function Product()
    {
        return $this->belongsTo('App\Models\Product');
    }

    public function ProductOption()
    {
        return $this->belongsTo('App\Models\ProductOption', 'product_option_id');
    }

    public function OptionValue()
    {
        return $this->belongsTo('App\Models\OptionValue', 'option_value_id');
    }

}