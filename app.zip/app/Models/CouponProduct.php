<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CouponProduct extends Model
{
    protected $table = 'coupon_product';
    public $timestamps = true;


    protected $fillable = array('coupon_id', 'product_id');

    public function Coupon()
    {
        return $this->belongsTo('App\Models\Coupon');
    }

    public function Product()
    {
        return $this->belongsTo('App\Models\Product');
    }
}
