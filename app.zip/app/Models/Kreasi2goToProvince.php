<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Kreasi2goToProvince extends Model
{
    protected $table = 'kreasi2go_to_province';
    public $timestamps = false;

    protected $fillable = array('kreasi2go_id', 'province_id');

    public function Kreasi2go()
    {
        return $this->belongsTo('App\Models\Kreasi2go');
    }

    public function Province()
    {
        return $this->belongsTo('App\Models\Province');
    }
}
