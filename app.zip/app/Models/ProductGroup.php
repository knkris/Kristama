<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProductGroup extends Model 
{

    protected $table = 'product_group';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];
    protected $fillable = array('customer_group_id', 'name', 'desc', 'timed_discount', 'start', 'end', 'group_discount', 'bind_to', 'discount', 'discount_type_id', 'status', 'max_discount', 'minimum', 'maximum');

    public function DiscountType()
    {
        return $this->belongsTo('App\Models\DiscountType');
    }

    public function CustomerGroup()
    {
        return $this->belongsTo('App\Models\CustomerGroup');
    }

    public function ProductGroupDetail()
    {
        return $this->hasMany('App\Models\ProductGroupDetail');
    }

    public function ProductGroupToCategory()
    {
        return $this->hasMany('App\Models\ProductGroupToCategory');
    }

}