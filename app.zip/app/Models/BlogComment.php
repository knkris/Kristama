<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class BlogComment extends Model
{
    protected $table = 'blog_comment';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];
    protected $fillable = array('blog_id', 'user_id', 'text', 'parent_id', 'ip');

    public function Blog()
    {
        return $this->belongsTo('App\Models\Blog');
    }

    public function User()
    {
        return $this->belongsTo('App\Models\User');
    }

    public function BlogCommentLike()
    {
        return $this->hasMany('App\Models\BlogCommentLike');
    }

    public function getConversation()
    {
        $get=BlogComment::whereParent_id($this->id)->get();
        return $get;
    }
}
