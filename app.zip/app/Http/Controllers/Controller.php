<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use GuzzleHttp\Client;
use Carbon\Carbon;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    protected $apiurl='https://pro.rajaongkir.com/api';
    protected $apikey='3d26057d0e65ebbbdac682b2dc99591f';

    public function get_words($sentence, $count = 10) {
      preg_match("/(?:\w+(?:\W+|$)){0,$count}/", $sentence, $matches);
      return $matches[0];
    }

    public function uploadImage(Request $request)
    {
	// A list of permitted file extensions
		if(empty($_FILES['file']))
		{
		    exit(); 
		}
		$filename=Carbon::now()->format('dmY_his')."_".$_FILES['file']['name'];
		$errorImgFile = public_path()."/uploads/img/img_upload_error.jpg";
		$destinationFilePath = public_path().'/uploads/img-uploads/'.$filename;
		if(!move_uploaded_file($_FILES['file']['tmp_name'], $destinationFilePath)){
		    echo $errorImgFile;
		}
		else{
		    echo url('/').'/uploads/img-uploads/'.$filename;
		}
    }

    public function getProvince($id='')
    {
        if($id!=''){
            $id='?id='.$id;
        }
        $client = new Client();
        
        $response = $client->request('GET', $this->apiurl.'/province'.$id, [
            'headers' => [
                'Key' => $this->apikey
            ]
        ]);
        $body = $response->getBody();
        return $body;
    }

    public function getCity($id='',$province='')
    {
        if($id!=''){
            $id='?id='.$id;
        }
        if($id=='' && $province!=''){
            $province='?province='.$province;
        }
        if($id!='' && $province!=''){
            $province='&province='.$province;
        }
        $client = new Client();
        
        $response = $client->request('GET', $this->apiurl.'/city'.$id.$province, [
            'headers' => [
                'Key' => $this->apikey
            ]
        ]);
        $body = $response->getBody();
        return $body;
    }

    public function getSubdistrict($id='',$city='')
    {
        if($id!=''){
            $id='?id='.$id;
        }
        if($id=='' && $city!=''){
            $city='?city='.$city;
        }
        if($id!='' && $city!=''){
            $city='&city='.$city;
        }
        $client = new Client();
        
        $response = $client->request('GET', $this->apiurl.'/subdistrict'.$id.$city, [
            'headers' => [
                'Key' => $this->apikey
            ]
        ]);
        $body = $response->getBody();
        return $body;
    }

    public function getCost($origin, $origintype, $destination, $destinationtype, $weight, $courier)
    {
    	$client = new Client();
    	
    	$response = $client->request('POST', $this->apiurl.'/cost', [
            'headers' => [
                'Key' => $this->apikey
            ],
            'form_params' => [
		        'origin' => $origin, //ID kota atau kabupaten asal
		        'originType' => $origintype, //Tipe origin: 'city' atau 'subdistrict'.
		        'destination' => $destination, //ID kota/kabupaten atau kecamatan tujuan
		        'destinationType' => $destinationtype, //Tipe destination: 'city' atau 'subdistrict'.
		        'weight' => $weight, //Berat kiriman dalam gram
		        'courier' => $courier //Kode kurir: jne, pos, tiki, rpx, esl, pcp, pandu, wahana, sicepat, jnt, pahala, cahaya, sap, jet, indah, dse, slis, first, ncs, star.
	        ]
        ]);
        $body = $response->getBody();
        return $body;
    }

    public function generateRandomString($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    public function nice_number($n) {
        // first strip any formatting;
        $n = (0+str_replace(",", "", $n));

        // is this a number?
        if (!is_numeric($n)) return false;

        // now filter it;
        if ($n > 1000000000000) return round(($n/1000000000000), 1).'t';
        elseif ($n > 1000000000) return round(($n/1000000000), 1).'m';
        elseif ($n > 1000000) return round(($n/1000000), 1).'jt';
        elseif ($n > 1000) return round(($n/1000)).'rb';

        return number_format($n);
    }

    public function avgRating()
    {
        foreach (\App\Models\Product::all() as $product) {

            $product->avg_rating=$product->ProductReview->pluck('rating')->avg();
            $product->save();

        }
        return 'done';
    }
}
