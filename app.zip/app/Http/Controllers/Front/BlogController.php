<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Blog;
use App\Models\BlogLike;
use App\Models\BlogComment;
use App\Models\BlogCommentLike;
use Auth;

class BlogController extends Controller
{
    public function find(Request $request)
    {
        //$products=Product::get();
        // Retrieve the user's input and escape it
        $query = e($request->input('q',''));

        //$products = Product::search($query)
        $blogs = Blog::where('title','like','%'.$query.'%')
                    ->orderBy('title','asc')
                    ->take(5)
                    ->get();
        $data=[];
        foreach ($blogs as $key => $value) {
            $blog=new \stdClass();
            $blog->name=$value->title;
            $blog->slug=$value->slug;
            $blog->img=$value->image;
            $data[]=$blog;
        }
        return $data;
    }

    public function index()
    {
        $trendingid=Blog::orderBy('viewed', 'desc')->take(3)->pluck('id')->toArray();
        $trending=Blog::whereIn('id', $trendingid)->get();
    	$blog=Blog::orderBy('created_at','desc')->paginate(12);
        foreach($blog as $key => $value) {
            if(in_array($value->id, $trendingid)){
                $value->most_viewed=1;
            }else{
                $value->most_viewed=0;
            }
        }
    	return view('blog.index', compact('blog', 'trending'));
    }

    public function indexTag($category)
    {
        $trendingid=Blog::orderBy('viewed', 'desc')->take(3)->pluck('id')->toArray();
        $trending=Blog::whereIn('id', $trendingid)->get();
        $blog=Blog::whereCategory($category)->orderBy('created_at','desc')->paginate(12);
        foreach($blog as $key => $value) {
            if(in_array($value->id, $trendingid)){
                $value->most_viewed=1;
            }else{
                $value->most_viewed=0;
            }
        }
        return view('blog.index', compact('blog', 'trending', 'category'));
    }

    public function show($slug=null)
    {
        $trendingid=Blog::orderBy('viewed', 'desc')->take(3)->pluck('id')->toArray();
        $trending=Blog::whereIn('id', $trendingid)->get();
    	$blog=Blog::whereSlug($slug)->firstOrFail();
    	$blog->viewed++;
    	$blog->save();
    	return view('blog.show', compact('blog', 'trending'));
    }

    public function handleShared($slug=null)
    {
        $data=new \stdClass();
        $blog=Blog::whereSlug($slug)->first();
        if(count($blog)){
            $blog->shared++;
            $blog->save();
        }

        return response()->json([]);
    }

    public function handleLike($slug=null)
    {
        $data=new \stdClass();
        $blog=Blog::whereSlug($slug)->first();
        if(count($blog)){
            $try=$blog->BlogLike()->whereUser_id(Auth::user()->id)->first();
            if(count($try)){
                $try->touch();
                $try->delete();
                $data->count=$blog->BlogLike()->count();
                $data->status=false;

                return response()->json($data);
            }else{
                $trash=$blog->BlogLike()->withTrashed()->whereUser_id(Auth::user()->id)->first();
                if(count($trash)){
                    $trash->restore();
                    $trash->touch();
                    $data->count=$blog->BlogLike()->count();
                    $data->status=true;

                    return response()->json($data);
                }else{
                    $new=new BlogLike();
                    $new->blog_id=$blog->id;
                    $new->user_id=Auth::user()->id;
                    $new->save();
                    $data->count=$blog->BlogLike()->count();
                    $data->status=true;

                    return response()->json($data);
                }
            }
        }
    }

    public function handleUpvote($id=null)
    {
        $data=new \stdClass();
        $comment=BlogComment::find($id);
        if(count($comment)){
            $try=$comment->BlogCommentLike()->whereUser_id(Auth::user()->id)->first();
            if(count($try)){
                switch ($try->up) {
                    case 1:
                        $try->up=0;
                        $data->status=false;
                        break;

                    case 0:
                        $try->up=1;
                        $try->down=0;
                        $data->status=true;
                        break;
                    
                    default:
                        # code...
                        break;
                }
                $try->save();
                $try->touch();
                $data->count=$comment->BlogCommentLike()->whereUp(1)->count() ?: '-'.$comment->BlogCommentLike()->whereDown(1)->count();
                if($data->count==='-0'){
                    $data->count=0;
                }

                return response()->json($data);
            }else{
                $up=new BlogCommentLike();
                $up->blog_comment_id=$comment->id;
                $up->user_id=Auth::user()->id;
                $up->up=1;
                $up->save();

                $data->count=$comment->BlogCommentLike()->whereUp(1)->count() ?: '-'.$comment->BlogCommentLike()->whereDown(1)->count();
                if($data->count==='-0'){
                    $data->count=0;
                }
                $data->status=true;

                return response()->json($data);
            }
        }
    }

    public function handleDownvote($id=null)
    {
        $data=new \stdClass();
        $comment=BlogComment::find($id);
        if(count($comment)){
            $try=$comment->BlogCommentLike()->whereUser_id(Auth::user()->id)->first();
            if(count($try)){
                switch ($try->down) {
                    case 1:
                        $try->down=0;
                        $data->status=false;
                        break;

                    case 0:
                        $try->down=1;
                        $try->up=0;
                        $data->status=true;
                        break;
                    
                    default:
                        # code...
                        break;
                }
                $try->save();
                $try->touch();
                $data->count=$comment->BlogCommentLike()->whereUp(1)->count() ?: '-'.$comment->BlogCommentLike()->whereDown(1)->count();
                if($data->count==='-0'){
                    $data->count=0;
                }

                return response()->json($data);
            }else{
                $up=new BlogCommentLike();
                $up->blog_comment_id=$comment->id;
                $up->user_id=Auth::user()->id;
                $up->down=1;
                $up->save();

                $data->count=$comment->BlogCommentLike()->whereUp(1)->count() ?: '-'.$comment->BlogCommentLike()->whereDown(1)->count();
                $data->status=true;
                if($data->count==='-0'){
                    $data->count=0;
                }
                return response()->json($data);
            }
        }
    }

    public function postComment($slug=null, Request $request)
    {
        $blog=Blog::whereSlug($slug)->firstOrFail();
        $comment=new BlogComment();
        $comment->blog_id=$blog->id;
        $comment->user_id=Auth::user()->id;
        $comment->text=$request->input('reply');
        $comment->ip=$request->ip();
        $comment->save();

        return back()->with('success', 'Your Comment has been posted.');
    }

    public function postCommentReply($id=null, Request $request)
    {
        $blogcomment=BlogComment::findOrFail($id);
        $comment=new BlogComment();
        $comment->blog_id=$blogcomment->blog_id;
        $comment->user_id=Auth::user()->id;
        $comment->text=$request->input('reply');
        $comment->parent_id=$blogcomment->id;
        $comment->ip=$request->ip();
        $comment->save();

        return back()->with('success', 'Your Comment has been posted.');
    }

    public function retrieveComment($slug=null,Request $request)
    {
        $blog=Blog::whereSlug($slug)->first();
        $items=$blog->BlogComment()->whereParent_id(0)->orderBy('created_at','desc')->paginate(3);
        $html="";
        foreach ($items as $key => $comment) {
            $html.='<div class="col-lg-8" style="margin-top:60px;">';
            $html.='<div>';
            $html.='<div class="col-lg-1" style="margin-top: -14px;">';
            if(Auth::check()){
                if($comment->BlogCommentLike()->whereUser_id(Auth::user()->id)->whereUp(1)->count()){
                    $html.='    <i id="upvote-arrow-'. $comment->id .'" class="fa fa-caret-up upvote-btn active" data-id="'. $comment->id .'"></i></br>';
                }else{
                    $html.='    <i id="upvote-arrow-'. $comment->id .'" class="fa fa-caret-up upvote-btn" data-id="'. $comment->id .'"></i></br>';
                }
            }else{
                $html.='    <i id="upvote-arrow-'. $comment->id .'" class="fa fa-caret-up upvote-btn" data-id="'. $comment->id .'"></i></br>';
            }
            
        $count=$comment->BlogCommentLike()->whereUp(1)->count() ?: '-'.$comment->BlogCommentLike()->whereDown(1)->count();
        if($count==='-0')
        {
            $count=0;
        }
            $html.='    <a id="vote-count-'. $comment->id .'" href="#">'. $count .'</a></br>';
            if(Auth::check()){
                if($comment->BlogCommentLike()->whereUser_id(Auth::user()->id)->whereDown(1)->count()){
                    $html.='    <i id="downvote-arrow-'. $comment->id .'" class="fa fa-caret-down downvote-btn active" data-id="'. $comment->id .'"></i>';
                }else{
                    $html.='    <i id="downvote-arrow-'. $comment->id .'" class="fa fa-caret-down downvote-btn" data-id="'. $comment->id .'"></i>';
                }
            }else{
                $html.='    <i id="downvote-arrow-'. $comment->id .'" class="fa fa-caret-down downvote-btn" data-id="'. $comment->id .'"></i>';
            }
            
            $html.='</div>';
            if($comment->User->avatar){
                $html.='<div class="col-lg-2" style="text-align: center;"><img src="'. $comment->User->avatar .'" width="75px"></div>';
            }else{
                $html.='<div class="col-lg-2" style="text-align: center;"><img src="'. $comment->User->getPhotoUrlAttribute() .'" width="75px"></div>';
            }
            $html.='<div class="col-lg-9">';
            $html.='    <span style="font-size:18px;"><strong>'. $comment->User->name .'</strong></span></br>';
            $html.='    <span>'. $comment->text .'</span>';
            $html.='</div>';  
            $html.='</div>';  
            $html.='</div>';
            
            $reply = $comment->getConversation();
            $countreply=count($reply);
            foreach($reply as $key2 => $value){
                $html.='<div class="col-lg-8" style="margin-top:20px;">';
                $html.='<div>';
                $html.='<div class="col-lg-1"></div>';
                
                if($key2==0){
                    $html.='<div class="col-lg-2 reply-collapse hide-reply" data-commentid="'. $comment->id .'" style="text-align: center;">';
                    $html.='    [ <i class="fa fa-plus" style="font-size:12px;"></i> ]';
                    $html.='</div>';
                    $html.='<div class="col-lg-9 show-comment-reply">';
                    $html.='    <span style="color:grey;">See '. $countreply .' Replies</span>';
                    $html.='</div>';
                }else{
                    $html.='<div class="col-lg-2 " style="text-align: center;"></div>';
                }

                
                
                $html.='<div class="col-lg-1 replies1-'. $comment->id .'" style="display: none;margin-top: -14px;">';
                if(Auth::check()){
                    if($value->BlogCommentLike()->whereUser_id(Auth::user()->id)->whereUp(1)->count()){
                        $html.='    <i id="upvote-arrow-'. $value->id .'" class="fa fa-caret-up upvote-btn active" data-id="'. $value->id .'" data-id="'. $value->id .'"></i></br>'; 
                    }else{
                        $html.='    <i id="upvote-arrow-'. $value->id .'" class="fa fa-caret-up upvote-btn" data-id="'. $value->id .'" data-id="'. $value->id .'"></i></br>';
                    }
                }else{
                    $html.='    <i id="upvote-arrow-'. $value->id .'" class="fa fa-caret-up upvote-btn" data-id="'. $value->id .'" data-id="'. $value->id .'"></i></br>';
                }
                
                    $countreply=$value->BlogCommentLike()->whereUp(1)->count() ?: '-'.$value->BlogCommentLike()->whereDown(1)->count();
                    if($countreply==='-0')
                    {
                        $countreply=0;
                    }
                $html.='    <a id="vote-count-'. $value->id .'" href="#">'. $countreply .'</a></br>';
                if(Auth::check()){
                    if($value->BlogCommentLike()->whereUser_id(Auth::user()->id)->whereDown(1)->count()){
                        $html.='    <i id="downvote-arrow-'. $value->id .'" class="fa fa-caret-down downvote-btn reply active" data-id="'. $value->id .'" data-id="'. $value->id .'"></i>';
                    }else{
                        $html.='    <i id="downvote-arrow-'. $value->id .'" class="fa fa-caret-down downvote-btn reply" data-id="'. $value->id .'" data-id="'. $value->id .'"></i>';
                    }
                }else{
                    $html.='    <i id="downvote-arrow-'. $value->id .'" class="fa fa-caret-down downvote-btn reply" data-id="'. $value->id .'" data-id="'. $value->id .'"></i>';
                }
                
                $html.='</div>';
                if($value->User->avatar){
                    $html.='<div class="col-lg-2 replies2-'. $comment->id .'" style="display: none;text-align: center;"><img src="'. $value->User->avatar .'" width="75px"></div>';
                }else{
                    $html.='<div class="col-lg-2 replies2-'. $comment->id .'" style="display: none;text-align: center;"><img src="'.  $value->User->getPhotoUrlAttribute() .'" width="75px"></div>';
                }
                $html.='<div class="col-lg-6 replies3-'. $comment->id .'" style="display: none;">';
                $html.='    <span style="font-size:18px;"><strong>'. $value->User->name .'</strong></span></br>';
                $html.='    <span>'. $value->text .'</span>';
                $html.='</div>';  
                $html.='</div>'; 
                $html.='</div>';
                

            }
            if(Auth::check()){
                    $html.='    <div class="col-lg-8" style="margin-top:20px;">';
                    $html.='    <div>';
                    $html.='    <div class="col-lg-3"></div>';
                    $html.='    <div class="col-lg-9">';
                    if(Auth::user()->avatar){
                        $html.='        <img src="'. Auth::user()->avatar  .'" width="75px" style="float:left;">';
                    }else{
                        $html.='        <img src="'. Auth::user()->getPhotoUrlAttribute() .'" width="75px" style="float:left;">';
                    }
                    
                    $html.='        <form action="'. url('post-comment-reply/'.$comment->id) .'" method="post">';
                    $html.= csrf_field() ;
                    $html.='            <input type="text" class="reply-comment" name="reply" placeholder="Write a reply . . ." style="float:left; height:75px; width: 85%; padding: 28px 20px;margin: 0 0;display: inline-block;border: 1px solid #ccc;border-radius: 0px; box-sizing: border-box;">';
                    $html.='        </form>';
                    $html.='    </div>';
                    $html.='    </div>';
                    $html.='    </div>';
                }
        }
        $data=new \stdClass();
        $data->lastPage=$items->lastPage();
        $data->html=$html;
        return response()->json($data);
    }
}
