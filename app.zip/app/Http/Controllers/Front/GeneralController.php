<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Manufacturer;
use App\Models\Product;
use App\Models\ProductOption;
use App\Models\ProductOptionDetail;
use App\Models\ProductToCategory;
use App\Models\Option;
use App\Models\OptionValue;
use App\Models\ProductStock;
use App\Models\ProductStockDetail;
use App\Models\User;
use App\Models\Wishlist;
use App\Models\Address;
use App\Models\Cart;
use App\Models\ShippingMethod;
use App\Models\ShippingCourier;
use App\Models\City;
use App\Models\Subdistrict;
use App\Models\PaymentMethod;
use App\Models\Order;
use App\Models\OrderDetail;
use App\Models\OrderHistory;
use App\Models\Bank;
use App\Models\WeightClass;
use App\Models\Blog;
use App\Models\RecommendedProduct;
use App\Models\ProductDiscussion;
use App\Models\ProductReview;
use App\Models\ProductToProduct;
use App\Models\OrderReturn;
use App\Models\Coupon;
use App\Models\Province;
use App\Models\FreeShipping;
use App\Models\FreeShippingToCategory;
use App\Models\FreeShippingToProduct;
use App\Models\FreeShippingToProvince;
use App\Models\Kreasi2go;
use App\Models\Kreasi2goToCategory;
use App\Models\Kreasi2goToProduct;
use App\Models\Kreasi2goToProvince;
use App\Models\EmailPreference;
use App\Models\Issue;
use App\Models\IssueAttachment;
use App\Models\ReturnAttachment;
use App\Lib\NicepayLib;
use App\Models\NicepayTransaction;
use Carbon\Carbon;
use Auth;
use Countries;
use Response;
use Mail;
use Hash;

class GeneralController extends Controller
{

    public function confirm($confirmation_code)
    {
        if( ! $confirmation_code)
        {
            //throw new InvalidConfirmationCodeException;
            return redirect('/')->with('error','Invalid confirmation code.');
        }

        $user = User::whereConfirmationCode($confirmation_code)->first();
        if ( ! $user)
        {
            //throw new InvalidConfirmationCodeException;
            return redirect('/')->with('error','Invalid confirmation code.');
        }

        $user->verify = 1;
        $user->confirmation_code = null;
        $user->save();

        Mail::send('mail.welcome', ['user'=>$user], function($message) use ($user) {
                 $message->to($user->email, $user->firstname)
                     ->subject('Kreasi2shop Registration information.');
             });

        return redirect('/')->with('success','You have successfully verified your account.');
    }

    public function appendImg($data, $element)
    {
        foreach ($data as $key => & $item) {
            $product= Product::whereSlug($item['slug'])->first();
            $img=$product->Image()->first();
            $item['icon'] = $img->image;
        }
        return $data;       
    }

    public function appendValue($data, $type, $element)
    {
        // operate on the item passed by reference, adding the element and type
        foreach ($data as $key => & $item) {
            $item[$element] = $type;
        }
        return $data;       
    }

    public function appendURL($data, $prefix)
    {
        // operate on the item passed by reference, adding the url based on slug
        foreach ($data as $key => & $item) {
            $item['url'] = url($prefix.'/'.$item['slug']);
        }
        return $data;       
    }

    public function index()
    {
        $parent=Category::whereNull('parent_id')->limit(6)->get();
    	return view('front.index', compact('parent'));
    }

    public function apiSearch(Request $request)
    {
        // Retrieve the user's input and escape it
        $query = e($request->input('q',''));

        // If the input is empty, return an error response
        if(!$query && $query == '') return Response::json(array(), 400);

        $products = Product::where('status', 1)
                    ->where('name','like','%'.$query.'%')
                    ->orderBy('name','asc')
                    ->where('qty','>',0)
                    ->take(5)
                    ->get(array('slug', 'name'))
                    ->toArray();

        $categories = Category::where('name','like','%'.$query.'%')
                    //->has('product')
                    ->take(5)
                    ->get(array('slug', 'name'))
                    ->toArray();

        // Normalize data
        $categories = $this->appendValue($categories, '','icon');
        $products = $this->appendImg($products,'icon');

        $products   = $this->appendURL($products, '');
        $categories = $this->appendURL($categories, 'categories');

        // Add type of data to each item of each set of results
        $products   = $this->appendValue($products, 'product', 'class');
        $categories = $this->appendValue($categories, 'category', 'class');
        // Add type of data to each item of each set of results
        // Merge all data into one array
        $data = array_merge($products, $categories);

        return Response::json(array(
            'data'=>$data
        ));
    }

    public function find(Request $request)
    {
    	//$products=Product::get();
        // Retrieve the user's input and escape it
        $query = e($request->input('q',''));

        //$products = Product::search($query)
        $products = Product::where('status', 1)
                    ->where('name','like','%'.$query.'%')
                    ->where('qty','>',0)
                    ->orderBy('name','asc')
                    ->take(5)
                    ->get();
        $data=[];
        foreach ($products as $key => $value) {
            $product=new \stdClass();
            $product->name=$value->name;
            $product->slug=$value->slug;
            $product->img=$value->Image()->first() ? $value->Image()->first()->image : '';
            $data[]=$product;
        }
    	return $data;
    }

    public static function round_up($value, $places) 
    {
        $mult = pow(10, abs($places)); 
         return $places < 0 ?
        ceil($value / $mult) * $mult :
            ceil($value * $mult) / $mult;
    }

    public function search($cat=null,Request $request)
    {
        $min=100000;
        $max=1000000;
        //dd($this->round_up(12345.23, -3));
        //dd(round(1241757,-6,PHP_ROUND_UP ));
        //$products=Product::get();
        // Retrieve the user's input and escape it
        $query = e($request->input('q',''));

        $sort=new \stdClass();
        $sort->col='created_at';
        $sort->dir='desc';

        $show=20;
        
        if(!empty($cat)){
            if($cat==='All Category'){
                $category=null;
                $subcategories=[];
            }else{
                $category=Category::whereSlug($cat)->first();
                $child=$category->child();
                if(count($child)){
                    $subcategories=$child;
                }else{
                    $subcategories=Category::whereParent_id($category->parent_id)->get();
                }
            }
        }else{
            $category=null;
            $subcategories=[];
        }
        if(!empty($request->input('subcategory'))){
            if($request->input('subcategory')==='All Category'){
                $subcategory=null;
            }else{
                $subcategory=null;
                $getcategory=Category::whereName($cat)->get();
                foreach ($getcategory as $key => $value) {
                    $trysubcategory=Category::whereName($request->input('subcategory'))->whereParent_id($value->id)->first();
                    if(count($trysubcategory)){
                        $subcategory=$trysubcategory;
                        $category=$value;
                    }
                }
            }
        }else{
            $subcategory=null;
        }
        if(!empty($request->input('brand'))){
            if($request->input('brand')==='All Brand'){
                $brand=null;
                $brandid=[];
            }else{
                $brandid=explode(',', $request->input('brand'));
                $brand=Manufacturer::whereIn('id',$brandid)->get();
            }
        }else{
             $brand=null;
             $brandid=[];
        }
        if(!empty($request->input('sort'))){
            switch ($request->input('sort')) {
                case 'lowest_price':
                    $sort->col='price';
                    $sort->dir='asc';
                    break;

                case 'highest_price':
                    $sort->col='price';
                    $sort->dir='desc';
                    break;

                case 'alphabet':
                    $sort->col='name';
                    $sort->dir='desc';
                    break;

                case 'popular':
                    $sort->col='avg_rating';
                    $sort->dir='desc';
                    break;
                
                default:
                    $sort->col='name';
                    $sort->dir='asc';
                    break;
            }
        }else{
            $sort->col='model';
            $sort->dir='asc';
        }

        if(!empty($request->input('show'))){
            switch ($request->input('show')) {
                case '40':
                    $show=40;
                    break;

                case '60':
                    $show=60;
                    break;

                case '80':
                    $show=80;
                    break;

                case '100':
                    $show=100;
                    break;
                
                default:
                    $show=20;
                    break;
            }
        }else{
            $show=20;
        }
        $products=[];
        //     $products=Product::select('*')
        //             ->when (!empty($query) , function ($q) use($request){
        //                 $q->where(function($query) use ($request){
        //                        $query->where('slug', 'like', '%'.$request->input('q').'%')
        //                             ->orWhere('name', 'like', '%'.$request->input('q').'%')
        //                             ->orWhere('model', 'like', '%'.$request->input('q').'%')
        //                             ->orWhere('desc', 'like', '%'.$request->input('q').'%');
        //                   //   })
        //                   // ->orWhere(function($query) use ($request) {
        //                   //       $string=explode(' ',$request->input('q'));
        //                   //       foreach($string as $key => $value){
        //                   //           $query->where('name', 'like', '%'.$value.'%');
        //                   //           $query->orWhere('model', 'like', '%'.$value.'%');
        //                   //           $query->orWhere('desc', 'like', '%'.$value.'%');
        //                   //       }
        //                     });
        //               return $q;
        //             })
        //             ->when (!empty($cat) && $category!=null , function ($query) use($category,$request){
        //                 return $query->whereHas('ProductToCategory', function($q) use ($category){
        //                     $q->where('category_id', '=', $category->id);
        //                 });
        //             })
        //             ->when (!empty($request->input('subcategory')) && $subcategory!=null , function ($query) use($subcategory,$request){
        //                 return $query->whereHas('ProductToCategory', function($q) use ($subcategory){
        //                     $q->where('category_id', '=', $subcategory->id);
        //                 });
        //             })
        //             ->when (!empty($request->input('brand')) && $brand!=null , function ($query) use($brand,$brandid){
        //                 return $query->whereIn('manufacturer_id', $brandid);
        //             })

        //             ->when (!empty($request->input('rating')) , function ($query) use($request){
        //                 return $query->where('avg_rating','=', $request->input('rating'));
        //             })
        //             ->when (!empty($request->input('min')) && !empty($request->input('max')) , function ($query) use($request){
        //                 return $query->where('price','>=', $request->input('min'))->where('price','<=', $request->input('max'));
        //             })
        //             ->when (empty($request->input('max')) && !empty($request->input('min')) , function ($query) use($request){
        //                 return $query->where('price','>=', $request->input('min'));
        //             })
                    
        //             ->orderBy($sort->col, $sort->dir)
        //             ->with('Image')
        //             ->with('Manufacturer')
        //             ->whereStatus(1)
        //             ->where('qty','>',0)
        //             ->paginate($show);

        // foreach ($products as $key => $value) {
        //     $value->name=ucwords(strtolower($value->name));
        // }

        $categories=Category::whereHas('ProductToCategory')->whereNull('parent_id')->get();
        $brands=Manufacturer::get();
        
        // $products = Product::where('status', 1)
        //             ->where('name','like','%'.$query.'%')
        //             ->orderBy('name','asc')
        //             ->paginate(20);
        // $recommended_products = RecommendedProduct::whereHas('Product')->inRandomOrder()->take(6)->get();
        //$blogs=Blog::orderBy('created_at', 'desc')->take(4)->get();
        return view('front.search', compact('products', 'recommended_products', 'blogs', 'categories', 'cat', 'brands', 'category', 'subcategories'));
       
    }

    public function viewProduct($slug, Request $request)
    {
        $result=Product::whereSlug($slug)->firstOrFail();
        // if (Auth::check()){
        //     $percent = round((($result->price - $result->finalPrice(Auth::user()->customer_group_id,1))*100) /$result->price) ;
        // }else{
        //     $percent = round((($result->price - $result->finalPrice(1,1))*100) /$result->price) ;
        // }
        $percent = round((($result->price - $result->price_filter)*100) /$result->price) ;
        $result->percent=$percent;
        if(isset($request['word'])){
            $discussions=$result->ProductDiscussion()->where('text','like','%'.$request['word'].'%')->whereNull('parent_id')->orderBy('created_at', 'desc')->paginate(10);
        }else{
            $discussions=$result->ProductDiscussion()->whereNull('parent_id')->orderBy('created_at', 'desc')->paginate(10);
        }
        $category=ProductToCategory::whereProduct_id($result->id)->first() ? ProductToCategory::whereProduct_id($result->id)->first()->Category->name : '';
        // $recommended_products = RecommendedProduct::whereHas('Product')->inRandomOrder()->take(6)->get();
        // $blogs=Blog::orderBy('created_at', 'desc')->take(3)->get();
        // $ptp=ProductToProduct::whereProduct_id($result->id)->pluck('to_product_id');
        // $related=Product::whereIn('id', $ptp)->inRandomOrder()->take(5)->get();
        $categories=ProductToCategory::whereProduct_id($result->id)->pluck('category_id')->toArray();
        $findProduct=ProductToCategory::whereIn('category_id', $categories)->inRandomOrder()->take(5)->pluck('product_id')->toArray();
        $related=Product::whereIn('id', $findProduct)->inRandomOrder()->take(5)->get();
        
        return view('front.productDetail', compact('result', 'category', 'discussions', 'related'));
    }

    public function viewProductDiscussion($slug, Request $request)
    {
        $result=Product::whereSlug($slug)->firstOrFail();
        $percent = round((($result->price - $result->price_filter)*100) /$result->price) ;
        $result->percent=$percent;
        if(isset($request['word'])){
            $discussions=$result->ProductDiscussion()->where('text','like','%'.$request['word'].'%')->whereNull('parent_id')->orderBy('created_at', 'desc')->paginate(10);
        }else{
            $discussions=$result->ProductDiscussion()->whereNull('parent_id')->orderBy('created_at', 'desc')->paginate(10);
        }
        $cat=ProductToCategory::whereProduct_id($result->id)->first()->Category;
        $category=ProductToCategory::whereProduct_id($result->id)->first() ? ProductToCategory::whereProduct_id($result->id)->first()->Category->name : '';
        
        
        return view('front.productDiscussion', compact('result', 'cat', 'category', 'discussions'));
    }

    public function viewProductReview($slug, Request $request)
    {
        $result=Product::whereSlug($slug)->firstOrFail();
        $percent = round((($result->price - $result->price_filter)*100) /$result->price) ;
        $result->percent=$percent;
        $reviews=$result->ProductReview()->orderBy('created_at', 'desc')->paginate(10);
        $cat=ProductToCategory::whereProduct_id($result->id)->first()->Category;
        $category=ProductToCategory::whereProduct_id($result->id)->first() ? ProductToCategory::whereProduct_id($result->id)->first()->Category->name : '';
        
        
        return view('front.productReview', compact('result', 'cat', 'category', 'reviews'));
    }

    public function postDiscussion($slug,Request $request)
    {
        $product=Product::whereSlug($slug)->firstOrFail();
        $user=User::find(Auth::user()->id);

        $request->validate([
            'post_disc' => 'required'
        ]);

        $disc=new ProductDiscussion();
        $disc->user_id=$user->id;
        $disc->product_id=$product->id;
        $disc->text=$request['post_disc'];
        $disc->ip=$request->ip();
        $disc->save();

        return back()->with('success', 'Pertanyaan anda telah kami terima dan akan kami jawab segera, mohon menunggu.');
    }

    public function dashboard()
    {
    	$user=User::find(Auth::user()->id);
    	$dob=Carbon::parse($user->dob);

    	$countries=Countries::get();
    	return view('front.dashboard', compact('user','dob','countries'));
    }

    public function address()
    {
        $user=User::find(Auth::user()->id);
        $address=$user->Address;
        return view('front.address', compact('user','address'));
    }

    public function orderHistory()
    {
        $orderhistory=Order::whereUser_id(Auth::user()->id)->orderBy('created_at', 'desc')->paginate(5);
        return view('front.orderHistory', compact('orderhistory'));
    }
	

    public function order($invoice=null, NicepayLib $nicepaylib)
    {
        $order=Order::whereInvoice('INV/'.Carbon::now()->year.'/'.$invoice)->first();
        $x=0;
        while($x<10){
            if(!count($order)){
                $order=Order::whereInvoice('INV/'.Carbon::now()->subYear()->year.'/'.$invoice)->first();
            }else{
                $x=10;
            }
            $x++;
        }
        if(!count($order)){
            return abort(404);
        }

        $nt=new \stdClass();
        if($order->bank_code!=null){
            $nt=$order->NicepayTransaction;
            if($nt->status==0 && $order->order_status_id==1){
                $nt=app('App\Http\Controllers\Front\NicepayController')->checkStatus($nicepaylib, $invoice);
            }
        }
        return view('front.orderDetailNew', compact('order', 'nt'));
    }

    public function showReturnForm($invoice)
    {
        $order=Order::whereInvoice('INV/'.Carbon::now()->year.'/'.$invoice)->first();
        $x=0;
        while($x<10){
            if(!count($order)){
                $order=Order::whereInvoice('INV/'.Carbon::now()->subYear()->year.'/'.$invoice)->first();
            }else{
                $x=10;
            }
            $x++;
        }
        if(!count($order)){
            return abort(404);
        }

        $product_id=OrderDetail::whereOrder_id($order->id)->pluck('product_id')->toArray();
        $products=Product::whereIn('id', $product_id)->get();

        // return view('front.return', compact('order', 'products'));
        return view('front.returnnew', compact('order', 'products'));
    }

    public function return($invoice, Request $request)
    {
        $order=Order::whereInvoice('INV/'.Carbon::now()->year.'/'.$invoice)->first();
        $x=0;
        while($x<10){
            if(!count($order)){
                $order=Order::whereInvoice('INV/'.Carbon::now()->subYear()->year.'/'.$invoice)->first();
            }else{
                $x=10;
            }
            $x++;
        }
        if(!count($order)){
            return abort(404);
        }

        $request->validate([
            'products' => 'required|array|min:1',
            'reason' => 'required' 
        ]);

        if($request->input('attachment') !== null) {
            if(count($request->input('attachment'))) {
                $request->validate([
                    'attachment.*' => 'image'
                ], [
                    'attachment.*.image' => 'Tautan Harus Berupa Gambar'
                ]);
            }
        }

        foreach ($request['products'] as $key => $value) {
            if($value>0){
                $try=Product::find($value);
                if(count($try)){
                    $return = new OrderReturn();
                    $return->order_id=$order->id;
                    $return->product_id=$value;
                    $return->reason=$request['reason'];
                    $return->note=$request['note'];
                    $return->status=1;
                    $return->save();

                    $found=0;
                    $tryreturn=OrderReturn::whereOrder_id($order->id)->get();

                    if(count($tryreturn)){
                        foreach ($tryreturn as $tr) {
                            $return_attachment=ReturnAttachment::whereReturn_id($tr->id)->get();
                            if(count($return_attachment)){
                                $found=$tr->id;
                            }
                        }
                    }

                    if($found!=0){
                        $return_attachment=ReturnAttachment::whereReturn_id($tr->id)->get();
                        foreach($return_attachment as $ra) {
                            $attachment=new ReturnAttachment();
                            $attachment->return_id=$return->id;
                            $attachment->path=$ra->path;
                            $attachment->save();
                        }
                    }else{
                        if($request->hasFile('attachment'))
                        {
                            $files = $request->file('attachment');
                         
                            foreach($files as $file){

                                $destinationPath = public_path('/img/issue_attachment');
                                $extension = $file->getClientOriginalExtension(); // getting image extension
                                $fileName = $file->getClientOriginalName().'_'. time().'.'.$file->getClientOriginalExtension(); // renameing image
                                $file->move($destinationPath, $fileName);

                                $path=url('/img/issue_attachment/'.$fileName);

                                $attachment=new ReturnAttachment();
                                $attachment->return_id=$return->id;
                                $attachment->path=$path;
                                $attachment->save();
                             
                            }
                         
                        }
                    }
                }
            }
        }

        $oh=new OrderHistory();
        $oh->order_id=$order->id;
        $oh->order_status_id=12;
        $oh->notify=0;
        $oh->save();

        $order->order_status_id=12;
        $order->save();
        $order->touch();

        return redirect('order-history')->with('success','Permintaan Retur telah diajukan.');
    }

    public function updateProfile(Request $request)
    {
    	$request['dob'] = $request['day'].'-'.$request['month'].'-'.$request['year'];
        $current_year          = Carbon::now()->year;
        $hundred_years_ago     = (new Carbon("100 years ago"))->year;
    	$request->validate([
            'avatar' => 'image',
		    'firstname' => 'required|max:255',
            'lastname' => 'required|max:255',
            'phone' => 'required',
            'country' => 'sometimes|exists:countries,id',
            'year' => 'required|integer|between:'.$hundred_years_ago.','.$current_year,
            'dob' => 'required|date',
            'gender'=> 'required|in:M,F'  
		]);
    	$user=User::find(Auth::user()->id);
        //check image
          if ($request->hasFile('avatar')) {
              $image = $request->file('avatar');

              $destinationPath = public_path('/img/avatar');
              $extension = $image->getClientOriginalExtension(); // getting image extension
              $fileName = time().'.'.$image->getClientOriginalExtension(); // renameing image
              $image->move($destinationPath, $fileName);

              $path=url('/img/avatar/'.$fileName);


              $store->user=$path;
          }
    	$user->firstname=$request['firstname'];
    	$user->lastname=$request['lastname'];
    	$user->telephone=$request['phone'];
    	$user->country_id=$request['country'];
    	$user->dob=Carbon::parse($request['dob']);
    	$user->gender=$request['gender'];
    	$user->about=$request['about'];
    	$user->save();
    	$user->touch();
    	return back()->with('success','Profile updated');
    }

    public function updateEmail(Request $request)
    {
        $request->validate([
            'email' => 'required|exists:users,email',
            'new_email' => 'required|email',
            'confirm_new_email' => 'required|email' 
        ]);
        $user=User::find(Auth::user()->id);
        if($user->email === $request->input('email')){
            if($request->input('new_email') === $request->input('confirm_new_email')){
                if (Hash::check($request->input('password'), $user->password)) {
                    $check_exist=User::whereEmail($request->input('new_email'))->count();
                    if($check_exist==0){
                        $user->email=$request['new_email'];
                        $user->save();
                        $user->touch();

                        Mail::send('mail.emailUpdated', ['user'=>$user], function($message) use ($user) {
                             $message->to($user->email, $user->firstname)
                                 ->subject('New Email Address '.$user->email.' Has Been Saved.');
                         });

                        return back()->with('success','Email updated');
                    }else{
                        return back()->with('error','New Email Address Already In Use!');
                    }
                }else{
                    return back()->with('error','Wrong Password!');
                }
            }else{
                return back()->with('error','New Email and Confirm New Email not match!');
            }
        }else{
            return back()->with('error','Wrong Current Email!');
        }
    }

    public function updatePassword(Request $request)
    {
        $request->validate([
            'old_password' => 'required',
            'password' => 'required|min:6|confirmed', 
        ]);
        $user=User::find(Auth::user()->id);
        if (Hash::check($request->input('old_password'), $user->password)) {
                $user->password=bcrypt($request['password']);
                $user->save();
                $user->touch();

                Mail::send('mail.passwordUpdated', ['user'=>$user], function($message) use ($user) {
                     $message->to($user->email, $user->firstname)
                         ->subject('Your Password Has Been Updated.');
                 });

                return back()->with('success','Password updated');
            
        }else{
            return back()->with('error','Wrong Password!');
        }
        
        
    }

    public function getCallingCode($id)
    {
    	$country=Countries::find($id);
    	return response()->json("+".$country->calling_code);
    }

    public function createAddress(Request $request)
    {
        $request->validate([
            'first_name' => 'required|max:191',
            'last_name' => 'required|max:191',
            'phone' => 'required|numeric',
            'city' => 'required|exists:city,id',
            'subdistrict' => 'required|exists:subdistrict,id',
            'postal_code' => 'required|numeric',
            'address' => 'required'
        ]);
        $address=new Address();
        
        $address->name=$request['first_name']." ".$request['middle_name']." ".$request['last_name'];
        $address->user_id=Auth::user()->id;
        $address->address=$request['address'];
        $address->subdistrict_id=$request['subdistrict'];
        $address->postal_code=$request['postal_code'];
        $address->telephone=$request['phone'];
        if(isset($request['default'])){
            $address->main=$request['default'];
            $main=Address::whereUser_id(Auth::user()->id)->whereMain(1)->first();
            if($main){
                $main->main=0;
                $main->save();
                $main->touch();
            }
        }
        $address->save();
        $address->touch();
        if(isset($request['back_url']) && strlen($request['back_url']) > 5){
            return redirect($request['back_url'])->with('success','Berhasil Menambahkan Alamat');
        }else{
            return redirect('address-book')->with('success','Berhasil Menambahkan Alamat');
        }
    }

    public function editAddress($id)
    {
        $address=Address::whereUser_id(Auth::user()->id)->whereId($id)->firstOrFail();
        return view('front.updateAddress', compact('address'));
    }

    public function updateAddress($id,Request $request)
    {
        $request->validate([
            'name' => 'required|max:191',
            'phone' => 'required|numeric',
            'city' => 'required|exists:subdistrict,id',
            'postal_code' => 'required|numeric',
            'address' => 'required'
        ]);
        $address=Address::whereUser_id(Auth::user()->id)->whereId($id)->firstOrFail();
        
        $address->name=$request['name'];
        $address->user_id=Auth::user()->id;
        $address->address=$request['address'];
        $address->subdistrict_id=$request['city'];
        $address->postal_code=$request['postal_code'];
        $address->telephone=$request['phone'];
        if(isset($request['default'])){
            $address->main=$request['default'];
        }
        $address->save();
        $address->touch();
        if(isset($request['back_url']) && strlen($request['back_url']) > 5){
            return redirect($request['back_url'])->with('success','Berhasil Mengubah Alamat');
        }else{
            return back()->with('success','Berhasil Mengubah Alamat');
        }
    }

    public function setMainAddress($id)
    {
        $main=Address::whereUser_id(Auth::user()->id)->whereMain(1)->first();
        if($main){
            $main->main=0;
            $main->save();
            $main->touch();
        }
        $address=Address::whereUser_id(Auth::user()->id)->whereId($id)->firstOrFail();
        $address->main=1;
        $address->save();
        $address->touch();

        return response()->json($address);
    }

    public function deleteAddress($id)
    {
        $address=Address::whereUser_id(Auth::user()->id)->whereId($id)->firstOrFail();
        $address->delete();
        return back()->with('success','Your address has been deleted!');
    }

    public function checkStock(Request $request)
    {
        $temp=[];
        $flag=0;
        $stockid=0;
        $request['combination']=json_decode($request['combination']);
        //return response()->json($request->all());

        if($request['combination']!==null && count($request['combination'])==1){
            $pod=ProductOptionDetail::whereProduct_id($request['product_id'])->whereOption_value_id($request['combination'][0]->value)->first();
          $temp=ProductStockDetail::whereProduct_option_detail_id($pod->id)->first();
          $stockid=$temp->product_stock_id;
          $ps=ProductStock::find($stockid);
          return response()->json([$ps]);
        }elseif($request['combination']!==null && count($request['combination'])>1){
          //   $pod=ProductOptionDetail::whereProduct_id($request['product_id'])->whereOption_value_id($request['combination'][0]->value)->first();
          // $temp=ProductStockDetail::whereProduct_option_detail_id($pod->id)->get();
          // //return response()->json($temp);
          // for($x=1;$x<count($request['combination']);$x++) {
          //   $pod=ProductOptionDetail::whereProduct_id($request['product_id'])->whereOption_value_id($request['combination'][$x]->value)->first();
          //   foreach ($temp as $key => $value) {
          //     $try=ProductStockDetail::whereProduct_stock_id($value->product_stock_id)
          //       ->whereProduct_option_detail_id($pod->id)
          //       ->first();
          //       if(count($try)>0){
          //         $stockid=$try->product_stock_id;
          //       }
          //   }
          // }
            $find=[];
            for($x=0;$x<count($request['combination']);$x++) {
                $pod=ProductOptionDetail::whereProduct_id($request['product_id'])->whereOption_value_id($request['combination'][$x]->value)->first();
                  $try=ProductStockDetail::whereProduct_option_detail_id($pod->id)
                    ->pluck('product_stock_id')->toArray();
                    if(count($try)>0){
                      $find[]=$try;
                    }else{
                        $find[]=[];
                    }
              }
              $stockid=call_user_func_array('array_intersect',$find);
          
          $ps=ProductStock::find($stockid);
          return response()->json($ps);
        }else{
            $ps=new \stdClass();
            $ps->id=0;
            return response()->json($ps);
        }

    }

    public function addToCart(Request $request)
    {
        // if($request['product_stock_id']!=0){
        //     $request->validate([
        //         'product_id' => 'required|exists:product,id',
        //         'product_stock_id' => 'required|exists:product_stock,id',
        //     ]);
        //     $ps=ProductStock::find($request['product_stock_id']);
            

        //     $item=Cart::whereUser_id(Auth::user()->id)->whereProduct_id($request['product_id'])->whereProduct_stock_id($request['product_stock_id'])->first();
        //     if(count($item)){
        //         $request['qty']=$item->qty+$request['qty'];
        //         $request->validate([
        //             'qty' => 'required|max:'.$ps->qty
        //         ]);
        //         $item->qty=$request['qty'];
        //         $item->save();
        //         $item->touch();
        //     }else{
        //         $request->validate([
        //             'qty' => 'required|max:'.$ps->qty
        //         ]);
        //         $item=new Cart();
        //         $item->user_id=Auth::user()->id;
        //         $item->product_id=$request['product_id'];
        //         $item->product_stock_id=$request['product_stock_id'];
        //         $item->qty=$request['qty'];
        //         $item->save();
        //     }
        //     return response()->json($item);
        // }else{
            $request->validate([
                'product_id' => 'required|exists:product,id',
            ]);
            
            $product=Product::find($request['product_id']);
            $item=Cart::whereUser_id(Auth::user()->id)->whereProduct_id($request['product_id'])->first();
            if(count($item)){
                $request['qty']=$item->qty+$request['qty'];
                $request->validate([
                    'qty' => 'required|max:'.$product->qty
                ]);
                $item->qty=$request['qty'];
                $item->save();
                $item->touch();
            }else{
                $request->validate([
                    'qty' => 'required|max:'.$product->qty
                ]);
                $item=new Cart();
                $item->user_id=Auth::user()->id;
                $item->product_id=$request['product_id'];
                $item->qty=$request['qty'];
                $item->save();
            }
            return response()->json($item);
        // }
    }

    public function cart()
    {
        $user=User::find(Auth::user()->id);
        $cart=$user->cart;
        return view('front.cart', compact('user','cart'));
    }

    public function clearCart()
    {
        $user=User::find(Auth::user()->id);
        $user->Cart()->delete();
        return back()->with('success','Keranjang belanja Anda berhasil di kosongkan.');
    }

    public function checkCartTotal()
    {
        $user=User::find(Auth::user()->id);
        return response()->json($user->CartQty());
    }

    public function updateCartXhr() 
    {
        $user=User::find(Auth::user()->id);
        $cart=$user->Cart;
        $html="";
        if(count($cart)){
            foreach($cart as $key => $value){
            $product=$value->Product;
            $html.="<li>";
            $html.="    <a href='".url($product->slug)."'>";
            $html.="        <span><img src='". $product->Image->first()->image ."' alt='". $product->name ."'/></span>";
            $html.="        <span>". $product->name ." <br>". $product->model ."</span>";
            $html.="        <span>". currency_format($product->price_filter, 'IDR') ."</span>";
            $html.="    </a>";
            $html.="</li>";
            }
           
        }else{
            $html.="<li>Keranjang belanja kosong</li>";
        }
        $html.="<li><a href='". url('cart') ."'>Tampilkan semua keranjang</a></li>";
        
        return $html;
            
            
    }

    public function updateCart(Request $request)
    {
        // return response()->json($request->all());
        $request->validate([
            'cart_id' => 'required|exists:cart,id'
        ]);
        $cart=Cart::find($request['cart_id']);
        if(count($cart)){
            $weight=0;
            $gram=WeightClass::find(2);
            foreach(Cart::whereUser_id($cart->user_id)->get() as $key => $value){
                $product=$value->Product;
                switch ($product->weight_class_id) {
                  case '2':
                    $temp=$product->weight*$value->qty;
                    $weight=$weight+$temp;
                    break;
                  
                  default:
                    $temp=($product->weight*$gram->value)*$value->qty;
                    $weight=$weight+$temp;
                    break;
                }
            }
            $ps=ProductStock::find($cart->product_stock_id);
            if(count($ps)){
                $request->validate([
                    'qty' => 'required|max:'.$ps->qty
                ]);
                $cart->qty=$request['qty'];
                $cart->save();
                $cart->touch();
                $courier="";
                $service="";
                $shipping_cost=0;
                $shipping_value=explode('_', $request->input('shipping_cost'));
                if(array_key_exists(0, $shipping_value)){
                    $courier=$shipping_value[0];
                }
                if(array_key_exists(1, $shipping_value)){
                    $courier_service=$shipping_value[1];
                }
                if(array_key_exists(2, $shipping_value)){
                    $shipping_cost=$shipping_value[2];
                }
                $obj=$this->calcCart(null, $request->input('coupon'), $shipping_cost);
                if(null !== $request->input('shipping_cost')){
                    $get_shipping_cost=$this->updateShippingCost($request->input('address_id'),$weight,$courier,$courier_service);
                }else{
                     $get_shipping_cost=0;
                }
                $product=Product::find($cart->product_id);
                $cart->formated_price=currency_format($product->finalPrice(Auth::user()->customer_group_id,$cart->qty),'IDR');
                $cart->formated_disc="-(".currency_format(($product->price*$cart->qty)-($product->finalPrice(Auth::user()->customer_group_id,$cart->qty))*$cart->qty,'IDR').")";
                $cart->formated_subtotal=currency_format($product->finalPrice(Auth::user()->customer_group_id,$cart->qty)*$cart->qty,'IDR');
                $cart->formated_subtotal_old=currency_format($product->price*$cart->qty,'IDR');
                $cart->cart_total=$obj->total;
                $cart->cart_nettotal=$obj->nettotal;
                $cart->cart_nettotal_raw=$obj->nettotal_raw;
                $cart->cart_totaldisc=$obj->totaldisc;
                $cart->shipping_option=$obj->shipping_option;
                $cart->shipping_cost=$obj->shipping_cost;
                $cart->shipping_cost="-";
                return response()->json($cart);
            }else{
                $product=Product::find($cart->product_id);
                $request->validate([
                    'qty' => 'required|max:'.$product->qty
                ]);
                $cart->qty=$request['qty'];
                $cart->save();
                $cart->touch();
                 $courier="";
                $service="";
                $shipping_cost=0;
                $shipping_value=explode('_', $request->input('shipping_cost'));
                if(array_key_exists(0, $shipping_value)){
                    $courier=$shipping_value[0];
                }
                if(array_key_exists(1, $shipping_value)){
                    $courier_service=$shipping_value[1];
                }
                if(array_key_exists(2, $shipping_value)){
                    $shipping_cost=$shipping_value[2];
                }
                $obj=$this->calcCart(null, $request->input('coupon'), $shipping_cost);
                if(null !== $request->input('shipping_cost') && isset($courier_service)){
                    $get_shipping_cost=$this->updateShippingCost($request->input('address_id'),$weight,$courier,$courier_service);
                }else{
                     $get_shipping_cost=0;
                }
                $cart->formated_price=currency_format($product->finalPrice(Auth::user()->customer_group_id,$cart->qty),'IDR');
                $cart->formated_disc="-(".currency_format(($product->price*$cart->qty)-($product->finalPrice(Auth::user()->customer_group_id,$cart->qty))*$cart->qty,'IDR').")";
                $cart->formated_subtotal=currency_format($product->finalPrice(Auth::user()->customer_group_id,$cart->qty)*$cart->qty,'IDR');
                $cart->formated_subtotal_old=currency_format($product->price*$cart->qty,'IDR');
                $cart->cart_total=$obj->total;
                $cart->cart_nettotal=$obj->nettotal;
                $cart->cart_nettotal_raw=$obj->nettotal_raw;
                $cart->cart_totaldisc=$obj->totaldisc;
                $cart->shipping_option=$obj->shipping_option;
                $cart->shipping_cost="-";
                return response()->json($cart);
            }
        }else{
            return response()->json(['error', 'Item not found'], 404);
        }
    }

    public function removeCartItem(Request $request)
    {
        $request->validate([
            'cart_id' => 'required|exists:cart,id'
        ]);
        $cart=Cart::find($request['cart_id']);
        $name=Product::find($cart->product_id)->name;
        if(count($cart)){
            $cart->delete();
            return response()->json($name);
        }else{
            return response()->json(['error', 'Item not found'], 404);
        }
    }

    public function checkout(Request $request)
    {
        $user=User::find(Auth::user()->id);
        $cart=$user->cart;
        $payment_method=PaymentMethod::whereStatus(1)->get();
        $addresses=$user->Address;
        if(!empty($request->input('address'))){
            $address=$user->Address()->whereId($request->input('address'))->firstOrFail();
        }else{
            $address=$user->Address()->whereMain(1)->first();
            if(count($address)==0){
                $address=$user->Address()->orderBy('created_at','asc')->first();
                if(count($address)==0){
                    return redirect()->route('address.add',['back_url' => route('checkout')]);
                }
            }
        }
        $cart=Cart::whereUser_id(Auth::user()->id)->get();
        $weight=0;
        $gram=WeightClass::find(2);
        if(count($cart)==0){
            return redirect('cart')->with('warning','Keranjang belanja anda kosong, ayo belanja sekarang!');
        }
        foreach($cart as $key => $value){
            $product=$value->Product;
            switch ($product->weight_class_id) {
              case '2':
                $temp=$product->weight*$value->qty;
                $weight=$weight+$temp;
                break;
              
              default:
                $temp=($product->weight*$gram->value)*$value->qty;
                $weight=$weight+$temp;
                break;
            }
        }
        $shipping_method=$this->getShippingCost($address->id,$weight);
        $bank=Bank::whereStatus(1)->get();
        // $recommended_products = RecommendedProduct::whereHas('Product')->inRandomOrder()->take(6)->get();
        //$blogs=Blog::orderBy('created_at', 'desc')->take(4)->get();
        return view('front.checkout', compact('user','cart','address','shipping_method','payment_method', 'bank', 'addresses'));
    }

    public function calcCart($address=null, $coupon=null, $shipping_cost=null)
    {
        $cart=Cart::whereUser_id(Auth::user()->id)->get();
        $total=0;
        $nettotal=0;
        $totaldisc=0;
        $weight=0;
        $gram=WeightClass::find(2);
        foreach($cart as $key => $value){
            $product=$value->Product;
            switch ($product->weight_class_id) {
              case '2':
                $temp=$product->weight*$value->qty;
                $weight=$weight+$temp;
                break;
              
              default:
                $temp=($product->weight*$gram->value)*$value->qty;
                $weight=$weight+$temp;
                break;
            }
            //$productStock=$product->ProductStock()->whereId($value->product_stock_id)->first();
            $grosssubtotal=$product->price*$value->qty;
            $subtotal=$product->finalPrice(Auth::user()->customer_group_id,$value->qty)*$value->qty;
            $total+=$grosssubtotal;
            $nettotal+=$subtotal;
            $disc=($product->price*$value->qty)-($product->finalPrice(Auth::user()->customer_group_id,$value->qty)*$value->qty);
            $totaldisc+=$disc;
        }
        $cval=0;
        $scval=0;
        if($coupon != null){
            $ps=Coupon::whereCode($coupon)
            ->whereStatus(1)
            ->where('start_date', '<=', Carbon::now())
            ->where('end_date', '>=', Carbon::now())
            ->first();
            if($nettotal > $ps->min_order){
                switch ($ps->type) {
                    case 'P':
                        $cval=$nettotal*$ps->discount/100;
                        if($ps->max_discount != 0){
                            if($cval > $ps->max_discount) {
                                $cval = $ps->max_discount;
                            }
                        }
                        break;

                    case 'F':
                        $cval=$ps->discount;
                        break;
                    
                    default:
                        # code...
                        break;
                }
            }
        }

        if($shipping_cost != null){
            $scval=(int)$shipping_cost;
        }
        $obj=new \stdClass();
        $obj->coupon="-(".currency_format($cval, 'IDR').")";
        $obj->coupon_raw=$cval;
        $obj->shipping_cost=currency_format($scval, 'IDR');
        $obj->shipping_cost_raw=$scval;
        $obj->total=currency_format($total, 'IDR');
        $obj->nettotal=currency_format($nettotal-$cval+$scval, 'IDR');
        $obj->nettotal_raw=$nettotal-$cval+$scval;
        $obj->totaldisc=currency_format($totaldisc, 'IDR');
        $user=User::find(Auth::user()->id);
        if($address==null){
            $obj->shipping_option=null;
            $address=$user->Address()->whereMain(1)->first();
            if(count($address)==0){
                $address=$user->Address()->orderBy('created_at','asc')->first();
            }
        }
        if(count($address)){
            $obj->shipping_option=$this->getShippingCost($address->id,$weight);
        }else{
            $obj->shipping_option=null;
        }

        return $obj;
    }

    public function getShippingCost($address,$weight)
    {
        if($address==null){
            return null;
        }
        $address=Address::whereUser_id(Auth::user()->id)->whereId($address)->first();
        $ship_method=ShippingMethod::whereStatus(1)->get();
        $shipping_city=$address->Subdistrict->name;
        $subdistrict=Subdistrict::whereName($shipping_city)->first();
        $shipping_option="";
        //return $subdistrict;
          foreach($ship_method as $key => $value){
            if($value->id==1 && Auth::user()->customer_group_id==$value->customer_group_id){
              $courier=ShippingCourier::whereStatus(1)->pluck('code');

              foreach ($courier as $key => $value) {
                
                if(count($subdistrict)>0){
                  $getcost=json_decode($this->getCost(env('APP_ORIGINID', 2087),env('APP_ORIGINTYPE', 'subdistrict'),$subdistrict->id,'subdistrict',$weight,$value))->rajaongkir->results;
                  foreach ($getcost[0]->costs as $ser) {
                    switch ($ser->service) {
                      case 'CTC':
                        $service="CTC REG";
                        break;
                      case 'CTCYES':
                        $service="CTC YES";
                        break;
                      case 'CTCOKE':
                        $service="CTC OKE";
                        break;
                      
                      default:
                        $service=$ser->service;
                        break;
                    }
                      
                    $shipping_option.="<div class='ic-radio'><label> ".strtoupper($getcost[0]->code)." ".$ser->service." <br>
                                        <i>Diterima dalam ". $ser->cost[0]->etd ." hari</i><input type='radio' name='shipping' value='".strtoupper($value)."_".$ser->service."_".$ser->cost[0]->value."' data-price='".$ser->cost[0]->value."' data-formated='".currency_format($ser->cost[0]->value,'IDR')."'/> <span class='checkmark'></span></label><span class='ic-price'>".currency_format($ser->cost[0]->value,'IDR')." </span></div>";
                  }
                }

              }
            }elseif ($value->id==2 && Auth::user()->customer_group_id==$value->customer_group_id) {
              // $freeshipping=$value->FreeShipping()->whereStatus(1)->get();
                $freeshipping=FreeShipping::whereStatus(1)->get();
              $free=false;
              foreach ($freeshipping as $key => $value) {
                $check_province=false;
                $check_category=false;
                $check_product=false;
                $check_subtotal=false;
                $province=$value->FreeShippingToProvince()->pluck('province_id')->toArray();
                $category=$value->FreeShippingToCategory()->pluck('category_id')->toArray();
                $filter_product=$value->FreeShippingToProduct()->pluck('product_id')->toArray();

                //check province
                if(count($province)>0){
                  $shipping_province_id=Province::whereName($address->Subdistrict->province)->first()->id;
                  if(in_array($shipping_province_id, $province)){
                    $check_province=true;
                  }else{
                    $check_province=false;
                  }
                }else{
                  $check_province=true;
                }

                //check category
                $cart=Cart::whereUser_id(Auth::user()->id)->get();
                if(count($category)>0){
                  foreach($cart as $cr){
                    $product_category=ProductToCategory::whereProduct_id($cr->product_id)->first()->category_id;
                    if(in_array($product_category, $category)){
                      $check_category=true;
                    }else{
                      $check_category=false;
                    }
                  }
                }else{
                  $check_category=true;
                }

                //check product
                if(count($filter_product)>0){
                  foreach($cart as $cr){
                    if(in_array($cr->product_id, $filter_product)){
                      $check_product=true;
                    }else{
                      $check_product=false;
                    }
                  }
                }else{
                  $check_product=true;
                }

                //check subtotal
                foreach($cart as $cr){
                    $subtotal=0;
                    $product=Product::find($cr->product_id);
                    $subtotal=$subtotal+((int)$cr->price_filter*$cr->qty);
                }
                if($subtotal>=$value->subtotal){ $check_subtotal=true; }  

                if($check_province==true && $check_category==true && $check_product==true && $check_subtotal==true){ $free=true; }
              }
              if($free==true){
                // $shipping_option.="<label><input type='radio' name='shipping' value='FREE_SHIPPING_0'/> Free Shipping</label>";
                $shipping_option.="<div class='ic-radio'><label> Free Shipping <br>
                                        <input type='radio' name='shipping' value='FREE_SHIPPING_0' data-price='0' data-formated='".currency_format(0,'IDR')."'/> <span class='checkmark'></span></label><span class='ic-price'>".currency_format(0,'IDR')." </span></div>";
              }

          }elseif ($value->id==3 && Auth::user()->customer_group_id==$value->customer_group_id) {
                // dd('check kreasi2go');
              // $kreasi2go=$value->Kreasi2go()->whereStatus(1)->get();
                $kreasi2go=Kreasi2go::whereStatus(1)->get();
              $kreasi2go_flag=false;
              foreach ($kreasi2go as $key => $value2) {
                $check_province=false;
                $check_category=false;
                $check_product=false;
                $check_subtotal=false;
                $province=$value2->Kreasi2goToProvince()->pluck('province_id')->toArray();
                $category=$value2->Kreasi2goToCategory()->pluck('category_id')->toArray();
                $filter_product=$value2->Kreasi2goToProduct()->pluck('product_id')->toArray();

                //check province
                if(count($province)>0){
                  $shipping_province_id=Province::whereName($address->Subdistrict->province)->first()->id;
                  if(in_array($shipping_province_id, $province)){
                    $check_province=true;
                  }else{
                    $check_province=false;
                  }
                }else{
                  $check_province=true;
                }


                //check category
                $cart=Cart::whereUser_id(Auth::user()->id)->get();
                if(count($category)>0){
                  foreach($cart as $cr){
                    $product_category=ProductToCategory::whereProduct_id($cr->product_id)->first()->category_id;
                    if(in_array($product_category, $category)){
                      $check_category=true;
                    }else{
                      $check_category=false;
                    }
                  }
                }else{
                  $check_category=true;
                }

                //check product
                if(count($filter_product)>0){
                  foreach($cart as $cr){
                    if(in_array($cr->product_id, $filter_product)){
                      $check_product=true;
                    }else{
                      $check_product=false;
                    }
                  }
                }else{
                  $check_product=true;
                }

                //check subtotal
                foreach($cart as $cr){
                    $subtotal=0;
                    $product=Product::find($cr->product_id);
                    $subtotal=$subtotal+((int)$product->price_filter*$cr->qty);
                }
                if($subtotal>=$value2->subtotal){ $check_subtotal=true; }  

                if($check_province==true && $check_category==true && $check_product==true && $check_subtotal==true){ $kreasi2go_flag=true; }
              }
              if($kreasi2go_flag==true){
                // $shipping_option.="<label><input type='radio' name='shipping' value='KREASI2GO_KREASI2GO_".$value->price."'/> Kreasi2go ". currency_format($value->price, 'IDR') ."</label>";
                $shipping_option.="<div class='ic-radio'><label> Kreasi2go <br>
                                    <i>Khusus DKI Jakarta</i>
                                        <input type='radio' name='shipping' value='KREASI2GO_KREASI2GO_".$value->price."' data-price='".$value->price."' data-formated='".currency_format($value->price,'IDR')."'/> <span class='checkmark'></span></label><span class='ic-price'>".currency_format($value->price,'IDR')." </span></div>";
              }
            }
          }
          return $shipping_option;
    }

    public function updateShippingCost($address,$weight,$courier,$courier_service)
    {
        if($address==null){
            return null;
        }
        $address=Address::whereUser_id(Auth::user()->id)->whereId($address)->first();
        $ship_method=ShippingMethod::whereStatus(1)->get();
        $shipping_city=$address->Subdistrict->name;
        $subdistrict=Subdistrict::whereName($shipping_city)->first();
        $shipping_cost=0;
        //return $subdistrict;
          foreach($ship_method as $key => $value){
            if($value->id==1 && Auth::user()->customer_group_id==$value->customer_group_id){
              $courier=ShippingCourier::whereStatus(1)->whereCode($courier)->pluck('code');

              foreach ($courier as $key => $value) {
                
                if(count($subdistrict)>0){
                  $getcost=json_decode($this->getCost(env('APP_ORIGINID', 2087),env('APP_ORIGINTYPE', 'subdistrict'),$subdistrict->id,'subdistrict',$weight,$value))->rajaongkir->results;
                  foreach ($getcost[0]->costs as $ser) {
                    switch ($ser->service) {
                      case 'CTC':
                        $service="CTC REG";
                        break;
                      case 'CTCYES':
                        $service="CTC YES";
                        break;
                      case 'CTCOKE':
                        $service="CTC OKE";
                        break;
                      
                      default:
                        $service=$ser->service;
                        break;
                    }
                    if($service===$courier_service || $ser->service===$courier_service){
                        $shipping_cost=$ser->cost[0]->value;
                    }
                    
                  }
                }

              }
            }elseif ($value->id==2 && Auth::user()->customer_group_id==$value->customer_group_id) {
              // $freeshipping=$value->FreeShipping()->whereStatus(1)->get();
                $freeshipping=FreeShipping::whereStatus(1)->get();
              $free=false;
              foreach ($freeshipping as $key => $value) {
                $check_province=false;
                $check_category=false;
                $check_product=false;
                $check_subtotal=false;
                $province=$value->FreeShippingToProvince()->pluck('province_id')->toArray();
                $category=$value->FreeShippingToCategory()->pluck('category_id')->toArray();
                $filter_product=$value->FreeShippingToProduct()->pluck('product_id')->toArray();

                //check province
                if(count($province)>0){
                  $shipping_province_id=Province::whereName($address->Subdistrict->province)->first()->id;
                  if(in_array($shipping_province_id, $province)){
                    $check_province=true;
                  }else{
                    $check_province=false;
                  }
                }else{
                  $check_province=true;
                }

                //check category
                $cart=Cart::whereUser_id(Auth::user()->id)->get();
                if(count($category)>0){
                  foreach($cart as $cr){
                    $product_category=ProductToCategory::whereProduct_id($cr->product_id)->first()->category_id;
                    if(in_array($product_category, $category)){
                      $check_category=true;
                    }else{
                      $check_category=false;
                    }
                  }
                }else{
                  $check_category=true;
                }

                //check product
                if(count($filter_product)>0){
                  foreach($cart as $cr){
                    if(in_array($cr->product_id, $filter_product)){
                      $check_product=true;
                    }else{
                      $check_product=false;
                    }
                  }
                }else{
                  $check_product=true;
                }

                //check subtotal
                foreach($cart as $cr){
                    $subtotal=0;
                    $product=Product::find($cr->product_id);
                    $subtotal=$subtotal+((int)$cr->price_filter*$cr->qty);
                }
                if($subtotal>=$value->subtotal){ $check_subtotal=true; }  

                if($check_province==true && $check_category==true && $check_product==true && $check_subtotal==true){ $free=true; }
              }
              if($free==true){
                if($courier_service==='FREE_SHIPPING_0'){
                        $shipping_cost=0;
                    }
                
              }
            }elseif ($value->id==3 && Auth::user()->customer_group_id==$value->customer_group_id) {
              // $kreasi2go=$value->Kreasi2go()->whereStatus(1)->get();
                    $kreasi2go=Kreasi2go::whereStatus(1)->get();
              $kreasi2go_flag=false;
              foreach ($kreasi2go as $key => $value2) {
                $check_province=false;
                $check_category=false;
                $check_product=false;
                $check_subtotal=false;
                $province=$value2->Kreasi2goToProvince()->pluck('province_id')->toArray();
                $category=$value2->Kreasi2goToCategory()->pluck('category_id')->toArray();
                $filter_product=$value2->Kreasi2goToProduct()->pluck('product_id')->toArray();

                //check province
                if(count($province)>0){
                  $shipping_province_id=Province::whereName($address->Subdistrict->province)->first()->id;
                  if(in_array($shipping_province_id, $province)){
                    $check_province=true;
                  }else{
                    $check_province=false;
                  }
                }else{
                  $check_province=true;
                }

                //check category
                $cart=Cart::whereUser_id(Auth::user()->id)->get();
                if(count($category)>0){
                  foreach($cart as $cr){
                    $product_category=ProductToCategory::whereProduct_id($cr->product_id)->first()->category_id;
                    if(in_array($product_category, $category)){
                      $check_category=true;
                    }else{
                      $check_category=false;
                    }
                  }
                }else{
                  $check_category=true;
                }

                //check product
                if(count($filter_product)>0){
                  foreach($cart as $cr){
                    if(in_array($cr->product_id, $filter_product)){
                      $check_product=true;
                    }else{
                      $check_product=false;
                    }
                  }
                }else{
                  $check_product=true;
                }

                //check subtotal
                foreach($cart as $cr){
                    $subtotal=0;
                    $product=Product::find($cr->product_id);
                    $subtotal=$subtotal+((int)$cr->price_filter*$cr->qty);
                }
                if($subtotal>=$value2->subtotal){ $check_subtotal=true; }  

                if($check_province==true && $check_category==true && $check_product==true && $check_subtotal==true){ $kreasi2go_flag=true; }
              }
              if($kreasi2go_flag==true){
                // $shipping_option.="<label><input type='radio' name='shipping' value='KREASI2GO_KREASI2GO_".$value->price."'/> Kreasi2go ". currency_format($value->price, 'IDR') ."</label>";
                if($courier_service==="KREASI2GO"){

                        $shipping_cost=$value->price;
                    }
              }
            }
          }
          return $shipping_cost;
    }

    public function addAddress()
    {
        return view('front.addAddress');
    }

    public function submitCoupon(Request $request)
    {
        // $request->validate([
        //     'coupon' => 'required'
        // ]);
        $cart=Cart::whereUser_id(Auth::user()->id)->get();
        if(count($cart)){
            
                // $obj=$this->calcCart(null,$request->input('coupon'), $request->input('shipping_cost'));
                $courier="";
                $service="";
                $shipping_cost=0;
                $shipping_value=explode('_', $request->input('shipping_cost'));
                if(array_key_exists(0, $shipping_value)){
                    $courier=$shipping_value[0];
                }
                if(array_key_exists(1, $shipping_value)){
                    $courier_service=$shipping_value[1];
                }
                if(array_key_exists(2, $shipping_value)){
                    $shipping_cost=$shipping_value[2];
                }
                $obj=$this->calcCart(null, $request->input('coupon'), $shipping_cost);
                
                return response()->json($obj);
            
        }else{
            return response()->json(['error', 'Invalid Coupon'], 404);
        }
    }

    public function postCheckout(Request $request)
      {
        //dd($request->all());
        
        $request->validate([
            //'customer' => 'exists:users,id',
            'payment_method' => 'exists:payment_method,id',
            'shipping_method' => 'required',
            
        ]);
        if($request['payment_method']=='3'){
            $request->validate([
                'bank' => 'exists:bank,id'
            ]);
        }
        $user=User::find(Auth::user()->id);
        $address=Address::find($request['shipping_address_id']);
        $payment_method=PaymentMethod::find($request['payment_method']);
        $store=new Order();
        $store->invoice=$this->generateInvoice();
        $store->user_id=$user->id;
        $store->customer_group_id=$user->customer_group_id;
        $store->name=$user->name;
        $store->email=$user->email;
        $store->telephone=$user->telephone;
        $store->fax=$user->fax;
        $store->payment_name=$address->name;
        $store->payment_company=$address->company;
        $store->payment_address=$address->address;
        $store->payment_city=$address->getCity();
        $store->payment_postal_code=$address->postal_code;
        $store->payment_province=$address->Subdistrict->province;
        $store->payment_telephone=$address->telephone;
        $store->shipping_name=$address->name;
        $store->shipping_company=$address->company;
        $store->shipping_address=$address->address;
        $store->shipping_city=$address->getCity();
        $store->shipping_postal_code=$address->postal_code;
        $store->shipping_province=$address->Subdistrict->province;
        $store->shipping_telephone=$address->telephone;

        $shipping_method=explode("_",$request['shipping_method']);

        $weight=0;
        $gram=WeightClass::find(2);
        foreach(Cart::whereUser_id(Auth::user()->id)->get() as $key => $value){
            $product=$value->Product;
            switch ($product->weight_class_id) {
              case '2':
                $temp=$product->weight*$value->qty;
                $weight=$weight+$temp;
                break;
              
              default:
                $temp=($product->weight*$gram->value)*$value->qty;
                $weight=$weight+$temp;
                break;
            }
        }
        $get_shipping_cost=$this->updateShippingCost($address->id,$weight,$shipping_method[0],$shipping_method[1]);
        $store->shipping_courier=$shipping_method[0];
        $store->courier_service=$shipping_method[1];
        $store->shipping_cost=$get_shipping_cost;
        $store->transfer_code=0;
        $store->payment_method=$payment_method->name;
        $store->order_status_id=1;
        $store->comment=$request['comment'];
        $store->save();

        $cart=$user->Cart;
        foreach($cart as $key=>$prod){
          $product=Product::find($prod->product_id);
          
          // if($prod['product_stock_id']!==null){
          //   $stock=ProductStock::find($prod['product_stock_id']);
          //   //$stock->qty=$stock->qty-(int)$prod->qty;
          //   // $stock->save();
          //   // $stock->touch();
          // }else{
            $stock=new \stdClass();
            $stock->qty=$product->qty;
          // }
          if((int)$prod->qty<1){
            $store->forceDelete();
            return back()->withInput()->with('error',$product->name.' value minimum is 1');
          }
          if((int)$prod->qty>$stock->qty){
            $store->forceDelete();
            return back()->withInput()->with('error',$product->name.' quantity may not be greater than '.$stock->qty);
          }
          

          $orderdetail=new OrderDetail();
          $orderdetail->order_id=$store->id;
          $orderdetail->product_id=$product->id;
          $orderdetail->qty=(int)$prod->qty;
          // $orderdetail->product_stock_id=$prod->product_stock_id;
          $orderdetail->price=$product->finalPrice($user->customer_group_id,1);
          $orderdetail->save();

          // if($prod->product_stock_id!==null){
          //   $stock->qty=$stock->qty-(int)$prod->qty;
          //   $stock->save();
          //   $stock->touch();
          // }
          $product->qty=$product->qty-(int)$prod->qty;
          $product->save();
          $product->touch();
        }

        $total=0;
        foreach ($store->OrderDetail as $key => $value) {
          $total=$total+($value->qty*$value->price);
        }
        $store->subtotal=$total;
        $store->total=$total+$store->transfer_code+$store->shipping_cost;
        $store->save();

        $oh=new OrderHistory();
        $oh->order_id=$store->id;
        $oh->order_status_id=1;
        $oh->notify=0;
        $oh->save();



        switch ($payment_method->id) {
            case 2:
                $nt=app('App\Http\Controllers\Front\NicepayController')->creditCard($store,'01');
                if($nt){
                    if(is_array($nt)){
                        $store->forceDelete();
                        return $nt['error'];
                    }else{
                        // $store->order_status_id=11;
                        $store->save();
                        $user->Cart()->delete();

                        // $oh=new OrderHistory();
                        // $oh->order_id=$store->id;
                        // $oh->order_status_id=11;
                        // $oh->notify=1;
                        // $oh->save();

                        Mail::send('mail.checkout_final', ['user'=>$user, 'order'=>$store], function($message) use ($user,$store) {
                             $message->to($user->email, $user->firstname)
                                 ->subject('Pesanan '.$store->invoice.' berhasil dibuat');
                         });

                        $payment_method->used++;
                        $payment_method->save();
                        $payment_method->touch();

                        return redirect($nt->data->requestURL."?tXid=".$nt->tXid);
                    }
                }else{
                    $store->forceDelete();
                    //dd($nt);
                    return "Timeout";
                }

                break;

            case 3:
                $bank=Bank::find(4);
                $store->bank_code=$bank->code;
                $store->bank=$bank->name;
                $store->save();
                $nt=app('App\Http\Controllers\Front\NicepayController')->registration($store,'02');
                break;

            case 4:
                $mitra=explode('_', $request['cvs']);
                $store->bank_code=$mitra[0];
                $store->bank=$mitra[1];
                $store->save();
                $nt=app('App\Http\Controllers\Front\NicepayController')->convenienceStore($store,'03');
                break;

            case 1:
                $digits=3;
                $store->transfer_code=rand(pow(10, $digits-1), pow(10, $digits)-1);
                $store->total=$store->total+$store->transfer_code;
                $store->save();
            
            default:
                # code...
                break;
        }

        $user->Cart()->delete();

        Mail::send('mail.checkout_final', ['user'=>$user, 'order'=>$store], function($message) use ($user,$store) {
                 $message->to($user->email, $user->firstname)
                     ->subject('Pesanan '.$store->invoice.' berhasil dibuat');
             });

        $payment_method->used++;
        $payment_method->save();
        $payment_method->touch();

        $inv=explode('/', $store->invoice);

        return redirect('confirmation/'.$inv[2])->with('success','Pesanan Berhasil dibuat!');
        
      }

      public function confirmation($invoice,Request $request)
      {
        $store=Order::whereInvoice('INV/'.Carbon::now()->year.'/'.$invoice)->first();
        $recommended_products = RecommendedProduct::whereHas('Product')->inRandomOrder()->take(6)->get();
        $blogs=Blog::orderBy('created_at', 'desc')->take(4)->get();
        $x=0;
        while($x<10){
            if(!count($store)){
                $store=Order::whereInvoice('INV/'.Carbon::now()->subYear()->year.'/'.$invoice)->first();
            }else{
                $x=10;
            }
            $x++;
        }
        if(!count($store)){
            return abort(404);
        }
        $nt=new \stdClass();
        if($store->bank_code!=null){
            $nt=$store->NicepayTransaction;
        }
        return view('front.confirmation', compact('store', 'nt', 'recommended_products', 'blogs'));
      }

      public function searchCity(Request $request)
      {
        $term = trim($request->q);


          $results = City::where('name', 'LIKE', '%'.$term.'%')
              ->orWhere('province', 'LIKE', '%'.$term.'%')
              ->limit(5)->get();

          $formatted_results = [];

        foreach ($results as $val) {
            $formatted_results[] = ['id' => $val->id, 'text' => $val->name.' - '.$val->province];
        }

        return response()->json($formatted_results);
      }

      public function searchSubdistrict(Request $request)
      {
        $term = trim($request->q);


          $results = Subdistrict::where(function($query) use ($term, $request){
                               $query->where('name', 'like', '%'.$term.'%')
                                    ->orWhere('province', 'like', '%'.$term.'%')
                                    ->orWhere('city', 'like', '%'.$term.'%');
                            })
                          ->where('city_id', '=', $request->input('city_id'))
                          ->limit(5)->get();

          $formatted_results = [];

        foreach ($results as $val) {
            $formatted_results[] = ['id' => $val->id, 'text' => $val->name.' - '.$val->type.' '.$val->city];
        }

        return response()->json($formatted_results);
      }

    public function nicepayCallback(NicepayLib $nicepaylib, Request $request)
    {
        $invoice=substr($request->input('referenceNo'), 4);
        $year = substr($request->input('referenceNo'), 0, 4);
        $order=Order::whereInvoice('INV/'.$year.'/'.$invoice)->first();
        $nt=new NicepayTransaction();
        $nt->order_id = $order->id;
        $nt->txid = $request->input('tXid');
        $nt->callbackurl = '';
        $nt->description = $request->input('description');
        $nt->payment_date = $request->input('transDt'); // YYMMDD
        $nt->payment_time = $request->input('transTm'); // HH24MISS
        $nt->va_number = $request->input('cardNo');
        $nt->result_code = $request->input('resultCd');
        $nt->result_message = $request->input('resultMsg');
        $nt->reference = $request->input('referenceNo');
        $nt->payment_method = 'CC';
        $nt->save();
        if($order){
            $nt=app('App\Http\Controllers\Front\NicepayController')->checkStatus($nicepaylib, $invoice, $year);
            return redirect('order/'.$invoice);
        }
    }

      public function searchPostalCode(Request $request)
      {
        $term = trim($request->q);


          $results = City::where('postal_code', 'LIKE', '%'.$term.'%')
              ->limit(5)->get();

          $formatted_results = [];

        foreach ($results as $val) {
            $formatted_results[] = ['id' => $val->id, 'text' => $val->postal_code];
        }

        return response()->json($formatted_results);
      }

      public function showSubmitReview($invoice)
      {
        // $order=Order::whereInvoice($inv)->whereUser_id(Auth::user()->id)->firstOrFail();
        $order=Order::whereInvoice('INV/'.Carbon::now()->year.'/'.$invoice)->first();
        $x=0;
        while($x<10){
            if(!count($order)){
                $store=Order::whereInvoice('INV/'.Carbon::now()->subYear()->year.'/'.$invoice)->first();
            }else{
                $x=10;
            }
            $x++;
        }
        if(!$order){
            abort(404);
        }
        return view('front.submitReview', compact('order'));
      }

      public function postSubmitReview($id=null, Request $request)
      {
        $order_detail=OrderDetail::findOrFail($id);
        $order=$order_detail->Order;
        if($order->user_id == Auth::user()->id){
            $request->validate([
                'rating' => 'required|numeric|min:1|max:5',
                'message' => 'required'
            ]);

            $review=new ProductReview();
            $review->product_id=$order_detail->product_id;
            $review->user_id=Auth::user()->id;
            $review->text=$request->input('message');
            $review->rating=$request->input('rating');
            $review->status=1;
            $review->ip=$request->ip();
            $review->save();

            $product=Product::find($order_detail->product_id);
            $product->avg_rating=$product->ProductReview->pluck('rating')->avg();
            $product->save();

            $order_detail->reviewed=1;
            $order_detail->save();
            $order_detail->touch();

            $check=OrderDetail::whereOrder_id($order->id)->whereReviewed(0)->count();
            if($check){
                return back()->with('success','Your Review has been submitted.');
            }else{
                $inv=explode('/', $order->invoice);
                return redirect('order/'.$inv[2])->with('success','Your Review has been submitted.');
            }
        }else{
            abort(404);
        }
      }


      public function postSupportIssue(Request $request)
      {
        $user = User::findOrFail(Auth::user()->id);
        $request->validate([
            'category' => 'required',
            'subcategory' => 'required',
            'subject' => 'required',
            'message' => 'required'
        ], [
            'category.required' => 'Issue Harus Dipilih',
            'subcategory.required' => 'Issue Harus Dipilih',
            'subject.required' => 'Subjek Harus Diisi',
            'message.required' => 'Pesan Harus Diisi',
        ]);

        if($request->input('attachment') !== null) {
            if(count($request->input('attachment'))) {
                $request->validate([
                    'attachment.*' => 'image'
                ], [
                    'attachment.*.image' => 'Tautan Harus Berupa Gambar'
                ]);
            }
        }

        $issue=new Issue();
        $issue->user_id=Auth::user()->id;
        $issue->category=$request->input('category');
        $issue->subcategory=$request->input('subcategory');
        $issue->subject=$request->input('subject');
        $issue->message=$request->input('message');
        $issue->ip=$request->ip();
        $issue->save();

        if($request->hasFile('attachment'))
        {
            $files = $request->file('attachment');
         
            foreach($files as $file){

                $destinationPath = public_path('/img/issue_attachment');
                $extension = $file->getClientOriginalExtension(); // getting image extension
                $fileName = $file->getClientOriginalName().'_'. time().'.'.$file->getClientOriginalExtension(); // renameing image
                $file->move($destinationPath, $fileName);

                $path=url('/img/issue_attachment/'.$fileName);

                $attachment=new IssueAttachment();
                $attachment->issue_id=$issue->id;
                $attachment->path=$path;
                $attachment->save();
             
            }
         
        }

        return back()->with('success', 'Your Issue Have Been submitted.');
      }

      public function downloadAttachment($id=null)
      {
        $attachment=IssueAttachment::whereId($id)->first();
        $issue=$attachment->Issue;
        if($issue->user_id == Auth::user()->id){
            $pathToFile=str_replace(url('/')."/", "", $attachment->path);

            return response()->download($pathToFile);
        }else{
            abort(404);
        }
      }

      public function showSupportIssueDetail($id=null)
      {
        $issue=Issue::findOrFail($id);
        return view('front.issueDetail', compact('issue'));
      }

      public function generateInvoice($prefix='INV')
      {
        //get last record
        $record = Order::latest()->first();
        if(count($record)>0){
          $expNum = explode('/', $record->invoice);

          //check first day in a year
          if($expNum[1]!=date('Y')) {
              $nextInvoiceNumber = $prefix.'/'.date('Y').'/00000001';
          } else {
              $last=$expNum[2]+1;
              //increase 1 with last invoice number
              $nextInvoiceNumber = $prefix.'/'.$expNum[1].'/'. str_pad($last, 8, '0', STR_PAD_LEFT);;
          }
        }else{
          $nextInvoiceNumber = $prefix.'/'.date('Y').'/00000001';
        }

        return $nextInvoiceNumber;
      }
	  
	  //additional david
	  public function tentangKami()
    {
    	return view('front.tentangKami');
    }
	 public function akun()
    {
    	return view('front.akun');
    }
	 public function caraBelanja()
    {
    	return view('front.caraBelanja');
    }
	 public function formRetur()
    {
    	return view('front.formRetur');
    }
	 public function garansi()
    {
    	return view('front.garansi');
    }
	public function hubungiKami()
    {
    	return view('front.hubungiKami');
    }
	public function kenapaBeli()
    {
    	return view('front.kenapaBeli');
    }
	public function kuponDiskon()
    {
    	return view('front.kuponDiskon');
    }
	public function mitraKami()
    {
    	return view('front.mitraKami');
    }
	public function pembayaran()
    {
    	return view('front.pembayaran');
    }
	public function pengiriman()
    {
    	return view('front.pengiriman');
    }
	public function returFaq()
    {
    	return view('front.returFaq');
    }
	public function serviceCenter()
    {
    	return view('front.serviceCenter');
    }
	public function umum()
    {
    	return view('front.umum');
    }
	public function faq()
    {
    	return view('front.faq');
    }
	 //TAMBAHAN DARI ITCLAN
	  public function checkoutNew(Request $request)
    {
        $user=User::find(Auth::user()->id);
        $cart=$user->cart;
        $payment_method=PaymentMethod::whereStatus(1)->get();
        $addresses=$user->Address;
        if(!empty($request->input('address'))){
            $address=$user->Address()->whereId($request->input('address'))->firstOrFail();
        }else{
            $address=$user->Address()->whereMain(1)->first();
            if(count($address)==0){
                $address=$user->Address()->orderBy('created_at','asc')->first();
                if(count($address)==0){
                    return redirect()->route('address.add',['back_url' => route('checkout')]);
                }
            }
        }
        $cart=Cart::whereUser_id(Auth::user()->id)->get();
        $weight=0;
        $gram=WeightClass::find(2);
        if(count($cart)==0){
            return redirect('cart')->with('warning','Keranjang belanja anda kosong, ayo belanja sekarang!');
        }
        foreach($cart as $key => $value){
            $product=$value->Product;
            switch ($product->weight_class_id) {
              case '2':
                $temp=$product->weight*$value->qty;
                $weight=$weight+$temp;
                break;
              
              default:
                $temp=($product->weight*$gram->value)*$value->qty;
                $weight=$weight+$temp;
                break;
            }
        }
        $shipping_method=$this->getShippingCost($address->id,$weight);
        $bank=Bank::whereStatus(1)->get();
        // $recommended_products = RecommendedProduct::whereHas('Product')->inRandomOrder()->take(6)->get();
        // $blogs=Blog::orderBy('created_at', 'desc')->take(4)->get();
        return view('front.checkoutNew', compact('user','cart','address','shipping_method','payment_method', 'bank', 'addresses'));
    }

    public function confirmationNew($invoice,Request $request)
      {
        $store=Order::whereInvoice('INV/'.Carbon::now()->year.'/'.$invoice)->first();
        $recommended_products = RecommendedProduct::whereHas('Product')->inRandomOrder()->take(6)->get();
        $blogs=Blog::orderBy('created_at', 'desc')->take(4)->get();
        $x=0;
        while($x<10){
            if(!count($store)){
                $store=Order::whereInvoice('INV/'.Carbon::now()->subYear()->year.'/'.$invoice)->first();
            }else{
                $x=10;
            }
            $x++;
        }
        if(!count($store)){
            return abort(404);
        }
        $nt=new \stdClass();
        if($store->bank_code!=null){
            $nt=$store->NicepayTransaction;
        }
        return view('front.confirmationNew', compact('store', 'nt', 'recommended_products', 'blogs'));
    }

    public function returns(Request $request)
    {
        $order_has_return=Order::whereUser_id(Auth::user()->id)->whereHas('OrderReturn')->pluck('id')->toArray();
        $return=OrderReturn::whereIn('order_id', $order_has_return)->orderBy('created_at', 'desc')->get();
        return view('front.returns', compact('return'));
    }

    public function recent()
    {
        return view('front.recent');
    }

    public function review()
    {
        return view('front.review');
    }

    public function address_book(){
        $user=User::find(Auth::user()->id);
        $address=$user->Address;
        return view('front.address_book', compact('user','address'));
    }

    public function advanced_search()
    {
        $categories=Category::whereNull('parent_id')->get();
        return view('front.advanced_search', compact('categories'));
    }

    public function contact_us(){
        return view('front.contact_us');
    }

    public function new_issue_contact_us(){
        return view('front.new_issue_contact_us');
    }

    public function dashboard_orders(){
        return view('front.dashboard_orders');
    }

    public function support_email_preference()
    {
        $user=User::findOrFail(Auth::user()->id);
        $pref=$user->EmailPreference;
        return view('front.support_email_preference', compact('user', 'pref'));
    }

    public function postSupportEmailPreference(Request $request)
    {
        if($request->input('subscribe') == 1){
            $request->validate([
                'mail_frequency' => 'required|numeric',
                'mail_type' => 'min:1'
            ]);
            $flag=1;
            $pref=EmailPreference::whereUser_id(Auth::user()->id)->first();
            if(!$pref){
                $pref=new EmailPreference();
                $flag=0;
            }
            $pref->user_id=Auth::user()->id;
            $pref->subscribe=1;
            $pref->mail_frequency=$request->input('mail_frequency');
            if(in_array('special_events', $request->input('mail_type'))){
                $pref->special_events=1;
            }else{
                $pref->special_events=0;
            }
            if(in_array('product_updates', $request->input('mail_type'))){
                $pref->product_updates=1;
            }
            else{
                $pref->product_updates=0;
            }
            if(in_array('monthly_newsletter', $request->input('mail_type'))){
                $pref->monthly_newsletter=1;
            }
            else{
                $pref->monthly_newsletter=0;
            }
            if(in_array('manual_email_blast', $request->input('mail_type'))){
                $pref->manual_email_blast=1;
            }
            else{
                $pref->manual_email_blast=0;
            }
            $pref->save();
            if(!$flag){
                $pref->touch();
            }

        }else{
            $flag=1;
            $pref=EmailPreference::whereUser_id(Auth::user()->id)->first();
            if(!$pref){
                $pref=new EmailPreference();
                $flag=0;
            }
            $pref->user_id=Auth::user()->id;
            $pref->subscribe=0;
            $pref->save();
            if(!$flag){
                $pref->touch();
            }
        }

        return back()->with('success', 'Your email preference has been saved.');

    }

    public function support_issue()
    {
        $issues=Issue::whereUser_id(Auth::user()->id)->orderBy('created_at', 'desc')->get();
        return view('front.support_issue', compact('issues'));
    }

    public function support_issue_detail(){
        return view('front.support_issue_detail');
    }

    public function order_detail_order_finished(){
        return view('front.order_detail_order_finished');
    }

    public function order_detail_order_made(){
        return view('front.order_detail_order_made');
    }

    public function order_detail_order_paid(){
        return view('front.order_detail_order_paid');
    }

    public function order_detail_order_receive(){
        return view('front.order_detail_order_receive');
    }

    public function order_detail_order_sent(){
        return view('front.order_detail_order_sent');
    }

    public function rating(){
        return view('front.rating');
    }

    public function return_form(){
        return view('front.return_form');
    }

    public function return_item(){
        return view('front.return_item');
    }

    public function testCheckoutMail($invoice=null)
    {
        $order=Order::whereInvoice('INV/'.Carbon::now()->year.'/'.$invoice)->first();
        $user=$order->User;
        $x=0;
        while($x<10){
            if(!count($order)){
                $order=Order::whereInvoice('INV/'.Carbon::now()->subYear()->year.'/'.$invoice)->first();
            }else{
                $x=10;
            }
            $x++;
        }
        if(!count($order)){
            return abort(404);
        }
        $nt=new \stdClass();
        if($order->bank_code!=null){
            $nt=$order->NicepayTransaction;
        }
        // Mail::send('mail.checkout', ['user'=>$user, 'order'=>$order], function($message) use ($user,$order) {
        //          $message->to($user->email, $user->firstname)
        //              ->subject('Pesanan '.$store->invoice.' berhasil dibuat');
        //      });
        return view('mail.checkout_final', compact('user', 'order'));

    }
	
	public function handleWishlist($id)
    {
        $user=User::find(Auth::user()->id);
        $find=$user->Wishlist()->where('product_id', '=', $id)->count();
        if($find) {
            $del=$user->Wishlist()->where('product_id', '=', $id)->delete();
            return '<i class="fa fa-heart-o" aria-hidden="true"></i>';
        } else {
            $create=new Wishlist();
            $create->user_id=Auth::user()->id;
            $create->product_id=$id;
            $create->save();
            return '<i class="fa fa-heart" aria-hidden="true" style="color: #b62127;"></i>';
        }
    }

    public function wishlist()
    {
        $user=User::find(Auth::user()->id);
        $wishlist=$user->WIshlist;
        return view('front.wishlist', compact('user','wishlist'));
    }
	
	public function orderMydashboard()
    {
        $orderhistory=Order::whereUser_id(Auth::user()->id)->orderBy('created_at', 'desc')->paginate(5);
        return view('front.orderMydashboard', compact('orderhistory'));
    }
	public function orderMyreturn()
    {
        $order_has_return=Order::whereUser_id(Auth::user()->id)->whereHas('OrderReturn')->pluck('id')->toArray();
        $return=OrderReturn::whereIn('order_id', $order_has_return)->orderBy('created_at', 'desc')->get();
        return view('front.orderMyreturn', compact('return'));
    }
}
