<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Models\CustomerGroup;
use App\Models\ShippingMethod;
use App\Models\ShippingCourier;
use App\Http\Controllers\Controller;
use Carbon\Carbon;

class ShippingMethodController extends Controller
{
    public function showIndex()
  {
      return view('admin.shipping_method.index', compact('results'));
  }

  /**
   * Display a listing of the resource.
   *
   * @return Response
   */
  public function index(Request $request)
  {
      $columns = array( 
                            0 =>'id', 
                            1 =>'customer_group_id',
                            2 =>'name',
                            3 =>'status',
                            4 =>'action'
                        );
  
        $totalData = ShippingMethod::count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        if(array_key_exists($request->input('order.0.column'), $columns)){
          $order = $columns[$request->input('order.0.column')];
        }else{
          $order = 'id';
        }
        if($request->input('order.0.dir')!==null){
          $dir = $request->input('order.0.dir');
        }else{
          $dir = 'asc';
        }
        
            
        if(empty($request->input('search.value')))
        {            
            $results = ShippingMethod::orderBy($order,$dir)->offset($start)->limit($limit)
                         ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $results =  ShippingMethod::where('name','LIKE',"%{$search}%")
                            ->orWhereHas('CustomerGroup', function ($query) use ($search) {
                                $query->where('name','LIKE',"%{$search}%");
                            })
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();

            $totalFiltered = ShippingMethod::where('name','LIKE',"%{$search}%")
                            ->orWhereHas('CustomerGroup', function ($query) use ($search) {
                                $query->where('name','LIKE',"%{$search}%");
                            })
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();
        }

        $data = array();
        if(!empty($results))
        {
            foreach ($results as $value)
            {
                $edit =  url('admin/shipping-method/edit',$value->id);

                $nestedData['id'] = "<input type='checkbox' name='selected[]'' value='{$value->id}'>";
                $nestedData['customer_group_id'] = $value->CustomerGroup->name;
                $nestedData['name'] =$value->name;
                if($value->status==1){
                  $nestedData['status'] = "<span class='label label-success' data-id='{$value->id}' data-type='status'>enabled</span>";
                }else{
                  $nestedData['status'] = "<span class='label label-danger' data-id='{$value->id}' data-type='status'>disabled</span>";
                }
                $nestedData['action'] = "&emsp;<a href='{$edit}' title='EDIT' ><span class='glyphicon glyphicon-edit'></span></a>";
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return Response
   */
  public function create()
  {
  	  $customergroup=CustomerGroup::get();
      return view('admin.shipping_method.create', compact('customergroup'));
  }

  /**
   * Store a newly created resource in storage.
   *
   * @return Response
   */
  public function store(Request $request)
  {
      $request->validate([
          'customer_group_id' => 'required|exists:customer_group,id',
          'name' => 'required',
          'status' => 'required',
      ]);

	  	$store=new ShippingMethod();
	  	
	  	$store->customer_group_id=$request['customer_group_id'];
	  	$store->name=$request['name'];
	  	$store->status=$request['status'];
	  	$store->save();
      
      
      return redirect('admin/shipping-method')->with('success',$store->name.' method successfully created.');
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function show($id)
  {
      
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function edit($id)
  {
  	  $customergroup=CustomerGroup::get();
      $results = ShippingMethod::findOrFail($id);
      return view('admin.shipping_method.edit', compact('results', 'customergroup'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function update($id, Request $request)
  {
      $request->validate([
          'customer_group_id' => 'required|exists:customer_group,id',
          'name' => 'required',
          'status' => 'required',
      ]);

	  	$store=ShippingMethod::findOrFail($id);
	  	
	  	$store->customer_group_id=$request['customer_group_id'];
	  	$store->name=$request['name'];
      if($store->id==3 && $request->input('price') != 0){
        $store->price=$request->input('price');
      }
	  	$store->status=$request['status'];
	  	$store->save();
	  	$store->touch();
      return redirect('admin/shipping-method')->with('success', $store->name.' method successfully updated.');
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function destroy($id)
  {
    
  }

  public function trash(Request $request)
  {
      $request->validate([
          'selected' => 'array'
      ]);
      $count=count($request['selected']);
      if($count>0)
      {
        $delete=ShippingMethod::whereIn('id',$request['selected'])->delete();
        return back()->with('success', $count.' item has been deleted.');
      }
  }

  public function QuickUpdate($id, Request $request)
  {
      

          $request->validate([
              'value' => 'required|numeric'
          ]);
          $store=ShippingMethod::findOrFail($id);
          if($request['value']==1){
            $store->status=$request['value'];
          }else{
            $store->status=0;
          }
      
      $store->save();
      $store->touch();


        $txt=$store->status==0 ? "disabled" : "enabled";
        if($store->status==0){
	        $store->html_status="<span class='label label-danger' data-id='{$store->id}' data-type='status'>{$txt}</span>";
	    }else{
	    	$store->html_status="<span class='label label-success' data-id='{$store->id}' data-type='status'>{$txt}</span>";
	    }
      
      return response()->json($store);
  }

  public function QuickStatusUpdate($id, Request $request)
  {
      

          $request->validate([
              'value' => 'required|numeric'
          ]);
          $store=ShippingCourier::findOrFail($id);
          if($request['value']==1){
            $store->status=$request['value'];
          }else{
            $store->status=0;
          }
      
      $store->save();
      $store->touch();


        $txt=$store->status==0 ? "disabled" : "enabled";
        if($store->status==0){
	        $store->html_status="<span class='label label-danger' data-id='{$store->id}' data-type='status'>{$txt}</span>";
	    }else{
	    	$store->html_status="<span class='label label-success' data-id='{$store->id}' data-type='status'>{$txt}</span>";
	    }
      
      return response()->json($store);
  }
}
