<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Kreasi2go;
use App\Models\Kreasi2goToProvince;
use App\Models\Kreasi2goToCategory;
use App\Models\Kreasi2goToProduct;
use App\Models\Province;
use App\Models\Category;

class Kreasi2goController extends Controller
{
    public function showIndex()
  {
      return view('admin.shipping_courier.index', compact('results'));
  }

  /**
   * Display a listing of the resource.
   *
   * @return Response
   */
  public function index(Request $request)
  {
      $columns = array( 
                            0 =>'id', 
                            1 =>'name',
                            2 =>'subtotal',
                            3 =>'status',
                            4 =>'action'
                        );
  
        $totalData = Kreasi2go::count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        if(array_key_exists($request->input('order.0.column'), $columns)){
          $order = $columns[$request->input('order.0.column')];
        }else{
          $order = 'id';
        }
        if($request->input('order.0.dir')!==null){
          $dir = $request->input('order.0.dir');
        }else{
          $dir = 'asc';
        }
        
            
        if(empty($request->input('search.value')))
        {            
            $results = Kreasi2go::orderBy($order,$dir)->offset($start)			->limit($limit)
                         ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $results =  Kreasi2go::where('name','LIKE',"%{$search}%")
            				->orWhere('subtotal', 'LIKE', "%{$search}%")
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();

            $totalFiltered = Kreasi2go::where('name','LIKE',"%{$search}%")
            				->orWhere('subtotal', 'LIKE', "%{$search}%")
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();
        }

        $data = array();
        if(!empty($results))
        {
            foreach ($results as $value)
            {
                $edit =  url('admin/kreasi2go/edit',$value->id);

                $nestedData['id'] = "<input type='checkbox' name='selected[]'' value='{$value->id}'>";
                $nestedData['name'] =$value->name;
                $nestedData['subtotal'] = currency_format($value->subtotal, 'IDR');
                if($value->status==1){
                  $nestedData['status'] = "<span class='label label-success' data-id='{$value->id}' data-type='status'>enabled</span>";
                }else{
                  $nestedData['status'] = "<span class='label label-danger' data-id='{$value->id}' data-type='status'>disabled</span>";
                }
                $nestedData['action'] = "&emsp;<a href='{$edit}' title='EDIT' ><span class='glyphicon glyphicon-edit'></span></a>";
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return Response
   */
  public function create()
  {
  	  $province=Province::get();
  	  $category=Category::get();
      return view('admin.kreasi2go.create', compact('province', 'category'));
  }

  /**
   * Store a newly created resource in storage.
   *
   * @return Response
   */
  public function store(Request $request)
  {
      $request->validate([
          'name' => 'required',
          'status' => 'required',
          'province' => 'array',
          'category' => 'array',
          'product' => 'array',
          'subtotal' => 'numeric',
      ],[
      	'subtotal.numeric' => "Minimum Order Value must be numeric"
      ]);

	  	$store=new Kreasi2go();
	  	
	  	$store->shipping_method_id=2;
	  	$store->name=$request['name'];
	  	$store->subtotal=$request['subtotal'];
	  	$store->status=$request['status'];
	  	$store->save();

	  	if(count($request['province'])>0){
	  		foreach($request['province'] as $key => $value){
	  			$pro=new Kreasi2goToProvince();
	  			$pro->kreasi2go_id=$store->id;
	  			$pro->province_id=$value;
	  			$pro->save();
	  		}
	  	}

	  	if(count($request['category'])>0){
	  		foreach($request['category'] as $key => $value){
	  			$cat=new Kreasi2goToCategory();
	  			$cat->kreasi2go_id=$store->id;
	  			$cat->category_id=$value;
	  			$cat->save();
	  		}
	  	}

	  	if(count($request['product'])>0){
	  		foreach($request['product'] as $key => $value){
	  			$cat=new Kreasi2goToProduct();
	  			$cat->kreasi2go_id=$store->id;
	  			$cat->product_id=$value;
	  			$cat->save();
	  		}
	  	}
      
      
      return redirect('admin/shipping-method/edit/3')->with('success',$store->name.' rule successfully created.');
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function show($id)
  {
      
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function edit($id)
  {
  	  $province=Province::get();
  	  $category=Category::get();
      $results = Kreasi2go::findOrFail($id);
      return view('admin.kreasi2go.edit', compact('results', 'province', 'category'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function update($id, Request $request)
  {
      $request->validate([
          'name' => 'required',
          'status' => 'required',
          'province' => 'array',
          'category' => 'array',
          'product' => 'array',
          'subtotal' => 'numeric',
      ],[
      	'subtotal.numeric' => "Minimum Order Value must be numeric"
      ]);

	  	$store=Kreasi2go::findOrFail($id);
	  	$store->name=$request['name'];
	  	$store->subtotal=$request['subtotal'];
	  	$store->status=$request['status'];
	  	$store->save();

	  	$store->Kreasi2goToProvince()->delete();
	  	if(count($request['province'])>0){
	  		foreach($request['province'] as $key => $value){
	  			$pro=new Kreasi2goToProvince();
	  			$pro->kreasi2go_id=$store->id;
	  			$pro->province_id=$value;
	  			$pro->save();
	  		}
	  	}

	  	$store->Kreasi2goToCategory()->delete();
	  	if(count($request['category'])>0){
	  		foreach($request['category'] as $key => $value){
	  			$cat=new Kreasi2goToCategory();
	  			$cat->kreasi2go_id=$store->id;
	  			$cat->category_id=$value;
	  			$cat->save();
	  		}
	  	}

	  	$store->Kreasi2goToProduct()->delete();
	  	if(count($request['product'])>0){
	  		foreach($request['product'] as $key => $value){
	  			$cat=new Kreasi2goToProduct();
	  			$cat->kreasi2go_id=$store->id;
	  			$cat->product_id=$value;
	  			$cat->save();
	  		}
	  	}
	  	$store->touch();
      return redirect('admin/shipping-method/edit/3')->with('success', $store->name.' rule successfully updated.');
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function destroy($id)
  {
    
  }

  public function trash(Request $request)
  {
      $request->validate([
          'selected' => 'array'
      ]);
      $count=count($request['selected']);
      if($count>0)
      {
        $delete=Kreasi2go::whereIn('id',$request['selected'])->delete();
        return back()->with('success', $count.' rule has been deleted.');
      }
  }

  public function QuickStatusUpdate($id, Request $request)
  {
      

          $request->validate([
              'value' => 'required|numeric'
          ]);
          $store=Kreasi2go::findOrFail($id);
          if($request['value']==1){
            $store->status=$request['value'];
          }else{
            $store->status=0;
          }
      
      $store->save();
      $store->touch();


        $txt=$store->status==0 ? "disabled" : "enabled";
        if($store->status==0){
	        $store->html_status="<span class='label label-danger' data-id='{$store->id}' data-type='status'>{$txt}</span>";
	    }else{
	    	$store->html_status="<span class='label label-success' data-id='{$store->id}' data-type='status'>{$txt}</span>";
	    }
      
      return response()->json($store);
  }
}
