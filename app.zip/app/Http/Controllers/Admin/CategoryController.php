<?php 

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Category;
use Carbon\Carbon;

class CategoryController extends Controller 
{
  public function showIndex()
  {
      $results = Category::orderBy('name')->paginate(20);
      return view('admin.category.index', compact('results'));
  }

  /**
   * Display a listing of the resource.
   *
   * @return Response
   */
  public function index(Request $request)
  {
      // $results = Category::orderBy('name')->paginate(20);
      // return view('admin.category.index', compact('results'));
      $columns = array( 
                            0 =>'id', 
                            1 =>'image',
                            2 =>'name',
                            3=> 'id',
                        );
  
        $totalData = Category::count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        if(array_key_exists($request->input('order.0.column'), $columns)){
          $order = $columns[$request->input('order.0.column')];
        }else{
          $order = 'id';
        }
        if($request->input('order.0.dir')!==null){
          $dir = $request->input('order.0.dir');
        }else{
          $dir = 'asc';
        }
        
            
        if(empty($request->input('search.value')))
        {            
            // $results = Category::offset($start)
            //              ->limit($limit)
            //              ->orderBy($order,$dir)
            //              ->get();
            $results = Category::orderBy($order,$dir)->offset($start)->limit($limit)
                         ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $results =  Category::where('name','LIKE',"%{$search}%")
                            ->orWhere('slug', 'LIKE',"%{$search}%")
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();

            $totalFiltered = Category::where('name','LIKE',"%{$search}%")
                             ->orWhere('slug', 'LIKE',"%{$search}%")
                             ->count();
        }

        $data = array();
        if(!empty($results))
        {
            foreach ($results as $value)
            {
                $edit =  url('admin/category/edit',$value->id);
                $img=$value->image!=null ? $value->image : 'http://via.placeholder.com/600x600';

                $nestedData['id'] = "<input type='checkbox' name='selected[]'' value='{$value->id}'>";
                $nestedData['image'] = "<img src='{$img}' style='width:150px;height:auto;'>";
                $nestedData['name'] = $value->fullname();
                $nestedData['action'] = "&emsp;<a href='{$edit}' title='EDIT' ><span class='glyphicon glyphicon-edit'></span></a>";
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return Response
   */
  public function create()
  {
      $category = Category::orderBy('name')->get();
      return view('admin.category.create', compact('category'));
  }

  /**
   * Store a newly created resource in storage.
   *
   * @return Response
   */
  public function store(Request $request)
  {
      if(isset($request['parent']) && $request['parent']==null){
        $request['parent']="";
      }
      $request->validate([
          'name' => 'required|max:191',
          'desc' => 'required',
          'parent' => 'sometimes|exists:category,id',
      ]);
      $store=new Category();
      $store->name=$request['name'];
      //check if slug exist
      $tryslug=Category::whereSlug(str_slug($request['name'], "-"))->first();
      if(count($tryslug)>0){
        $store->slug=Carbon::now()->format('his')."_".str_slug($request['name'], "-");
      }else{
        $store->slug=str_slug($request['name'], "-");
      }

      $store->desc=$request['desc'];
      if($request['parent']==""){
        $store->parent_id=null;
      }else{
        $store->parent_id=$request['parent'];
      }

      //check image
      if ($request->hasFile('image')) {
          $image = $request->file('image');

          $destinationPath = public_path('/img/category');
          $extension = $image->getClientOriginalExtension(); // getting image extension
          $fileName = time().'.'.$image->getClientOriginalExtension(); // renameing image
          $image->move($destinationPath, $fileName);

          $path=url('/img/category/'.$fileName);


          $store->image=$path;
      }
      
      $store->meta_title=$request['meta_title'];
      $store->meta_description=$request['meta_description'];
      $store->meta_keyword=$request['meta_keyword'];
      $store->save();
      return redirect('admin/category')->with('success',$request['name'].' successfully added.');
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function show($id)
  {
      
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function edit($id)
  {
      $results = Category::findOrFail($id);
      $category = Category::where('id','!=',$id)->orderBy('name')->get();
      return view('admin.category.edit', compact('results','category'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function update($id, Request $request)
  {
      if(isset($request['parent']) && $request['parent']==null){
        $request['parent']="";
      }
      $request->validate([
          'name' => 'required|max:191',
          'desc' => 'required',
          'parent' => 'sometimes|exists:category,id',
      ]);
      $store=Category::findOrFail($id);
      $store->name=$request['name'];
      //check if slug exist
      $tryslug=Category::where('id','!=',$id)->whereSlug(str_slug($request['name'], "-"))->first();
      if(count($tryslug)>0){
        $store->slug=Carbon::now()->format('his')."_".str_slug($request['name'], "-");
      }else{
        $store->slug=str_slug($request['name'], "-");
      }

      $store->desc=$request['desc'];
      if($request['parent']==""){
        $store->parent_id=null;
      }else{
        $store->parent_id=$request['parent'];
      }

      //check image
      if ($request->hasFile('image')) {
          $image = $request->file('image');

          $destinationPath = public_path('/img/category');
          $extension = $image->getClientOriginalExtension(); // getting image extension
          $fileName = time().'.'.$image->getClientOriginalExtension(); // renameing image
          $image->move($destinationPath, $fileName);

          $path=url('/img/category/'.$fileName);


          $store->image=$path;
      }
      
      $store->meta_title=$request['meta_title'];
      $store->meta_description=$request['meta_description'];
      $store->meta_keyword=$request['meta_keyword'];
      $store->save();
      $store->touch();
      return redirect('admin/category')->with('success',$request['name'].' successfully updated.');
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function destroy($id)
  {
    
  }

  public function trash(Request $request)
  {
      $request->validate([
          'selected' => 'array'
      ]);
      $count=count($request['selected']);
      if($count>0)
      {
        $delete=Category::whereIn('id',$request['selected'])->delete();
        return back()->with('success', $count.' item has been deleted.');
      }
  }

  public function deleteImage($id)
  {
      $deleteimage=Category::find($id);
      $deleteimage->image=null;
      $deleteimage->save();
      $deleteimage->touch();
      return back()->with('success', 'Image has been deleted.');
  }
  
}

?>