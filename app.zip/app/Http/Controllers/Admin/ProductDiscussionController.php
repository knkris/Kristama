<?php 

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\ProductDiscussion;
use App\Models\Product;
use App\Models\User;
use Carbon\Carbon;

class ProductDiscussionController extends Controller 
{

  public function showIndex()
  {
      return view('admin.discussion.index');
  }

  /**
   * Display a listing of the resource.
   *
   * @return Response
   */
  public function index(Request $request)
  {
      // $results = ProductDiscussion::orderBy('name')->paginate(20);
      // return view('admin.discussion.index', compact('results'));
      $columns = array( 
                            0 =>'id', 
                            1 =>'product_id',
                            2 =>'user_id',
                            3 =>'text',
                            4 =>'created_at'
                        );
  
        $totalData = ProductDiscussion::whereNull('parent_id')->count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        if(array_key_exists($request->input('order.0.column'), $columns)){
          $order = $columns[$request->input('order.0.column')];
        }else{
          $order = 'id';
        }
        if($request->input('order.0.dir')!==null){
          $dir = $request->input('order.0.dir');
        }else{
          $dir = 'asc';
        }
        
            
        if(empty($request->input('search.value')))
        {            
            // $results = ProductDiscussion::offset($start)
            //              ->limit($limit)
            //              ->orderBy($order,$dir)
            //              ->get();
            $results = ProductDiscussion::whereHas('Product')->whereNull('parent_id')->orderBy($order,$dir)->offset($start)->limit($limit)
                         ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $results =  ProductDiscussion::whereHas('Product')->whereNull('parent_id')->where('text','LIKE',"%{$search}%")
                            ->orWhereHas('Product', function ($query) use ($search) {
                                $query->where('name','LIKE',"%{$search}%");
                            })
                            ->orWhereHas('User', function ($query) use ($search) {
                                $query->where('name','LIKE',"%{$search}%");
                            })
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();

            $totalFiltered = ProductDiscussion::whereNull('parent_id')->where('text','LIKE',"%{$search}%")
                            ->orWhereHas('Product', function ($query) use ($search) {
                                $query->where('name','LIKE',"%{$search}%");
                            })
                            ->orWhereHas('User', function ($query) use ($search) {
                                $query->where('name','LIKE',"%{$search}%");
                            })
                             ->count();
        }

        $data = array();
        if(!empty($results))
        {
            foreach ($results as $value)
            {
                $edit =  url('admin/discussion/edit',$value->id);

                $nestedData['id'] = "<input type='checkbox' name='selected[]'' value='{$value->id}'>";
                $nestedData['product_id'] = $value->Product->name;
                $nestedData['user_id'] = $value->User->name;
                $nestedData['text'] = $value->text;
                $nestedData['created_at'] = Carbon::parse($value->created_at)->format('d/m/Y H:i:s');
                $nestedData['action'] = "&emsp;<i class='fa fa-reply conversation' data-id='{$value->id}' data-product='{$value->product->name}' aria-hidden='true' style='cursor: pointer'></i>";
                $nestedData['action'] .= "&emsp;<a href='{$edit}' title='EDIT' ><span class='glyphicon glyphicon-edit'></span></a>";
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return Response
   */
  public function create()
  {
      return view('admin.discussion.create');
  }

  /**
   * Store a newly created resource in storage.
   *
   * @return Response
   */
  public function store(Request $request)
  {
      $request->validate([
          'customer' => 'required|exists:users,id',
          'product_id' => 'required|exists:product,id',
          'text' => 'required',
          'created_at' =>'required|date',
      ]);
      $store=new Productdiscussion();
      $store->user_id=$request['customer'];
      $store->product_id=$request['product_id'];
      $store->text=$request['text'];
      $store->save();
      $store->created_at=Carbon::createFromFormat('d-m-Y H:i:s', $request['created_at']);
      $store->save();

      
      return redirect('admin/discussion')->with('success','Discussion successfully added.');
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function show($id)
  {
      
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function edit($id)
  {
      $results = ProductDiscussion::findOrFail($id);
      return view('admin.discussion.edit', compact('results'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function update($id, Request $request)
  {
      $request->validate([
          'customer' => 'required|exists:users,id',
          'product_id' => 'required|exists:product,id',
          'text' => 'required',
          'created_at' =>'required|date',
      ]);
      $store=ProductDiscussion::findOrFail($id);
      $store->user_id=$request['customer'];
      $store->product_id=$request['product_id'];
      $store->text=$request['text'];
      $store->created_at=Carbon::createFromFormat('d-m-Y H:i:s', $request['created_at']);
      $store->save();
      $store->touch();
      return redirect('admin/discussion')->with('success','Discussion successfully updated.');
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function destroy($id)
  {
    
  }

  public function trash(Request $request)
  {
      $request->validate([
          'selected' => 'array'
      ]);
      $count=count($request['selected']);
      if($count>0)
      {
        $delete=ProductDiscussion::whereIn('id',$request['selected'])->delete();
        return back()->with('success', $count.' item has been deleted.');
      }
  }

  public function conversation($id=null)
  {
    $discussion=ProductDiscussion::findOrFail($id);
    $conversation=$discussion->getConversation();
    $html='<section class="post-heading">';
    $html.='  <div class="row">';
    $html.='    <div class="col-md-11">';
    $html.='      <div class="media">';
    $html.='        <div class="media-body">';
    $html.='          <a href="#" class="anchor-username">';
    $html.='            <h4 class="media-heading">'.$discussion->User->name.'</h4></a>'; 
    $html.='             <a href="#" class="anchor-time">'.Carbon::parse($discussion->created_at)->diffForHumans().'</a>';
    $html.='             </div>';
    $html.='           </div>';
    $html.='         </div>';
    $html.='       </div>';            
    $html.='</section>';
    $html.='<section class="post-body">';
    $html.='  <p>'.$discussion->text.'</p>';
    $html.='</section>';
    $html.='<section class="post-footer"><hr>';
    $html.='  <div class="post-footer-comment-wrapper">';
    $html.='    <div class="comment-form"></div>';
    foreach($conversation as $con){
      $html.='      <div class="comment">';
      $html.='        <div class="media">';
      $html.='          <div class="media-body">';

      $name=$con->user_id>0 ? $con->User->name : env('APP_NAME','Laravel');

      $html.='            <a href="#" class="anchor-username"><h4 class="media-heading">'.$name.'</h4></a>';
      $html.='            <p>'.$con->text.'</p>';
      $html.='            <a href="#" class="anchor-time">'.Carbon::parse($con->created_at)->diffForHumans().'</a>';
      $html.='          </div>';
      $html.='        </div>';
      $html.='      </div>';
    }
    $html.='      <div class="comment">';
    $html.='        <div class="media">';
    $html.='          <div class="media-body">';
    $html.='            <h4 class="media-heading">Reply as '.env('APP_NAME','Laravel').'</h4>';
    $html.='            <textarea id="post-reply" name="reply" class="form-control"></textarea>';
    $html.='            <input type="hidden" id="disccussion-id" name="discussion_id" value="'.$discussion->id.'" />';
    $html.='          </div>';
    $html.='        </div>';
    $html.='      </div>';
    $html.='    </div>';
    $html.='</section>';

    return $html;
  }
  
  public function postReply(Request $request)
  {
    //return $request->all();
    $request->validate([
          'reply' => 'required',
    ]);
    $discussion=ProductDiscussion::find($request['discussion_id']);
    $reply=new ProductDiscussion();
    $reply->product_id=$discussion->product_id;
    $reply->user_id=null;
    $reply->text=$request['reply'];
    $reply->parent_id=$discussion->id;
    $reply->save();

    return redirect('admin/discussion')->with('success','Reply posted.');
  }

}

?>