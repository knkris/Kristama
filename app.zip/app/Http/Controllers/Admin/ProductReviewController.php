<?php 

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\ProductReview;
use App\Models\Product;
use App\Models\User;
use Carbon\Carbon;

class ProductReviewController extends Controller 
{

  public function showIndex()
  {
      return view('admin.review.index');
  }

  /**
   * Display a listing of the resource.
   *
   * @return Response
   */
  public function index(Request $request)
  {
      // $results = ProductReview::orderBy('name')->paginate(20);
      // return view('admin.review.index', compact('results'));
      $columns = array( 
                            0 =>'id', 
                            1 =>'product_id',
                            2 =>'user_id',
                            3 =>'rating',
                            4 =>'status',
                            5 =>'created_at'
                        );
  
        $totalData = ProductReview::count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        if(array_key_exists($request->input('order.0.column'), $columns)){
          $order = $columns[$request->input('order.0.column')];
        }else{
          $order = 'id';
        }
        if($request->input('order.0.dir')!==null){
          $dir = $request->input('order.0.dir');
        }else{
          $dir = 'asc';
        }
        
            
        if(empty($request->input('search.value')))
        {            
            // $results = ProductReview::offset($start)
            //              ->limit($limit)
            //              ->orderBy($order,$dir)
            //              ->get();
            $results = ProductReview::whereHas('Product')->orderBy($order,$dir)->offset($start)->limit($limit)
                         ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $results =  ProductReview::whereHas('Product')->where('text','LIKE',"%{$search}%")
                            ->orWhereHas('Product', function ($query) use ($search) {
                                $query->where('name','LIKE',"%{$search}%");
                            })
                            ->orWhereHas('User', function ($query) use ($search) {
                                $query->where('name','LIKE',"%{$search}%");
                            })
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();

            $totalFiltered = ProductReview::where('text','LIKE',"%{$search}%")
                            ->orWhereHas('Product', function ($query) use ($search) {
                                $query->where('name','LIKE',"%{$search}%");
                            })
                            ->orWhereHas('User', function ($query) use ($search) {
                                $query->where('name','LIKE',"%{$search}%");
                            })
                             ->count();
        }

        $data = array();
        if(!empty($results))
        {
            foreach ($results as $value)
            {
                $edit =  url('admin/review/edit',$value->id);

                $nestedData['id'] = "<input type='checkbox' name='selected[]'' value='{$value->id}'>";
                $nestedData['product_id'] = $value->Product->name;
                $nestedData['user_id'] = $value->User->name;
                $nestedData['rating'] = $value->rating;
                $nestedData['status'] = $value->status;
                $nestedData['created_at'] = Carbon::parse($value->created_at)->format('d/m/Y H:i:s');
                $nestedData['action'] = "&emsp;<a href='{$edit}' title='EDIT' ><span class='glyphicon glyphicon-edit'></span></a>";
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return Response
   */
  public function create()
  {
      return view('admin.review.create');
  }

  /**
   * Store a newly created resource in storage.
   *
   * @return Response
   */
  public function store(Request $request)
  {
      $request->validate([
          'customer' => 'required|exists:users,id',
          'product_id' => 'required|exists:product,id',
          'text' => 'required',
          'rating' => 'required',
          'created_at' =>'required|date',
          'status' => 'required'
      ]);
      $store=new ProductReview();
      $store->user_id=$request['customer'];
      $store->product_id=$request['product_id'];
      $store->text=$request['text'];
      $store->rating=$request['rating'];
      $store->status=$request['status'];
      $store->save();
      $store->created_at=Carbon::createFromFormat('d-m-Y H:i:s', $request['created_at']);
      $store->save();

      
      return redirect('admin/review')->with('success','Review successfully added.');
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function show($id)
  {
      
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function edit($id)
  {
      $results = ProductReview::findOrFail($id);
      return view('admin.review.edit', compact('results'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function update($id, Request $request)
  {
      $request->validate([
          'customer' => 'required|exists:users,id',
          'product_id' => 'required|exists:product,id',
          'text' => 'required',
          'rating' => 'required',
          'created_at' =>'required|date',
          'status' => 'required'
      ]);
      $store=ProductReview::findOrFail($id);
      $store->user_id=$request['customer'];
      $store->product_id=$request['product_id'];
      $store->text=$request['text'];
      $store->rating=$request['rating'];
      $store->status=$request['status'];
      $store->created_at=Carbon::createFromFormat('d-m-Y H:i:s', $request['created_at']);
      $store->save();
      $store->touch();
      return redirect('admin/review')->with('success','Review successfully updated.');
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function destroy($id)
  {
    
  }

  public function trash(Request $request)
  {
      $request->validate([
          'selected' => 'array'
      ]);
      $count=count($request['selected']);
      if($count>0)
      {
        $delete=ProductReview::whereIn('id',$request['selected'])->delete();
        return back()->with('success', $count.' item has been deleted.');
      }
  }
  
}

?>