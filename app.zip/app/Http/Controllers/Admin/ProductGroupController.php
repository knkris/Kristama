<?php 

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\CustomerGroup;
use App\Models\ProductGroup;
use App\Models\ProductGroupDetail;
use App\Models\Product;
use App\Models\ProductToCategory;
use App\Models\ProductGroupToCategory;
use App\Models\Category;
use App\Models\DiscountType;
use Carbon\Carbon;

class ProductGroupController extends Controller 
{

  public function showIndex()
  {
      return view('admin.product_group.index');
  }


  /**
   * Display a listing of the resource.
   *
   * @return Response
   */
  public function index(Request $request)
  {
      $columns = array( 
                            0 =>'id', 
                            1 =>'customer_group_id',
                            2 =>'name',
                            3 =>'status',
                            4 =>'action'
                        );
  
        $totalData = ProductGroup::count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        if(array_key_exists($request->input('order.0.column'), $columns)){
          $order = $columns[$request->input('order.0.column')];
        }else{
          $order = 'id';
        }
        if($request->input('order.0.dir')!==null){
          $dir = $request->input('order.0.dir');
        }else{
          $dir = 'asc';
        }
        
            
        if(empty($request->input('search.value')))
        {            
            $results = ProductGroup::orderBy($order,$dir)->offset($start)->limit($limit)
                         ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $results =  ProductGroup::where('name','LIKE',"%{$search}%")
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();

            $totalFiltered = ProductGroup::where('name','LIKE',"%{$search}%")
                             ->count();
        }

        $data = array();
        if(!empty($results))
        {
            foreach ($results as $value)
            {
                $edit =  url('admin/product-group/edit',$value->id);

                $nestedData['id'] = "<input type='checkbox' name='selected[]'' value='{$value->id}'>";
                $nestedData['customer_group_id'] = $value->CustomerGroup ? $value->CustomerGroup->name : "All";
                $nestedData['name'] = $value->name;
                if($value->status==1){
                  $nestedData['status'] = "<span class='label label-success' data-id='{$value->id}' data-type='status'>enabled</span>";
                }else{
                  $nestedData['status'] = "<span class='label label-danger' data-id='{$value->id}' data-type='status'>disabled</span>";
                }
                $nestedData['action'] = "&emsp;<a href='{$edit}' title='EDIT' ><span class='glyphicon glyphicon-edit'></span></a>";
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return Response
   */
  public function create()
  {
      $customer_group=CustomerGroup::get();
      $discount_type=DiscountType::get();
      $category=Category::get();
      return view('admin.product_group.create', compact('discount_type', 'category', 'customer_group'));
  }

  /**
   * Store a newly created resource in storage.
   *
   * @return Response
   */
  public function store(Request $request)
  {
      $request->validate([
          'name' => 'required|max:191',
          'description' => 'required',
          'timed_discount' => 'required',
          'group_discount' => 'required',
          'status' => 'required',
      ]);
      

      $store=new ProductGroup();
      $store->customer_group_id=$request['customer_group'];
      $store->name=$request['name'];
      $store->desc=$request['description'];
      $store->timed_discount=$request['timed_discount'];
      if($request['timed_discount']==1){
        $request->validate([
          'start' => 'required|date',
          'end' => 'required|date'
        ]);
        $store->start=Carbon::parse($request['start']);
        $store->end=Carbon::parse($request['end']);
      }
      $store->group_discount=$request['group_discount'];
      $store->bind_to=$request['bind_to'];
      $store->discount=$request['discount'];
      $store->discount_type_id=$request['discount_type'];
      if($request['discount_type']==1){
        $store->max_discount=$request['max_discount'];
      }
      if($request['group_discount']==1){
        $request->validate([
          'minimum' => 'required|min:1',
          'maximum' => 'required|min:1'
        ]);
        $store->minimum=$request['minimum'];
        $store->maximum=$request['maximum'];
      }
      $store->status=$request['status'];

      $store->save();

      if($request['bind_to']==1){
        if(count($request['category'])>0){
          foreach($request['category'] as $cat){
            $pgtc=new ProductGroupToCategory();
            $pgtc->product_group_id=$store->id;
            $pgtc->category_id=$cat;
            $pgtc->save();
          }
        }
      }

      $store->save();
      return redirect('admin/product-group')->with('success',$request['name'].' product group successfully added.');
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function show($id)
  {
      
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function edit($id)
  {
      $customer_group=CustomerGroup::get();
      $discount_type=DiscountType::get();
      $category=Category::get();
      $results = ProductGroup::findOrFail($id);
      return view('admin.product_group.edit', compact('results', 'customer_group', 'discount_type', 'category'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function update($id, Request $request)
  {
      $request->validate([
          'name' => 'required|max:191',
          'description' => 'required',
          'timed_discount' => 'required',
          'group_discount' => 'required',
          'status' => 'required',
      ]);
      

      $store=ProductGroup::findOrFail($id);
      $store->customer_group_id=$request['customer_group'];
      $store->name=$request['name'];
      $store->desc=$request['description'];
      $store->timed_discount=$request['timed_discount'];
      if($request['timed_discount']==1){
        $request->validate([
          'start' => 'required|date',
          'end' => 'required|date'
        ]);
        $store->start=Carbon::parse($request['start']);
        $store->end=Carbon::parse($request['end']);
      }
      if($store->group_discount!=$request['group_discount']){
        $store->ProductGroupDetail()->delete();
      }

      $store->group_discount=$request['group_discount'];
      $store->bind_to=$request['bind_to'];
      $store->discount=$request['discount'];
      $store->discount_type_id=$request['discount_type'];
      if($request['discount_type']==1){
        $store->max_discount=$request['max_discount'];
      }
      if($request['group_discount']==1){
        $request->validate([
          'minimum' => 'required|min:1',
          'maximum' => 'required|min:1'
        ]);
        $store->minimum=$request['minimum'];
        $store->maximum=$request['maximum'];
      }
      $store->status=$request['status'];

      $store->save();

      if($request['bind_to']==1){
        if(count($request['category'])>0){
          $store->ProductGroupToCategory()->delete();
          foreach($request['category'] as $cat){
            $pgtc=new ProductGroupToCategory();
            $pgtc->product_group_id=$store->id;
            $pgtc->category_id=$cat;
            $pgtc->save();
          }
        }
      }

      $store->touch();
      return redirect('admin/product-group')->with('success',$request['name'].' successfully updated.');
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function destroy($id)
  {
    
  }

  public function trash(Request $request)
  {
      $request->validate([
          'selected' => 'array'
      ]);
      $count=count($request['selected']);
      if($count>0)
      {
        $delete=ProductGroup::whereIn('id',$request['selected'])->delete();
        return back()->with('success', $count.' item has been deleted.');
      }
  }

  public function QuickStatusUpdate($id, Request $request)
  {
      

          $request->validate([
              'value' => 'required|numeric'
          ]);
          $store=ProductGroup::findOrFail($id);
          if($request['value']==1){
            $store->status=$request['value'];
          }else{
            $store->status=0;
          }
      
      $store->save();
      $store->touch();


        $txt=$store->status==0 ? "disabled" : "enabled";
        if($store->status==0){
          $store->html_status="<span class='label label-danger' data-id='{$store->id}' data-type='status'>{$txt}</span>";
      }else{
        $store->html_status="<span class='label label-success' data-id='{$store->id}' data-type='status'>{$txt}</span>";
      }
      
      return response()->json($store);
  }

  public function productIndex($id, Request $request)
  {
      $columns = array( 
                            0 =>'id', 
                            1 =>'image',
                            2 =>'name',
                            3 =>'discount',
                            4 =>'discount_type_id',
                            5 =>'maximum',
                            6 =>'final'
                        );
  
        $totalData = ProductGroupDetail::whereProduct_group_id($id)->count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        if(array_key_exists($request->input('order.0.column'), $columns)){
          $order = $columns[$request->input('order.0.column')];
        }else{
          $order = 'id';
        }
        if($request->input('order.0.dir')!==null){
          $dir = $request->input('order.0.dir');
        }else{
          $dir = 'asc';
        }
        
            
        if(empty($request->input('search.value')))
        {            
            $results = ProductGroupDetail::whereProduct_group_id($id)->orderBy($order,$dir)->offset($start)->limit($limit)
                         ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $results =  ProductGroupDetail::whereProduct_group_id($id)
                            ->whereHas('Product', function ($query) use ($search) {
                                $query->where('name','LIKE',"%{$search}%")
                                      ->orWhere('model','LIKE',"%{$search}%");
                            })
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();

            $totalFiltered = ProductGroupDetail::whereProduct_group_id($id)
                            ->whereHas('Product', function ($query) use ($search) {
                                $query->where('name','LIKE',"%{$search}%")
                                      ->orWhere('model','LIKE',"%{$search}%");
                            })
                             ->count();
        }

        $data = array();
        if(!empty($results))
        {
            foreach ($results as $value)
            {
                $delete=url('admin/product-group/delete-product',$value->id);
                $product=$value->Product;
                $product_group=$value->ProductGroup;
                $img = $product->Image->first() ? $product->Image->first()->image : '';

                $nestedData['id'] = "<input type='checkbox' name='selected[]'' value='{$value->id}'>";
                $nestedData['image'] = "<img src='{$img}' style='width:50px;height:auto;'>";
                $nestedData['name'] = $product->name;
                $nestedData['discount'] = round($product_group->discount);
                $nestedData['discount_type_id'] = $product_group->DiscountType->name;
                $nestedData['maximum'] = $product_group->minimum.'/'.$product_group->maximum;
                switch ($product_group->discount_type_id) {
                  case '1':
                    $initprice=$product->price;
                    $disc=($initprice*(round($product_group->discount)/100));
                    if($product_group->max_discount>1){
                      if($disc>$product_group->max_discount){
                        $disc=$product_group->max_discount;
                      }
                    }
                    $final=$product->price-$disc;
                    $nestedData['final'] = currency_format($final, 'IDR');
                    break;

                  case '2':
                    $initprice=$product->price;
                    $final=$product->price-round($product_group->discount);
                    $nestedData['final'] = currency_format($final, 'IDR');
                    break;

                  case '3':
                    $final=$product_group->discount;
                    $nestedData['final'] = currency_format($final, 'IDR');
                    break;
                  
                }
                $nestedData['action'] = "&emsp;<a data-href='{$delete}' title='Delete' class='delete-product' ><span class='glyphicon glyphicon-trash'></span></a>";
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
  }

  public function productIndex1($id, Request $request)
  {
      $columns = array( 
                            0 =>'id', 
                            1 =>'image',
                            2 =>'name',
                            3 =>'discount',
                            4 =>'discount_type_id',
                            5 =>'maximum',
                            6 =>'final'
                        );
  
        $totalData = ProductGroupDetail::whereProduct_group_id($id)->count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        if(array_key_exists($request->input('order.0.column'), $columns)){
          $order = $columns[$request->input('order.0.column')];
        }else{
          $order = 'id';
        }
        if($request->input('order.0.dir')!==null){
          $dir = $request->input('order.0.dir');
        }else{
          $dir = 'asc';
        }
        
            
        if(empty($request->input('search.value')))
        {            
            $results = ProductGroupDetail::whereProduct_group_id($id)->orderBy($order,$dir)->offset($start)->limit($limit)
                         ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $results =  ProductGroupDetail::whereProduct_group_id($id)
                            ->whereHas('Product', function ($query) use ($search) {
                                $query->where('name','LIKE',"%{$search}%")
                                      ->orWhere('model','LIKE',"%{$search}%");
                            })
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();

            $totalFiltered = ProductGroupDetail::whereProduct_group_id($id)
                            ->whereHas('Product', function ($query) use ($search) {
                                $query->where('name','LIKE',"%{$search}%")
                                      ->orWhere('model','LIKE',"%{$search}%");
                            })
                             ->count();
        }

        $data = array();
        if(!empty($results))
        {
            foreach ($results as $value)
            {
                $delete=url('admin/product-group/delete-product',$value->id);
                $product=$value->Product;
                $product_group=$value->ProductGroup;
                $img = $product->Image->first() ? $product->Image->first()->image : '';

                $nestedData['id'] = "<input type='checkbox' name='selected[]'' value='{$value->id}'>";
                $nestedData['image'] = "<img src='{$img}' style='width:50px;height:auto;'>";
                $nestedData['name'] = $product->name;
                $nestedData['discount'] = round($value->discount);
                $nestedData['discount_type_id'] = $value->DiscountType->name;
                $nestedData['maximum'] = $value->minimum.'/'.$value->maximum;
                switch ($value->discount_type_id) {
                  case '1':
                    $initprice=$product->price;
                    $disc=($initprice*(round($value->discount)/100));
                    if($value->max_discount>1){
                      if($disc>$value->max_discount){
                        $disc=$value->max_discount;
                      }
                    }
                    $final=$product->price-$disc;
                    $nestedData['final'] = currency_format($final, 'IDR');
                    break;

                  case '2':
                    $initprice=$product->price;
                    $final=$product->price-round($value->discount);
                    $nestedData['final'] = currency_format($final, 'IDR');
                    break;

                  case '3':
                    $final=$value->discount;
                    $nestedData['final'] = currency_format($final, 'IDR');
                    break;
                  
                }
                $nestedData['action'] = "&emsp;<a data-href='{$delete}' title='Delete' class='delete-product' ><span class='glyphicon glyphicon-trash'></span></a>";
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
  }

  public function searchProduct($id, Request $request)
  {
      $term = trim($request->q);

      $filter=ProductGroupDetail::whereProduct_group_id($id)->pluck('product_id')->toArray();

      $results = Product::whereNotIn('id',$filter)->where('name', 'LIKE', '%'.$term.'%')->limit(5)->get();

      $formatted_results = [];

      foreach ($results as $val) {
          $formatted_results[] = ['id' => $val->id, 'text' => $val->name." - ".currency_format($val->price,'IDR')];
      }

      return response()->json($formatted_results);
  }

  public function addProduct($id, Request $request)
  {
    $request->validate([
      'product_id' => 'required|exists:product,id'
    ]);

    $product_group=ProductGroup::find($id);
    if(count($product_group)>0){
      $pgd=new ProductGroupDetail();
      $pgd->product_group_id=$id;
      $pgd->product_id=$request['product_id'];
      $pgd->save();

      return response()->json($pgd);
    }
    return response()->json(['error'=>"Invalid Product Group!"], 404);
  }

  public function addProduct1($id, Request $request)
  {
    $request->validate([
      'product_id' => 'required|exists:product,id',
      'discount_type' => 'required|exists:discount_type,id',
      'discount' => 'numeric',
      'minimum' => 'numeric',
      'maximum' => 'numeric',
    ]);
    if($request['discount_type']==1){
      $request->validate([
        'discount' => 'numeric|max:100'
      ]);
    }

    $product_group=ProductGroup::find($id);
    if(count($product_group)>0){
      $pgd=new ProductGroupDetail();
      $pgd->product_group_id=$id;
      $pgd->product_id=$request['product_id'];
      $pgd->discount_type_id=$request['discount_type'];
      $pgd->discount=$request['discount'];
      $pgd->max_discount=$request['max_discount'];
      $pgd->minimum=$request['minimum'];
      $pgd->maximum=$request['maximum'];
      $pgd->save();

      return response()->json($pgd);
    }
    return response()->json(['error'=>"Invalid Product Group!"], 404);
  }

  public function deleteProduct($id)
  {
    $pgd=ProductGroupDetail::findOrFail($id);
    $pgd->delete();

    return back()->with('success','Delete Successful');
  }
  
}

?>