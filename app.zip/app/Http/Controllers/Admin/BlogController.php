<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Blog;
use App\Models\Product;
use App\Models\BlogToBlog;
use App\Models\BlogToProduct;
use Carbon\Carbon;
use Auth;

class BlogController extends Controller
{
    public function showIndex()
  {
      $results = Blog::orderBy('title')->paginate(20);
      return view('admin.blog.index', compact('results'));
  }

  /**
   * Display a listing of the resource.
   *
   * @return Response
   */
  public function index(Request $request)
  {
      $columns = array( 
                            0 =>'id', 
                            1 =>'image',
                            2=> 'title',
                        );
  
        $totalData = Blog::count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        if(array_key_exists($request->input('order.0.column'), $columns)){
          $order = $columns[$request->input('order.0.column')];
        }else{
          $order = 'id';
        }
        if($request->input('order.0.dir')!==null){
          $dir = $request->input('order.0.dir');
        }else{
          $dir = 'asc';
        }
        
            
        if(empty($request->input('search.value')))
        {            
            $results = Blog::orderBy($order,$dir)->offset($start)->limit($limit)
                         ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $results =  Blog::where('title','LIKE',"%{$search}%")
                            ->orWhere('slug', 'LIKE',"%{$search}%")
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();

            $totalFiltered = Blog::where('title','LIKE',"%{$search}%")
                             ->orWhere('slug', 'LIKE',"%{$search}%")
                             ->count();
        }

        $data = array();
        if(!empty($results))
        {
            foreach ($results as $value)
            {
                $edit =  url('admin/blog/edit',$value->id);

                $nestedData['id'] = "<input type='checkbox' name='selected[]'' value='{$value->id}'>";
                $nestedData['title'] = $value->title;
                $nestedData['image'] = "<img src='{$value->image}' style='width:150px;height:auto;'>";
                $nestedData['action'] = "&emsp;<a href='{$edit}' title='EDIT' ><span class='glyphicon glyphicon-edit'></span></a>";
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return Response
   */
  public function create()
  {
      return view('admin.blog.create');
  }

  /**
   * Store a newly created resource in storage.
   *
   * @return Response
   */
  public function store(Request $request)
  {
      $request->validate([
          'title' => 'required|max:191',
          'category' => 'required',
          'content' => 'required',
          'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
          'related_product' =>'array',
          'related_blog' =>'array',
      ]);
      $store=new Blog();
      $store->title=$request['title'];
      $store->category=$request['category'];
      //check if slug exist
      $tryslug=Blog::whereSlug(str_slug($request['title'], "-"))->first();
      if(count($tryslug)>0){
        $store->slug=Carbon::now()->format('his')."_".str_slug($request['title'], "-");
      }else{
        $store->slug=str_slug($request['title'], "-");
      }

      $store->content=$request['content'];
      
      //check image
      if ($request->hasFile('image')) {
          $image = $request->file('image');

          $destinationPath = public_path('/img/blog-asset');
          $extension = $image->getClientOriginalExtension(); // getting image extension
          $fileName = time().'.'.$image->getClientOriginalExtension(); // renameing image
          $image->move($destinationPath, $fileName);

          $path=url('/img/blog-asset/'.$fileName);


          $store->image=$path;
      }

      //check image
      if ($request->hasFile('cover')) {
          $image = $request->file('cover');

          $destinationPath = public_path('/img/blog-asset');
          $extension = $image->getClientOriginalExtension(); // getting image extension
          $fileName = time().'.'.$image->getClientOriginalExtension(); // renameing image
          $image->move($destinationPath, $fileName);

          $path=url('/img/blog-asset/'.$fileName);


          $store->cover=$path;
      }
      
      $store->meta_title=$request['meta_title'];
      $store->meta_description=$request['meta_description'];
      $store->meta_keyword=$request['meta_keyword'];
      $store->admin_id=Auth::user()->id;
      $store->save();

      if(count($request['related_product'])>0){
        foreach ($request['related_product'] as $key => $value) {
            $rel_prod=new BlogToProduct();
            $rel_prod->blog_id=$store->id;
            $rel_prod->product_id=$value;
            $rel_prod->save();
        }
      }
      if(count($request['related_blog'])>0){
        foreach ($request['related_blog'] as $key => $value) {
            $rel_prod=new BlogToBlog();
            $rel_prod->blog_id=$store->id;
            $rel_prod->to_blog_id=$value;
            $rel_prod->save();
        }
      }
      return redirect('admin/blog')->with('success',$request['title'].' successfully added.');
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function show($id)
  {
      
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function edit($id)
  {
      $results = Blog::findOrFail($id);
      return view('admin.blog.edit', compact('results'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function update($id, Request $request)
  {
      $request->validate([
          'title' => 'required|max:191',
          'category' => 'required',
          'content' => 'required',
          'image' => 'image|mimes:jpeg,png,jpg,gif,svg',
          'related_product' =>'array',
          'related_blog' =>'array',
      ]);
      $store=Blog::findOrFail($id);
      $store->title=$request['title'];
      $store->category=$request['category'];
      //check if slug exist
      $tryslug=Blog::where('id','!=',$id)->whereSlug(str_slug($request['name'], "-"))->first();
      if(count($tryslug)>0){
        $store->slug=Carbon::now()->format('his')."_".str_slug($request['title'], "-");
      }else{
        $store->slug=str_slug($request['title'], "-");
      }

      $store->content=$request['content'];
      
      //check image
      if ($request->hasFile('image')) {
          $image = $request->file('image');

          $destinationPath = public_path('/img/blog-asset');
          $extension = $image->getClientOriginalExtension(); // getting image extension
          $fileName = time().'.'.$image->getClientOriginalExtension(); // renameing image
          $image->move($destinationPath, $fileName);

          $path=url('/img/blog-asset/'.$fileName);


          $store->image=$path;
      }

      //check image
      if ($request->hasFile('cover')) {
          $image = $request->file('cover');

          $destinationPath = public_path('/img/blog-asset');
          $extension = $image->getClientOriginalExtension(); // getting image extension
          $fileName = time().'.'.$image->getClientOriginalExtension(); // renameing image
          $image->move($destinationPath, $fileName);

          $path=url('/img/blog-asset/'.$fileName);


          $store->cover=$path;
      }
      
      $store->meta_title=$request['meta_title'];
      $store->meta_description=$request['meta_description'];
      $store->meta_keyword=$request['meta_keyword'];
      $store->save();
      $store->touch();

      if(count($request['related_product'])>0){
        $store->BlogToProduct()->delete();
        foreach ($request['related_product'] as $key => $value) {
            $rel_prod=new BlogToProduct();
            $rel_prod->blog_id=$store->id;
            $rel_prod->product_id=$value;
            $rel_prod->save();
        }
      }
      if(count($request['related_blog'])>0){
        $store->BlogToBlog()->delete();
        foreach ($request['related_blog'] as $key => $value) {
            $rel_prod=new BlogToBlog();
            $rel_prod->blog_id=$store->id;
            $rel_prod->to_blog_id=$value;
            $rel_prod->save();
        }
      }
      return redirect('admin/blog')->with('success',$request['title'].' successfully updated.');
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function destroy($id)
  {
    
  }

  public function trash(Request $request)
  {
      $request->validate([
          'selected' => 'array'
      ]);
      $count=count($request['selected']);
      if($count>0)
      {
        $delete=Blog::whereIn('id',$request['selected'])->delete();
        return back()->with('success', $count.' item has been deleted.');
      }
  }

  public function deleteImage($id)
  {
      $deleteimage=Blog::find($id);
      $deleteimage->image=null;
      $deleteimage->save();
      $deleteimage->touch();
      return back()->with('success', 'Image has been deleted.');
  }

  public function deleteCover($id)
  {
      $deleteimage=Blog::find($id);
      $deleteimage->cover=null;
      $deleteimage->save();
      $deleteimage->touch();
      return back()->with('success', 'Cover has been deleted.');
  }

  public function searchBlogCategory(Request $request){
    $term = $request->input('term');
    
    $results = array();
    
    $queries = Blog::where('category', 'LIKE', '%'.$term.'%')
      ->take(5)->get();
    
    foreach ($queries as $query)
    {
        $results[] = [ 'id' => $query->id, 'value' => $query->category ];
    }
    return response()->json($results);
  }
}
