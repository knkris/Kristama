<?php 

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\CustomerGroup;
use App\Models\Address;
use App\Models\Subdistrict;
use Carbon\Carbon;
use Validator;

class UserController extends Controller 
{

  public function showIndex()
  {
      $results = User::orderBy('name')->paginate(20);
      return view('admin.customer.index', compact('results'));
  }

  /**
   * Display a listing of the resource.
   *
   * @return Response
   */
  public function index(Request $request)
  {
      // $results = Category::orderBy('name')->paginate(20);
      // return view('admin.category.index', compact('results'));
      $columns = array( 
                            0 =>'id', 
                            1 =>'name',
                            2 =>'email',
                            3 =>'customer_group_id',
                            4 =>'status',
                            5 =>'created_at',
                            6=> 'action',
                        );
  
        $totalData = User::count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        if(array_key_exists($request->input('order.0.column'), $columns)){
          $order = $columns[$request->input('order.0.column')];
        }else{
          $order = 'id';
        }
        if($request->input('order.0.dir')!==null){
          $dir = $request->input('order.0.dir');
        }else{
          $dir = 'asc';
        }
        
            
        if(empty($request->input('search.value')))
        {            
            // $results = Category::offset($start)
            //              ->limit($limit)
            //              ->orderBy($order,$dir)
            //              ->get();
            $results = User::orderBy($order,$dir)->offset($start)->limit($limit)
                         ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $results =  User::where('name','LIKE',"%{$search}%")
                            ->orWhere('email', 'LIKE',"%{$search}%")
                            ->orWhereHas('CustomerGroup', function ($query) use ($search) {
                                $query->where('name','LIKE',"%{$search}%");
                            })
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();

            $totalFiltered = User::where('name','LIKE',"%{$search}%")
                             ->orWhere('email', 'LIKE',"%{$search}%")
                             ->orWhereHas('CustomerGroup', function ($query) use ($search) {
                                $query->where('name','LIKE',"%{$search}%");
                              })
                             ->count();
        }

        $data = array();
        if(!empty($results))
        {
            foreach ($results as $value)
            {
                $edit =  url('admin/customer/edit',$value->id);

                $nestedData['id'] = "<input type='checkbox' name='selected[]'' value='{$value->id}'>";
                $nestedData['name'] = $value->name;
                $nestedData['email'] = $value->email;
                $nestedData['customer_group_id'] = $value->CustomerGroup->name;
                $nestedData['status'] = $value->status;
                $nestedData['created_at'] = Carbon::parse($value->created_at)->format('d/m/Y H:i:s');;
                $nestedData['action'] = "&emsp;<a href='{$edit}' title='EDIT' ><span class='glyphicon glyphicon-edit'></span></a>";
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return Response
   */
  public function create()
  {
      $customergroup=CustomerGroup::get();
      return view('admin.customer.create', compact('customergroup'));
  }

  /**
   * Store a newly created resource in storage.
   *
   * @return Response
   */
  public function store(Request $request)
  {
    $request->validate([
      'name' => 'required|max:255',
      'email' => 'required|email|max:255|unique:users',
      'password' => 'required|min:6|confirmed',
      'telephone' => 'required'
    ]);

    $customer=new User();
    $customer->name=$request['name'];
    $customer->telephone=$request['telephone'];
    $customer->email=$request['email'];
    $customer->password=bcrypt($request['password']);
    $customer->newsletter=$request['newsletter'];
    $customer->status=$request['status'];
    $customer->safe=$request['safe'];
    $customer->save();

    if(count($request['address'])>0){
      foreach ($request['address'] as $key => $value) {
        if($request['address'][$key]['name']!==""){
          $validator = Validator::make($request->all(), [
           'address.'.$key.'.name' => 'required|max:191',
           'address.'.$key.'.address' => 'required',
           'address.'.$key.'.city' => 'required',
           'address.'.$key.'.postcode' => 'required',
           'address.'.$key.'.telephone' => 'required'
          ]);
          if ($validator->fails()) {
             $customer->forceDelete();
             return back()->withErrors($validator)
                          ->withInput();
          }

          $address=new Address();
          $address->user_id=$customer->id;
          $address->name=$value['name'];
          $address->company=$value['company'];
          $address->telephone=$value['telephone'];
          $address->address=$value['address'];
          $address->subdistrict_id=$value['city'];
          $address->postal_code=$value['postcode'];
          if(isset($value['default'])){
            if($value['default']==1){
              $alladd=Address::whereUser_id($customer->id)->get();
              foreach ($alladd as $key2 => $value2) {
                $value2->main=0;
                $value2->save();
              }
            }
            $address->main=$value['default'];
          }
          $address->main=$value['default'];
          $address->save();
        }
      }
    }

    return redirect('admin/customer')->with('success', $customer->name.' has been added.');
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function show($id)
  {
    
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function edit($id)
  {
    $results=User::findOrFail($id);
    $addresses=$results->Address;
    $customergroup=CustomerGroup::get();

    return view('admin.customer.edit', compact('results', 'addresses', 'customergroup'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function update($id, Request $request)
  {
    $request->validate([
      'name' => 'required|max:255',
      'email' => 'required|email|max:255|unique:users,email,'.$id,
      'telephone' => 'required'
    ]);
    if(strlen($request['password'])>0){
      $request->validate([
        'password' => 'required|min:6|confirmed',
      ]);
    }

    $customer=User::findOrFail($id);
    $customer->name=$request['name'];
    $customer->telephone=$request['telephone'];
    $customer->email=$request['email'];
    $customer->password=bcrypt($request['password']);
    $customer->newsletter=$request['newsletter'];
    $customer->status=$request['status'];
    $customer->safe=$request['safe'];
    

    if(count($request['address'])>0){
      foreach ($request['address'] as $key => $value) {
        if($value['address_id']>0){
          $validator = Validator::make($request->all(), [
             'address.'.$key.'.name' => 'required|max:191',
             'address.'.$key.'.address' => 'required',
             'address.'.$key.'.city' => 'required',
             'address.'.$key.'.postcode' => 'required',
             'address.'.$key.'.telephone' => 'required'
            ]);
            if ($validator->fails()) {
               return back()->withErrors($validator)
                            ->withInput();
            }

            $address=Address::find($value['address_id']);
            $address->user_id=$customer->id;
            $address->name=$value['name'];
            $address->company=$value['company'];
            $address->telephone=$value['telephone'];
            $address->address=$value['address'];
            $address->subdistrict_id=$value['city'];
            $address->postal_code=$value['postcode'];
            if(isset($value['default'])){
              if($value['default']==1){
                $alladd=Address::whereUser_id($customer->id)->get();
                foreach ($alladd as $key2 => $value2) {
                  $value2->main=0;
                  $value2->save();
                }
              }
              $address->main=$value['default'];
            }
            $address->save();
            $address->touch();
        }else{
          if($request['address'][$key]['name']!==""){
            $validator = Validator::make($request->all(), [
             'address.'.$key.'.name' => 'required|max:191',
             'address.'.$key.'.address' => 'required',
             'address.'.$key.'.city' => 'required',
             'address.'.$key.'.postcode' => 'required',
             'address.'.$key.'.telephone' => 'required'
            ]);
            if ($validator->fails()) {
               return back()->withErrors($validator)
                            ->withInput();
            }

            $address=new Address();
            $address->user_id=$customer->id;
            $address->name=$value['name'];
            $address->company=$value['company'];
            $address->telephone=$value['telephone'];
            $address->address=$value['address'];
            $address->subdistrict_id=$value['city'];
            $address->postal_code=$value['postcode'];
            if(isset($value['default'])){
              if($value['default']==1){
                $alladd=Address::whereUser_id($customer->id)->get();
                foreach ($alladd as $key2 => $value2) {
                  $value2->main=0;
                  $value2->save();
                }
              }
              $address->main=$value['default'];
            }
            $address->save();
          }
        }
      }
    }
    $customer->save();
    $customer->touch();

    return redirect('admin/customer')->with('success', $customer->name.' has been updated.');
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function destroy($id)
  {
    
  }

  public function trash(Request $request)
  {
      $request->validate([
          'selected' => 'array'
      ]);
      $count=count($request['selected']);
      if($count>0)
      {
        $delete=User::whereIn('id',$request['selected'])->delete();
        return back()->with('success', $count.' admin has been deleted.');
      }
  }

  public function searchCity(Request $request)
  {
    $term = trim($request->q);


      $results = Subdistrict::where('name', 'LIKE', '%'.$term.'%')
          ->orWhere('province', 'LIKE', '%'.$term.'%')
          ->orWhere('city', 'LIKE', '%'.$term.'%')
          ->limit(5)->get();

      $formatted_results = [];

    foreach ($results as $val) {
        $formatted_results[] = ['id' => $val->id, 'text' => $val->name.' - '.$val->type.' '.$val->city];
    }

    return response()->json($formatted_results);
  }
  
}

?>