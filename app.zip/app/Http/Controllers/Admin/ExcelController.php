<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Order;
use App\OrderProduct;
use App\OrderHistory;
use App\OrderOption;
use App\OrderStatus;
use App\ProductOption;
use App\OptionDescription;
use App\ExportedOrderProduct;
use Carbon\Carbon;
use Excel;
use DB;
use Illuminate\Support\Facades\Log;
use Mail;

class ExcelController extends Controller
{
	public function createPicklist()
	{
        $min=Carbon::yesterday();
        $max=Carbon::now();
        $order_id=Order::whereOrder_status_id(2)
                ->whereBetween('date_modified',[$min,$max])
                ->select('order_id')
                ->get()
                ->toArray();
        $exportedIds = ExportedOrderProduct::select('purplejade_order_product_id as order_product_id')->groupBy('purplejade_order_product_id')->get()->all();


        
            $products=DB::table('purplejade_order_product')
            ->join('purplejade_order_option', 'purplejade_order_option.order_id', '=', 'purplejade_order_product.order_id')
            ->whereIn('purplejade_order_product.order_id',$order_id)
            ->whereNotIn('purplejade_order_product.order_product_id',$exportedIds)
            ->select('purplejade_order_product.name as name','purplejade_order_option.name as optionName', 'purplejade_order_option.value as optionValue', DB::raw("sum(purplejade_order_product.quantity) as quantity"))
            ->groupBy('name','optionName','optionValue')
            ->orderBy('name','asc')
            ->get();

        $array=[];

        foreach ($products as $product) {
            $object = new \stdClass();
            $object->Name=$product->name;
            $object->Option=$product->optionName." : ".$product->optionValue;
            $object->Quantity=$product->quantity;
            $array[]=$object;
        }

    

		return view('createPicklist',compact('array','min','max'));
	}

    public function test($status=2,$min=null, $max=null)
    {
    	if($min==null){
    		$min=Carbon::yesterday();
    	}else{
    		$min=Carbon::parse($min);
    	}

    	if($max==null){
    		$max=Carbon::now();
    	}else{
    		$max=Carbon::parse($max);
    	}
    	$order_id=Order::whereOrder_status_id($request['status'])
                ->whereBetween('date_modified',[$min,$max])
                ->select('order_id')
                ->get()
                ->toArray();

    	$products=DB::table('purplejade_order_product')
    		->join('purplejade_order_option', 'purplejade_order_option.order_id', '=', 'purplejade_order_product.order_id')
    		->whereIn('purplejade_order_product.order_id',$order_id)
    		
    		->select('purplejade_order_product.name as name','purplejade_order_option.name as optionName', 'purplejade_order_option.value as optionValue', DB::raw("sum(purplejade_order_product.quantity) as quantity"))
    		->groupBy('name','optionName','optionValue')
    		->orderBy('name','asc')
    		->get();

    	$array=[];
    	// Define the Excel spreadsheet headers
    	$array[] = ["Date Created : ".Carbon::now()->toFormattedDateString()];
    	$array[] = ['Name', 'Option', 'Quantity'];

    	foreach ($products as $product) {
    		$object = new \stdClass();
    		//$orderOption=OrderOption::whereOrder_id($product->order_id)->first();
    		//$order=Order::whereOrder_id($product->order_id)->first();
    		//$productOption=ProductOption::whereProduct_option_id($orderOption->product_option_id)->first();
    		//$optionDescription=OptionDescription::whereOption_id($productOption->option_id)->first();
    		//$product->Option=$optionDescription->name." - ".$orderOption->name." : ".$orderOption->value;
    		$object->Name=$product->name;
    		//$object->Option=$orderOption->name." : ".$orderOption->value;
    		$object->Option=$product->optionName." : ".$product->optionValue;
    		$object->Quantity=$product->quantity;
    		// unset($product->OrderOption);
    		// unset($product->ProductOption);
    		// unset($product->OptionDescription);
    		// unset($product->order_product_id);
    		// unset($product->order_id);
    		// unset($product->product_id);
    		// unset($product->price);
    		// unset($product->total);
    		// unset($product->tax);
    		// unset($product->reward);
    		// unset($product->base_price);
    		// unset($product->cost);
    		// unset($product->model);
	        //$array[] = $product->toArray();
	        $array[] = [$object->Name, $object->Option, $object->Quantity];
	    }
    	//return response()->json($products);

    	// Generate and return the spreadsheet
    Excel::create('picklist', function($excel) use ($array) {

        // Set the spreadsheet title, creator, and description
        $excel->setTitle('Picklist');
        $excel->setCreator('Petrus')->setCompany('Purple Jade Butik');
        $excel->setDescription('Picklist item keluar dari gudang');

        // Build the spreadsheet, passing in the payments array
        $excel->sheet('sheet1', function($sheet) use ($array) {

        	$sheet->cell('A1', function($cell) {

			    // manipulate the cell
			    $cell->setFontSize(20);

			});
            $sheet->fromArray($array, null, 'A1', false, false);
        });

    })->download('xlsx');
    }

    public function postPicklist(Request $request)
    {
    	$daterange=explode(' - ',$request['daterange']);
    	//dd($daterange);


    	$min=Carbon::parse($daterange[0]);
    	$max=Carbon::parse($daterange[1]);
    	$order_id=Order::whereOrder_status_id($request['status'])
                ->whereBetween('date_added',[$min,$max])
                ->select('order_id')
                ->get()
                ->toArray();
        $exportedIds = ExportedOrderProduct::select('purplejade_order_product_id as order_product_id')->groupBy('purplejade_order_product_id')->get()->all();
        Log::info($order_id);
    	// if(isset($request['reexport']) && $request['reexport']==1)
    	// {
    	// 	$products=DB::table('purplejade_order_product')
    	// 	->join('purplejade_order_option', 'purplejade_order_option.order_id', '=', 'purplejade_order_product.order_id')
    	// 	->whereIn('purplejade_order_product.order_id',$order_id)
    		
    	// 	->select('purplejade_order_product.name as name','purplejade_order_option.name as optionName', 'purplejade_order_option.value as optionValue', DB::raw("sum(purplejade_order_product.quantity) as quantity"))
    	// 	->groupBy('name','optionName','optionValue')
    	// 	->orderBy('name','asc')
    	// 	->get();
    	// }else{
    		$products=DB::table('purplejade_order_product')
    		->join('purplejade_order_option', 'purplejade_order_option.order_id', '=', 'purplejade_order_product.order_id')
    		->whereIn('purplejade_order_product.order_id',$order_id)
    		//->whereNotIn('purplejade_order_product.order_product_id',$exportedIds)
    		->select('purplejade_order_product.order_id as order_id','purplejade_order_option.order_option_id','purplejade_order_product.name as name','purplejade_order_option.name as optionName', 'purplejade_order_option.value as optionValue', DB::raw("sum(purplejade_order_product.quantity) as quantity"))
    		->groupBy('name','optionName','optionValue')
    		->orderBy('name','asc')
    		->get();

            
    	//}


    	$array=[];
    	// Define the Excel spreadsheet headers
    	$array[] = ["Date Created : ".Carbon::now()->toFormattedDateString()];
    	$array[] = ['Name', 'Option', 'Quantity'];

    	foreach ($products as $product) {
    		$object = new \stdClass();
    		$object->Name=$product->name;
    		$object->Option=$product->optionName." : ".$product->optionValue;
    		$object->Quantity=$product->quantity;
	        $array[] = [$object->Name, $object->Option, $object->Quantity];
	    }

	    $exported=OrderProduct::whereIn('order_id',$order_id)->get();
	    foreach($exported as $ex)
	    {
	    	// $ex->exported=Carbon::now();
	    	// $ex->save();
            $createExport=ExportedOrderProduct::create([
                "purplejade_order_product_id" => $ex->order_product_id
            ]);
	    }

    	// Generate and return the spreadsheet
    Excel::create('picklist', function($excel) use ($array) {

        // Set the spreadsheet title, creator, and description
        $excel->setTitle('Picklist');
        $excel->setCreator('Petrus')->setCompany('Purple Jade Butik');
        $excel->setDescription('Picklist item keluar dari gudang');

        // Build the spreadsheet, passing in the payments array
        $excel->sheet('sheet1', function($sheet) use ($array) {

        	$sheet->cell('A1', function($cell) {

			    // manipulate the cell
			    $cell->setFontSize(20);

			});
            $sheet->fromArray($array, null, 'A1', false, false);
        });

    })->download('xlsx');
    }

    public function tableFilter(Request $request)
    {
        $daterange=explode(' - ',$request['daterange']);
        //dd($daterange);
        $min=Carbon::parse($daterange[0]);
        $max=Carbon::parse($daterange[1]);

            $order_id=Order::whereOrder_status_id($request['status'])
                ->whereBetween('date_modified',[$min,$max])
                ->select('order_id')
                ->get()
                ->toArray();
            $exportedIds = ExportedOrderProduct::select('purplejade_order_product_id as order_product_id')->groupBy('purplejade_order_product_id')->get()->all();

        if( $request['reexport']==0)
        {
            $products=DB::table('purplejade_order_product')
            ->join('purplejade_order_option', 'purplejade_order_option.order_id', '=', 'purplejade_order_product.order_id')
            ->whereIn('purplejade_order_product.order_id',$order_id)
            ->whereNotIn('purplejade_order_product.order_product_id',$exportedIds)
            ->select('purplejade_order_product.name as name','purplejade_order_option.name as optionName', 'purplejade_order_option.value as optionValue', DB::raw("sum(purplejade_order_product.quantity) as quantity"))
            ->groupBy('name','optionName','optionValue')
            ->orderBy('name','asc')
            ->get();
        }else{
            $products=DB::table('purplejade_order_product')
            ->join('purplejade_order_option', 'purplejade_order_option.order_id', '=', 'purplejade_order_product.order_id')
            ->whereIn('purplejade_order_product.order_id',$order_id)
            
            ->select('purplejade_order_product.name as name','purplejade_order_option.name as optionName', 'purplejade_order_option.value as optionValue', DB::raw("sum(purplejade_order_product.quantity) as quantity"))
            ->groupBy('name','optionName','optionValue')
            ->orderBy('name','asc')
            ->get();
        }
        
            

        $array=[];

        foreach ($products as $product) {
            $object = new \stdClass();
            $object->Name=$product->name;
            $object->Option=$product->optionName." : ".$product->optionValue;
            $object->Quantity=$product->quantity;
            $array[]=$object;
        }

    

            return view('table',compact('array'))->render();
    }

    public function postTablePicklist(Request $request)
    {
        //dd($request->all());
        $daterange=explode(' - ',$request['daterange2']);
        //dd($daterange);
        $min=Carbon::parse($daterange[0]);
        $max=Carbon::parse($daterange[1]);
        $order_id=Order::whereOrder_status_id($request['status2'])
                ->whereBetween('date_modified',[$min,$max])
                ->select('order_id')
                ->get()
                ->toArray();
            $selName=[];
            $selOptionName=[];
            $selOptionValue=[];
            foreach($request['check'] as $sel)
            {
                $selected=explode('|-|',$sel);
                $option=explode(" : ",$selected[1]);
                $selName[]=$selected[0];
                $selOptionName[]=$option[0];
                $selOptionValue[]=$option[1];
            }
        
            $products=DB::table('purplejade_order_product')
            ->join('purplejade_order_option', 'purplejade_order_option.order_id', '=', 'purplejade_order_product.order_id')
            ->whereIn('purplejade_order_product.order_id',$order_id)
            ->whereIn('purplejade_order_product.name',$selName)
            ->whereIn('purplejade_order_option.name',$selOptionName)
            ->whereIn('purplejade_order_option.value',$selOptionValue)
            ->select('purplejade_order_product.name as name','purplejade_order_option.name as optionName', 'purplejade_order_option.value as optionValue', DB::raw("sum(purplejade_order_product.quantity) as quantity"))
            ->groupBy('name','optionName','optionValue')
            ->orderBy('name','asc')
            ->get();
            //dd($products);
        


        $array=[];
        // Define the Excel spreadsheet headers
        $array[] = ["Date Created : ".Carbon::now()->toFormattedDateString()];
        $array[] = ['Name', 'Option', 'Quantity'];

        foreach ($products as $product) {
            $object = new \stdClass();
            $object->Name=$product->name;
            $object->Option=$product->optionName." : ".$product->optionValue;
            $object->Quantity=$product->quantity;
            $array[] = [$object->Name, $object->Option, $object->Quantity];
        }

        $exported=OrderProduct::join('purplejade_order_option', 'purplejade_order_option.order_id', '=', 'purplejade_order_product.order_id')
            ->whereIn('purplejade_order_product.order_id',$order_id)
            ->whereIn('purplejade_order_product.name',$selName)
            ->whereIn('purplejade_order_option.name',$selOptionName)
            ->whereIn('purplejade_order_option.value',$selOptionValue)
            
            ->orderBy('purplejade_order_product.name','asc')
            ->get();
        foreach($exported as $ex)
        {
            // $ex->exported=Carbon::now();
            // $ex->save();
            $createExport=ExportedOrderProduct::create([
                "purplejade_order_product_id" => $ex->order_product_id
            ]);
        }

        // Generate and return the spreadsheet
    Excel::create('picklist', function($excel) use ($array) {

        // Set the spreadsheet title, creator, and description
        $excel->setTitle('Picklist');
        $excel->setCreator('Petrus')->setCompany('Purple Jade Butik');
        $excel->setDescription('Picklist item keluar dari gudang');

        // Build the spreadsheet, passing in the payments array
        $excel->sheet('sheet1', function($sheet) use ($array) {

            $sheet->cell('A1', function($cell) {

                // manipulate the cell
                $cell->setFontSize(20);

            });
            $sheet->fromArray($array, null, 'A1', false, false);
        });

        })->download('xlsx');
    }

    public function showOrder()
    {
        $min=Carbon::yesterday();
        $max=Carbon::now();
        $orders=Order::whereOrder_status_id(18)
                ->whereBetween('date_added',[$min,$max])
                ->orderBy('date_added','desc')
                ->get();
        $orderStatus=OrderStatus::get();
        

    

        return view('showOrder',compact('orders','orderStatus','min','max'));
    }

    public function orderFilter(Request $request)
    {
        $daterange=explode(' - ',$request['daterange']);
        
        $min=Carbon::parse($daterange[0]);
        $max=Carbon::parse($daterange[1]);
        
            $order_id=Order::whereOrder_status_id($request['status'])
                ->whereBetween('date_added',[$min,$max])
                ->pluck('order_id')
                ->toArray();
            $exportedIds = ExportedOrderProduct::select('purplejade_order_product_id as order_product_id')->groupBy('purplejade_order_product_id')->pluck('order_product_id')->all();
            $exportedOrderIds=OrderProduct::select('order_id')
                    ->whereIn('order_product_id', $exportedIds)
                    ->groupBy('order_id')
                    ->get()
                    ->toArray();
                    //Log::info($order_id);
        // if( $request['reexport']==0)
        // {
        //     $orders=Order::whereIn('order_id',$order_id)
        //         ->whereNotIn('order_id',$exportedOrderIds)
        //         ->orderBy('date_added','desc')
        //         ->get();
        // }else{
            $orders=Order::whereIn('order_id',$order_id)
                ->orderBy('date_added','desc')
                ->get();
        //}

    

            return view('tableOrder',compact('orders'))->render();
    }

    public function postOrderPicklist(Request $request)
    {
        //dd($request->all());
        $daterange=explode(' - ',$request['daterange2']);
        //dd($daterange);
        $min=Carbon::parse($daterange[0]);
        $max=Carbon::parse($daterange[1]);
        $order_id=Order::whereOrder_status_id($request['status2'])
                ->whereBetween('date_added',[$min,$max])
                ->select('order_id')
                ->get()
                ->toArray();
        
            $products=DB::table('purplejade_order_product')
            ->join('purplejade_order_option', 'purplejade_order_option.order_product_id', '=', 'purplejade_order_product.order_product_id')
            ->whereIn('purplejade_order_product.order_id',$request['check'])
            ->select('purplejade_order_product.order_id as order_id','purplejade_order_option.order_option_id','purplejade_order_product.name as name','purplejade_order_option.name as optionName', 'purplejade_order_option.value as optionValue', DB::raw("sum(purplejade_order_product.quantity) as quantity"))
            ->groupBy('name','purplejade_order_option.order_option_id','optionName','optionValue')
            ->orderBy('name','asc')
            ->get();
            //dd($products);
        $orders=Order::whereIn('order_id',$request['check'])
                ->get();

        // foreach($orders as $order){
        //     $addHistory=new OrderHistory();
        //     $addHistory->order_id = $order->order_id;
        //     $addHistory->order_status_id = 2;
        //     $addHistory->notify = 1;
        //     $addHistory->comment = '';
        //     $addHistory->date_added = Carbon::now();
        //     $addHistory->save();
        //     $tryhistory=OrderHistory::find($addHistory->order_history_id);
        //     Log::info($tryhistory);
        //     $order->order_status_id=2;
        //     $order->save();
        //     Mail::send('email.orderProcess', ['order'=>$order], function($message) use ($order) {
        //     $message->to('lukas@expersideconsulting.com', $order->firstname.' '.$order->lastname)
        //         ->subject(sprintf('%s - Order %s', $order->store_name, $order->order_id));
        // });
        // }


        $array=[];
        // Define the Excel spreadsheet headers
        $array[] = ["Date Created : ".Carbon::now()->toFormattedDateString()];
        $array[] = ['Name', 'Option', 'Quantity'];

        foreach ($products as $product) {
            $object = new \stdClass();
            $object->Name=$product->name;
            $object->Option=$product->optionName." : ".$product->optionValue;
            $object->Quantity=$product->quantity;
            $array[] = [$object->Name, $object->Option, $object->Quantity];
        }

        $exported=OrderProduct::join('purplejade_order_option', 'purplejade_order_option.order_id', '=', 'purplejade_order_product.order_id')
            ->whereIn('purplejade_order_product.order_id',$request['check'])
            
            ->orderBy('purplejade_order_product.name','asc')
            ->get();
        foreach($exported as $ex)
        {
            // $ex->exported=Carbon::now();
            // $ex->save();
            $createExport=ExportedOrderProduct::create([
                "purplejade_order_product_id" => $ex->order_product_id
            ]);
        }

        // Generate and return the spreadsheet
    Excel::create('picklist', function($excel) use ($array) {

        // Set the spreadsheet title, creator, and description
        $excel->setTitle('Picklist');
        $excel->setCreator('Petrus')->setCompany('Purple Jade Butik');
        $excel->setDescription('Picklist item keluar dari gudang');

        // Build the spreadsheet, passing in the payments array
        $excel->sheet('sheet1', function($sheet) use ($array) {

            $sheet->cell('A1', function($cell) {

                // manipulate the cell
                $cell->setFontSize(20);

            });
            $sheet->fromArray($array, null, 'A1', false, false);
        });

        })->download('xlsx');
    }

    public function postOrderPicklistShippingLabel(Request $request)
    {
        $orders=Order::whereIn('order_id',$request['check'])
                ->get();

        $exportedIds = ExportedOrderProduct::select('purplejade_order_product_id as order_product_id')->groupBy('purplejade_order_product_id')->pluck('order_product_id')->all();
        $exportedOrderIds=OrderProduct::select('order_id')
                ->whereIn('order_product_id', $exportedIds)
                ->groupBy('order_id')
                ->pluck('order_id')->all();

        foreach($orders as $order){
		            $addHistory=new OrderHistory();
		            $addHistory->order_id = $order->order_id;
		            $addHistory->order_status_id = 2;
		            if(isset($request['notify']) && $request['notify']==1){
		                $addHistory->notify = $request['notify'];
		            }else{
		                $addHistory->notify = 0;
		            }
		            if(strlen($request['comment'])>0){
		                $addHistory->comment = $request['comment'];
		            }else{
		                $addHistory->comment = ' ';
		            }
		            $addHistory->date_added = Carbon::now();
		            $addHistory->save();
		            $tryhistory=OrderHistory::find($addHistory->order_history_id);
		            Log::info($tryhistory);
		            $order->order_status_id=2;
		            $order->date_modified=Carbon::now();
		            $order->save();

		            if(isset($request['notify']) && $request['notify']==1){
		                    Mail::send('email.orderProcess', ['order'=>$order,'history'=>$addHistory], function($message) use ($order) {
		                    $message->to($order->email, $order->firstname.' '.$order->lastname)
		                        ->subject(sprintf('%s - Order %s Telah Diproses', $order->store_name, $order->order_id));

		                });
		            }
        }
                

        // Generate and return the view
        return view('shippingLabel2',compact('orders'));
    }


    public function postOrderPicklistShippingLabelProcessed(Request $request)
    {
        $orders=Order::whereIn('order_id',$request['check'])
                ->get();

        $exportedIds = ExportedOrderProduct::select('purplejade_order_product_id as order_product_id')->groupBy('purplejade_order_product_id')->pluck('order_product_id')->all();
        $exportedOrderIds=OrderProduct::select('order_id')
                ->whereIn('order_product_id', $exportedIds)
                ->groupBy('order_id')
                ->pluck('order_id')->all();

        foreach($orders as $order){
        	//if(isset($request['reexport']) && $request['reexport']==1){
            		//if (!in_array($order->id, $exportedOrderIds)) {
		            $addHistory=new OrderHistory();
		            $addHistory->order_id = $order->order_id;
		            $addHistory->order_status_id = 15;
		            if(isset($request['notify']) && $request['notify']==1){
		                $addHistory->notify = $request['notify'];
		            }else{
		                $addHistory->notify = 0;
		            }
		            if(strlen($request['comment'])>0){
		                $addHistory->comment = $request['comment'];
		            }else{
		                $addHistory->comment = ' ';
		            }
		            $addHistory->date_added = Carbon::now();
		            $addHistory->save();
		            $tryhistory=OrderHistory::find($addHistory->order_history_id);
		            Log::info($tryhistory);
		            $order->order_status_id=15;
		            $order->date_modified=Carbon::now();
		            $order->save();
		            if(isset($request['notify']) && $request['notify']==1){
		            	
		                    Mail::send('email.orderProcess', ['order'=>$order,'history'=>$addHistory], function($message) use ($order) {
		                    $message->to($order->email, $order->firstname.' '.$order->lastname)
		                        ->subject(sprintf('%s - Order %s Telah Diproses', $order->store_name, $order->order_id));

		                });
		            }
        }
                

        // Generate and return the view
        return view('shippingLabelProcessed',compact('orders'));
    }

    public function postOrderPicklistReprint(Request $request)
    {
        $orders=Order::whereIn('order_id',$request['check'])
                ->get();
        // Generate and return the view
        return view('shippingLabel2',compact('orders'));
    }
}
