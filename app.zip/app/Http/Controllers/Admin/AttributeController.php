<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\AttributeGroup;
use App\Models\Attribute;
use App\Models\Product;
use Carbon\Carbon;
use Validator;

class AttributeController extends Controller
{
  public function showIndex()
  {
      return view('admin.attribute.index', compact('results'));
  }

  /**
   * Display a listing of the resource.
   *
   * @return Response
   */
  public function index(Request $request)
  {
      $columns = array( 
                            0 =>'id', 
                            1 =>'name',
                            2 =>'attribute_group',
                            3 =>'action'
                        );
  
        $totalData = Attribute::count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        if(array_key_exists($request->input('order.0.column'), $columns)){
          $order = $columns[$request->input('order.0.column')];
        }else{
          $order = 'id';
        }
        if($request->input('order.0.dir')!==null){
          $dir = $request->input('order.0.dir');
        }else{
          $dir = 'asc';
        }
        
            
        if(empty($request->input('search.value')))
        {            
            $results = Attribute::orderBy($order,$dir)->offset($start)->limit($limit)
                         ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $results =  Attribute::where('name','LIKE',"%{$search}%")
                            ->orWhereHas('AttributeGroup', function ($query) use ($search) {
                                $query->where('name','LIKE',"%{$search}%");
                            })
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();

            $totalFiltered = Attribute::where('name','LIKE',"%{$search}%")
                            ->orWhereHas('AttributeGroup', function ($query) use ($search) {
                                $query->where('name','LIKE',"%{$search}%");
                            })
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();
        }

        $data = array();
        if(!empty($results))
        {
            foreach ($results as $value)
            {
                $edit =  url('admin/attribute/edit',$value->id);

                $nestedData['id'] = "<input type='checkbox' name='selected[]'' value='{$value->id}'>";
                $nestedData['name'] = $value->name;
                $nestedData['attribute_group'] = $value->AttributeGroup->name;
                $nestedData['sort_order'] = $value->sort_order;
                $nestedData['action'] = "&emsp;<a href='{$edit}' title='EDIT' ><span class='glyphicon glyphicon-edit'></span></a>";
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return Response
   */
  public function create()
  {
  	  $attribute_group=AttributeGroup::get();
      return view('admin.attribute.create', compact('attribute_group'));
  }

  /**
   * Store a newly created resource in storage.
   *
   * @return Response
   */
  public function store(Request $request)
  {
      $request->validate([
          'name' => 'required',
          'sort_order' => 'numeric',
          'attribute_group_id' =>'required|exists:attribute_group,id',
      ]);
  	$store=new Attribute();
  	$store->name=$request['name'];
  	$store->attribute_group_id=$request['attribute_group_id'];
  	$store->sort_order=$request['sort_order'];
  	$store->save();
      
      
    return redirect('admin/attribute')->with('success',$request['name'].' attribute successfully created.');
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function show($id)
  {
      
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function edit($id)
  {
  	  $attribute_group=AttributeGroup::get();
      $results = Attribute::findOrFail($id);
      return view('admin.attribute.edit', compact('results', 'attribute_group'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function update($id, Request $request)
  {
      $request->validate([
          'name' => 'required',
          'sort_order' => 'numeric',
          'attribute_group_id' =>'required|exists:attribute_group,id',
      ]);
     $store=Attribute::findOrFail($id);
	 $store->name=$request['name'];
  	 $store->attribute_group_id=$request['attribute_group_id'];
  	 $store->sort_order=$request['sort_order'];
  	 $store->save();
  	 $store->touch();
     return redirect('admin/attribute')->with('success',$request['name'].' attribute successfully updated.');
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function destroy($id)
  {
    
  }

  public function trash(Request $request)
  {
      $request->validate([
          'selected' => 'array'
      ]);
      $count=count($request['selected']);
      if($count>0)
      {
        $delete=Attribute::whereIn('id',$request['selected'])->delete();
        return back()->with('success', $count.' item has been deleted.');
      }
  }

  public function searchAttribute(Request $request)
  {
      $term = trim($request->q);

      // if (empty($term)) {
      //     return \Response::json([]);
      // }

      $results = Attribute::where('name', 'LIKE', '%'.$term.'%')->limit(5)->get();

      $formatted_results = [];

      foreach ($results as $val) {
          $formatted_results[] = ['id' => $val->id, 'text' => $val->name];
      }

      return response()->json($formatted_results);
  }
}
