<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\VoucherTheme;
use App\Models\Voucher;
use App\Models\Order;
use App\Models\User;
use App\Models\Admin;
use Carbon\Carbon;
use Auth;

class VoucherController extends Controller
{
  public function showIndex()
  {
      $results = Voucher::orderBy('voucher_theme_id')->paginate(20);
      return view('admin.vouchers.index', compact('results'));
  }

  /**
   * Display a listing of the resource.
   *
   * @return Response
   */
  public function index(Request $request)
  {
      $columns = array( 
                            0 =>'id', 
                            1 =>'code',
                            2 =>'value',
                            3 =>'theme',
                            4 =>'status',
                            5 =>'used_by',
                            6 =>'expired_at',
                            7 =>'created_at',
                            8 =>'updated_at'
                        );
  
        $totalData = Voucher::count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        if(array_key_exists($request->input('order.0.column'), $columns)){
          $order = $columns[$request->input('order.0.column')];
        }else{
          $order = 'id';
        }
        if($request->input('order.0.dir')!==null){
          $dir = $request->input('order.0.dir');
        }else{
          $dir = 'asc';
        }
        
            
        if(empty($request->input('search.value')))
        {            
            $results = Voucher::orderBy($order,$dir)->offset($start)->limit($limit)
                         ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $results =  Voucher::where('code','LIKE',"%{$search}%")
                            ->orWhereHas('VoucherTheme', function ($query) use ($search) {
                                $query->where('name','LIKE',"%{$search}%");
                            })
                            ->orWhereHas('User', function ($query) use ($search) {
                                $query->where('name','LIKE',"%{$search}%");
                            })
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();

            $totalFiltered = Voucher::where('code','LIKE',"%{$search}%")
                            ->orWhereHas('VoucherTheme', function ($query) use ($search) {
                                $query->where('name','LIKE',"%{$search}%");
                            })
                            ->orWhereHas('User', function ($query) use ($search) {
                                $query->where('name','LIKE',"%{$search}%");
                            })
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();
        }

        $data = array();
        if(!empty($results))
        {
            foreach ($results as $value)
            {
                $edit =  url('admin/vouchers/edit',$value->id);

                $nestedData['id'] = "<input type='checkbox' name='selected[]'' value='{$value->id}'>";
                $nestedData['code'] = $value->code;
                $nestedData['value'] = currency_format($value->value,'IDR');
                $nestedData['status'] = $value->status;
                $nestedData['used_by'] = $value->User ? $value->User->name : "-";
                $nestedData['expired_at'] = $value->expired_at!=null ? Carbon::parse($value->expired_at)->format('d/m/Y') : "-";
                $nestedData['created_at'] = Carbon::parse($value->created_at)->format('d/m/Y H:i:s');
                $nestedData['updated_at'] = Carbon::parse($value->updated_at)->format('d/m/Y H:i:s');
                $nestedData['action'] = "&emsp;<a href='{$edit}' title='EDIT' ><span class='glyphicon glyphicon-edit'></span></a>";
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return Response
   */
  public function create()
  {
  	  $themes=VoucherTheme::get();
      return view('admin.vouchers.create', compact('themes'));
  }

  /**
   * Store a newly created resource in storage.
   *
   * @return Response
   */
  public function store(Request $request)
  {
      $request->validate([
          'amount' => 'required|min:1',
          'prefix' => 'required',
          'value' => 'required|numeric|min:1',
          'theme' =>'required|exists:voucher_theme,id',
      ]);
      for($x=0;$x<$request['amount'];$x++){
      	$store=new Voucher();
      	$rand=$this->randomNumber();
      	$try=Voucher::whereCode(strtoupper($request['prefix']).$rand)->first();
      	while(count($try)==1){
      		$rand=$this->randomNumber();
      		$try=Voucher::whereCode(strtoupper($request['prefix']).$rand)->first();
      	}
      	$store->code=strtoupper($request['prefix']).$rand;
      	$store->value=$request['value'];
      	$store->voucher_theme_id=$request['theme'];
      	$store->message=$request['message'];
      	$created_by=new \stdClass();
      	$created_by->id=Auth::user('admin')->id;
      	$created_by->role='Admin';
      	$store->created_by=json_encode($created_by);
      	if($request['expired_at']!=null){
	      	if (Carbon::createFromFormat('d-m-Y', $request['expired_at']) !== false) {
			    $store->expired_at=Carbon::createFromFormat('d-m-Y', $request['expired_at']);
			}
		}
      	$store->save();
      }
      
      
      return redirect('admin/vouchers')->with('success',$request['amount'].' voucher successfully created.');
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function show($id)
  {
      
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function edit($id)
  {
  	  $themes=VoucherTheme::get();
      $results = Voucher::findOrFail($id);
      return view('admin.vouchers.edit', compact('results', 'themes'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function update($id, Request $request)
  {
      $request->validate([
          'code' => 'required|unique:voucher,code,'.$id,
          'value' => 'required|numeric|min:1',
          'theme' =>'required|exists:voucher_theme,id',
          'status' => 'required|numeric'
      ]);
      	$store=Voucher::findOrFail($id);
	  	$store->code=strtoupper($request['code']);
	  	$store->value=$request['value'];
	  	$store->voucher_theme_id=$request['theme'];
	  	$store->message=$request['message'];
	  	$store->status=$request['status'];
	  	$created_by=new \stdClass();
	  	$created_by->id=Auth::user('admin')->id;
	  	$created_by->role='Admin';
	  	$store->created_by=json_encode($created_by);
	  	if($request['expired_at']!=null){
	      	if (Carbon::createFromFormat('d-m-Y', $request['expired_at']) !== false) {
			    $store->expired_at=Carbon::createFromFormat('d-m-Y', $request['expired_at']);
			}
		}else{
			$store->expired_at=null;
		}
	  	$store->save();
	  	$store->touch();
      return redirect('admin/vouchers')->with('success','Voucher successfully updated.');
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function destroy($id)
  {
    
  }

  public function trash(Request $request)
  {
      $request->validate([
          'selected' => 'array'
      ]);
      $count=count($request['selected']);
      if($count>0)
      {
        $delete=Voucher::whereIn('id',$request['selected'])->delete();
        return back()->with('success', $count.' item has been deleted.');
      }
  }

  public function randomNumber($x=8)
  {
  	$digits_needed=$x;

	$random_number=''; // set up a blank string

	$count=0;

	while ( $count < $digits_needed ) {
	    $random_digit = mt_rand(0, 9);
	    
	    $random_number .= $random_digit;
	    $count++;
	}

	return $random_number;
  }
}
