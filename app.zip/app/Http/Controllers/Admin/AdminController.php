<?php 

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Admin;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\ProductOption;
use App\Models\ProductOptionDetail;
use App\Models\Option;
use App\Models\OptionValue;
use App\Models\Category;
use App\Models\Manufacturer;
use App\Models\WeightClass;
use App\Models\LengthClass;
use App\Models\StockStatus;
use App\Models\Order;
use App\Models\OrderHistory;
use App\Models\PaymentMethod;
use App\Models\User;
use App\Models\PermissionGroup;
use Carbon\Carbon;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller 
{

  public function showIndex()
  {
      $results = Admin::orderBy('name')->paginate(20);
      return view('admin.admin.index', compact('results'));
  }

  /**
   * Display a listing of the resource.
   *
   * @return Response
   */
  public function index(Request $request)
  {
      // $results = Category::orderBy('name')->paginate(20);
      // return view('admin.category.index', compact('results'));
      $columns = array( 
                            0 =>'id', 
                            1 =>'name',
                            2 =>'created_at',
                            3=> 'action',
                        );
  
        $totalData = Admin::count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        if(array_key_exists($request->input('order.0.column'), $columns)){
          $order = $columns[$request->input('order.0.column')];
        }else{
          $order = 'id';
        }
        if($request->input('order.0.dir')!==null){
          $dir = $request->input('order.0.dir');
        }else{
          $dir = 'asc';
        }
        
            
        if(empty($request->input('search.value')))
        {            
            // $results = Category::offset($start)
            //              ->limit($limit)
            //              ->orderBy($order,$dir)
            //              ->get();
            $results = Admin::orderBy($order,$dir)->offset($start)->limit($limit)
                         ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $results =  Admin::where('name','LIKE',"%{$search}%")
                            ->orWhere('email', 'LIKE',"%{$search}%")
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();

            $totalFiltered = Admin::where('name','LIKE',"%{$search}%")
                             ->orWhere('email', 'LIKE',"%{$search}%")
                             ->count();
        }

        $data = array();
        if(!empty($results))
        {
            foreach ($results as $value)
            {
                $edit =  url('admin/admin/edit',$value->id);

                $nestedData['id'] = "<input type='checkbox' name='selected[]'' value='{$value->id}'>";
                $nestedData['name'] = $value->name;
                $nestedData['created_at'] = Carbon::parse($value->created_at)->format('d/m/Y H:i:s');;
                $nestedData['action'] = "&emsp;<a href='{$edit}' title='EDIT' ><span class='glyphicon glyphicon-edit'></span></a>";
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return Response
   */
  public function create()
  {
      $category = Admin::orderBy('name')->get();
      return view('admin.admin.create', compact('category'));
  }

  /**
   * Store a newly created resource in storage.
   *
   * @return Response
   */
  public function store(Request $request)
  {
    $request->validate([
      'name' => 'required|max:255',
      'username' => 'required|max:255|unique:admin',
      'email' => 'required|email|max:255|unique:admin',
      'password' => 'required|min:6|confirmed',
    ]);

    $admin=new Admin();
    $admin->name=$request['name'];
    $admin->username=$request['username'];
    $admin->email=$request['email'];
    $admin->password=bcrypt($request['password']);
    $admin->save();

    return redirect('admin/admin')->with('success', $admin->name.' has been added.');
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function show($id)
  {
    
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function edit($id)
  {
    $results=Admin::findOrFail($id);
    $permission_group=PermissionGroup::select('name')->groupBy('name')->get();
    $permission=Permission::get();
    $permissions=$results->getAllPermissions();
    $permission_id=[];


    foreach ($permissions as $key => $value) {
      $permission_id[]=$value->id;
    }
    return view('admin.admin.edit', compact('results', 'permission', 'permission_id', 'permission_group'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function update($id, Request $request)
  {
    $admin=Admin::findOrFail($id);
    $request->validate([
      'name' => 'required|max:255',
      'username' => 'required|max:255|unique:admin,username,'.$id,
      'email' => 'required|email|max:255|unique:admin,email,'.$id,
    ]);

    
    $admin->name=$request['name'];
    $admin->username=$request['username'];
    $admin->email=$request['email'];
    $admin->save();


    $msg="";
    if($admin->id!=1){
      $admin->syncPermissions();
      if(count($request['permission'])>0){
        $admin->givePermissionTo(array_filter($request['permission']));
      }
    }else{
      $msg.=" You can't change this account permissions";
    }

    return redirect('admin/admin')->with('success', $admin->name.' has been updated.'.$msg);
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function destroy($id)
  {
    
  }

  public function trash(Request $request)
  {
      $request->validate([
          'selected' => 'array'
      ]);
      $count=count($request['selected']);
      if($count>0)
      {
        $delete=Admin::whereIn('id',$request['selected'])->delete();
        return back()->with('success', $count.' admin has been deleted.');
      }
  }

  public function dashboard(Request $request)
  {
    if($request->input('date_range')!==null){
      $date_range=explode('_-_',$request->input('date_range'));
      $start=Carbon::createFromFormat('m-d-Y H:i:s', $date_range[0]." 00:00:00");
      $end=Carbon::createFromFormat('m-d-Y H:i:s', $date_range[1]." 23:59:59");
    }else{
      $start=new Carbon('first day of this month');
      $end=Carbon::now();
    }
    $totalorder=Order::count();
    $total_order_per_date=Order::whereBetween('created_at',[$start,$end])->get()
                          ->groupBy(function($date) {
                              return Carbon::parse($date->created_at)->format('Y-m-d'); // grouping by years
                              //return Carbon::parse($date->created_at)->format('m'); // grouping by months
                          });
    //dd($total_order_per_date);
    $totalsales=Order::whereOrder_status_id(4)->sum('total');
    $totaluser=User::count();
    $totalproduct=Product::count();
    $admin=Admin::find(Auth::user()->id);
    $totalsales=$this->nice_number($totalsales);
    $getdeletedorder=Order::onlyTrashed()->pluck('id')->toArray();
    $latest_transaction=OrderHistory::whereNotIn('order_id', $getdeletedorder)->orderBy('created_at','desc')->limit(10)->get();
    $payment_method=PaymentMethod::get();

    return view('admin.index', compact('totalorder', 'totalsales', 'totaluser', 'totalproduct', 'latest_transaction','total_order_per_date', 'payment_method'));
  }


  
  
}

?>