<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\ProductOption;
use App\Models\ProductOptionDetail;
use App\Models\Option;
use App\Models\OptionValue;
use App\Models\Category;
use App\Models\Manufacturer;
use App\Models\WeightClass;
use App\Models\LengthClass;
use App\Models\StockStatus;
use App\Models\ProductStock;
use App\Models\ProductStockDetail;
use Carbon\Carbon;
use Excel;

class StockController extends Controller
{
    public function showIndex()
  {
      $results = Product::orderBy('name')->paginate(20);
      return view('admin.stock.index', compact('results'));
  }


  /**
   * Display a listing of the resource.
   *
   * @return Response
   */
  public function index(Request $request)
  {
      $columns = array( 
                            0 =>'id', 
                            1 =>'image',
                            2 =>'name',
                            3 =>'model',
                            4 =>'price',
                            5 =>'qty',
                            6 =>'status',
                            7 =>'action'
                        );
  
        $totalData = Product::has('ProductOption')->count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        if(array_key_exists($request->input('order.0.column'), $columns)){
          $order = $columns[$request->input('order.0.column')];
        }else{
          $order = 'id';
        }
        if($request->input('order.0.dir')!==null){
          $dir = $request->input('order.0.dir');
        }else{
          $dir = 'asc';
        }
        
            
        if(empty($request->input('search.value')))
        {            
            $results = Product::has('ProductOption')->orderBy($order,$dir)->offset($start)->limit($limit)
                         ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $results =  Product::has('ProductOption')->where('name','LIKE',"%{$search}%")
                            ->orWhere('model','LIKE',"%{$search}%")
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();

            $totalFiltered = Product::has('ProductOption')->where('name','LIKE',"%{$search}%")
                             ->orWhere('model','LIKE',"%{$search}%")
                             ->count();
        }

        $data = array();
        if(!empty($results))
        {
            foreach ($results as $value)
            {
                $edit =  url('admin/stock/edit',$value->id);
                $img = $value->Image->first()->image;

                $nestedData['id'] = "<input type='checkbox' name='selected[]'' value='{$value->id}'>";
                $nestedData['image'] = "<img src='{$img}' style='width:50px;height:auto;'>";
                $nestedData['name'] = "<p data-id='{$value->id}' data-type='name'>{$value->name}</p>";
                $nestedData['model'] = "<p data-id='{$value->id}' data-type='model'>{$value->model}</p>";
                $nestedData['price'] = "<p data-id='{$value->id}' data-price='{$value->price}' data-type='price'>".currency_format($value->price,'IDR')."</p>";
                if($value->qty>0){
                  $nestedData['qty'] = "<span class='label label-success' data-id='{$value->id}' data-type='qty'>{$value->qty}</span>";
                }else{
                  $nestedData['qty'] = "<span class='label label-warning' data-id='{$value->id}' data-type='qty'>{$value->qty}</span>";
                }
                if($value->status==1){
                  $nestedData['status'] = "<p data-id='{$value->id}' data-type='status'>enabled</p>";
                }else{
                  $nestedData['status'] = "<p data-id='{$value->id}' data-type='status'>disabled</p>";
                }
                $nestedData['action'] = "&emsp;<a href='{$edit}' title='EDIT' ><span class='glyphicon glyphicon-edit'></span></a>";
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
  }

  public function edit($id)
  {
      $results = Product::findOrFail($id);
      return view('admin.stock.edit', compact('results'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function update($id, Request $request)
  {
  	  //return $request->all();
      $request->validate([
      	  'product_stock.*.product_option_detail_id.*' => 'exists:product_option_detail,id',
          'product_stock.*.qty' => 'numeric',
      ]);
      

      $store=Product::findOrFail($id);
      $product_option=$store->ProductOption;
      $totalqty=0;

      //$delps=ProductStock::whereProduct_id($store->id)->forceDelete();
      $store_id=[];
      foreach ($request['product_stock'] as $key => $value) {


      		

      	$product_stock=ProductStock::find($value['product_stock_id']);
      	$totalqty+=$value['qty'];

      	if(count($product_stock)==0){
      	  	$product_stock=new ProductStock();
        }
      	$product_stock->product_id=$store->id;
      	$product_stock->qty=$value['qty'];
      	$product_stock->sku=$value['sku'];
      	$product_stock->save();
      	$store_id[]=$product_stock->id;

      	$delpsd=ProductStockDetail::whereProduct_stock_id($product_stock->id)->forceDelete();
      	foreach($value['product_option_detail_id'] as $key=>$val){
      		$psd=new ProductStockDetail();
      		$psd->product_stock_id=$product_stock->id;
      		$psd->product_option_detail_id=$val;
      		$psd->save();
      	}
      }
      $delpsd=ProductStock::whereProduct_id($store->id)->whereNotIn('id',$store_id)->forceDelete();

      $store->qty=$totalqty;
      $store->save();
      $store->touch();
      
      return redirect('admin/stock')->with('success',$request['name'].' stock successfully updated.');
  }

  public function showIndexCombination(Request $request)
  {
      if(!empty($request->input('filter_option'))){
        $option=OptionValue::where('name','LIKE','%'.$request->input('filter_option').'%')->pluck('id')->toArray();
        $product_option_detail_id=ProductOptionDetail::WhereIn('option_value_id',$option)->pluck('id')->toArray();
      }else{
        $option=[];
        $product_option_detail_id=[];
      }

      
      $product_stock=ProductStock::select('*')
                      ->when (count($product_option_detail_id)>0 , function ($query) use($request,$product_option_detail_id){
                       $query->whereHas('ProductStockDetail', function ($query2) use ($request,$product_option_detail_id) {
                                        $query2->whereIn('product_option_detail_id',$product_option_detail_id);
                                    });
                      }) 
                      ->when (!empty($request->input('filter_comb_quantity')) , function ($query) use($request){
                        return $query->where('qty','<=', $request->input('filter_comb_quantity'));
                      })
                      ->when (!empty($request->input('filter_name')) , function ($query) use($request){
                        $query->whereHas('Product', function ($query2) use ($request) {
                                        $query2->where('name','LIKE', '%'.$request->input('filter_name').'%');
                                    });
                      })
                      ->when (!empty($request->input('filter_model')) , function ($query) use($request){
                        $query->whereHas('Product', function ($query2) use ($request) {
                                        $query2->where('model','LIKE', '%'.$request->input('filter_model').'%');
                                    });
                      })
                      ->when (!empty($request->input('filter_quantity')) , function ($query) use($request){
                        $query->whereHas('Product', function ($query2) use ($request) {
                                        $query2->where('qty','<=', $request->input('filter_quantity'));
                                    });
                      })
                      ->paginate(20);
      $products=[];
      $temp_id=[];
      foreach($product_stock as $key => $value){
        if(!in_array($value->product_id, $temp_id)){
          $product=Product::find($value->product_id);
          $products[]=$product;
          $temp_id[]=$value->product_id;
        }
      }
      
      return view('admin.stock.combination', compact('products', 'product_stock'));
  }

  public function report(Request $request)
  {
      $limit=$request['stock_module_report_limit'] ?: 3;
      

      
      $product_stock=ProductStock::where('qty','<', $limit)
                      ->get();
      $products=[];
      $temp_id=[];
      foreach($product_stock as $key => $value){
        if(!in_array($value->product_id, $temp_id)){
          $product=Product::find($value->product_id);
          $products[]=$product;
          $temp_id[]=$value->product_id;
        }
      }
      
      return view('admin.stock.report', compact('products', 'product_stock', 'limit'));
  }

  public function excelReport(Request $request)
  {
      $limit=$request['stock_module_report_limit'] ?: 3;
      
      $product_stock=ProductStock::where('qty','<', $limit)
                      ->get();
      $products=[];
      $temp_id=[];
      foreach($product_stock as $key => $value){
        if(!in_array($value->product_id, $temp_id)){
          $product=Product::find($value->product_id);
          $products[]=$product;
          $temp_id[]=$value->product_id;
        }
      }
      

        $array=[];
        // Define the Excel spreadsheet headers
        $array[] = ["Date Created : ".Carbon::now()->toFormattedDateString()];

        foreach ($products as $prod) {
          $object = new \stdClass();
          $object->name=$prod->name;
          $array[] = [$object->name, "SKU", "Quantity"];

          foreach($product_stock as $index => $stock){
            if($stock->product_id==$prod->id){
              $option_detail_name="";
            
              $stock_detail=$stock->ProductStockDetail;
              foreach($stock_detail as $key => $sd){
                $pod=$sd->ProductOptionDetail;
                if($key==0){
                  $option_detail_name.=$pod->OptionValue->name;
                }else{
                  $option_detail_name.=' / '.$pod->OptionValue->name;
                }
              }

              $array[] = [$option_detail_name, $stock->sku, $stock->qty];
            }
          }
              $array[] = ["", "", ""];         
        }

        // Generate and return the spreadsheet
        Excel::create('stock_report', function($excel) use ($array) {

            // Set the spreadsheet title, creator, and description
            $excel->setTitle('stock_report');
            $excel->setCreator(env('APP_NAME', 'Laravel'))->setCompany(env('APP_NAME', 'Laravel'));
            $excel->setDescription('Export Stock Report to excel');

            // Build the spreadsheet, passing in the payments array
            $excel->sheet('stock_report', function($sheet) use ($array) {

              $sheet->cell('A1', function($cell) {

                  // manipulate the cell
                  $cell->setFontSize(20);

              });
                $sheet->fromArray($array, null, 'A1', false, false);
            });

        })->download('xlsx');
  }

  public function updateCombination(Request $request)
  {
    $request->validate([
          'product_id' => 'exists:product,id',
          'product_combinations.*.combination_id' => 'exists:product_stock,id',
          'product_combinations.*.quantity' => 'numeric',
      ]);
    //return response()->json($request->all());
    $product=Product::find($request->input('product_id'));
    $prod_qty=0;
    foreach($request->input('product_combinations') as $key => $value){
      
      $prod_qty=$prod_qty+$value['quantity'];
      $comb=ProductStock::find($value['combination_id']);
      $comb->qty=$value['quantity'];
      $comb->sku=$value['sku'];
      $comb->save();
      $comb->touch();
    }
    $product->qty=$prod_qty;
    $product->save();
    $product->touch();

    return response()->json(['product_quantity' => $product->qty]);
  }
}
