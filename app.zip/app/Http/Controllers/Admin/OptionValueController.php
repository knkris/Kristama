<?php 

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Option;
use App\Models\OptionValue;

class OptionValueController extends Controller 
{


  /**
   * Display a listing of the resource.
   *
   * @return Response
   */
  public function index($id,Request $request)
  {
      $columns = array( 
                            0 =>'id', 
                            1 =>'name',
                            2 =>'sort_order',
                            3 =>'action'
                        );
  
        $totalData = OptionValue::whereOption_id($id)->count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        if(array_key_exists($request->input('order.0.column'), $columns)){
          $order = $columns[$request->input('order.0.column')];
        }else{
          $order = 'id';
        }
        if($request->input('order.0.dir')!==null){
          $dir = $request->input('order.0.dir');
        }else{
          $dir = 'asc';
        }
        
            
        if(empty($request->input('search.value')))
        {            
            $results = OptionValue::whereOption_id($id)->orderBy($order,$dir)->offset($start)->limit($limit)
                         ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $results =  OptionValue::whereOption_id($id)->where('name','LIKE',"%{$search}%")
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();

            $totalFiltered = OptionValue::whereOption_id($id)->where('name','LIKE',"%{$search}%")
                             ->count();
        }

        $data = array();
        if(!empty($results))
        {
            foreach ($results as $value)
            {
                $edit =  url('admin/option/edit',$value->id);

                $nestedData['id'] = "<input type='checkbox' name='selected[]'' value='{$value->id}'>";
                $nestedData['name'] = $value->name;
                $nestedData['sort_order'] = $value->sort_order;
                $nestedData['action'] = "&emsp;<a href='{$edit}' title='EDIT' ><span class='glyphicon glyphicon-edit'></span></a>";
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return Response
   */
  public function create()
  {
      return view('admin.option.create');
  }

  /**
   * Store a newly created resource in storage.
   *
   * @return Response
   */
  public function store(Request $request)
  {
      $request->validate([
          'name' => 'required|max:191',
          //'type' => 'required',
          'required' => 'required|numeric',
          'sort_order' => 'numeric'
      ]);
      

      $store=new option();
      $store->name=$request['name'];
      $store->type='select';
      $store->required=$request['required'];
      $store->sort_order=$request['sort_order'];
      $store->save();
      return redirect('admin/option')->with('success',$request['name'].' successfully added.');
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function show($id)
  {
      
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function edit($id)
  {
      $results = OptionValue::findOrFail($id);
      return view('admin.option.edit', compact('results'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function update($id, Request $request)
  {
      $request->validate([
          'name' => 'required|max:191',
          'image' => 'image|mimes:jpeg,png,jpg,gif,svg',
          'sort_order' => 'numeric'
      ]);
      $store=OptionValue::findOrFail($id);
      $store->name=$request['name'];
      $store->type='select';
      $store->required=$request['required'];

      $store->sort_order=$request['sort_order'];
      $store->save();
      $store->touch();
      return redirect('admin/option')->with('success',$request['name'].' successfully updated.');
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function destroy($id)
  {
    
  }

  public function trash(Request $request)
  {
      $request->validate([
          'selected' => 'array'
      ]);
      $count=count($request['selected']);
      if($count>0)
      {
        $delete=OptionValue::whereIn('id',$request['selected'])->delete();
        return back()->with('success', $count.' item has been deleted.');
      }
  }

  public function deleteImage($id)
  {
      $deleteimage=OptionValue::find($id);
      $deleteimage->image=null;
      $deleteimage->save();
      $deleteimage->touch();
      return back()->with('success', 'Image has been deleted.');
  }
  
}

?>