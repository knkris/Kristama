<?php 

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\ProductOption;
use App\Models\ProductOptionDetail;
use App\Models\Option;
use App\Models\OptionValue;
use App\Models\Category;
use App\Models\Manufacturer;
use App\Models\WeightClass;
use App\Models\LengthClass;
use App\Models\StockStatus;
use App\Models\ProductStock;
use App\Models\ProductStockDetail;
use App\Models\ProductToCategory;
use App\Models\Order;
use App\Models\OrderDetail;
use App\Models\OrderHistory;
use App\Models\OrderStatus;
use App\Models\User;
use App\Models\CustomerGroup;
use App\Models\Province;
use App\Models\Subdistrict;
use App\Models\City;
use App\Models\Address;
use App\Models\Blog;
use App\Models\ShippingMethod;
use App\Models\ShippingCourier;
use App\Models\PaymentMethod;
use Carbon\Carbon;
use Validator;
use Excel;
use Mail;

class OrderController extends Controller 
{
  public function showIndex()
  {
      $order_status = OrderStatus::get();
      return view('admin.order.index', compact('order_status'));
  }


  /**
   * Display a listing of the resource.
   *
   * @return Response
   */
  public function index(Request $request)
  {
      //return response()->json($request->all());
      $columns = array( 
                            0 =>'id', 
                            1 =>'invoice',
                            2 =>'name',
                            3 =>'status',
                            4 =>'total',
                            5 =>'created_at',
                            6 =>'updated+at',
                            7 =>'action',
                            8 =>'order_id',
                            9 =>'order_status_id'
                        );
  
        $totalData = Order::count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        if(array_key_exists($request->input('order.0.column'), $columns)){
          $order = $columns[$request->input('order.0.column')];
        }else{
          $order = 'id';
        }
        if($request->input('order.0.dir')!==null){
          $dir = $request->input('order.0.dir');
        }else{
          $dir = 'asc';
        }
        
            
        if(empty($request->input('search.value')))
        {   
          $results=Order::select('*')
                    ->when(!empty($request->input('date_range')) , function ($query) use($request){
                      $date_range=explode(' - ',$request->input('date_range'));
                      $start_date=Carbon::parse($date_range[0]);
                      $end=Carbon::parse($date_range[1]);
                      return $query->whereBetween('created_at',[$start_date,$end]);
                    })
                    ->when (!empty($request->input('order_status_id')) , function ($query) use($request){
                      return $query->where('order_status_id',$request->input('order_status_id'));
                    })
                    ->orderBy($order,$dir)->offset($start)->limit($limit)
                    ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $results =  Order::where('name','LIKE',"%{$search}%")
                              ->orWhere('email','LIKE',"%{$search}%")
                              ->orWhere('invoice','LIKE',"%{$search}%")
                              ->orWhere('fax','LIKE',"%{$search}%")
                              ->orWhere('payment_address','LIKE',"%{$search}%")
                              ->orWhere('payment_province','LIKE',"%{$search}%")
                              ->orWhere('payment_city','LIKE',"%{$search}%")
                              ->orWhere('payment_postal_code','LIKE',"%{$search}%")
                              ->orWhere('payment_method','LIKE',"%{$search}%")
                              ->orWhere('shipping_courier','LIKE',"%{$search}%")
                              ->orWhere('shipping_address','LIKE',"%{$search}%")
                              ->orWhere('shipping_province','LIKE',"%{$search}%")
                              ->orWhere('shipping_city','LIKE',"%{$search}%")
                              ->orWhere('shipping_postal_code','LIKE',"%{$search}%")
                              ->orWhereHas('OrderStatus', function ($query) use ($search) {
                                  $query->where('name_en','LIKE',"%{$search}%");
                              })
                              ->when(!empty($request->input('date_range')) , function ($query) use($request){
                                $date_range=explode(' - ',$request->input('date_range'));
                                $start_date=Carbon::parse($date_range[0]);
                                $end=Carbon::parse($date_range[1]);
                                return $query->whereBetween('created_at',[$start_date,$end]);
                              })
                              ->when (!empty($request->input('order_status_id')) , function ($query) use($request){
                                return $query->where('order_status_id',$request->input('order_status_id'));
                              })
                              ->offset($start)
                              ->limit($limit)
                              ->orderBy($order,$dir)
                              ->get();
            

            $totalFiltered = Order::where('name','LIKE',"%{$search}%")
                             ->orWhere('email','LIKE',"%{$search}%")
                             ->orWhere('invoice','LIKE',"%{$search}%")
                            ->orWhere('fax','LIKE',"%{$search}%")
                            ->orWhere('payment_address','LIKE',"%{$search}%")
                            ->orWhere('payment_province','LIKE',"%{$search}%")
                            ->orWhere('payment_city','LIKE',"%{$search}%")
                            ->orWhere('payment_postal_code','LIKE',"%{$search}%")
                            ->orWhere('payment_method','LIKE',"%{$search}%")
                            ->orWhere('shipping_courier','LIKE',"%{$search}%")
                            ->orWhere('shipping_address','LIKE',"%{$search}%")
                            ->orWhere('shipping_province','LIKE',"%{$search}%")
                            ->orWhere('shipping_city','LIKE',"%{$search}%")
                            ->orWhere('shipping_postal_code','LIKE',"%{$search}%")
                            ->orWhereHas('OrderStatus', function ($query) use ($search) {
                                $query->where('name_en','LIKE',"%{$search}%");
                            })->when(!empty($request->input('date_range')) , function ($query) use($request){
                                $date_range=explode(' - ',$request->input('date_range'));
                                $start_date=Carbon::parse($date_range[0]);
                                $end=Carbon::parse($date_range[1]);
                                return $query->whereBetween('created_at',[$start_date,$end]);
                              })
                              ->when (!empty($request->input('order_status_id')) , function ($query) use($request){
                                return $query->where('order_status_id',$request->input('order_status_id'));
                              })->count();
        }

        $data = array();
        if(!empty($results))
        {
            foreach ($results as $value)
            {
                $view =  url('admin/order/view',$value->id);
                $edit =  url('admin/order/edit/1',$value->id);

                $nestedData['id'] = "<input type='checkbox' name='selected[]'' value='{$value->id}'>";
                $nestedData['invoice'] = $value->invoice;
                $nestedData['name'] = $value->name;
                $nestedData['status'] = $value->OrderStatus->name_en;
                $nestedData['total'] = currency_format($value->total,'IDR');
                $nestedData['created_at'] = Carbon::parse($value->created_at)->format('d/m/Y H:i:s');
                $nestedData['updated_at'] = Carbon::parse($value->updated_at)->format('d/m/Y H:i:s');

                $nestedData['action'] = "<a class='btn btn-primary' href='{$view}' title='VIEW' ><span class='fa fa-eye'></span></a>
                <a class='btn btn-primary' href='{$edit}' title='EDIT' ><span class='fa fa-pencil'></span></a>";
                $nestedData['order_id'] = $value->id;
                $nestedData['order_status_id'] = $value->order_status_id;
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
  }

  public function create()
  {
    $customer_group=CustomerGroup::get();
    $province=Province::get();
    $orderstatus=OrderStatus::get();
    $payment_method=PaymentMethod::whereStatus(1)->get();
    $transfer_code=rand(100, 999);
    return view('admin.order.add', compact('customer_group', 'province', 'orderstatus', 'transfer_code', 'payment_method'));
  }

  public function store(Request $request)
  {
    //dd($request->all());
    // foreach($request['product'] as $key=>$product){
    //   if($product['product_stock_id']!==null){
    //     $stock=ProductStock::find($product['product_stock_id']);
    //   }else{
    //     $stock=new \stdClass();
    //     $stock->qty=$product->qty;
    //   }
    //   echo $product['id']."-".$product['product_stock_id']."-".$product['quantity']."==".$stock->qty."<br>";

    // }
    $request->validate([
        //'customer' => 'exists:users,id',
        'customer_group' => 'exists:customer_group,id',
        'name' => 'required|max:191',
        'email' => 'required|email|max:191',
        'telephone' => 'required',
        'payment_name' => 'required|max:191',
        'payment_company' => 'required|max:191',
        'payment_address' => 'required|max:191',
        'payment_city' => 'required|max:191',
        'payment_postal_code' => 'required|max:191',
        'payment_province' => 'required|max:191',
        'payment_telephone' => 'required|max:191',
        'shipping_name' => 'required|max:191',
        'shipping_company' => 'required|max:191',
        'shipping_address' => 'required|max:191',
        'shipping_city' => 'required|max:191',
        'shipping_postal_code' => 'required|max:191',
        'shipping_province' => 'required|max:191',
        'shipping_telephone' => 'required|max:191',
        'shipping_method' => 'required',
        'payment_method' => 'required',
        'order_status' => 'exists:order_status,id'
    ]);
    $user=User::whereName($request['name'])->first();

    $store=new Order();
    $store->invoice=$this->generateInvoice();
    $store->user_id=$user->id;
    $store->customer_group_id=$request['customer_group'];
    $store->name=$request['name'];
    $store->email=$request['email'];
    $store->telephone=$request['telephone'];
    $store->fax=$request['fax'];
    $store->payment_name=$request['payment_name'];
    $store->payment_company=$request['payment_company'];
    $store->payment_address=$request['payment_address'];
    $store->payment_city=$request['payment_city'];
    $store->payment_postal_code=$request['payment_postal_code'];
    $store->payment_province=$request['payment_province'];
    $store->payment_telephone=$request['payment_telephone'];
    $store->shipping_name=$request['shipping_name'];
    $store->shipping_company=$request['shipping_company'];
    $store->shipping_address=$request['shipping_address'];
    $store->shipping_city=$request['shipping_city'];
    $store->shipping_postal_code=$request['shipping_postal_code'];
    $store->shipping_province=$request['shipping_province'];
    $store->shipping_telephone=$request['shipping_telephone'];

    $shipping_method=explode("_",$request['shipping_method']);
    if(!is_array($shipping_method)){
      return back()->withInput()->with('error','Please select shipping method');
    }
    $store->shipping_courier=$shipping_method[0];
    $store->courier_service=$shipping_method[1];
    $store->shipping_cost=$shipping_method[2];
    $store->transfer_code=$request['transfer_code'];
    $store->payment_method=$request['payment_method'];
    $store->order_status_id=$request['order_status'];
    $store->comment=$request['comment'];
    $store->save();


    foreach($request['product'] as $key=>$prod){
      $product=Product::find($prod['id']);
      $sqty=0;
      foreach($request['product'] as $keys=>$tryfind){
        if($tryfind['id']==$prod['id']){
          $sqty=$sqty+$tryfind['quantity'];
        }
      }
      if($prod['product_stock_id']!==null){
        $stock=ProductStock::find($prod['product_stock_id']);
        $stock->qty=$stock->qty-(int)$prod['quantity'];
        $stock->save();
        $stock->touch();
      }else{
        $stock=new \stdClass();
        $stock->qty=$product->qty;
      }
      if((int)$prod['quantity']<1){
        $store->forceDelete();
        return back()->withInput()->with('error',$product->name.' value minimum is 1');
      }
      if((int)$prod['quantity']>$stock->qty){
        $store->forceDelete();
        return back()->withInput()->with('error',$product->name.' quantity may not be greater than '.$stock->qty);
      }
      

      $orderdetail=new OrderDetail();
      $orderdetail->order_id=$store->id;
      $orderdetail->product_id=$prod['id'];
      $orderdetail->qty=(int)$prod['quantity'];
      $orderdetail->product_stock_id=$prod['product_stock_id'];
      $orderdetail->price=$product->finalPrice($request['customer_group'],$sqty);
      $orderdetail->save();

      if($prod['product_stock_id']!==null){
      }
      $product->qty=$product->qty-(int)$prod['quantity'];
      $product->save();
      $product->touch();
    }

    $total=0;
    foreach ($store->OrderDetail as $key => $value) {
      $total=$total+($value->qty*$value->price);
    }
    $store->subtotal=$total;
    $store->total=$total+$store->transfer_code+$store->shipping_cost;
    $store->save();

    $oh=new OrderHistory();
    $oh->order_id=$store->id;
    $oh->order_status_id=1;
    $oh->notify=0;
    $oh->save();

    $payment_method=PaymentMethod::where('name','=',$store->payment_method)->first();
    if($oh->order_status_id==4){
      $payment_method->complete++;
    }
    $payment_method->used++;
    $payment_method->save();
    $payment_method->touch();

    return redirect('admin/order')->with('success','Add Order Success!');
    
  }

  public function edit($page=1,$id)
  {
      $results = Order::findOrFail($id);
      switch ($page) {
        case '1':
          $customer_group=CustomerGroup::get();
          return view('admin.order.edit', compact('results', 'customer_group'));
          break;

        case '2':
          $orderdetail=$results->OrderDetail;
          return view('admin.order.edit2', compact('results','orderdetail'));
          break;

        case '3':
          $province=Province::get();
          $address=Address::whereUser_id($results->user_id)->get();
          foreach ($address as $key => $value) {
            $subdistrict=$value->Subdistrict;
            $value->city=$subdistrict->city;
            $value->province=$subdistrict->province;
          }
          return view('admin.order.edit3', compact('results', 'province', 'address'));
          break;

        case '4':
          $province=Province::get();
          $address=Address::whereUser_id($results->user_id)->get();
          foreach ($address as $key => $value) {
            $subdistrict=$value->Subdistrict;
            $value->city=$subdistrict->city;
            $value->province=$subdistrict->province;
          }
          return view('admin.order.edit4', compact('results', 'province', 'address'));
          break;

        case '5':
          $orderdetail=$results->OrderDetail;
          $orderstatus=OrderStatus::get();
          $payment_method=PaymentMethod::whereStatus(1)->get();
          $weight=0;
          $gram=WeightClass::find(2);
          foreach($orderdetail as $od){
            $product=$od->Product;
            switch ($product->weight_class_id) {
              case '2':
                $temp=$product->weight*$od->qty;
                $weight=$weight+$temp;
                break;
              
              default:
                $temp=($product->weight*$gram->value)*$od->qty;
                $weight=$weight+$temp;
                break;
            }
          }
          $ship_method=ShippingMethod::whereStatus(1)->get();
          $shipping_option="<option>Choose Method</option>";
          foreach($ship_method as $key => $value){
            if($value->id==1 && $results->customer_group_id==$value->customer_group_id){
              $courier=ShippingCourier::whereStatus(1)->pluck('code');

              $shipping_city=explode(" - ",$results->shipping_city);
              $subdistrict=Subdistrict::whereName($shipping_city[0])->first();
              foreach ($courier as $key => $value) {
                
                if(count($subdistrict)>0){
                  $getcost=json_decode($this->getCost(env('APP_ORIGINID', 2087),env('APP_ORIGINTYPE', 'subdistrict'),$subdistrict->id,'subdistrict',$weight,$value))->rajaongkir->results;
                  foreach ($getcost[0]->costs as $ser) {
                    switch ($ser->service) {
                      case 'CTC':
                        $service="CTC REG";
                        break;
                      case 'CTCYES':
                        $service="CTC YES";
                        break;
                      case 'CTCOKE':
                        $service="CTC OKE";
                        break;
                      
                      default:
                        $service=$ser->service;
                        break;
                    }
                      
                    $shipping_option.="<option value='".strtoupper($value)."_".$ser->service."_".$ser->cost[0]->value."'>".strtoupper($getcost[0]->code)." - ".$service." - ".currency_format($ser->cost[0]->value,'IDR')."</option>";
                  }
                }

              }
            }elseif ($value->id==2 && $results->customer_group_id==$value->customer_group_id) {
              $freeshipping=$value->FreeShipping()->whereStatus(1)->get();
              $free=false;
              foreach ($freeshipping as $key => $value) {
                $check_province=false;
                $check_category=false;
                $check_product=false;
                $check_subtotal=false;
                $province=$value->FreeShippingToProvince()->pluck('province_id')->toArray();
                $category=$value->FreeShippingToCategory()->pluck('category_id')->toArray();
                $filter_product=$value->FreeShippingToProduct()->pluck('product_id')->toArray();

                //check province
                if(count($province)>0){
                  $shipping_province_id=Province::whereName($results->shipping_province)->first()->id;
                  if(in_array($shipping_province_id, $province)){
                    $check_province=true;
                  }else{
                    $check_province=false;
                  }
                }else{
                  $check_province=true;
                }

                //check category
                if(count($category)>0){
                  foreach($orderdetail as $od){
                    $product_category=ProductToCategory::whereProduct_id($od->product_id)->first()->category_id;
                    if(in_array($product_category, $category)){
                      $check_category=true;
                    }else{
                      $check_category=false;
                    }
                  }
                }else{
                  $check_category=true;
                }

                //check product
                if(count($filter_product)>0){
                  foreach($orderdetail as $od){
                    if(in_array($od->product_id, $filter_product)){
                      $check_product=true;
                    }else{
                      $check_product=false;
                    }
                  }
                }else{
                  $check_product=true;
                }

                //check subtotal
                foreach($orderdetail as $od){
                    $subtotal=0;
                    $product=Product::find($od->product_id);
                    $subtotal=$subtotal+((int)$od->price*$od->qty);
                }
                if($subtotal>=$value->subtotal){ $check_subtotal=true; }  

                if($check_province==true && $check_category==true && $check_product==true && $check_subtotal==true){ $free=true; }
              }
              if($free==true){
                $shipping_option.="<option value='FREE_SHIPPING_0'>Free Shipping</option>";
              }
            }
          }
          $log="weight=".$weight." sub_id=".$subdistrict->id;
          
          return view('admin.order.edit5', compact('results','orderdetail', 'shipping_option', 'orderstatus','log', 'payment_method'));
          break;
        
        default:
          # code...
          break;
      }
      
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function update($page=1,$id, Request $request)
  {
      //return $request->all();
      switch ($page) {
        case '1':
          $request->validate([
              'customer' => 'exists:users,id',
              'customer_group' => 'exists:customer_group,id',
              'name' => 'required|max:191',
              'email' => 'required|email|max:191',
              'telephone' => 'required',
          ]);
          

          $store=Order::findOrFail($id);
          $store->user_id=$request['customer'];
          $store->customer_group_id=$request['customer_group'];
          $store->name=$request['name'];
          $store->email=$request['email'];
          $store->telephone=$request['telephone'];
          $store->fax=$request['fax'];
          $store->save();
          $store->touch();
          
          return redirect('admin/order/edit/2/'.$id);
          break;

        case '2':
          //return $request->all();
          $check=Order::findOrFail($id);
          $product=Product::findOrFail($request['product']);
          if($request['product_stock_id']!==null){
            $stock=ProductStock::findOrFail($request['product_stock_id']);
          }else{
            $stock=new \stdClass();
            $stock->qty=$product->qty;
          }
          $request->validate([
              'product' => 'exists:product,id',
              'qty' => 'required|numeric|min:1|max:'.$stock->qty,
          ],[
              'qty.required' => 'The Quantity is required!',
              'qty.numeric' => 'The Quantity value must be numeric!',
              'qty.min' => 'The Quantity value minimum is :min',
              'qty.max' => 'The Quantity may not be greater than :max'
          ]);
          $product=Product::find($request['product']);
          if(count($product->ProductOption)>0){
            $request->validate([
              'product_stock_id' => 'required'
            ],[
              'required' => 'You must choose an option'
            ]);

            
          }
          
          

          $store=OrderDetail::whereOrder_id($id)->whereProduct_id($request['product'])->whereProduct_stock_id($request['product_stock_id'])->first();
          if(count($store)>0){
            $store->qty=$store->qty+$request['qty'];
            $store->save();
            $store->touch();
          }else{
            $store=new OrderDetail();
            $store->order_id=$id;
            $store->product_id=$request['product'];
            $store->qty=$request['qty'];
            $store->product_stock_id=$request['product_stock_id'];
            $store->price=$product->price;
            $store->save();
          }
          $total=0;
          foreach ($check->OrderDetail as $key => $value) {
            $total=$total+($value->qty*$value->price);
          }
          $check->subtotal=$total;
          $check->total=$total;
          $check->save();
          $check->touch();
          if($request['product_stock_id']!==null){
            $stock->qty=$stock->qty-$request['qty'];
            $stock->save();
            $stock->touch();
          }
          $product->qty=$product->qty-$request['qty'];
          $product->save();
          $product->touch();

          if($request->ajax()){
              return response()->json($store);
          }
          
          return redirect('admin/order/edit/3/'.$id);
          break;

        case '3':
          $request->validate([
              'name' => 'required|max:191',
              'company' => 'required|max:191',
              'address' => 'required|max:191',
              'city' => 'required|max:191',
              'postal_code' => 'required|max:191',
              'province' => 'required|max:191',
              'telephone' => 'required|max:191',
          ]);
          

          $store=Order::findOrFail($id);
          $store->payment_name=$request['name'];
          $store->payment_company=$request['company'];
          $store->payment_address=$request['address'];
          $store->payment_city=$request['city'];
          $store->payment_postal_code=$request['postal_code'];
          $store->payment_province=$request['province'];
          $store->payment_telephone=$request['telephone'];
          $store->save();
          $store->touch();
          
          return redirect('admin/order/edit/4/'.$id);
          break;

        case '4':
          $request->validate([
              'name' => 'required|max:191',
              'company' => 'required|max:191',
              'address' => 'required|max:191',
              'city' => 'required|max:191',
              'postal_code' => 'required|max:191',
              'province' => 'required|max:191',
              'telephone' => 'required|max:191',
          ]);
          

          $store=Order::findOrFail($id);
          $store->shipping_name=$request['name'];
          $store->shipping_company=$request['company'];
          $store->shipping_address=$request['address'];
          $store->shipping_city=$request['city'];
          $store->shipping_postal_code=$request['postal_code'];
          $store->shipping_province=$request['province'];
          $store->shipping_telephone=$request['telephone'];
          $store->save();
          $store->touch();
          
          return redirect('admin/order/edit/5/'.$id);
          break;

        case '5':
          $request->validate([
              'shipping_method' => 'required',
              'payment_method' => 'required',
              'order_status' => 'exists:order_status,id'
          ]);
          
          $shipping_method=explode("_",$request['shipping_method']);
          $store=Order::findOrFail($id);

          if($store->payment_method!==$request['payment_method']){
            $payment_method=PaymentMethod::where('name','=',$store->payment_method)->first();
            if($store->order_status_id==4){
              $payment_method->complete--;
            }
            $payment_method->used--;
            $payment_method->save();
            $payment_method->touch();

            $payment_method=PaymentMethod::where('name','=',$request['payment_method'])->first();
            if($store->order_status_id==4){
              $payment_method->complete++;
            }
            $payment_method->used++;
            $payment_method->save();
            $payment_method->touch();
          }

          $store->shipping_courier=$shipping_method[0];
          $store->courier_service=$shipping_method[1];
          $store->shipping_cost=$shipping_method[2];
          $store->total=$store->subtotal+$store->transfer_code+$store->shipping_cost;
          $store->payment_method=$request['payment_method'];
          $store->order_status_id=$request['order_status'];
          $store->comment=$request['comment'];
          $store->save();
          $store->touch();
          
          return redirect('admin/order')->with('Success!', 'Order ID '.$store->id.' has been updated!', 'success');
          break;
        
        default:
          # code...
          break;
      }
      
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function show($id)
  {
    $results=Order::findOrFail($id);
    $user=$results->User;
    $orderstatus=OrderStatus::get();
    return view('admin.order.view', compact('results', 'user', 'orderstatus'));
  }

  public function trash(Request $request)
  {
      $request->validate([
          'selected' => 'array'
      ]);
      $count=count($request['selected']);
      if($count>0)
      {
        $delete=Order::whereIn('id',$request['selected'])->delete();
        return back()->with('success', $count.' order has been deleted.');
      }
  }

  public function exportToExcel(Request $request)
  {
    $request->validate([
        'selected' => 'array'
    ]);
    $count=count($request['selected']);
    if($count>0)
    {
      $export=Order::whereIn('id',$request['selected'])->get();

      $array=[];
      // Define the Excel spreadsheet headers
      $array[] = ["Date Created : ".Carbon::now()->toFormattedDateString()];
      $array[] = ['Order Id', 'Name', 'Status', 'Total', 'Created At', 'Updated At'];

      foreach ($export as $exp) {
        $object = new \stdClass();
        $object->order_id=$exp->id;
        $object->name=$exp->name;
        $object->status=$exp->OrderStatus->name_en;
        $object->total=currency_format($exp->total,'IDR');
        $object->created_at= Carbon::parse($exp->created_at)->format('d/m/Y H:i:s');
        $object->updated_at= Carbon::parse($exp->updated_at)->format('d/m/Y H:i:s');
        $array[] = [$object->order_id, $object->name, $object->status, $object->total, $object->created_at, $object->updated_at];
      }

      // Generate and return the spreadsheet
      Excel::create('exported', function($excel) use ($array) {

          // Set the spreadsheet title, creator, and description
          $excel->setTitle('Picklist');
          $excel->setCreator(env('APP_NAME', 'Kreasi2shop'))->setCompany(env('APP_NAME', 'Kreasi2shop'));
          $excel->setDescription('Export order to excel');

          // Build the spreadsheet, passing in the payments array
          $excel->sheet('sheet1', function($sheet) use ($array) {

            $sheet->cell('A1', function($cell) {

                // manipulate the cell
                $cell->setFontSize(20);

            });
              $sheet->fromArray($array, null, 'A1', false, false);
          });

      })->download('xlsx');
    }
  }

  public function addHistory($id,Request $request)
  {

    $results=Order::findOrFail($id);
    $request->validate([
              'order_status' => 'exists:order_status,id'
          ]);

    if($request['order_status_id']==4){
      $checkCompletedBefore=$results->OrderHistory()->whereOrder_status_id(4)->count();
      if($checkCompletedBefore<1){
        $payment_method=PaymentMethod::where('name','=',$results->payment_method)->first();
        $payment_method->complete++;
        $payment_method->save();
        $payment_method->touch();
      }
    }


    $orderhistory=new OrderHistory();
    $orderhistory->order_id=$id;
    $orderhistory->order_status_id=$request['order_status'];
    if($request['notify']!=null){
      $orderhistory->notify=$request['notify'];
    }else{
      $orderhistory->notify=0;
    }
    $orderhistory->comment=$request['comment'];
    $orderhistory->save();

    $results->order_status_id=$request['order_status'];
    $results->save();
    $results->touch();

    if($request['order_status_id']==11 && $request['notify']){
      Mail::send('mail.checkout', ['user'=>$results->User, 'order'=>$results], function($message) use ($results) {
                 $message->to($results->User->email, $results->User->firstname)
                     ->subject('Perbayaran Pesanan '. $results->invoice .' Telah Diterima.');
             });
    }

    if($request['order_status_id']==3 && $request['notify']){
      Mail::send('mail.orderSent', ['user'=>$results->User, 'order'=>$results], function($message) use ($results) {
                 $message->to($results->User->email, $results->User->firstname)
                     ->subject('Pesanan '. $results->invoice .' Telah Dikirim.');
             });
    }


    return redirect('admin/order/view/'.$id)->with('success', 'Success Add History!');
  }

  public function quickAddOrderHistory($id,Request $request)
  {
    // return response()->json($request->all());
    $results=Order::find($id);
    if(count($results)){
      $request->validate([
                'order_status_id' => 'exists:order_status,id'
            ]);

      if($request['order_status_id']==4){
        $checkCompletedBefore=$results->OrderHistory()->whereOrder_status_id(4)->count();
        if($checkCompletedBefore<1){
          $payment_method=PaymentMethod::where('name','=',$results->payment_method)->first();
          $payment_method->complete++;
          $payment_method->save();
          $payment_method->touch();
        }
      }


      $orderhistory=new OrderHistory();
      $orderhistory->order_id=$id;
      $orderhistory->order_status_id=$request['order_status_id'];
      if($request['notify']!=null){
        $orderhistory->notify=$request['notify'];
      }else{
        $orderhistory->notify=0;
      }
      $orderhistory->comment=$request['comment'];
      $orderhistory->save();

      $results->order_status_id=$request['order_status_id'];
      $results->save();
      $results->touch();

      if($request['order_status_id']==11 && $request['notify']=="1"){
        Mail::send('mail.checkout', ['user'=>$results->User, 'order'=>$results], function($message) use ($results) {
                   $message->to($results->User->email, $results->User->firstname)
                       ->subject('Perbayaran Pesanan '. $results->invoice .' Telah Diterima.');
               });
      }

      if($request['order_status_id']==3 && $request['notify']=="1"){
        Mail::send('mail.orderSent', ['user'=>$results->User, 'order'=>$results], function($message) use ($results) {
                   $message->to($results->User->email, $results->User->firstname)
                       ->subject('Pesanan '. $results->invoice .' Telah Dikirim.');
               });
      }


      return response()->json([$results,$orderhistory]);
    }else{
      return response()->json(['error' => 'Order Not Found!']);
    }
  }

  public function searchUser(Request $request)
  {
      $term = trim($request->q);

      // if (empty($term)) {
      //     return \Response::json([]);
      // }

      $results = User::where('name', 'LIKE', '%'.$term.'%')->limit(5)->get();

      $formatted_results = [];

      foreach ($results as $val) {
          $formatted_results[] = ['id' => $val->id, 'text' => $val->name];
      }

      return response()->json($formatted_results);
  }

  public function getUser($id)
  {
    $user=User::find($id);
    return response()->json($user);
  }

  public function searchProduct(Request $request)
  {
      $term = trim($request->q);

      // if (empty($term)) {
      //     return \Response::json([]);
      // }

      $results = Product::where('name', 'LIKE', '%'.$term.'%')->limit(5)->get();

      $formatted_results = [];

      foreach ($results as $val) {
          $formatted_results[] = ['id' => $val->id, 'text' => $val->name];
      }

      return response()->json($formatted_results);
  }

  public function getProduct($cust_group,$id,$stock_id,$qty=1,$sqty=1)
  {
    $sqty=$sqty;
    $product=Product::find($id);
    $stock=ProductStock::find($stock_id);
    $stockDetail=$stock->ProductStockDetail;
    $price=$product->finalPrice($cust_group,$sqty);
    $product->price_idr=currency_format($price,'IDR');
    $product->subtotal=$price*$qty;
    $product->subtotal_idr=currency_format($price*$qty,'IDR');
    $product->price=$price;
    foreach($stockDetail as $val){
      $ov=$val->ProductOptionDetail->OptionValue;
      $options[]=$ov->Option->name.": ".$ov->name;
      
    }
    $product->options=$options;
    return response()->json($product);
  }

  public function getProductOption($id)
  {
    $productoption=ProductOption::whereProduct_id($id)->get();
    foreach($productoption as $po){
      $po->Product;
      $po->name=$po->Option->name;
      $productoptiondetail=$po->ProductOptionDetail;
      foreach ($productoptiondetail as $k => $pod) {
        $pod->name=$pod->OptionValue->name;
      }
      $po->options=$productoptiondetail;
    }
    
    return response()->json($productoption);
  }

  public function searchAddressByUser($id, Request $request)
  {
    $term = trim($request->q);


    $results = Address::whereUser_id($id)
        ->where(function ($query) use($term) {
                $query->where('name', 'LIKE', '%'.$term.'%')
                      ->orWhere('company', 'LIKE', '%'.$term.'%')
                      ->orWhere('address', 'LIKE', '%'.$term.'%');
            })
        
        ->limit(5)->get();

    $formatted_results = [];

    foreach ($results as $val) {
        $subdistrict=$val->Subdistrict;
        $formatted_results[] = ['id' => $val->id, 'text' => $val->name.', '.$val->address.', '.$subdistrict->city.', '.$subdistrict->Province->name];
    }

    return response()->json($formatted_results);
  }

  public function searchAddress($id, Request $request)
  {
    $order=Order::find($id);
    $term = trim($request->q);


    $results = Address::where('name', 'LIKE', '%'.$term.'%')
        ->orWhere('company', 'LIKE', '%'.$term.'%')
        ->orWhere('address', 'LIKE', '%'.$term.'%')
        ->whereUser_id($order->user_id)
        ->limit(5)->get();

    $formatted_results = [];

    foreach ($results as $val) {
        $formatted_results[] = ['id' => $val->id, 'text' => $val->name.', '.$val->address.', '.$val->city.', '.$val->province];
    }

    return response()->json($formatted_results);
  }

  public function getAddressByUser($id, Request $request)
  {
    $address=Address::whereUser_id($id)->whereId($request['id'])->first();
    $subdistrict=$address->Subdistrict;
    $address->city=$subdistrict->name.' - '.$subdistrict->type.' '.$subdistrict->city;
    $address->postal_code=$address->postal_code;
    $address->province=$subdistrict->province;
    
    return response()->json($address);
  }

  public function getAddress($id, Request $request)
  {
    $order=Order::find($id);
    $address=Address::whereUser_id($order->user_id)->whereId($request['id'])->first();
    $subdistrict=$address->Subdistrict;
    $address->city=$subdistrict->name.' - '.$subdistrict->type.' '.$subdistrict->city;
    $address->postal_code=$address->postal_code;
    $address->province=$subdistrict->province;
    
    return response()->json($address);
  }

  public function searchCity(Request $request)
  {
    $term = trim($request->q);


      $results = Subdistrict::where('name', 'LIKE', '%'.$term.'%')
          ->orWhere('province', 'LIKE', '%'.$term.'%')
          ->orWhere('city', 'LIKE', '%'.$term.'%')
          ->limit(5)->get();

      $formatted_results = [];

    foreach ($results as $val) {
        $formatted_results[] = ['id' => $val->name.' - '.$val->type.' '.$val->city, 'text' => $val->name.' - '.$val->type.' '.$val->city];
    }

    return response()->json($formatted_results);
  }

  public function searchBlog(Request $request)
  {
    $term = trim($request->q);


    $results = Blog::where('title', 'LIKE', '%'.$term.'%')
        ->orWhere('content', 'LIKE', '%'.$term.'%')
        ->limit(5)->get();

    $formatted_results = [];

    foreach ($results as $val) {
        $formatted_results[] = ['id' => $val->id, 'text' => $val->title];
    }

    return response()->json($formatted_results);
  }

  public function checkStock(Request $request)
  {
    //return $request->all();
    $temp=[];
    $flag=0;
    $stockid=0;

    if($request['combination']!==null && count($request['combination'])==1){
      $temp=ProductStockDetail::whereProduct_option_detail_id($request['combination'][0])->first();
      $stockid=$temp->product_stock_id;
      $ps=ProductStock::find($stockid);
      return response()->json($ps);
    }elseif($request['combination']!==null && count($request['combination'])>1){
      $temp=ProductStockDetail::whereProduct_option_detail_id($request['combination'][0])->get();
      for($x=1;$x<count($request['combination']);$x++) {
        foreach ($temp as $key => $value) {
          $try=ProductStockDetail::whereProduct_stock_id($value->product_stock_id)
            ->whereProduct_option_detail_id($request['combination'][$x])
            ->first();
            if(count($try)>0){
              $stockid=$try->product_stock_id;
            }
        }
      }
      
      $ps=ProductStock::find($stockid);
      return response()->json($ps);
    }//check combination request
  }

  public function updateQty($id, Request $request)
  {
    $orderdetail=OrderDetail::find($id);
    if(count($orderdetail)>0){
      $stock=ProductStock::find($orderdetail->product_stock_id);
      $product=Product::find($orderdetail->product_id);
      if(count($stock)>0){
        $maxqty=$stock->qty;
      }else{
        $maxqty=$product->qty;
      }
      
      $request->validate([
          'qty' => 'required|numeric|min:1|max:'.$maxqty,
      ],[
          'qty.required' => 'The Quantity is required!',
          'qty.numeric' => 'The Quantity value must be numeric!',
          'qty.min' => 'The Quantity value minimum is :min',
          'qty.max' => 'The Quantity may not be greater than :max'
      ]);
      $diff=$orderdetail->qty-$request['qty'];
      $orderdetail->qty=$request['qty'];
      $orderdetail->save();
      $orderdetail->touch();
      $stock->qty=$stock->qty+$diff;
      $stock->save();
      $stock->touch();
      $product=Product::find($orderdetail->product_id);
      $product->qty=$product->qty+$diff;
      $product->save();
      $product->touch();

      $total=0;
      $check=Order::find($orderdetail->order_id);
      foreach ($check->OrderDetail as $key => $value) {
        $total=$total+($value->qty*$value->price);
      }
      $check->subtotal=$total;
      $check->total=$total;
      $check->save();
      $check->touch();

      $orderdetail->price_idr=currency_format($orderdetail->price,'IDR');
      $orderdetail->total_idr=currency_format($orderdetail->price*$orderdetail->qty,'IDR');
      return response()->json($orderdetail);
    }else{
      return response()->json("['err' => 'Not Found']",404);
    }
  }

  public function deleteDetail($id,Request $request)
  {
    $orderdetail=OrderDetail::find($id);
    $qty=$orderdetail->qty;
    if($orderdetail->product_stock_id!=null){
      $stock=ProductStock::find($orderdetail->product_stock_id);
      $stock->qty=$stock->qty+$qty;
      $stock->save();
      $stock->touch();
    }
    $product=Product::find($orderdetail->product_id);
    $product->qty=$product->qty+$qty;
    $product->save();
    $product->touch();

    return response()->json('success');
  }

  public function printInvoice(Request $request)
    {

      $request->validate([
          'selected' => 'array'
      ]);
      $count=count($request['selected']);
      if($count>0)
      {
        $orders=Order::whereIn('id',$request['selected'])->get();
        // Generate and return the view
        return view('admin.order.invoice',compact('orders'));
      }

      return back();
    }

  public function printShippingLabel(Request $request)
  {

    $request->validate([
        'selected' => 'array'
    ]);
    $count=count($request['selected']);
    if($count>0)
    {
      $orders=Order::whereIn('id',$request['selected'])->get();
      // Generate and return the view
      return view('admin.order.shippinglabel',compact('orders'));
    }

    return back();
  }

  public function getShippingCost(Request $request)
  {
      //return response()->json($request->all());
      $weight=0;
      $gram=WeightClass::find(2);
      foreach ($request['product'] as $key => $value) {
        $product=Product::find($value['id']);
        switch ($product->weight_class_id) {
          case '2':
            $temp=$product->weight*$value['quantity'];
            $weight=$weight+$temp;
            break;
          
          default:
            $temp=($product->weight*$gram->value)*$value['quantity'];
            $weight=$weight+$temp;
            break;
        }
      }
      
      $ship_method=ShippingMethod::whereStatus(1)->get();
      $shipping_option="<option>Choose Method</option>";
      foreach($ship_method as $key => $value){
        if($value->id==1 && $request['customer_group']==$value->customer_group_id){
          $courier=ShippingCourier::whereStatus(1)->pluck('code');

          $shipping_city=explode(" - ",$request['shipping_city']);
          $subdistrict=Subdistrict::whereName($shipping_city[0])->first();
          foreach ($courier as $key => $value) {
            
            if(count($subdistrict)>0){
              $getcost=json_decode($this->getCost(env('APP_ORIGINID', 2087),env('APP_ORIGINTYPE', 'subdistrict'),$subdistrict->id,'subdistrict',$weight,$value))->rajaongkir->results;
              foreach ($getcost[0]->costs as $ser) {
                switch ($ser->service) {
                  case 'CTC':
                    $service="CTC REG";
                    break;
                  case 'CTCYES':
                    $service="CTC YES";
                    break;
                  case 'CTCOKE':
                    $service="CTC OKE";
                    break;
                  
                  default:
                    $service=$ser->service;
                    break;
                }
                  
                $shipping_option.="<option value='".strtoupper($value)."_".$ser->service."_".$ser->cost[0]->value."'>".strtoupper($getcost[0]->code)." - ".$service." - ".currency_format($ser->cost[0]->value,'IDR')."</option>";
              }
            }

          }
        }elseif ($value->id==2 && $request['customer_group']==$value->customer_group_id) {
          $freeshipping=$value->FreeShipping()->whereStatus(1)->get();
          $free=false;
          foreach ($freeshipping as $key => $value) {
            $check_province=false;
            $check_category=false;
            $check_product=false;
            $check_subtotal=false;
            $province=$value->FreeShippingToProvince()->pluck('province_id')->toArray();
            $category=$value->FreeShippingToCategory()->pluck('category_id')->toArray();
            $filter_product=$value->FreeShippingToProduct()->pluck('product_id')->toArray();

            //check province
            if(count($province)>0){
              $shipping_province_id=Province::whereName($request['shipping_province'])->first()->id;
              if(in_array($shipping_province_id, $province)){
                $check_province=true;
              }else{
                $check_province=false;
              }
            }else{
              $check_province=true;
            }

            //check category
            if(count($category)>0){
              foreach($request['product'] as $od){
                $product_category=ProductToCategory::whereProduct_id($od['id'])->first()->category_id;
                if(in_array($product_category, $category)){
                  $check_category=true;
                }else{
                  $check_category=false;
                }
              }
            }else{
              $check_category=true;
            }

            //check product
            if(count($filter_product)>0){
              foreach($request['product'] as $od){
                if(in_array($od['id'], $filter_product)){
                  $check_product=true;
                }else{
                  $check_product=false;
                }
              }
            }else{
              $check_product=true;
            }

            //check subtotal
            foreach($request['product'] as $od){
                $subtotal=0;
                $product=Product::find($od['id']);
                $subtotal=$subtotal+((int)$product->price*$od['quantity']);
            }
            if($subtotal>=$value->subtotal){ $check_subtotal=true; }  

            if($check_province==true && $check_category==true && $check_product==true && $check_subtotal==true){ $free=true; }
          }
          if($free==true){
            $shipping_option.="<option value='FREE_SHIPPING_0'>Free Shipping</option>";
          }
        }
      }
      return response()->json($shipping_option);
  }

  public function generateInvoice($prefix='INV')
  {
    //get last record
    $record = Order::latest()->first();
    if(count($record)>0){
      $expNum = explode('/', $record->invoice);

      //check first day in a year
      if($expNum[1]!=date('Y')) {
          $nextInvoiceNumber = $prefix.'/'.date('Y').'/00000001';
      } else {
          $last=$expNum[2]+1;
          //increase 1 with last invoice number
          $nextInvoiceNumber = $prefix.'/'.$expNum[1].'/'. str_pad($last, 8, '0', STR_PAD_LEFT);;
      }
    }else{
      $nextInvoiceNumber = $prefix.'/'.date('Y').'/00000001';
    }

    return $nextInvoiceNumber;
  }

  public function testCost()
  {
    dd(json_decode($this->getCost(2087,'subdistrict',765,'subdistrict',1000,'jne'))->rajaongkir->results);
  }
  
}

?>