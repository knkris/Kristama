<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Coupon;
use App\Models\CouponCategory;
use App\Models\CouponProduct;
use App\Models\Category;
use Carbon\Carbon;

class CouponController extends Controller
{
  public function showIndex()
  {
      $results = Coupon::orderBy('created_at')->paginate(20);
      return view('admin.coupon.index', compact('results'));
  }

  /**
   * Display a listing of the resource.
   *
   * @return Response
   */
  public function index(Request $request)
  {
      $columns = array( 
                            0 =>'id', 
                            1 =>'name',
                            2 =>'code',
                            3 =>'discount',
                            4 =>'max_discount',
                            5 =>'start_date',
                            6 =>'end_date',
                            7 =>'status',
                        );
  
        $totalData = Coupon::count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        if(array_key_exists($request->input('order.0.column'), $columns)){
          $order = $columns[$request->input('order.0.column')];
        }else{
          $order = 'id';
        }
        if($request->input('order.0.dir')!==null){
          $dir = $request->input('order.0.dir');
        }else{
          $dir = 'asc';
        }
        
            
        if(empty($request->input('search.value')))
        {            
            $results = Coupon::orderBy($order,$dir)->offset($start)->limit($limit)
                         ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $results =  Coupon::where('name','LIKE',"%{$search}%")
                            ->orWhere('code','LIKE',"%{$search}%")
                            ->orWhere('start_date','LIKE',"%{$search}%")
                            ->orWhere('end_date','LIKE',"%{$search}%")
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();

            $totalFiltered = Coupon::where('name','LIKE',"%{$search}%")
                            ->orWhere('code','LIKE',"%{$search}%")
                            ->orWhere('start_date','LIKE',"%{$search}%")
                            ->orWhere('end_date','LIKE',"%{$search}%")
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();
        }

        $data = array();
        if(!empty($results))
        {
            foreach ($results as $value)
            {
                $edit =  url('admin/coupon/edit',$value->id);

                $nestedData['id'] = "<input type='checkbox' name='selected[]'' value='{$value->id}'>";
                $nestedData['name'] = $value->name;
                $nestedData['code'] = $value->code;
                switch ($value->type) {
                	case 'P':
                		$nestedData['discount'] = (string)($value->discount+0);
                		$nestedData['discount'] = $nestedData['discount']."%";
                		break;

            		case 'F':
                		$nestedData['discount'] = currency_format($value->discount,'IDR');
                		break;
                	
                	default:
                		# code...
                		break;
                }
                $nestedData['max_discount'] = $value->max_discount>0 ? currency_format($value->max_discount,'IDR') : "";
                $nestedData['start_date'] = Carbon::parse($value->start_date)->format('d/m/Y');
                $nestedData['end_date'] = Carbon::parse($value->end_date)->format('d/m/Y');
                $nestedData['status'] = $value->status;
                $nestedData['action'] = "&emsp;<a href='{$edit}' title='EDIT' ><span class='glyphicon glyphicon-edit'></span></a>";
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return Response
   */
  public function create()
  {
  	  $category=Category::get();
      return view('admin.coupon.create', compact('category'));
  }

  /**
   * Store a newly created resource in storage.
   *
   * @return Response
   */
  public function store(Request $request)
  {
      $request->validate([
          'name' => 'required|max:191',
          'code' => 'required|unique:coupon,code',
          'type' => 'required',
          'discount' => 'required|numeric|min:1',
          'shipping' =>'required',
          'start_date' =>'required|date',
          'end_date' =>'required|date',
          'uses_total' => 'required|numeric',
          'uses_customer' => 'required|numeric',
          'status' =>'required',
      ]);
	  	$store=new Coupon();
	  	$store->name=$request['name'];
	  	$store->code=strtoupper($request['code']);
	  	$store->type=$request['type'];
	  	$store->discount=$request['discount'];
	  	if($request['type']==="P"){
	  		$store->max_discount=$request['max_discount'];
	  	}
	  	if($request['min_order']>0){
	  		$store->min_order=$request['min_order'];
	  	}
	  	$store->free_shipping=$request['shipping'];
	    $store->start_date=Carbon::createFromFormat('d-m-Y', $request['start_date']);
	    $store->end_date=Carbon::createFromFormat('d-m-Y', $request['end_date']);
      $store->uses_total=$request['uses_total'];
      $store->uses_customer=$request['uses_customer'];
	    $store->status=$request['status'];
	  	$store->save();

	  	if(count($request['rel_product'])>0){
	  		foreach ($request['rel_product'] as $key => $value) {
	            $prod=new CouponProduct();
	            $prod->coupon_id=$store->id;
	            $prod->product_id=$value;
	            $prod->save();
	        }
	  	}
	  	if(count($request['category'])>0){
	  		foreach ($request['category'] as $key => $value) {
	            $prod=new CouponCategory();
	            $prod->coupon_id=$store->id;
	            $prod->category_id=$value;
	            $prod->save();
	        }
	  	}
      
      
      return redirect('admin/coupon')->with('success',$request['name'].' coupon successfully created.');
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function show($id)
  {
      
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function edit($id)
  {
  	  $category=Category::get();
      $results = Coupon::findOrFail($id);
      $couponcategory = $results->CouponCategory()->pluck('category_id')->toArray();
      return view('admin.coupon.edit', compact('results', 'category', 'couponcategory'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function update($id, Request $request)
  {
      $request->validate([
          'name' => 'required|max:191',
          'code' => 'required|unique:coupon,code',
          'type' => 'required',
          'discount' => 'required|numeric|min:1',
          'shipping' =>'required',
          'start_date' =>'required|date',
          'end_date' =>'required|date',
          'uses_total' => 'required|numeric',
          'uses_customer' => 'required|numeric',
          'status' =>'required',
      ]);
	  	$store=Coupon::findOrFail($id);
	  	$store->name=$request['name'];
	  	$store->code=strtoupper($request['code']);
	  	$store->type=$request['type'];
	  	$store->discount=$request['discount'];
	  	if($request['type']==="P"){
	  		$store->max_discount=$request['max_discount'];
	  	}
	  	if($request['min_order']>0){
	  		$store->min_order=$request['min_order'];
	  	}
	  	$store->free_shipping=$request['shipping'];
	    $store->start_date=Carbon::createFromFormat('d-m-Y', $request['start_date']);
	    $store->end_date=Carbon::createFromFormat('d-m-Y', $request['end_date']);
      $store->uses_total=$request['uses_total'];
      $store->uses_customer=$request['uses_customer'];
	    $store->status=$request['status'];
	  	$store->save();

	  	$store->CouponProduct()->delete();

	  	if(count($request['rel_product'])>0){
	  		foreach ($request['rel_product'] as $key => $value) {
	            $prod=new CouponProduct();
	            $prod->coupon_id=$store->id;
	            $prod->product_id=$value;
	            $prod->save();
	        }
	  	}

	  	$store->CouponCategory()->delete();
	  	if(count($request['category'])>0){
	  		foreach ($request['category'] as $key => $value) {
	            $prod=new CouponCategory();
	            $prod->coupon_id=$store->id;
	            $prod->category_id=$value;
	            $prod->save();
	        }
	  	}
	  	$store->touch();
      return redirect('admin/coupon')->with('success','Voucher successfully updated.');
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function destroy($id)
  {
    
  }

  public function trash(Request $request)
  {
      $request->validate([
          'selected' => 'array'
      ]);
      $count=count($request['selected']);
      if($count>0)
      {
        $delete=Coupon::whereIn('id',$request['selected'])->delete();
        return back()->with('success', $count.' item has been deleted.');
      }
  }
}
