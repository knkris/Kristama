<?php 

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\CustomerGroup;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\ProductAttribute;
use App\Models\ProductDiscount;
use App\Models\ProductSpecial;
use App\Models\ProductOption;
use App\Models\ProductOptionDetail;
use App\Models\Attribute;
use App\Models\Option;
use App\Models\OptionValue;
use App\Models\Category;
use App\Models\Manufacturer;
use App\Models\WeightClass;
use App\Models\LengthClass;
use App\Models\StockStatus;
use App\Models\ProductToCategory;
use App\Models\ProductToProduct;
use App\Models\ExcelImportFile;
use App\Models\RecommendedProduct;
use Carbon\Carbon;
use Excel;
use Storage;

class ProductController extends Controller 
{
  public function showIndex()
  {
      $recommended = RecommendedProduct::whereHas('Product')->get();
      return view('admin.product.index', compact('recommended'));
  }


  /**
   * Display a listing of the resource.
   *
   * @return Response
   */
  public function index(Request $request)
  {
      $columns = array( 
                            0 =>'id', 
                            1 =>'image',
                            2 =>'name',
                            3 =>'model',
                            4 =>'price',
                            5 =>'qty',
                            6 =>'status',
                            7 =>'action'
                        );
  
        $totalData = Product::count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        if(array_key_exists($request->input('order.0.column'), $columns)){
          $order = $columns[$request->input('order.0.column')];
        }else{
          $order = 'id';
        }
        if($request->input('order.0.dir')!==null){
          $dir = $request->input('order.0.dir');
        }else{
          $dir = 'asc';
        }
        
            
        if(empty($request->input('search.value')))
        {            
            $results = Product::orderBy($order,$dir)->offset($start)->limit($limit)
                         ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $results =  Product::where('name','LIKE',"%{$search}%")
                            ->orWhere('model','LIKE',"%{$search}%")
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();

            $totalFiltered = Product::where('name','LIKE',"%{$search}%")
                             ->orWhere('model','LIKE',"%{$search}%")
                             ->count();
        }

        $data = array();
        if(!empty($results))
        {
            foreach ($results as $value)
            {
                $edit =  url('admin/product/edit',$value->id);
                $img = $value->Image->first()->image;

                $nestedData['id'] = "<input type='checkbox' name='selected[]'' value='{$value->id}'>";
                $nestedData['image'] = "<img src='{$img}' style='width:50px;height:auto;'>";
                $nestedData['name'] = "<p data-id='{$value->id}' data-type='name'>{$value->name}</p>";
                $nestedData['model'] = "<p data-id='{$value->id}' data-type='model'>{$value->model}</p>";
                $nestedData['price'] = "<p data-id='{$value->id}' data-price='{$value->price}' data-type='price'>".currency_format($value->price,'IDR')."</p>";
                if($value->qty>0){
                  $nestedData['qty'] = "<span class='label label-success' data-id='{$value->id}' data-type='qty'>{$value->qty}</span>";
                }else{
                  $nestedData['qty'] = "<span class='label label-warning' data-id='{$value->id}' data-type='qty'>{$value->qty}</span>";
                }
                if($value->status==1){
                  $nestedData['status'] = "<span class='label label-success' data-id='{$value->id}' data-type='status'>enabled</span>";
                }else{
                  $nestedData['status'] = "<span class='label label-danger' data-id='{$value->id}' data-type='status'>disabled</span>";
                }
                $nestedData['action'] = "&emsp;<a href='{$edit}' title='EDIT' ><span class='glyphicon glyphicon-edit'></span></a>";
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return Response
   */
  public function create()
  {
      $category = Category::get();
      $manufacturer = Manufacturer::get();
      $weightclass = WeightClass::get();
      $lengthclass = LengthClass::get();
      $stockstatus = StockStatus::get();
      $customergroup = CustomerGroup::get();
      return view('admin.product.create', compact('category', 'manufacturer', 'weightclass', 'lengthclass', 'stockstatus', 'customergroup'));
  }

  /**
   * Store a newly created resource in storage.
   *
   * @return Response
   */
  public function store(Request $request)
  {
      //return $request->all();
      $request->validate([
          'name' => 'required|max:191',
          'model' => 'required|max:191',
          'desc' => 'required',
          'short_desc' => 'required',
          'category' => 'required',
          //'manufacturer' => 'sometimes|exists:manufacturer,id',
          'weight' => 'required|numeric',
          'length' => 'numeric',
          'width' => 'numeric',
          'height' => 'numeric',
          'weight_class' => 'required|exists:weight_class,id',
          'length_class' => 'required|exists:length_class,id',
          'price' => 'required|numeric',
          'price_filter' => 'required|numeric',
          'qty' => 'required|numeric',
          'stock_status' => 'required|exists:stock_status,id',
          'status' => 'required|numeric',
          'shipping' => 'required|numeric',
          'substract' => 'required|numeric',
          'minimum' => 'required|numeric',
          'sort_order' => 'numeric',
          'image.*' => 'image|mimes:jpeg,png,jpg,gif,svg',
          'productoption.*.option_id' => 'exists:option,id',
          'productoption.*.stock_enabled' => 'required',
          'productoption.*.required' => 'numeric',
          'productoption.*..*.option_value_id' => 'numeric|exists:option_value,id',
          'productoption.*..*.qty' => 'numeric',
          'productoption.*..*.substract' => 'numeric',
          'productoption.*..*.price' => 'numeric',
      ], [
        'price.required' => 'Old Price field is required.',
        'price_filter.required' => 'New Price field is required.',
        'price.numeric' => 'Old Price must be number.',
        'price_filter.numeric' => 'New Price must be number.'
      ]);
      

      $store=new product();
      $store->name=$request['name'];
      $store->sku=$request['sku'];
      $store->model=$request['model'];
      if(strlen($request['seo'])>0){
        $store->slug=$request['seo'];
      }else{
        $store->slug=str_slug($request['name']);
      }
      $store->desc=$request['desc'];
      $store->short_desc=$request['short_desc'];
      // $store->category_id=$request['category'];
      //$store->category=json_encode($request['category']);
      if($request['manufacturer']!=""){
        $store->manufacturer_id=$request['manufacturer'];
      }
      $store->price=$request['price'];
      $store->price_filter=$request['price_filter'];
      if($request['status']==1){
        $store->status=$request['status'];
      }else{
        $store->status=0;
      }
      $store->qty=$request['qty'];
      $store->weight=$request['weight'];
      $store->length=$request['length'];
      $store->width=$request['width'];
      $store->height=$request['height'];
      $store->weight_class_id=$request['weight_class'];
      $store->length_class_id=$request['length_class'];
      $store->stock_status_id=$request['stock_status'];
      $store->substract=$request['substract'];
      $store->minimum=$request['minimum'];
      $store->sort_order=$request['sort_order'];
      $store->shipping=$request['shipping'];
      $store->save();

      if(count($request['category'])>0){
        foreach($request['category'] as $key => $value){
          $pro=new ProductToCategory();
          $pro->product_id=$store->id;
          $pro->category_id=$value;
          $pro->save();
        }
      }

      if(count($request->image)>0){
      foreach ($request->image as $image) {
            $destinationPath = public_path('/img/product_image');
            $extension = $image->getClientOriginalExtension(); // getting image extension
            $fileName = time().'.'.$image->getClientOriginalName().'.'.$image->getClientOriginalExtension(); // renameing image
            $image->move($destinationPath, $fileName);

            $path=url('/img/product_image/'.$fileName);


            ProductImage::create([
                'product_id' => $store->id,
                'image' => $path
            ]);
        }
      }

      if(count($request->input('product_attribute'))>0){
        foreach($request->input('product_attribute') as $pd){
          if($pd['name']>0 && strlen($pd['value'])>0){
            $product_attribute = new ProductAttribute();
            $product_attribute->product_id = $store->id;
            $product_attribute->attribute_id = $pd['name'];
            $product_attribute->value = $pd['value'];
            $product_attribute->save();
          }
        }
      }

      if(count($request->input('product_discount'))>0){
        foreach($request->input('product_discount') as $pd){
          if(strlen($pd['quantity'])>0 && strlen($pd['priority'])>0 && strlen($pd['price'])>0){
            $product_discount = new ProductDiscount();
            $product_discount->product_id = $store->id;
            $product_discount->customer_group_id = $pd['customer_group_id'];
            $product_discount->quantity = $pd['quantity'];
            $product_discount->priority = $pd['priority'];
            $product_discount->price = $pd['price'];
            $product_discount->start = strlen($pd['date_start'])>0 ? Carbon::parse($pd['date_start']) : null;
            $product_discount->end = strlen($pd['date_end'])>0 ? Carbon::parse($pd['date_end']) : null;
            $product_discount->save();
          }
        }
      }

      if(count($request->input('related_product'))>0){
        foreach($request->input('related_product') as $pd){
            $related_product = new ProductToProduct();
            $related_product->product_id = $store->id;
            $related_product->to_product_id = $pd;
            $related_product->save();
        }
      }

      if(count($request->input('product_special'))>0){
        foreach($request->input('product_special') as $pd){
          if(strlen($pd['priority'])>0 && strlen($pd['price'])>0){
            $product_special = new ProductSpecial();
            $product_special->product_id = $store->id;
            $product_special->customer_group_id = $pd['customer_group_id'];
            $product_special->priority = $pd['priority'];
            $product_special->price = $pd['price'];
            $product_special->start = strlen($pd['date_start'])>0 ? Carbon::parse($pd['date_start']) : null;
            $product_special->end = strlen($pd['date_end'])>0 ? Carbon::parse($pd['date_end']) : null;
            $product_special->save();
          }
        }
      }

      $opqty=0;
      if(count($request->input('productoption'))>0){
        foreach($request->input('productoption') as $po)
        if(strlen($po['option_id'])>0){
          $poval=new ProductOption();
          $poval->product_id=$store->id;
          $poval->option_id=$po['option_id'];
          if($po['required']==1){
            $poval->required=$po['required'];
          }else{
            $poval->required=0;
          }
          if($po['stock_enabled']==1){
            $poval->stock_enabled=$po['stock_enabled'];
          }else{
            $poval->stock_enabled=0;
          }
          $poval->save();

          if(array_key_exists("option",$po)){
            foreach($po['option'] as $pod){
              $podval=new ProductOptionDetail();
              $podval->product_id=$store->id;
              $podval->product_option_id=$poval->id;
              $podval->option_id=$po['option_id'];
              $podval->option_value_id=$pod['option_value_id'];
              $podval->qty=$pod['qty'];
              $podval->substract=$pod['substract'];
              $podval->price=$pod['price'];
              $podval->save();
            }
          }
          
          
        }
      }
      
      return redirect('admin/product')->with('success',$request['name'].' successfully added.');
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function show($id)
  {
      
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function edit($id)
  {
      $results = Product::findOrFail($id);
      $category = Category::get();
      $manufacturer = Manufacturer::get();
      $weightclass = WeightClass::get();
      $lengthclass = LengthClass::get();
      $stockstatus = StockStatus::get();
      $customergroup = CustomerGroup::get();
      return view('admin.product.edit', compact('results', 'category', 'manufacturer', 'weightclass', 'lengthclass', 'stockstatus', 'customergroup'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function update($id, Request $request)
  {
      //return $request->all();
      $request->validate([
          'name' => 'required|max:191',
          'model' => 'required|max:191',
          'desc' => 'required',
          'short_desc' => 'required',
          'category' => 'required',
          //'manufacturer' => 'sometimes|exists:manufacturer,id',
          'weight' => 'numeric',
          'length' => 'numeric',
          'width' => 'numeric',
          'height' => 'numeric',
          'weight_class' => 'required|exists:weight_class,id',
          'length_class' => 'required|exists:length_class,id',
          'price' => 'required|numeric',
          'price_filter' => 'required|numeric',
          'qty' => 'required|numeric',
          'stock_status' => 'required|exists:stock_status,id',
          'status' => 'required|numeric',
          'shipping' => 'required|numeric',
          'substract' => 'required|numeric',
          'minimum' => 'required|numeric',
          'sort_order' => 'numeric',
          'image.*' => 'image|mimes:jpeg,png,jpg,gif,svg',
          'productoption.*.option_id' => 'exists:option,id',
          'productoption.*.stock_enabled' => 'required',
          'productoption.*.required' => 'numeric',
          'productoption.*..*.option_value_id' => 'numeric|exists:option_value,id',
          'productoption.*..*.qty' => 'numeric',
          'productoption.*..*.substract' => 'numeric',
          'productoption.*..*.price' => 'numeric',
      ], [
        'price.required' => 'Old Price field is required.',
        'price_filter.required' => 'New Price field is required.',
        'price.numeric' => 'Old Price must be number.',
        'price_filter.numeric' => 'New Price must be number.'
      ]);
      

      $store=Product::findOrFail($id);
      $store->name=$request['name'];
      $store->sku=$request['sku'];
      $store->model=$request['model'];
      if(strlen($request['seo'])>0){
        $store->slug=$request['seo'];
      }else{
        $store->slug=str_slug($request['name']);
      }
      $store->desc=$request['desc'];
      $store->short_desc=$request['short_desc'];
      // $store->category_id=$request['category'];
      //$store->category=json_encode($request['category']);
      if($request['manufacturer']!=""){
        $store->manufacturer_id=$request['manufacturer'];
      }
      $store->price=$request['price'];
      $store->price_filter=$request['price_filter'];
      if($request['status']==1){
        $store->status=$request['status'];
      }else{
        $store->status=0;
      }
      $store->qty=$request['qty'];
      $store->weight=$request['weight'];
      $store->length=$request['length'];
      $store->width=$request['width'];
      $store->height=$request['height'];
      $store->weight_class_id=$request['weight_class'];
      $store->length_class_id=$request['length_class'];
      $store->stock_status_id=$request['stock_status'];
      $store->substract=$request['substract'];
      $store->minimum=$request['minimum'];
      $store->sort_order=$request['sort_order'];
      $store->shipping=$request['shipping'];
      $store->save();
      $store->touch();

      $store->ProductToCategory()->delete();
      if(count($request['category'])>0){
        foreach($request['category'] as $key => $value){
          $pro=new ProductToCategory();
          $pro->product_id=$store->id;
          $pro->category_id=$value;
          $pro->save();
        }
      }

      if(count($request->image)>0){
      foreach ($request->image as $image) {
            $destinationPath = public_path('/img/product_image');
            $extension = $image->getClientOriginalExtension(); // getting image extension
            $fileName = time().'.'.$image->getClientOriginalName().'.'.$image->getClientOriginalExtension(); // renameing image
            $image->move($destinationPath, $fileName);

            $path=url('/img/product_image/'.$fileName);


            ProductImage::create([
                'product_id' => $store->id,
                'image' => $path
            ]);
        }
      }

      if(count($request->input('product_attribute'))>0){
        $store->ProductAttribute()->delete();
        foreach($request->input('product_attribute') as $pd){
          if($pd['name']>0 && strlen($pd['value'])>0){
            $product_attribute = new ProductAttribute();
            $product_attribute->product_id = $store->id;
            $product_attribute->attribute_id = $pd['name'];
            $product_attribute->value = $pd['value'];
            $product_attribute->save();
          }
        }
      }

      if(count($request->input('product_discount'))>0){
        $store->ProductDiscount()->delete();
        foreach($request->input('product_discount') as $pd){
          if(strlen($pd['quantity'])>0 && strlen($pd['priority'])>0 && strlen($pd['price'])>0){
            $product_discount = new ProductDiscount();
            $product_discount->product_id = $store->id;
            $product_discount->customer_group_id = $pd['customer_group_id'];
            $product_discount->quantity = $pd['quantity'];
            $product_discount->priority = $pd['priority'];
            $product_discount->price = $pd['price'];
            $product_discount->start = strlen($pd['date_start'])>0 ? Carbon::parse($pd['date_start']) : null;
            $product_discount->end = strlen($pd['date_end'])>0 ? Carbon::parse($pd['date_end']) : null;
            $product_discount->save();
          }
        }
      }

      $store->ProductToProduct()->delete();
      if(count($request->input('related_product'))>0){
        foreach($request->input('related_product') as $pd){
            $related_product = new ProductToProduct();
            $related_product->product_id = $store->id;
            $related_product->to_product_id = $pd;
            $related_product->save();
        }
      }

      if(count($request->input('product_special'))>0){
        $store->ProductSpecial()->delete();
        foreach($request->input('product_special') as $pd){
          if(strlen($pd['priority'])>0 && strlen($pd['price'])>0){
            $product_special = new ProductSpecial();
            $product_special->product_id = $store->id;
            $product_special->customer_group_id = $pd['customer_group_id'];
            $product_special->priority = $pd['priority'];
            $product_special->price = $pd['price'];
            $product_special->start = strlen($pd['date_start'])>0 ? Carbon::parse($pd['date_start']) : null;
            $product_special->end = strlen($pd['date_end'])>0 ? Carbon::parse($pd['date_end']) : null;
            $product_special->save();
          }
        }
      }

      $opqty=0;
      
      $po_ids=[];
      $pod_ids=[];
      if(count($request->input('productoption'))>0){
        foreach($request->input('productoption') as $po){

          if(strlen($po['option_id'])>0){
            if (array_key_exists('product_option_id',$po)){
              $poval=ProductOption::find($po['product_option_id']);
                if(count($poval)>0){
                }else{
                  $poval=new ProductOption();
                }
              }else{
                $poval=new ProductOption();
              }
            $poval->product_id=$store->id;
            $poval->option_id=$po['option_id'];
            if($po['required']==1){
              $poval->required=$po['required'];
            }else{
              $poval->required=0;
            }
            if($po['stock_enabled']==1){
              $poval->stock_enabled=$po['stock_enabled'];
            }else{
              $poval->stock_enabled=0;
            }
            $poval->save();
            if (array_key_exists('product_option_id',$po)){
              $poval->touch();
            }
            $po_ids[]=$poval->id;

            if(array_key_exists("option",$po)){
              foreach($po['option'] as $pod){
                if (array_key_exists('product_option_detail_id',$pod)){
                  $podval=ProductOptionDetail::find($pod['product_option_detail_id']);
                  if(count($podval)>0){
                  }else{
                    $podval=new ProductOptionDetail();
                  }
                }else{
                  $podval=new ProductOptionDetail();
                }
                $podval->product_id=$store->id;
                $podval->product_option_id=$poval->id;
                $podval->option_id=$po['option_id'];
                $podval->option_value_id=$pod['option_value_id'];
                $podval->qty=$pod['qty'];
                $podval->substract=$pod['substract'];
                $podval->price=$pod['price'];
                $podval->save();
                if (array_key_exists('product_option_detail_id',$pod)){
                  $podval->touch();
                }
                $pod_ids[]=$podval->id;
              }
            }
            
          }
        }
      }
      $delPO=ProductOption::whereProduct_id($store->id)->whereNotIn('id',$po_ids)->forceDelete();
      $delPOD=ProductOptionDetail::whereProduct_id($store->id)->whereNotIn('id',$pod_ids)->forceDelete();
      
      return redirect('admin/product')->with('success',$request['name'].' successfully updated.');
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function destroy($id)
  {
    
  }

  public function trash(Request $request)
  {
      $request->validate([
          'selected' => 'array'
      ]);
      $count=count($request['selected']);
      if($count>0)
      {
        $delete=Product::whereIn('id',$request['selected'])->delete();
        return back()->with('success', $count.' item has been deleted.');
      }
  }

  public function postRecommendedProduct(Request $request)
  {
      $recommended=RecommendedProduct::truncate();
      if(count($request->input('recommended_product'))>0){
        foreach($request->input('recommended_product') as $pd){
            $recommended_product = new RecommendedProduct();
            $recommended_product->product_id = $pd;
            $recommended_product->save();
        }
      }

      return back()->with('success', 'Recommended Product has been updated');
  }

  public function recommendedSearch(Request $request)
  {
      $term = trim($request->q);

      // if (empty($term)) {
      //     return \Response::json([]);
      // }

      $results = Product::where('name', 'LIKE', '%'.$term.'%')->whereStatus(1)->limit(5)->get();

      $formatted_results = [];

      foreach ($results as $val) {
          $formatted_results[] = ['id' => $val->id, 'image' => $val->Image ? $val->Image->first()->image : '', 'text' => $val->name];
      }

      return response()->json($formatted_results);
  }


  public function deleteProductImage($id, Request $request)
  {
      $deleteimage=ProductImage::find($id);
      $deleteimage->delete();
      return response()->json('success');
  }

  public function QuickUpdate($type,$id, Request $request)
  {
      switch ($type) {
        case 'name':
          $request->validate([
              'value' => 'required|max:191'
          ]);
          $store=Product::findOrFail($id);
          $store->name=$request['value'];
          break;

        case 'model':
          $request->validate([
              'value' => 'required|max:191'
          ]);
          $store=Product::findOrFail($id);
          $store->model=$request['value'];
          break;

        case 'price':
          $request->validate([
              'value' => 'required|numeric'
          ]);
          $store=Product::findOrFail($id);
          $store->price=$request['value'];
          break;

        case 'qty':
          $request->validate([
              'value' => 'required|numeric'
          ]);
          $store=Product::findOrFail($id);
          $store->qty=$request['value'];
          break;

        case 'status':
          $request->validate([
              'value' => 'required|numeric'
          ]);
          $store=Product::findOrFail($id);
          if($request['value']==1){
            $store->status=$request['value'];
          }else{
            $store->status=0;
          }
          break;
        
      }
      
      $store->save();
      $store->touch();

      if($type==="price"){
        $store->rp_price="<p data-id='{$store->id}' data-price='{$store->price}' data-type='price'>".currency_format($store->price,'IDR')."</p>";
      }

      if($type==="status"){
        $txt=$store->status==0 ? "disabled" : "enabled";
        if($store->status==0){
          $store->html_status="<span class='label label-danger' data-id='{$store->id}' data-type='status'>{$txt}</span>";
        }else{
          $store->html_status="<span class='label label-success' data-id='{$store->id}' data-type='status'>{$txt}</span>";
        }
      }
      
      return response()->json($store);
  }

  public function search(Request $request)
    {
        $term = trim($request->q);

        // if (empty($term)) {
        //     return \Response::json([]);
        // }

        $results = Product::where('name', 'LIKE', '%'.$term.'%')->limit(5)->get();

        $formatted_results = [];

        foreach ($results as $val) {
            $formatted_results[] = ['id' => $val->id, 'text' => $val->name];
        }

        return response()->json($formatted_results);
    }

  public function searchSKU(Request $request){
    $term = $request->input('term');
    
    $results = array();
    
    $queries = Product::where('sku', 'LIKE', '%'.$term.'%')
      ->take(5)->get();
    
    foreach ($queries as $query)
    {
        $results[] = [ 'id' => $query->id, 'value' => $query->sku ];
    }
    return response()->json($results);
  }

  public function searchModel(Request $request){
    $term = $request->input('term');
    
    $results = array();
    
    $queries = Product::where('model', 'LIKE', '%'.$term.'%')
      ->take(5)->get();
    
    foreach ($queries as $query)
    {
        $results[] = [ 'id' => $query->id, 'value' => $query->model ];
    }
    return response()->json($results);
  }

  public function relatedSearch(Request $request)
  {
      $term = trim($request->q);

      // if (empty($term)) {
      //     return \Response::json([]);
      // }

      $results = Product::where('name', 'LIKE', '%'.$term.'%')->where('id','!=',$request->product_id)->whereStatus(1)->limit(5)->get();

      $formatted_results = [];

      foreach ($results as $val) {
          $formatted_results[] = ['id' => $val->id, 'image' => $val->Image ? $val->Image->first()->image : '', 'text' => $val->name];
      }

      return response()->json($formatted_results);
  }

  public function exportToExcel(Request $request)
  {
    // $request->validate([
    //     'selected' => 'array'
    // ]);
    // $count=count($request['selected']);
    // if($count>0)
    // {
      $export=Product::get();

      $array=[];
      // Define the Excel spreadsheet headers
      //$array[] = ["Date Created : ".Carbon::now()->toFormattedDateString()];
      // $array[] = ['Product ID', 'Name', 'Model', 'Description', 'Category', 'Attribute', 'Manufacturer', 'Price', 'Status', 'Weight', 'Weight Class', 'Length', 'Width', 'Height', 'Length Class', 'Quantity', 'Out of Stock Status', 'Substract Stock', 'Minimum Quantity', 'Sort Order', 'Require Shipping', 'Option', 'Stock Enabled', 'Required', 'Option Value', 'Option Substract Stock', 'Option Price' ];
      $array[] = ['Product ID', 'Name', 'Model', 'Description', 'Category', 'Attribute', 'Manufacturer', 'Old Price', 'New Price', 'Status', 'Weight', 'Weight Class', 'Length', 'Width', 'Height', 'Length Class', 'Quantity', 'Out of Stock Status', 'Substract Stock', 'Minimum Quantity', 'Sort Order', 'Require Shipping' ];

      foreach ($export as $num_row => $exp) {
        if($num_row!=0){
          // $array[] = [
          //     '', '', '', '',
          //     '', '', '', '',
          //     '', '', '', '',
          //     '', '', '', '',
          //     '', '', '',
          //     '', '', '',
          //     '', '', '',
          //     '', '',
          //   ];
          // $array[] = [
          //     '', '', '', '',
          //     '', '', '', '',
          //     '', '', '', '',
          //     '', '', '', '',
          //     '', '', '',
          //     '', 
          //   ];
          // $array[] = [
          //     '', '', '', '',
          //     '', '', '', '',
          //     '', '', '', '',
          //     '', '', '', '',
          //     '', '', '',
          //     '', 
          //   ];
        }
        $object = new \stdClass();
        $object->id=$exp->id;
        $object->name=$exp->name;
        $object->model=$exp->model;
        $object->description=$exp->desc;
        //category
        $categories=$exp->ProductToCategory;
        $formatted_categories='';
        foreach ($categories as $key => $value) {
            $formatted_categories.=$value->Category->name."\n";
        }
        $object->category=$formatted_categories;
        //attribute
        $attributes=$exp->ProductAttribute;
        $formatted_attributes='';
        foreach ($attributes as $key => $value) {
            $formatted_attributes.=$value->Attribute->name.' : '.$value->value."\n";
        }

        $object->attribute=$formatted_attributes;
        $manufacturer=$exp->Manufacturer;
        $object->manufacturer=$manufacturer['name'];
        $object->price=$exp->price+0;
        $object->price_filter=$exp->price_filter+0;
        $object->status=$exp->status==1 ? "enabled" : "disabled";
        $object->weight=(string)($exp->weight+0);
        $object->weight_class=$exp->WeightClass->unit;
        $object->length=(string)($exp->length*$exp->LengthClass->value);
        $object->width=(string)($exp->width*$exp->LengthClass->value);
        $object->height=(string)($exp->height*$exp->LengthClass->value);
        $object->length_class=$exp->LengthClass->unit;
        $object->qty=$exp->qty;
        $object->stock_status=$exp->StockStatus->name_en;
        $object->substract=$exp->substract==1 ? "yes" : "no";
        $object->minimum=$exp->minimum;
        $object->sort_order=$exp->sort_order;
        $object->shipping=$exp->shipping==1 ? "yes" : "no";
        if($exp->ProductOption()->count()>0){
          $po=$exp->ProductOption()->first();
          $object->option=$po->Option()->first()->name;
          $object->stock_enabled=$po->stock_enabled==1 ? "yes" : "no";
          $object->required=$po->required==1 ? "yes" : "no";

          // $pod=$po->ProductOptionDetail()->first();
          // $object->option_detail=$pod->OptionValue->name;
          // $object->option_substract=$pod->substract==1 ? "yes" : "no";
          // $object->option_price=(string)($pod->price+0);

          // $array[] = [
          //   $object->id, $object->name, $object->model, $object->description,
          //   $object->category, $object->attribute, $object->manufacturer, $object->price, $object->price_filter,
          //   $object->status, $object->weight, $object->weight_class, $object->length,
          //   $object->width, $object->height, $object->length_class, $object->qty,
          //   $object->stock_status, $object->substract, $object->minimum,
          //   $object->sort_order, $object->shipping, $object->option,
          //   $object->stock_enabled, $object->required, $object->option_detail,
          //   $object->option_substract, $object->option_price
          // ];

          $array[] = [
            $object->id, $object->name, $object->model, $object->description,
            $object->category, $object->attribute, $object->manufacturer, $object->price, $object->price_filter,
            $object->status, $object->weight, $object->weight_class, $object->length,
            $object->width, $object->height, $object->length_class, $object->qty,
            $object->stock_status, $object->substract, $object->minimum,
            $object->sort_order, $object->shipping
          ];

          // $count_pod=$po->ProductOptionDetail()->count();
          // foreach($po->ProductOptionDetail()->skip(1)->take($count_pod-1)->get() as $ov){
          //   // $object_detail = new \stdClass();
          //   // $object_detail->option_detail=$ov->OptionValue->name;
          //   // $object_detail->option_substract=$ov->substract==1 ? "yes" : "no";
          //   // $object_detail->option_price=(string)($ov->price+0);
          //   // $array[] = [
          //   //   '', '', '', '',
          //   //   '', '', '', '',
          //   //   '', '', '', '',
          //   //   '', '', '', '',
          //   //   '', '', '',
          //   //   '', '', '',
          //   //   '', '', $object_detail->option_detail,
          //   //   $object_detail->option_substract, $object_detail->option_price
          //   // ];

          //   $array[] = [
          //     '', '', '', '',
          //     '', '', '', '',
          //     '', '', '', '',
          //     '', '', '', '',
          //     '', '', '',
          //     '', ''
          //   ];
          // }
          // $left=$exp->ProductOption()->count()-1;
          // if($left>0){
          //   foreach($exp->ProductOption()->skip(1)->take($left)->get() as $o){
          //     $object_option = new \stdClass();
          //     $object_option->option=$o->Option()->first()->name;
          //     $object_option->stock_enabled=$o->stock_enabled==1 ? "yes" : "no";
          //     $object_option->required=$o->required==1 ? "yes" : "no";

          //     // $pod=$o->ProductOptionDetail()->first();
          //     // $object_option->option_detail=$pod->OptionValue->name;
          //     // $object_option->option_substract=$pod->substract==1 ? "yes" : "no";
          //     // $object_option->option_price=(string)($pod->price+0);

          //     // $array[] = [
          //     //   '', '', '', '',
          //     //   '', '', '', '',
          //     //   '', '', '', '',
          //     //   '', '', '', '',
          //     //   '', '', '',
          //     //   '', '', $object_option->option,
          //     //   $object_option->stock_enabled, $object_option->required, $object_option->option_detail,
          //     //   $object_option->option_substract, $object_option->option_price
          //     // ];
          //     $array[] = [
          //       '', '', '', '',
          //       '', '', '', '',
          //       '', '', '', '',
          //       '', '', '', '',
          //       '', '', '',
          //       '', ''
          //     ];
          //     $count_pod=$o->ProductOptionDetail()->count();
          //     foreach($o->ProductOptionDetail()->skip(1)->take($count_pod-1)->get() as $ov){
          //       // $object_detail = new \stdClass();
          //       // $object_detail->option_detail=$ov->OptionValue->name;
          //       // $object_detail->option_substract=$ov->substract==1 ? "yes" : "no";
          //       // $object_detail->option_price=(string)($ov->price+0);
          //       // $array[] = [
          //       //   '', '', '', '',
          //       //   '', '', '', '',
          //       //   '', '', '', '',
          //       //   '', '', '', '',
          //       //   '', '', '',
          //       //   '', '', '',
          //       //   '', '', $object_detail->option_detail,
          //       //   $object_detail->option_substract, $object_detail->option_price
          //       // ];
          //       $array[] = [
          //         '', '', '', '',
          //         '', '', '', '',
          //         '', '', '', '',
          //         '', '', '', '',
          //         '', '', '',
          //         '', ''
          //       ];
          //     }
          //   }
          // }
        }else{

          $array[] = [
            $object->id, $object->name, $object->model, $object->description,
            $object->category, $object->attribute, $object->manufacturer, $object->price,
            $object->status, $object->weight, $object->weight_class, $object->length,
            $object->width, $object->height, $object->length_class, $object->qty,
            $object->stock_status, $object->substract, $object->minimum,
            $object->sort_order, $object->shipping
          ];
        }
      }

      $count_array=count($array);

      // Generate and return the spreadsheet
      Excel::create('products', function($excel) use ($array, $count_array) {

          // Set the spreadsheet title, creator, and description
          $excel->setTitle('Product');
          $excel->setCreator(env('APP_NAME', 'Laravel'))->setCompany(env('APP_NAME', 'Laravel'));
          $excel->setDescription('Export Product to excel');

          // Build the spreadsheet, passing in the payments array
          $excel->sheet('sheet1', function($sheet) use ($array, $count_array) {
              $sheet->fromArray($array, null, 'A1', false, false);

              $sheet->getProtection()->setSheet(true);  // Needs to be set to true in order to enable any worksheet protection!
              //$sheet->protectCells('A1:A'.$count_array, 'rusakdah');
              $sheet->getStyle('B2:AA'.(int)($count_array+100))->getProtection()->setLocked(\PHPExcel_Style_Protection::PROTECTION_UNPROTECTED);
              $sheet->getStyle('E2:F'.(int)($count_array+100))
                    ->getAlignment()
                    ->setWrapText(true);
              $sheet->getStyle('A2:AA'.(int)($count_array+100))
                    ->getAlignment()
                    ->setVertical(\PHPExcel_Style_Alignment::VERTICAL_TOP);
              
          });

      })->download('xlsx');
    // }
  }

  public function importFile(Request $request){

        if($request->hasFile('product_file')){

            $path = $request->file('sample_file')->getRealPath();

            $data = \Excel::load($path)->get();

            //dd($data);

            if($data->count()){

                foreach ($data as $key => $value) {
                    dd($value);
                    $arr[] = ['title' => $value->title, 'body' => $value->body];

                }

                if(!empty($arr)){

                    DB::table('products')->insert($arr);

                    dd('Insert Recorded successfully.');

                }

            }

        }

        dd('Request data does not have any files to import.');      

    } 

    public function importWithExcel(Request $request)
    {
      //dd($request->file('file_input'));
      $request->validate([
        'file_input'=>'required|max:50000|mimes:xlsx,xls'
      ]);
      
      $file = $request->file('file_input');
      $path = $request->file('file_input')->getRealPath();

          $destinationPath = public_path('/excel-import');
            $extension = $file->getClientOriginalExtension(); // getting file extension
            $fileName = time().'.'.$file->getClientOriginalName().'.'.$file->getClientOriginalExtension(); // renameing file
            $file->move($destinationPath, $fileName);

            $path=public_path('/excel-import/'.$fileName);


            $save=ExcelImportFile::create([
                'path' => $path,
                'name' => $fileName,
                'token'=> $this->generateRandomString(12),
                'imported' => 0
            ]);

            $data = \Excel::load($path)->get();

            //dd($data);

            $count_product=0;$count_option=0;$count_option_detail=0;
            $product_new=0;$option_new=0;$option_detail_new=0;
            $product_modified=0;$option_modified=0;$option_detail_modified=0;
            $array=[];
            $last_product=new \stdClass;
            $last_product_option=new \stdClass;
            $last_option=new \stdClass;
            $removed_product=[];
            $option_id=[];
            $option_detail_id=[];
            foreach($data as $key => $value){
              if($value->product_id!=null){
                $product=Product::find($value->product_id);
                $last_product=$product;
                $count_product++;
                $check_modified=false;
                $check_modified_option=false;
                $check_modified_option_detail=false;
                if($value->name==null && $value->model==null){
                  $removed_product[]=$product->id;
                  $array[]=$product->name." will be deleted";
                }
                if($product->name!==$value->name){ 
                  $check_modified=true; 
                  $array[]=$product->name." => ".$value->name; 
                }
                if($product->model!==$value->model){
                  $check_modified=true; 
                  $array[]=$product->name." model ".$product->model." => ".$value->model;
                }
                if($product->desc!==$value->description){
                  $check_modified=true; 
                  $array[]=$product->name." description ".$product->desc." => ".$value->description;
                }
                $categories=$product->ProductToCategory;
                $formatted_categories='';
                foreach ($categories as $key => $val) {
                    $formatted_categories.=$val->Category->name."\n";
                }
                if(str_replace(" ","",str_replace("\n","",$formatted_categories))!==str_replace(" ","",str_replace("\n","",$value->category))){
                  $check_modified=true; 
                  $array[]=$product->name." category ".$formatted_categories." => ".$value->category;
                }
                //attribute
                $attributes=$product->ProductAttribute;
                $formatted_attributes='';
                foreach ($attributes as $key => $val) {
                    $formatted_attributes.=$val->Attribute->name.' : '.$val->value."\n";
                }

                if(str_replace(" ","",str_replace("\n","",$formatted_attributes))!==str_replace(" ","",str_replace("\n","",$value->attribute))){
                  $check_modified=true; 
                  $array[]=$product->name." attribute ".$formatted_attributes." => ".$value->attribute;
                }
                $manufacturer=$product->Manufacturer;
                if($manufacturer['name']!==$value->manufacturer){
                  $check_modified=true; 
                  $array[]=$product->name." manufacturer ".$manufacturer['name']." => ".$value->manufacturer;
                }
                if($product->price!=$value->price){
                  $check_modified=true; 
                  $array[]=$product->name." price ".$product->price." => ".$value->price;
                }
                $status=$product->status==0 ? "disabled" : "enabled";
                if($status!==$value->status){
                  $check_modified=true; 
                  $array[]=$product->name." status ".$status." => ".$value->status;
                }
                if($product->weight!=$value->weight){
                  $check_modified=true; 
                  $array[]=$product->name." weight ".$product->weight." => ".$value->weight;
                }
                $weight_class=$product->WeightClass->unit;
                if($weight_class!=$value->weight_class){
                  $check_modified=true; 
                  $array[]=$product->name." weight class ".$weight_class." => ".$value->weight_class;
                }
                if($product->length!=$value->length){
                  $check_modified=true; 
                  $array[]=$product->name." length ".$product->length." => ".$value->length;
                }
                if($product->width!=$value->width){
                  $check_modified=true; 
                  $array[]=$product->name." width ".$product->width." => ".$value->width;
                }
                if($product->height!=$value->height){
                  $check_modified=true; 
                  $array[]=$product->name." height ".$product->height." => ".$value->height;
                }
                $length_class=$product->LengthClass->unit;
                if($length_class!=$value->length_class){
                  $check_modified=true; 
                  $array[]=$product->name." length class ".$length_class." => ".$value->length_class;
                }
                if($product->qty!=$value->quantity){
                  $check_modified=true; 
                  $array[]=$product->name." quantity ".$product->qty." => ".$value->quantity;
                }
                $stock_status=$product->StockStatus->name_en;
                if($stock_status!=$value->out_of_stock_status){
                  $check_modified=true; 
                  $array[]=$product->name." out of stock status ".$stock_status." => ".$value->out_of_stock_status;
                }
                $substract=$product->substract==0 ? "no" : "yes";
                if($substract!==$value->substract_stock){
                  $check_modified=true; 
                  $array[]=$product->name." substract stock ".$substract." => ".$value->substract_stock;
                }
                if($product->minimum!=$value->minimum_quantity){
                  $check_modified=true; 
                  $array[]=$product->name." minimum quantity ".$product->minimum." => ".$value->minimum_quantity;
                }
                $sort_order=$value->sort_order==null ? 0 : $value->sort_order;
                if($product->sort_order!=$sort_order){
                  $check_modified=true; 
                  $array[]=$product->name." sort order ".$product->sort_order." => ".$sort_order;
                }
                $shipping=$product->shipping==0 ? "no" : "yes";
                if($shipping!==$value->require_shipping){
                  $check_modified=true; 
                  $array[]=$product->name." require_shipping ".$shipping." => ".$value->require_shipping;
                }
                if($value->option!=null){
                  $option=Option::whereName($value->option)->first();
                  if(count($option)>0){
                    $count_option++;
                    $last_option=$option;
                    $product_option=$product->ProductOption()->whereOption_id($option->id)->first();
                    if(count($product_option)>0){
                      $option_id[]=$product_option->id;
                      $last_product_option=$product_option;
                      $last_product_option->option_name=$option->name;
                      $stock_enabled=$product_option->stock_enabled==0 ? "no" : "yes";
                      if($stock_enabled!==$value->stock_enabled){
                        $check_modified_option=true; 
                        $array[]=$product->name." option ".$option->name." stock enabled ".$stock_enabled." => ".$value->stock_enabled;
                      }
                      $required=$product_option->required==0 ? "no" : "yes";
                      if($required!==$value->required){
                        $check_modified_option=true; 
                        $array[]=$product->name." option ".$option->name." required ".$required." => ".$value->required;
                      }
                      $option_detail=OptionValue::whereName($value->option_value)->first();
                      if(count($option_detail)>0){
                        $product_option_detail=$product_option->ProductOptionDetail()->whereOption_value_id($option_detail->id)->first();
                        $count_option_detail++;
                        if(count($product_option_detail)>0){
                          $option_detail_id[]=$product_option_detail->id;
                          $check_modified_option_detail=false;
                          $option_substract_stock=$product_option_detail->substract==0 ? "no" : "yes";
                          if($option_substract_stock!==$value->option_substract_stock){
                            $check_modified_option_detail=true; 
                            $array[]=$last_product->name." option ".$option->name." - ".$option_detail->name." substract stock ".$option_substract_stock." => ".$value->option_substract_stock;
                          }
                          if(round($product_option_detail->price)!=$value->option_price){
                            $check_modified_option_detail=true; 
                            $array[]=$last_product->name." option ".$option->name." option price ".round($product_option_detail->price)." => ".$value->option_price;
                          }
                          if($check_modified_option_detail==true){ $option_detail_modified++; }
                        }else{ //product option detail not found
                          $option_detail_new++;
                          $array[]=$product->name." option ".$option->name." new value ".$value->option_value;
                        }
                      }
                    }else{ //product option not found
                      $option_new++;
                      $array[]=$product->name." new option ".$option->name;
                      $option_detail_new++;
                      $array[]=$product->name." option ".$option->name." new value ".$value->option_value;
                    }
                  }
                }
                if($check_modified==true){ $product_modified++; }
                if($check_modified_option==true){ $option_modified++; }
              }else{ //product id null
                if($value->name==null){
                  if($value->option!=null){
                    $option=Option::whereName($value->option)->first();
                    if(count($option)>0){
                      $count_option++;
                      $last_option=$option;
                      if(is_callable(array($last_product, 'ProductOption'))){
                        $product_option=$last_product->ProductOption()->whereOption_id($option->id)->first();

                        if(count($product_option)>0){
                          $option_id[]=$product_option->id;
                          $check_modified_option=false;
                          $check_modified_option_detail=false;
                          $last_product_option=$product_option;
                          $last_product_option->option_name=$option->name;
                          $stock_enabled=$product_option->stock_enabled==0 ? "no" : "yes";
                          if($stock_enabled!==$value->stock_enabled){
                            $check_modified_option=true; 
                            $array[]=$last_product->name." option ".$option->name." stock enabled ".$stock_enabled." => ".$value->stock_enabled;
                          }
                          $required=$product_option->required==0 ? "no" : "yes";
                          if($required!==$value->required){
                            $check_modified_option=true; 
                            $array[]=$last_product->name." option ".$option->name." required ".$required." => ".$value->required;
                          }
                          $option_detail=OptionValue::whereName($value->option_value)->first();
                          if(count($option_detail)>0){
                            $product_option_detail=$product_option->ProductOptionDetail()->whereOption_value_id($option_detail->id)->first();
                            $count_option_detail++;
                            if(count($product_option_detail)>0){
                              $option_detail_id[]=$product_option_detail->id;
                              $check_modified_option_detail=false;
                              $option_substract_stock=$product_option_detail->substract==0 ? "no" : "yes";
                              if($option_substract_stock!==$value->option_substract_stock){
                                $check_modified_option_detail=true; 
                                $array[]=$last_product->name." option ".$option->name." - ".$option_detail->name." substract stock ".$option_substract_stock." => ".$value->option_substract_stock;
                              }
                              if(round($product_option_detail->price)!=$value->option_price){
                                $check_modified_option_detail=true; 
                                $array[]=$last_product->name." option ".$option->name." option price ".round($product_option_detail->price)." => ".$value->option_price;
                              }
                              if($check_modified_option_detail==true){ $option_detail_modified++; }
                            }else{ //product option detail not found
                              $option_detail_new++;
                              $array[]=$last_product->name." option ".$option->name." new value ".$value->option_value;
                            }

                          }
                          if($check_modified_option==true){ $option_modified++; }
                        }else{
                          $option_new++;
                          $array[]=$last_product->name." new option ".$option->name;
                          $optionvalue=OptionValue::whereName($value->option_value)->first();
                          if(count($optionvalue)>0){
                            $count_option_detail++;
                            $option_detail_new++;
                            $array[]=$last_product->name." option ".$option->name." new value ".$value->option_value;
                          }
                        }
                      }else{ //new product and new option
                        $option_value=OptionValue::whereName($value->option_value)->first();
                        if(count($option_value)>0){
                          $array[]=$last_product->name." option ".$option->name." will be created";
                          $option_new++;
                          $array[]=$last_product->name." option ".$option->name." with value ".$option_value->name." will be created";
                          $option_detail_new++;
                        }
                      } 
                    }
                  }else{ //product option not found
                    $option_detail=OptionValue::whereName($value->option_value)->first();
                    if(count($option_detail)>0){
                      $check_modified_option_detail=false;
                      if(is_callable(array($last_product_option, 'ProductOptionDetail'))){
                        $product_option_detail=$last_product_option->ProductOptionDetail()->whereOption_value_id($option_detail->id)->first();
                        $count_option_detail++;
                        if(count($product_option_detail)>0){
                          $option_detail_id[]=$product_option_detail->id;
                          $check_modified_option_detail=false;
                          $option_substract_stock=$product_option_detail->substract==0 ? "no" : "yes";
                          if($option_substract_stock!==$value->option_substract_stock){
                            $check_modified_option_detail=true; 
                            $array[]=$last_product->name." option ".$last_option->name." - ".$option_detail->name." substract stock ".$option_substract_stock." => ".$value->option_substract_stock;
                          }
                          if(round($product_option_detail->price)!=$value->option_price){
                            $check_modified_option_detail=true; 
                            $array[]=$last_product->name." option ".$last_option->name." option price ".round($product_option_detail->price)." => ".$value->option_price;
                          }
                          if($check_modified_option_detail==true){ $option_detail_modified++; }
                        }else{ //product option detail not found
                          $optionvalue=OptionValue::whereName($value->option_value)->first();
                          if(count($optionvalue)>0){
                            $count_option_detail++;
                            $option_detail_new++;
                            $array[]=$last_product->name." option ".$last_option->name." new value ".$value->option_value;
                          }
                        }
                      }else{ //new product and new option detail
                        $option_value=OptionValue::whereName($value->option_value)->first();
                        if(count($option_value)>0){
                          $array[]=$last_product->name." option ".$option_value->Option->name." will be created";
                          $option_new++;
                          $array[]=$last_product->name." option ".$option_value->Option->name." with value ".$option_value->name." will be created";
                          $option_detail_new++;
                        }
                      }
                    }
                  }
                }else{ //new product
                  $err=false;
                  $failreason=[];
                  if($value->model==null){
                    $failreason[]="model";
                    $err=true;
                  }
                  if($value->description==null){
                    $failreason[]="description";
                    $err=true;
                  }
                  if($value->category==null){
                    $failreason[]="category";
                    $err=true;
                  }
                  if($value->weight==null){
                    $failreason[]="weight";
                    $err=true;
                  }
                  if($value->weight_class==null){
                    $failreason[]="weight class";
                    $err=true;
                  }
                  if($value->length_class==null){
                    $failreason[]="length class";
                    $err=true;
                  }
                  if($value->price==null){
                    $failreason[]="price";
                    $err=true;
                  }
                  if($value->quantity==null){
                    $failreason[]="quantity";
                    $err=true;
                  }
                  if($value->stock_status==null){
                    $value->stock_status=3;
                  }
                  if($value->status==null){
                    $value->status=0;
                  }
                  if($value->shipping==null){
                    $value->shipping=1;
                  }
                  if($value->substract==null){
                    $value->substract=1;
                  }
                  if($value->minimum==null){
                    $value->minimum=1;
                  }
                  if($value->sort_order==null){
                    $value->sort_order=0;
                  }
                  if($err==true){
                    $fieldlist="";
                    $totalerr=count($failreason);
                    foreach($failreason as $key => $fr){
                      if($key==0){
                        $fieldlist.=$fr;
                      }elseif(($key+1)==$totalerr){
                        $fieldlist.=" and ".$fr;
                      }else{
                        $fieldlist.=", ".$fr;
                      }
                    }
                    $array[]=$value->name." will not be created as new product, because ".$fieldlist." cannot be empty";
                  }else{
                    $last_product=new \stdClass;
                    $last_product->name=$value->name;
                    $array[]=$value->name." will be created as new product";
                    $product_new++;
                    $option=Option::whereName($value->option)->first();
                    if(count($option)>0){
                      $count_option++;
                      $last_option=$option;
                      $array[]=$value->name." option ".$value->option." will be created";
                      $optiondetail=OptionValue::whereName($value->option_value)->first();
                      if(count($optiondetail)>0){
                        $array[]=$value->name." option ".$value->option." with value ".$value->option_value." will be created";
                      }
                      
                    }
                  }
                  
                }
              }
            }

            $count_rp=count($removed_product);

            $removed_product_option=ProductOption::whereNotIn('id',$option_id)->get();
            $count_rpo=count($removed_product_option);
            foreach ($removed_product_option as $key => $rpo) {
              $product=Product::find($rpo->product_id);
              $option=Option::find($rpo->option_id);
              $array[]=$product->name." option ".$option->name." will be deleted";
            }
            $removed_product_option_detail=ProductOptionDetail::whereNotIn('id',$option_detail_id)->get();
            $count_rpod=count($removed_product_option_detail);
            foreach ($removed_product_option_detail as $key => $rpod) {
              $rpo=ProductOption::find($rpod->product_option_id);
              $product=Product::find($rpo->product_id);
              $option=Option::find($rpo->option_id);
              $array[]=$product->name." option ".$option->name." value ".$rpod->OptionValue->name;
            }

            $results=new \stdClass;
            $results->count_product=$count_product;
            $results->count_option=$count_option;
            $results->count_option_detail=$count_option_detail;
            $results->product_new=$product_new;
            $results->option_new=$option_new;
            $results->option_detail_new=$option_detail_new;
            $results->product_modified=$product_modified;
            $results->option_modified=$option_modified;
            $results->option_detail_modified=$option_detail_modified;
            $results->deleted_product=$count_rp;
            $results->deleted_option=$count_rpo;
            $results->deleted_option_detail=$count_rpod;
            $results->option_id=$option_id;
            $results->option_detail_id=$option_detail_id;
            $results->log=$array;
            $results->token=$save->token;
            //dd($results);

           return redirect('admin/product')->with('import',$results);
    }

    public function confirmImportWithExcel(Request $request)
    {
      
            $excel=ExcelImportFile::whereToken($request['token'])->first();

            $data = \Excel::load($excel->path)->get();

            //dd($data);

            $array=[];
            $last_product=new \stdClass;
            $last_product_option=new \stdClass;
            $last_option=new \stdClass;
            $removed_product=[];
            $option_id=[];
            $option_detail_id=[];
            foreach($data as $key => $value){
              if($value->product_id!=null){
                $product=Product::find($value->product_id);
                $last_product=$product;
                
                if($value->name==null && $value->model==null){
                  $removed_product[]=$product->id;
                  $array[]=$product->name." has been deleted";
                  $product->delete();
                }else{
                  if($product->name!==$value->name){  
                    //$array[]=$product->name." => ".$value->name; 
                    $product->name=$value->name;
                  }
                  if($product->model!==$value->model){ 
                    //$array[]=$product->name." model ".$product->model." => ".$value->model;
                    $product->model=$value->model;
                  }
                  if($product->desc!==$value->description){ 
                    //$array[]=$product->name." description ".$product->desc." => ".$value->description;
                    $product->desc=$value->description;
                  }
                  $categories=$product->ProductToCategory;
                  $formatted_categories='';
                  foreach ($categories as $key => $val) {
                      $formatted_categories.=$val->Category->name."\n";
                  }
                  if(str_replace(" ","",str_replace("\n","",$formatted_categories))!==str_replace(" ","",str_replace("\n","",$value->category))){ 
                    //$array[]=$product->name." category ".$formatted_categories." => ".$value->category;
                    $product->ProductToCategory()->delete();
                    $newcat=explode("\n",$value->category);
                    foreach($newcat as $cat){
                      $findcategory=Category::whereName(str_replace(" ","",$cat))->first();
                      if(count($findcategory)>0){
                        $createptc=new ProductToCategory();
                        $createptc->product_id=$product->id;
                        $createptc->category_id=$findcategory->id;
                        $createptc->save();
                      }
                    }
                  }
                  //attribute
                  $attributes=$product->ProductAttribute;
                  $formatted_attributes='';
                  foreach ($attributes as $key => $val) {
                      $formatted_attributes.=$val->Attribute->name.' : '.$value->value."\n";
                  }

                  if(str_replace(" ","",str_replace("\n","",$formatted_attributes))!==str_replace(" ","",str_replace("\n","",$value->attribute))){ 
                    //$array[]=$product->name." attribute ".$formatted_attributes." => ".$value->attribute;
                    $product->ProductAttribute()->delete();
                    $newatt=explode("\n",$value->attribute);
                    foreach($newatt as $att){
                      $array_att=explode(" : ",$att);
                      $att_name=$array_att[0];
                      $att_value=array_key_exists(1, $array_att) ? $array_att[1] : '';
                      if(strlen($att_value)>0){
                        $findattribute=Attribute::whereName($att_name)->first();
                        if(count($findattribute)>0){
                          $createpta=new ProductAttribute();
                          $createpta->product_id=$product->id;
                          $createpta->attribute_id=$findattribute->id;
                          $createpta->value=$att_value;
                          $createpta->save();
                        }
                      }
                    }
                  }
                  $manufacturer=$product->Manufacturer;
                  if($manufacturer['name']!==$value->manufacturer){ 
                    //$array[]=$product->name." manufacturer ".$manufacturer['name']." => ".$value->manufacturer;
                    $findmanufacturer=Manufacturer::whereName($value->manufacturer)->first();
                    if(count($findmanufacturer)>0){
                      $product->manufacturer_id=$findmanufacturer->id;
                    }
                  }
                  if($product->price!=$value->price){ 
                    //$array[]=$product->name." price ".$product->price." => ".$value->price;
                    $product->price=$value->price;
                  }
                  $status=$value->status=="enabled" ? 1 : 0;
                  //$status=$product->status==0 ? "disabled" : "enabled";
                  //if($status!==$value->status){ 
                    //$array[]=$product->name." status ".$status." => ".$value->status;
                    $product->status=$product->status==$status ? $product->status : $status;
                  //}
                  if($product->weight!=$value->weight){ 
                    //$array[]=$product->name." weight ".$product->weight." => ".$value->weight;
                    $product->weight=$value->weight;
                  }
                  $weight_class=$product->WeightClass->unit;
                  if($weight_class!=$value->weight_class){ 
                    //$array[]=$product->name." weight class ".$weight_class." => ".$value->weight_class;
                    $findweightclass=WeightClass::whereUnit($value->weight_class)->first();
                    if(count($findweightclass)>0){
                      $product->weight_class_id=$findweightclass->id;
                    }
                  }
                  if($product->length!=$value->length){ 
                    //$array[]=$product->name." length ".$product->length." => ".$value->length;
                    $product->length=$value->length;
                  }
                  if($product->width!=$value->width){ 
                    //$array[]=$product->name." width ".$product->width." => ".$value->width;
                    $product->width=$value->width;
                  }
                  if($product->height!=$value->height){ 
                    //$array[]=$product->name." height ".$product->height." => ".$value->height;
                    $product->height=$value->height;
                  }
                  $length_class=$product->LengthClass->unit;
                  if($length_class!=$value->length_class){ 
                    //$array[]=$product->name." length class ".$length_class." => ".$value->length_class;
                    $findlengthclass=LengthClass::whereUnit($value->length_class)->first();
                    if(count($findlengthclass)>0){
                      $product->length_class_id=$findlengthclass->id;
                    }
                  }
                  if($product->qty!=$value->quantity){ 
                    //$array[]=$product->name." quantity ".$product->qty." => ".$value->quantity;
                    $product->qty=$value->quantity;
                  }
                  $stock_status=$product->StockStatus->name_en;
                  if($stock_status!=$value->out_of_stock_status){ 
                    //$array[]=$product->name." out of stock status ".$stock_status." => ".$value->out_of_stock_status;
                    $findstockstatus=StockStatus::whereName_en($value->out_of_stock_status)
                      ->orWhere('name_id',$value->out_of_stock_status)
                      ->first();
                    if(count($findstockstatus)>0){
                      $product->stock_status_id=$findstockstatus->id;
                    }
                  }
                  $substract=$product->substract==0 ? "no" : "yes";
                  if($substract!==$value->substract_stock){ 
                    $newsubstract=$value->substract_stock==="yes" ? 1 : 0;
                    //$array[]=$product->name." substract stock ".$substract." => ".$value->substract_stock;
                    $product->substract=$newsubstract;
                  }
                  if($product->minimum!=$value->minimum_quantity){ 
                    //$array[]=$product->name." minimum quantity ".$product->minimum." => ".$value->minimum_quantity;
                    $product->minimum=$value->minimum_quantity;
                  }
                  $sort_order=$value->sort_order==null ? 0 : $value->sort_order;
                  if($product->sort_order!=$sort_order){ 
                    //$array[]=$product->name." sort order ".$product->sort_order." => ".$sort_order;
                    $product->sort_order=$sort_order;
                  }
                  $shipping=$product->shipping==0 ? "no" : "yes";
                  if($shipping!==$value->require_shipping){ 
                    //$array[]=$product->name." require_shipping ".$shipping." => ".$value->require_shipping;
                    $newshipping=$value->require_shipping==="yes" ? 1 : 0;
                    $product->shipping=$newshipping;
                  }
                  if($value->option!=null){
                    $option=Option::whereName($value->option)->first();
                    if(count($option)>0){
                      $last_option=$option;
                      $product_option=$product->ProductOption()->whereOption_id($option->id)->first();
                      if(count($product_option)>0){
                        $option_id[]=$product_option->id;
                        $last_product_option=$product_option;
                        $last_product_option->option_name=$option->name;
                        $stock_enabled=$product_option->stock_enabled==0 ? "no" : "yes";
                        if($stock_enabled!==$value->stock_enabled){ 
                          //$array[]=$product->name." option ".$option->name." stock enabled ".$stock_enabled." => ".$value->stock_enabled;
                          $newstock_enabled=$value->stock_enabled==="yes" ? 1 : 0;
                          $product_option->stock_enabled=$newstock_enabled;
                        }
                        $required=$product_option->required==0 ? "no" : "yes";
                        if($required!==$value->required){
                          //$array[]=$product->name." option ".$option->name." required ".$required." => ".$value->required;
                          $newrequired=$value->required==="yes" ? 1 : 0;
                          $product_option->required=$newrequired;
                        }
                        $option_detail=OptionValue::whereName($value->option_value)->first();
                        if(count($option_detail)>0){
                          $product_option_detail=$product_option->ProductOptionDetail()->whereOption_value_id($option_detail->id)->first();
                          if(count($product_option_detail)>0){
                            $option_detail_id[]=$product_option_detail->id;
                            $option_substract_stock=$product_option_detail->substract==0 ? "no" : "yes";
                            if($option_substract_stock!==$value->option_substract_stock){
                              //$array[]=$last_product->name." option ".$option->name." - ".$option_detail->name." substract stock ".$option_substract_stock." => ".$value->option_substract_stock;
                              $new_option_substract=$value->option_substract_stock==="yes" ? 1 : 0;
                              $product_option_detail->substract=$new_option_substract;
                            }
                            if(round($product_option_detail->price)!=$value->option_price){
                              //$array[]=$last_product->name." option ".$option->name." option price ".round($product_option_detail->price)." => ".$value->option_price;
                              $product_option_detail->price=$value->option_price;
                            }
                            $product_option_detail->save();
                          }else{ //product option detail not found
                            //$array[]=$product->name." option ".$option->name." new value ".$value->option_value;
                            $product_option_detail=new ProductOptionDetail();
                            $product_option_detail->product_id=$product->id;
                            $product_option_detail->product_option_id=$product_option->id;
                            $product_option_detail->option_id=$option->id;
                            $product_option_detail->option_value_id=$option_detail->id;
                            $product_option_detail->qty=0;
                            $new_option_substract=$value->option_substract_stock==="yes" ? 1 : 0;
                            $product_option_detail->substract=$new_option_substract;
                            $product_option_detail->price=$value->option_price;
                            $product_option_detail->save();
                          }
                        }
                      }else{ //product option not found
                        //$array[]=$product->name." new option ".$option->name;
                        //$array[]=$product->name." option ".$option->name." new value ".$value->option_value;
                        $new_po=new ProductOption();
                        $new_po->product_id=$product->id;
                        $new_po->option_id=$option->id;
                        $new_po->required=$value->required==="yes" ? 1 : 0;
                        $new_po->stock_enabled=$value->stock_enabled==="yes" ? 1 : 0;
                        $new_po->save();

                            $product_option_detail=new ProductOptionDetail();
                            $product_option_detail->product_id=$product->id;
                            $product_option_detail->product_option_id=$new_po->id;
                            $product_option_detail->option_id=$option->id;
                            $product_option_detail->option_value_id=$option_detail->id;
                            $product_option_detail->qty=0;
                            $new_option_substract=$value->option_substract_stock==="yes" ? 1 : 0;
                            $product_option_detail->substract=$new_option_substract;
                            $product_option_detail->price=$value->option_price;
                            $product_option_detail->save();
                      }
                    }
                  }
                  $product->save();
                  $product->touch();
                }
              }else{ //product id null
                if($value->name==null){
                  if($value->option!=null){
                    $option=Option::whereName($value->option)->first();
                    if(count($option)>0){
                      $last_option=$option;
                      if(is_callable(array($last_product, 'ProductOption'))){
                        $product_option=$last_product->ProductOption()->whereOption_id($option->id)->first();

                        if(count($product_option)>0){
                          $option_id[]=$product_option->id;
                          $last_product_option=$product_option;
                          $last_product_option->option_name=$option->name;
                          $stock_enabled=$product_option->stock_enabled==0 ? "no" : "yes";
                          if($stock_enabled!==$value->stock_enabled){
                            //$array[]=$last_product->name." option ".$option->name." stock enabled ".$stock_enabled." => ".$value->stock_enabled;
                            $newstock_enabled=$value->stock_enabled==="yes" ? 1 : 0;
                            $product_option->stock_enabled=$newstock_enabled;
                          }
                          $required=$product_option->required==0 ? "no" : "yes";
                          if($required!==$value->required){
                            //$array[]=$last_product->name." option ".$option->name." required ".$required." => ".$value->required;
                            $newrequired=$value->required==="yes" ? 1 : 0;
                            $product_option->required=$newrequired;
                          }
                          $option_detail=OptionValue::whereName($value->option_value)->first();
                          if(count($option_detail)>0){
                            $product_option_detail=$product_option->ProductOptionDetail()->whereOption_value_id($option_detail->id)->first();
                            if(count($product_option_detail)>0){
                              $option_detail_id[]=$product_option_detail->id;
                              $option_substract_stock=$product_option_detail->substract==0 ? "no" : "yes";
                              if($option_substract_stock!==$value->option_substract_stock){
                                //$array[]=$last_product->name." option ".$option->name." - ".$option_detail->name." substract stock ".$option_substract_stock." => ".$value->option_substract_stock;
                                $new_option_substract=$value->option_substract_stock==="yes" ? 1 : 0;
                                $product_option_detail->substract=$new_option_substract;
                              }
                              if(round($product_option_detail->price)!=$value->option_price){
                                //$array[]=$last_product->name." option ".$option->name." option price ".round($product_option_detail->price)." => ".$value->option_price;
                                $product_option_detail->price=$value->option_price;
                              }
                              $product_option_detail->save();
                            }else{ //product option detail not found
                              $option_detail_new++;
                              $array[]=$last_product->name." option ".$option->name." new value ".$value->option_value;
                            }

                          }
                          $product_option_detail->save();
                        }else{
                          //$array[]=$last_product->name." new option ".$option->name;
                          $optionvalue=OptionValue::whereName($value->option_value)->first();
                          if(count($optionvalue)>0){
                            //$array[]=$last_product->name." option ".$option->name." new value ".$value->option_value;
                            $product_option_detail=new ProductOptionDetail();
                            $product_option_detail->product_id=$product->id;
                            $product_option_detail->product_option_id=$product_option->id;
                            $product_option_detail->option_id=$option->id;
                            $product_option_detail->option_value_id=$optionvalue->id;
                            $product_option_detail->qty=0;
                            $new_option_substract=$value->option_substract_stock==="yes" ? 1 : 0;
                            $product_option_detail->substract=$new_option_substract;
                            $product_option_detail->price=$value->option_price;
                            $product_option_detail->save();
                          }
                        }
                      }else{ //new product and new option
                        $option_value=OptionValue::whereName($value->option_value)->first();
                        if(count($option_value)>0){
                          //$array[]=$last_product->name." option ".$option->name." will be created";
                          //$array[]=$last_product->name." option ".$option->name." with value ".$option_value->name." will be created";\
                          $new_po=new ProductOption();
                          $new_po->product_id=$last_product->id;
                          $new_po->option_id=$option->id;
                          $new_po->required=$value->required==="yes" ? 1 : 0;
                          $new_po->stock_enabled=$value->stock_enabled==="yes" ? 1 : 0;
                          $new_po->save();

                              $product_option_detail=new ProductOptionDetail();
                              $product_option_detail->product_id=$last_product->id;
                              $product_option_detail->product_option_id=$new_po->id;
                              $product_option_detail->option_id=$option->id;
                              $product_option_detail->option_value_id=$option_value->id;
                              $product_option_detail->qty=0;
                              $new_option_substract=$value->option_substract_stock==="yes" ? 1 : 0;
                              $product_option_detail->substract=$new_option_substract;
                              $product_option_detail->price=$value->option_price;
                              $product_option_detail->save();
                        }
                      } 
                    }
                  }else{ //product option not found
                    $option_detail=OptionValue::whereName($value->option_value)->first();
                    if(count($option_detail)>0){
                      if(is_callable(array($last_product_option, 'ProductOptionDetail'))){
                        $product_option_detail=$last_product_option->ProductOptionDetail()->whereOption_value_id($option_detail->id)->first();
                        if(count($product_option_detail)>0){
                          $option_detail_id[]=$product_option_detail->id;
                          $option_substract_stock=$product_option_detail->substract==0 ? "no" : "yes";
                          if($option_substract_stock!==$value->option_substract_stock){
                            //$array[]=$last_product->name." option ".$last_option->name." - ".$option_detail->name." substract stock ".$option_substract_stock." => ".$value->option_substract_stock;
                            $new_option_substract=$value->option_substract_stock==="yes" ? 1 : 0;
                            $product_option_detail->substract=$new_option_substract;
                          }
                          if(round($product_option_detail->price)!=$value->option_price){
                            //$array[]=$last_product->name." option ".$last_option->name." option price ".round($product_option_detail->price)." => ".$value->option_price;
                            $product_option_detail->price=$value->option_price;
                          }
                          $product_option_detail->save();
                        }else{ //product option detail not found
                          $optionvalue=OptionValue::whereName($value->option_value)->first();
                          if(count($optionvalue)>0){
                            //$array[]=$last_product->name." option ".$last_option->name." new value ".$value->option_value;
                            $product_option_detail=new ProductOptionDetail();
                            $product_option_detail->product_id=$last_product->id;
                            $product_option_detail->product_option_id=$last_product_option->id;
                            $product_option_detail->option_id=$last_option->id;
                            $product_option_detail->option_value_id=$optionvalue->id;
                            $product_option_detail->qty=0;
                            $new_option_substract=$value->option_substract_stock==="yes" ? 1 : 0;
                            $product_option_detail->substract=$new_option_substract;
                            $product_option_detail->price=$value->option_price;
                            $product_option_detail->save();
                          }
                        }
                      }else{ //new product and new option detail
                        $option_value=OptionValue::whereName($value->option_value)->first();
                        if(count($option_value)>0){
                          //$array[]=$last_product->name." option ".$option_value->Option->name." will be created";
                          //$array[]=$last_product->name." option ".$option_value->Option->name." with value ".$option_value->name." will be created";
                          $product_option_detail=new ProductOptionDetail();
                          $product_option_detail->product_id=$last_product->id;
                          $product_option_detail->product_option_id=$last_product_option->id;
                          $product_option_detail->option_id=$last_option->id;
                          $product_option_detail->option_value_id=$optionvalue->id;
                          $product_option_detail->qty=0;
                          $new_option_substract=$value->option_substract_stock==="yes" ? 1 : 0;
                          $product_option_detail->substract=$new_option_substract;
                          $product_option_detail->price=$value->option_price;
                          $product_option_detail->save();
                        }
                      }
                    }
                  }
                }else{ //new product
                  $err=false;
                  $failreason=[];
                  if($value->model==null){
                    $failreason[]="model";
                    $err=true;
                  }
                  if($value->description==null){
                    $failreason[]="description";
                    $err=true;
                  }
                  if($value->category==null){
                    $failreason[]="category";
                    $err=true;
                  }
                  if($value->weight==null){
                    $failreason[]="weight";
                    $err=true;
                  }
                  if($value->weight_class==null){
                    $failreason[]="weight class";
                    $err=true;
                  }
                  if($value->length_class==null){
                    $failreason[]="length class";
                    $err=true;
                  }
                  if($value->price==null){
                    $failreason[]="price";
                    $err=true;
                  }
                  if($value->quantity==null){
                    $failreason[]="quantity";
                    $err=true;
                  }
                  if($value->stock_status==null){
                    $value->stock_status=3;
                  }
                  if($value->status==null){
                    $value->status=0;
                  }
                  if($value->shipping==null){
                    $value->shipping=1;
                  }
                  if($value->substract==null){
                    $value->substract=1;
                  }
                  if($value->minimum==null){
                    $value->minimum=1;
                  }
                  if($value->sort_order==null){
                    $value->sort_order=0;
                  }
                  if($err==true){
                    $fieldlist="";
                    $totalerr=count($failreason);
                    foreach($failreason as $key => $fr){
                      if($key==0){
                        $fieldlist.=$fr;
                      }elseif(($key+1)==$totalerr){
                        $fieldlist.=" and ".$fr;
                      }else{
                        $fieldlist.=", ".$fr;
                      }
                    }
                    //$array[]=$value->name." will not be created as new product, because ".$fieldlist." cannot be empty";
                  }else{
                    //$array[]=$value->name." will be created as new product";
                    $product=new Product();
                    $product->name=$value->name;
                    $product->model=$value->model;
                    $product->desc=$value->description;
                    $findmanufacturer=Manufacturer::whereName($value->manufacturer)->first();
                    if(count($findmanufacturer)>0){
                      $product->manufacturer_id=$findmanufacturer->id;
                    }
                    $product->price=$value->price;
                    $product->status=$product->status==$status ? $product->status : $status;
                    $product->weight=$value->weight;
                    $findweightclass=WeightClass::whereUnit($value->weight_class)->first();
                    if(count($findweightclass)>0){
                      $product->weight_class_id=$findweightclass->id;
                    }
                    $product->length=$value->length;
                    $product->width=$value->width;
                    $product->height=$value->height;
                    $findlengthclass=LengthClass::whereUnit($value->length_class)->first();
                    if(count($findlengthclass)>0){
                      $product->length_class_id=$findlengthclass->id;
                    }
                    $product->qty=$value->quantity;
                    $findstockstatus=StockStatus::whereName_en($value->out_of_stock_status)
                      ->orWhere('name_id',$value->out_of_stock_status)
                      ->first();
                    if(count($findstockstatus)>0){
                      $product->stock_status_id=$findstockstatus->id;
                    }
                    $newsubstract=$value->substract_stock==="yes" ? 1 : 0;
                    $product->substract=$newsubstract;
                    $product->minimum=$value->minimum_quantity;

                    $sort_order=$value->sort_order==null ? 0 : $value->sort_order;
                    $product->sort_order=$sort_order;
                    $newshipping=$value->require_shipping==="yes" ? 1 : 0;
                    $product->shipping=$newshipping;
                    $product->save();

                    $newcat=explode("\n",$value->category);
                    foreach($newcat as $cat){
                      $findcategory=Category::whereName(str_replace(" ","",$cat))->first();
                      if(count($findcategory)>0){
                        $createptc=new ProductToCategory();
                        $createptc->product_id=$product->id;
                        $createptc->category_id=$findcategory->id;
                        $createptc->save();
                      }
                    }

                    $newatt=explode("\n",$value->attribute);
                    foreach($newatt as $att){
                      $array_att=explode(" : ",$att);
                      $att_name=$array_att[0];
                      $att_value=array_key_exists(1, $array_att) ? $array_att[1] : '';
                      if(strlen($att_value)>0){
                        $findattribute=Attribute::whereName($att_name)->first();
                        if(count($findattribute)>0){
                          $createpta=new ProductAttribute();
                          $createpta->product_id=$product->id;
                          $createpta->attribute_id=$findattribute->id;
                          $createpta->value=$att_value;
                          $createpta->save();
                        }
                      }
                    }

                    $option=Option::whereName($value->option)->first();
                    if(count($option)>0){
                      $last_option=$option;
                      //$array[]=$value->name." option ".$value->option." will be created";
                      $new_po=new ProductOption();
                      $new_po->product_id=$product->id;
                      $new_po->option_id=$option->id;
                      $new_po->required=$value->required==="yes" ? 1 : 0;
                      $new_po->stock_enabled=$value->stock_enabled==="yes" ? 1 : 0;
                      $new_po->save();

                      $optiondetail=OptionValue::whereName($value->option_value)->first();
                      if(count($optiondetail)>0){
                        //$array[]=$value->name." option ".$value->option." with value ".$value->option_value." will be created";
                        $product_option_detail=new ProductOptionDetail();
                        $product_option_detail->product_id=$product->id;
                        $product_option_detail->product_option_id=$new_po->id;
                        $product_option_detail->option_id=$option->id;
                        $product_option_detail->option_value_id=$optiondetail->id;
                        $product_option_detail->qty=0;
                        $new_option_substract=$value->option_substract_stock==="yes" ? 1 : 0;
                        $product_option_detail->substract=$new_option_substract;
                        $product_option_detail->price=$value->option_price;
                        $product_option_detail->save();
                      }
                      
                    }
                  }
                  
                }
              }
            }

            $count_rp=count($removed_product);

            $removed_product_option=ProductOption::whereNotIn('id',$option_id)->delete();
            //$count_rpo=count($removed_product_option);
            // foreach ($removed_product_option as $key => $rpo) {
            //   $product=Product::find($rpo->product_id);
            //   $option=Option::find($rpo->option_id);
            //   $array[]=$product->name." option ".$option->name." will be deleted";
            // }
            $removed_product_option_detail=ProductOptionDetail::whereNotIn('id',$option_detail_id)->delete();
            //$count_rpod=count($removed_product_option_detail);
            // foreach ($removed_product_option_detail as $key => $rpod) {
            //   $rpo=ProductOption::find($rpod->product_option_id);
            //   $product=Product::find($rpo->product_id);
            //   $option=Option::find($rpo->option_id);
            //   $array[]=$product->name." option ".$option->name." value ".$rpod->OptionValue->name;
            // }

            

           return redirect('admin/product')->with('success',"Import Success");
    }

}

?>