<?php 

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Option;
use App\Models\OptionValue;

class OptionController extends Controller 
{
  public function showIndex()
  {
      $results = Option::orderBy('name')->paginate(20);
      return view('admin.option.index', compact('results'));
  }


  /**
   * Display a listing of the resource.
   *
   * @return Response
   */
  public function index(Request $request)
  {
      $columns = array( 
                            0 =>'id', 
                            1 =>'name',
                            2 =>'type',
                            3 =>'sort_order',
                            4 =>'action'
                        );
  
        $totalData = Option::count();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        if(array_key_exists($request->input('order.0.column'), $columns)){
          $order = $columns[$request->input('order.0.column')];
        }else{
          $order = 'id';
        }
        if($request->input('order.0.dir')!==null){
          $dir = $request->input('order.0.dir');
        }else{
          $dir = 'asc';
        }
        
            
        if(empty($request->input('search.value')))
        {            
            $results = Option::orderBy($order,$dir)->offset($start)->limit($limit)
                         ->get();
        }
        else {
            $search = $request->input('search.value'); 

            $results =  Option::where('name','LIKE',"%{$search}%")
                            ->offset($start)
                            ->limit($limit)
                            ->orderBy($order,$dir)
                            ->get();

            $totalFiltered = Option::where('name','LIKE',"%{$search}%")
                             ->count();
        }

        $data = array();
        if(!empty($results))
        {
            foreach ($results as $value)
            {
                $edit =  url('admin/option/edit',$value->id);

                $nestedData['id'] = "<input type='checkbox' name='selected[]'' value='{$value->id}'>";
                $nestedData['name'] = $value->name;
                $nestedData['type'] = $value->type;
                $nestedData['sort_order'] = $value->sort_order;
                $nestedData['action'] = "&emsp;<a href='{$edit}' title='EDIT' ><span class='glyphicon glyphicon-edit'></span></a>";
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data); 
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return Response
   */
  public function create()
  {
      return view('admin.option.create');
  }

  /**
   * Store a newly created resource in storage.
   *
   * @return Response
   */
  public function store(Request $request)
  {
      //return $request->all();
      $request->validate([
          'name' => 'required|max:191',
          //'type' => 'required',
          'required' => 'required|numeric',
          'sort_order' => 'numeric',
          'optionvalue.*.sort_order' => 'numeric',
      ]);
      

      $store=new Option();
      $store->name=$request['name'];
      $store->type='select';
      $store->required=$request['required'];
      $store->sort_order=$request['sort_order'];
      $store->save();

      foreach($request->input('optionvalue') as $ov)
      if(strlen($ov['name'])>0){
        $opval=new OptionValue();
        $opval->option_id=$store->id;
        $opval->name=$ov['name'];
        $opval->sort_order=$ov['sort_order'];
        $opval->save();
      }
      return redirect('admin/option')->with('success',$request['name'].' successfully added.');
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function show($id)
  {
      
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function edit($id)
  {
      $results = Option::findOrFail($id);
      return view('admin.option.edit', compact('results'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function update($id, Request $request)
  {
      $request->validate([
          'name' => 'required|max:191',
          'sort_order' => 'numeric',
          'required' => 'required|numeric',
          'optionvalue.*.sort_order' => 'numeric',
      ]);
      $store=Option::findOrFail($id);
      $store->name=$request['name'];
      $store->type='select';
      $store->required=$request['required'];

      $store->sort_order=$request['sort_order'];
      $store->save();
      $store->touch();

      //$delOV=OptionValue::whereOption_id($id)->delete();
      $arr=[];
      foreach($request->input('optionvalue') as $key=>$ov){
        if(strlen($ov['name'])>0){
          $getOV=OptionValue::find($key);
          if(count($getOV)>0){
            // $arr[]=$key;
            $getOV->option_id=$store->id;
            $getOV->name=$ov['name'];
            $getOV->sort_order=$ov['sort_order'];
            $getOV->save();
            $getOV->touch();
            $arr[]=$getOV->id;
          }else{
            $opval=new OptionValue();
            $opval->option_id=$store->id;
            $opval->name=$ov['name'];
            $opval->sort_order=$ov['sort_order'];
            $opval->save();
            $arr[]=$opval->id;
          }
        }
      }

      $delOV=OptionValue::whereOption_id($store->id)->whereNotIn('id',$arr)->delete();
      
      return redirect('admin/option')->with('success',$request['name'].' successfully updated.');
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function destroy($id)
  {
    
  }

  public function trash(Request $request)
  {
      $request->validate([
          'selected' => 'array'
      ]);
      $count=count($request['selected']);
      if($count>0)
      {
        $delete=Option::whereIn('id',$request['selected'])->delete();
        return back()->with('success', $count.' item has been deleted.');
      }
  }

  public function deleteImage($id)
  {
      $deleteimage=Option::find($id);
      $deleteimage->image=null;
      $deleteimage->save();
      $deleteimage->touch();
      return back()->with('success', 'Image has been deleted.');
  }

  public function search(Request $request)
    {
        $term = trim($request->q);

        // if (empty($term)) {
        //     return \Response::json([]);
        // }

        $results = Option::where('name', 'LIKE', '%'.$term.'%')->limit(5)->get();

        $formatted_results = [];

        foreach ($results as $val) {
            $formatted_results[] = ['id' => $val->id, 'text' => $val->name];
        }

        return response()->json($formatted_results);
    }

    public function optionValue($id,$index)
    {
        $optionvalue=OptionValue::whereOption_id($id)->get();
        $element="";
        // if(count($optionvalue)>0){
        //   $element.="<select name='productoption[{$index}][option_value_id]' value='' placeholder='Option' id='optionvalue{$index}' class='form-control optionvalue'>";
        // }
        foreach($optionvalue as $val){
          $element.="<option value='{$val->id}'>{$val->name}</option>";
        }
        // if(count($optionvalue)>0){
        //   $element.="</select>";
        // }
        return response()->json($element);
    }
  
}

?>