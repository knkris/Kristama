<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Manufacturer;
use App\Models\Product;
use App\Models\ProductOption;
use App\Models\ProductOptionDetail;
use App\Models\ProductToCategory;
use App\Models\Option;
use App\Models\OptionValue;
use App\Models\ProductStock;
use App\Models\ProductStockDetail;
use App\Models\User;
use App\Models\Address;
use App\Models\Cart;
use App\Models\ShippingMethod;
use App\Models\ShippingCourier;
use App\Models\City;
use App\Models\Subdistrict;
use App\Models\PaymentMethod;
use App\Models\Order;
use App\Models\OrderDetail;
use App\Models\OrderHistory;
use App\Models\Bank;
use App\Models\WeightClass;
use App\Models\Blog;
use App\Models\RecommendedProduct;
use App\Models\ProductDiscussion;
use App\Models\ProductToProduct;
use Carbon\Carbon;
use Auth;
use Countries;
use Response;
use Mail;

class ApiController extends Controller
{
    public function retrieveProducts(Request $request)
    {
        $sort=new \stdClass();
        $sort->col='created_at';
        $sort->dir='desc';

        $show=20;
        if(!empty($cat)){
            if($cat==='All Category'){
                $category=null;
                $subcategories=[];
            }else{
                $category=Category::whereSlug($cat)->first();
                $child=$category->child();
                if(count($child)){
                    $subcategories=$child;
                }else{
                    $subcategories=Category::whereParent_id($category->parent_id)->get();
                }
            }
        }else{
            $category=null;
            $subcategories=[];
        }
        if(!empty($request->input('category'))){
            if($request->input('category')==='All Category'){
                $category=null;
                $subcategories=[];
            }else{
                $category=Category::whereSlug($request->input('category'))->first();
                $child=$category->child();
                if(count($child)){
                    $subcategories=$child;
                }else{
                    $subcategories=Category::whereParent_id($category->parent_id)->get();
                }
            }
        }else{
            $category=null;
            $subcategories=[];
        }
        if(!empty($request->input('subcategory'))){
            if($request->input('subcategory')==='All Category'){
                $subcategory=null;
            }else{
                $subcategory=null;
                $getcategory=Category::whereName($cat)->get();
                foreach ($getcategory as $key => $value) {
                    $trysubcategory=Category::whereName($request->input('subcategory'))->whereParent_id($value->id)->first();
                    if(count($trysubcategory)){
                        $subcategory=$trysubcategory;
                        $category=$value;
                    }
                }
            }
        }else{
            $subcategory=null;
        }
        if(!empty($request->input('brand'))){
            if($request->input('brand')==='All Brand'){
                $brand=null;
                $brandid=[];
            }else{
                $brandid=explode(',', $request->input('brand'));
                $brand=Manufacturer::whereIn('id',$brandid)->get();
            }
        }else{
             $brand=null;
             $brandid=[];
        }
        if(!empty($request->input('sort'))){
            switch ($request->input('sort')) {
                case 'lowest_price':
                    $sort->col='pric_filter';
                    $sort->dir='asc';
                    break;

                case 'highest_price':
                    $sort->col='price_filter';
                    $sort->dir='desc';
                    break;

                case 'sold':
                    $sort->col='sold';
                    $sort->dir='desc';
                    break;

                case 'newer':
                    $sort->col='created_at';
                    $sort->dir='desc';
                    break;
                
                default:
                    $sort->col='model';
                    $sort->dir='asc';
                    break;
            }
        }

        if(!empty($request->input('show'))){
            switch ($request->input('show')) {
                case '40':
                    $show=40;
                    break;

                case '60':
                    $show=60;
                    break;

                case '80':
                    $show=80;
                    break;

                case '100':
                    $show=100;
                    break;
                
                default:
                    $show=20;
                    break;
            }
        }
        // if(!empty($request->input('q'))){
        //     $search_history=new SearchHistory();
        //     if(Auth::check()){
        //         $search_history->user_id=Auth::user()->id;
        //     }
        //     $search_history->keyword=$request->input('q');
        //     $search_history->ip=$request->ip();
        //     $search_history->save();
        // }
        $products=Product::when (!empty($request->input('category')) && $category!=null , function ($query) use($category,$request){
                        return $query->whereHas('ProductToCategory', function($q) use ($category){
                            $q->where('category_id', '=', $category->id);
                        });
                    })
                    ->when (!empty($request->input('min')) && !empty($request->input('max')) , function ($query) use($request){
                        return $query->where('price_filter','>=', $request->input('min'))->where('price_filter','<=', $request->input('max'));
                    })
                    ->when (empty($request->input('max')) && !empty($request->input('min')) , function ($query) use($request){
                        return $query->where('price_filter','>=', $request->input('min'));
                    })
                    ->when (!empty($request->input('max')) && empty($request->input('min')) , function ($query) use($request){
                        return $query->where('price_filter','<=', $request->input('max'));
                    })
                    ->when (!empty($request->input('brand')) && $brand!=null , function ($query) use($brand,$brandid){
                        return $query->whereIn('manufacturer_id', $brandid);
                    })
                    ->when (!empty($request->input('sort')) , function ($query) use($request, $sort){
                        switch ($request->input('sort')) {
                            case 'lowest_price':
                                return $query->orderBy('price_filter','asc');
                                break;

                            case 'highest_price':
                                return $query->orderBy('price_filter','desc');
                                break;

                            default:
                                return $query->orderBy($sort->col, $sort->dir);
                                break;
                        }
                    })
                    ->when (!empty($request->input('rating')) , function ($query) use($request){
                        return $query->where('avg_rating','=', $request->input('rating'));
                    })
                    ->when (!empty($request->input('q')) , function ($q) use($brand,$request){
                        $q->where(function($query) use ($brand,$request){
                               $query->where('name', 'like', '%'.$request->input('q').'%')
                                    ->orWhere('slug', 'like', '%'.$request->input('q').'%')
                                    ->orWhere('model', 'like', '%'.$request->input('q').'%')
                                    ->orWhere('desc', 'like', '%'.$request->input('q').'%');
                            });
                          // ->orWhere(function($query) use ($brand,$request) {
                          //       $string=explode(' ',$request->input('q'));
                          //       foreach($string as $key => $value){
                          //           $query->where('name', 'like', '%'.$value.'%');
                          //           $query->orWhere('model', 'like', '%'.$value.'%');
                          //           $query->orWhere('desc', 'like', '%'.$value.'%');
                          //       }
                          //   });
                        
                      return $q;
                    })
                    ->when (!empty($request->input('exact')) , function ($q) use($brand,$request){
                        $q->where(function($query) use ($brand,$request){
                               $query->where('name', 'like', '%'.$request->input('exact').'%');
                            });
                        
                      return $q;
                    })
                    ->when (!empty($request->input('words')) , function ($q) use($brand,$request){
                        $q->where(function($query) use ($brand,$request) {
                                $string=explode(' ',$request->input('words'));
                                foreach($string as $key => $value){
                                    $query->where('name', 'like', '%'.$value.'%');
                                    $query->orWhere('model', 'like', '%'.$value.'%');
                                    $query->orWhere('desc', 'like', '%'.$value.'%');
                                }
                                
                            });
                      return $q;
                    })
                    ->when (!empty($request->input('exclude')) , function ($q) use($brand,$request){
                        $q->where(function($query) use ($brand,$request){
                               $query->where('name', 'NOT LIKE', '%'.$request->input('exclude').'%');
                            });
                      return $q;
                    })
                    ->when (!empty($request->input('color')) , function ($q) use($request){
                        $q->where(function($query) use ($request) {
                                $query->where('name', 'like', '% '.$request->input('color').'%');
                                
                            });
                      return $q;
                    })
                    //->orderBy($sort->col, $sort->dir)
                    ->with('Image')
                    ->with('Manufacturer')
                    ->whereStatus(1)
                    ->where('qty','>',0)
                    ->paginate(20);

        foreach ($products->items() as $key => $value) {
        	$name=strlen($value->name)>30 ? substr($value->name, 0, 30)."..." : $value->name;
            $value->name=ucwords(strtolower($name));
            $value->star=$value->Star();
            //if (Auth::check()){
	            $value->final_price=currency_format($value->price_filter,'IDR');
	        // }else{
	        // 	$value->final_price=currency_format($value->finalPrice(1,1),'IDR');
	        // }
            $value->price_format=currency_format($value->price,'IDR');
            $value->img=$value->Image ? $value->Image->first()->image : 'http://via.placeholder.com/174x111';
        }

        return response()->json($products);
    }

    public function recommendedProduct()
    {
    	$recommended_products = RecommendedProduct::whereHas('Product')->inRandomOrder()->take(5)->get();
    	foreach ($recommended_products as $key => $recommended) {
    		$value=$recommended->Product;
    		$name=strlen($value->name)>30 ? substr($value->name, 0, 30)."..." : $value->name;
            $value->name=ucwords(strtolower($name));
            $value->star=$value->Star();
            if (Auth::check()){
	            $value->final_price=currency_format($value->finalPrice(Auth::user()->customer_group_id,1),'IDR');
	        }else{
	        	$value->final_price=currency_format($value->finalPrice(1,1),'IDR');
	        }
            $value->price_format=currency_format($value->price,'IDR');
            $value->img=$value->Image ? $value->Image->first()->image : 'http://via.placeholder.com/174x111';
    	}
    	return response()->json($recommended_products);
    }

    public function getBlogs()
    {
    	$blogs=Blog::orderBy('created_at', 'desc')->take(3)->get();
    	foreach ($blogs as $key => $value) {
    		$value->title=strlen($value->title)>100 ? substr($value->title, 0, 100)."..." : $value->title;
    		$value->Admin;
    		$start = strpos($value->content, '<p>');
			$end = strpos($value->content, '</p>', $start);
			$paragraph = substr($value->content, $start, $end-$start+4);
			$paragraph = html_entity_decode(strip_tags($paragraph));
			$paragraph = strlen($paragraph)>200 ? substr($paragraph, 0, 200)."..." : $paragraph;
			$value->paragraph=$paragraph;
    	}

    	return response()->json($blogs);
    }
}
