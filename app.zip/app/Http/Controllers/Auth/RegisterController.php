<?php

namespace App\Http\Controllers\Auth;

use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Auth\Events\Registered;
use Carbon\Carbon;
use Mail;
use Auth;

class RegisterController extends Controller
{
    use RegistersUsers;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    protected $redirectTo = '/';

    /**
     * The user has been registered.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  mixed  $user
     * @return mixed
     */
    protected function registeredAPI(Request $request, $user)
    {
        return $user;
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        $data['dob'] = $data['date_of_birth'].'-'.$data['month_of_birth'].'-'.$data['year_of_birth'];
        $current_year          = Carbon::now()->year;
        $hundred_years_ago     = (new Carbon("100 years ago"))->year;
        return Validator::make($data, [
            //'name' => 'required|max:255',
            'firstname' => 'required|max:255',
            'lastname' => 'required|max:255',
            'email' => 'required|email|max:255|unique:users',
            'password' => 'required|min:6|confirmed',
            'phone' => 'required',
            'year_of_birth' => 'required|integer|between:'.$hundred_years_ago.','.$current_year,
            'dob' => 'required|date',
            'gender'=> 'required|in:M,F'  
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data)
    {
        $user = User::create([
            'name' => $data['firstname'].' '.$data['lastname'],
            'firstname' => $data['firstname'],
            'lastname' => $data['lastname'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
            'telephone' => $data['phone'],
            'dob' => Carbon::createFromDate($data['year_of_birth'], $data['month_of_birth'], $data['date_of_birth']),
            'gender' => $data['gender']
        ]);

        if (array_get($data, 'newsletter', false)) {
            // Logic to sign user up to newsletter
            $user->newsletter=1;
            $user->save();
        }
        $user->confirmation_code=str_random(30);
        $user->save();

        return $user;
    }

    protected function guard()
    {
        return Auth::guard();
    }

    public function register(Request $request)
    {
        $this->validator($request->all())->validate();

        event(new Registered($user = $this->create($request->all())));

        $this->guard()->login($user);

        Mail::send('mail.verify', ['user'=>$user], function($message) use ($user) {
                 $message->to($user->email, $user->firstname)
                     ->subject('Satu langkah lagi untuk bergabung dengan Kreasi2shop.');
             });

        // return $this->registered($request, $user)
        //                 ?: redirect($this->redirectPath());
        return redirect('/')->with('success','Kami telah mengirimkan petunjuk untuk melakukan verifikasi ke email anda, mohon cek kotak masuk email anda.');
    }

    public function registerAPI(Request $request)
    {
        $this->validator($request->all())->validate();

        event(new RegisteredAPI($user = $this->create($request->all())));

        $this->guard()->login($user);

        return $this->registeredAPI($request, $user)
                        ?: redirect($this->redirectPath());
    }

}
