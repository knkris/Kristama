<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use Auth;
use Mail;

class SocialAccountController extends Controller
{
    /**
     * Redirect the user to the GitHub authentication page.
     *
     * @return Response
     */
    public function redirectToProvider($provider)
    {
        switch ($provider) {
            case 'facebook':
                return \Socialite::driver($provider)->fields([
                    'first_name', 'last_name', 'email', 'gender'
                ])->scopes([
                    'email', 'user_gender'
                ])->redirect();
                break;
            
            default:
                return \Socialite::driver($provider)->redirect();
                break;
        }
    }

    /**
     * Obtain the user information
     *
     * @return Response
     */
    public function handleProviderCallback(\App\SocialAccountService $accountService, $provider)
    {

        try {
            $user = \Socialite::with($provider)->user();
        } catch (\Exception $e) {
            return redirect('/sign-in');
        }

        $authUser = $accountService->findOrCreate(
            $user,
            $provider
        );

        auth()->login($authUser, true);

        if(auth()->user()->dob==null){
            $user=User::find(Auth::user()->id);
            Mail::send('mail.welcome', ['user'=>$user], function($message) use ($user) {
                 $message->to($user->email, $user->firstname)
                     ->subject('Kreasi2shop Registration information.');
             });
            return redirect()->to('dashboard')->with('warning', 'Please complete your profile!');
        }else{
            return redirect()->to('/');
        }
    }
}
