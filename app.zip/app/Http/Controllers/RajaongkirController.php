<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Province;
use App\Models\City;
use App\Models\Subdistrict;

class RajaongkirController extends Controller
{
    public function updateRajaOngkir()
	{
        ini_set('max_execution_time', 300);
        $newprovince = json_decode($this->getProvince())->rajaongkir->results;
        
        foreach($newprovince as $key=>$value)
        {
            $province=Province::firstOrCreate(
                ['id' => $value->province_id], ['name' => $value->province]
            );
            
            $newcity=json_decode($this->getCity('',$value->province_id))->rajaongkir->results;

            foreach($newcity as $key=>$value)
            {
                $city=City::find($value->city_id);
                if(count($city)==0)
                {
                    $createCity=City::create([
                        'id' => $value->city_id,
                        'province_id' => $value->province_id,
                        'type' => $value->type,
                        'province' => $value->province,
                        'name' => $value->city_name,
                        'postal_code' => $value->postal_code
                    ]);
                }

                $newsubdistrict=json_decode($this->getSubdistrict('',$value->city_id))->rajaongkir->results;

                foreach($newsubdistrict as $key=>$value)
                {
                    $subdistrict=Subdistrict::find($value->city_id);
                    if(count($subdistrict)==0)
                    {
                        $createsubdistrict=Subdistrict::create([
                            'id' => $value->subdistrict_id,
                            'city_id' => $value->city_id,
                            'province_id' => $value->province_id,
                            'type' => $value->type,
                            'province' => $value->province,
                            'city' => $value->city,
                            'name' => $value->subdistrict_name
                        ]);
                    }
                }
            }
        }

        return 'done';
	}

	
}
