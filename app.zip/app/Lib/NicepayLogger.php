<?php
namespace App\Lib;
// error_reporting(E_ALL);
// ini_set("display_errors", 1);
/*
 * ____________________________________________________________
 *
 * Copyright (C) 2016 NICE IT&T
 *
 * Please do not modify this module.
 * This module may used as it is, there is no warranty.
 *
 * @ description : PHP SSL Client module.
 * @ name        : NicepayLite.php
 * @ author      : NICEPAY I&T (tech@nicepay.co.kr)
 * @ date        : 
 * @ modify      : 22.02.2016
 *
 * 2016.02.22 Update Log
 *
 * ____________________________________________________________
 */
use App\Lib\NicepayConfig;
class NicepayLogger extends NicepayConfig{
    public $handle;
    public $type;
    public $log;
    public $debug_mode;
    public $array_key;
    public $debug_msg;
    public $starttime;

    public $NICEPAY_IMID="IONPAYTEST";                                                  // Merchant ID
    public $NICEPAY_MERCHANT_KEY = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A=="; // API Key


    public $NICEPAY_CALLBACK_URL = "http://localhost/nicepay-sdk/result.html";                       // Merchant's result page URL
    public $NICEPAY_DBPROCESS_URL = "http://httpresponder.com/nicepay";          // Merchant's notification handler URL

    /* TIMEOUT - Define as needed (in seconds) */
    public $NICEPAY_TIMEOUT_CONNECT = 15 ;
    public $NICEPAY_TIMEOUT_READ = 25 ;


    // Please do not change

    public $NICEPAY_PROGRAM = "NicepayLite";
    public $NICEPAY_VERSION = "1.11";
    public $NICEPAY_BUILDDATE = "20160309";
    public $NICEPAY_REQ_CC_URL = "https://www.nicepay.co.id/nicepay/api/orderRegist.do";            // Credit Card API URL
    public $NICEPAY_REQ_VA_URL =  "https://www.nicepay.co.id/nicepay/api/onePass.do";                // Request Virtual Account API URL
    public $NICEPAY_CANCEL_VA_URL =  "https://www.nicepay.co.id/nicepay/api/onePassAllCancel.do";       // Cancel Virtual Account API URL
    public $NICEPAY_ORDER_STATUS_URL = "https://www.nicepay.co.id/nicepay/api/onePassStatus.do";          // Check payment status URL

    public $NICEPAY_READ_TIMEOUT_ERR = "10200";

    /* LOG LEVEL */

    public $NICEPAY_LOG_CRITICAL = 1;
    public $NICEPAY_LOG_ERROR = 2;
    public $NICEPAY_LOG_NOTICE = 3;
    public $NICEPAY_LOG_INFO = 5;
    public $NICEPAY_LOG_DEBUG = 7;

    function NicepayLog($log, $mode)
    {
        $this->debug_msg = array( "", "CRITICAL", "ERROR", "NOTICE", "4", "INFO", "6", "DEBUG", "8"  );
        $this->debug_mode = $mode;
        $this->log = $log;
        $this->starttime=GetMicroTime();
    }
    function StartLog($dir, $mid) 
    {
        if( $this->log == "false" ) return true;

        $logfile = $dir. "/logs/".$this->NICEPAY_PROGRAM."_".$this->type."_".$mid."_".date("ymd").".log";
        $this->handle = fopen( $logfile, "a+" );
        if( !$this->handle )
        {
            return false;
        }
        
        $this->WriteLog("START ".$this->NICEPAY_PROGRAM." ".$this->type." (V".$this->NICEPAY_VERSION."B".BUILDDATE."(OS:".php_uname('s').php_uname('r').",PHP:".phpversion()."))" );
        return true;
    }
    function CloseNicepayLog($msg)
    {
        $laptime=$this->GetMicroTime()-$this->starttime;
        $this->WriteLog( "END ".$this->type." ".$msg ." Laptime:[".round($laptime,3)."sec]" );
        $this->WriteLog("===============================================================" );
        fclose( $this->handle );
    }

    function WriteLog($data) 
    {
        if( !$this->handle || $this->log == "false" ) return;
        $pfx = " [" . date("Y-m-d H:i:s") . "] <" . getmypid() . "> ";
        fwrite( $this->handle, $pfx . $data . "\r\n" );
    }
        
    function GetMicroTime()
    {
        list($usec, $sec) = explode(" ", microtime(true));
        return (float)$usec + (float)$sec;
    }
    function SetTimestamp()
    {
        $m = explode(' ',microtime());
        list($totalSeconds, $extraMilliseconds) = array($m[1], (int)round($m[0]*1000,3));
        return date("Y-m-d H:i:s", $totalSeconds) . ":$extraMilliseconds";
    }
    function SetTimestamp1()
    {
        $m = explode(' ',microtime());
        list($totalSeconds, $extraMilliseconds) = array($m[1], (int)round($m[0]*10000,4));
        return date("ymdHis", $totalSeconds) . "$extraMilliseconds";
    }

}