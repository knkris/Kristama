<?php

namespace App\Providers;

use Laravel\Dusk\DuskServiceProvider;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;
use App\Models\Category;
use App\Models\RecommendedProduct;
use App\Models\Blog;
use DOMDocument;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        if ($this->app->runningUnitTests()) {
            Schema::defaultStringLength(191);
        }
        $navbarCat=Category::whereNull('parent_id')->get();
        $recommended_products = RecommendedProduct::whereHas('Product')->inRandomOrder()->take(5)->get();
        $blogs=Blog::orderBy('created_at', 'desc')->take(3)->get();
        view()->share('navbarCat', $navbarCat);
        view()->share('recommended_products', $recommended_products);
        view()->share('blogs', $blogs);

             // For SVG Image
        view()->composer('*', function($view) {
            // Instantiate new DOMDocument object
            $svg = new DOMDocument();

            // Load SVG file from public folder
            $svg->load(asset('images/address-book-regular.svg'));
            // Get XML without version element
            $address_book_image = $svg->saveXML($svg->documentElement);

            // Load SVG file from public folder
            $svg->load(asset('images/order_made.svg'));
            // Get XML without version element
            $order_made = $svg->saveXML($svg->documentElement);

            // Load SVG file from public folder
            $svg->load(asset('images/order_sent.svg'));
            // Get XML without version element
            $order_sent = $svg->saveXML($svg->documentElement);

            // Load SVG file from public folder
            $svg->load(asset('images/order_shipping.svg'));
            // Get XML without version element
            $order_shipping = $svg->saveXML($svg->documentElement);

            // Load SVG file from public folder
            $svg->load(asset('images/order_box.svg'));
            // Get XML without version element
            $order_box = $svg->saveXML($svg->documentElement);

            // Load SVG file from public folder
            $svg->load(asset('images/order_check.svg'));
            // Get XML without version element
            $order_check = $svg->saveXML($svg->documentElement);

            // Attach data to view
            $view->with(['address_book_image'=>$address_book_image, 'order_made'=>$order_made,'order_sent'=>$order_sent, 'order_shipping'=>$order_shipping, 'order_box'=>$order_box, 'order_check'=>$order_check]);
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        if ($this->app->environment('local', 'testing')) {
            $this->app->register(DuskServiceProvider::class);
        }
    }
}
